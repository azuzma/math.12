import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { ButtonLink } from "@/components/ui/buttons";
import { redirect } from "next/navigation";

export default async function DashboardNotFound() {
  const user = await getCurrentUser();
  const home =
    user?.role === "ADMIN" || user?.role === "TEACHER" || user?.role === "OWNER"
      ? "/admin"
      : user
        ? "/dashboard"
        : "/login";

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
      <p className="text-5xl font-bold text-brand-600">404</p>
      <h1 className="mt-4 text-xl font-bold text-ink-900">العنصر غير موجود</h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-ink-600">
        ربما تم حذف هذا العنصر أو لا تملك صلاحية الوصول إليه.
      </p>
      <div className="mt-6 flex gap-3">
        <ButtonLink href={home}>العودة للوحة</ButtonLink>
        <Link href="/" className="btn btn-outline">
          الرئيسية
        </Link>
      </div>
    </div>
  );
}