import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { EmptyState } from "@/components/ui/buttons";
import { DataTable } from "@/components/admin/ui";
import { ScoreBadge } from "@/components/ui/badges";
import { formatDateTime } from "@/lib/utils";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

export const metadata = { title: "نتائجي" };

export default async function ResultsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/results");

  const attempts = await prisma.examAttempt.findMany({
    where: { studentId: user.id, submittedAt: { gte: SUBMITTED_EPOCH } },
    orderBy: { submittedAt: "desc" },
    take: 100,
    include: { exam: { select: { title: true, passingScore: true, unitId: true } } },
  });

  const passed = attempts.filter((a) => a.passed).length;
  const average = attempts.length
    ? Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)
    : 0;
  const best = attempts.length
    ? Math.max(...attempts.map((a) => a.percentage))
    : 0;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">نتائجي</h1>
        <p className="mt-1 text-sm text-ink-600">
          كل محاولاتك في الاختبارات مع مراجعة مفصّلة للإجابات.
        </p>
      </header>

      {attempts.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-4">
          {[
            { label: "إجمالي المحاولات", value: attempts.length },
            { label: "ناجح", value: passed },
            { label: "متوسط الدرجات", value: `${average}%` },
            { label: "أفضل نتيجة", value: `${Math.round(best)}%` },
          ].map((s) => (
            <div key={s.label} className="card p-4">
              <p className="text-2xl font-bold text-ink-900 tabular-nums">
                {s.value}
              </p>
              <p className="text-xs text-ink-500">{s.label}</p>
            </div>
          ))}
        </div>
      ) : null}

      {attempts.length === 0 ? (
        <EmptyState
          title="لم تخض أي اختبار بعد"
          description="ابدأ باختبار قصير على أي درس لترى مستوى تحسّنك."
          action={
            <Link href="/dashboard/exams" className="btn btn-primary">
              اختر اختبارًا
            </Link>
          }
        />
      ) : (
        <div className="card">
          <DataTable headers={["الاختبار", "التاريخ", "الدرجة", "النسبة", "الحالة", ""]}>
            {attempts.map((a) => (
              <tr key={a.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3 font-medium text-ink-900">
                  {a.exam.title}
                  <p className="text-xs text-ink-400">
                    المحاولة {a.attemptNumber} · نجاح من {a.exam.passingScore}%
                  </p>
                </td>
                <td className="px-4 py-3 text-xs text-ink-600">
                  {formatDateTime(a.submittedAt)}
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {a.score} / {a.maxScore}
                </td>
                <td className="px-4 py-3">
                  <ScoreBadge percentage={Math.round(a.percentage)} />
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs font-bold ${
                      a.passed ? "text-emerald-700" : "text-rose-700"
                    }`}
                  >
                    {a.passed ? "ناجح" : "لم تجتز"}
                  </span>
                  {a.needsReview ? (
                    <p className="text-[11px] text-amber-700">بانتظار التصحيح</p>
                  ) : null}
                </td>
                <td className="px-4 py-3">
                  <Link
                    href={`/dashboard/exams/${a.examId}/result/${a.id}`}
                    className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                  >
                    مراجعة
                  </Link>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}