import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import {
  Target,
  TrendingUp,
  TrendingDown,
  ArrowLeft,
  Lock,
  Award,
  BookOpen,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { analyzeStudent } from "@/lib/analysis";
import { ProgressBar, ProgressRing } from "@/components/dashboard/progress-bar";
import { ButtonLink, Alert } from "@/components/ui/buttons";
import { PLATFORM } from "@/lib/platform";
import { getViewerContext } from "@/lib/auth/viewer";
import { ServiceGate } from "@/components/dashboard/service-gate";

export const metadata: Metadata = { title: "مستواي" };

/** أيقونة لكل نوع توصية */
const REC_ICON = {
  REVIEW_LESSON: BookOpen,
  WATCH_VIDEO: BookOpen,
  SOLVE_WORKSHEET: Target,
  PRACTICE_QUESTIONS: TrendingUp,
  TAKE_QUIZ: Award,
  START: BookOpen,
} as const;

export default async function AnalysisPage() {
  const { user, userId, gradeId, ent } = await getViewerContext();

  if (!ent.canSeeAnalysis) {
    return (
      <div className="space-y-6">
        <header>
          <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
            <Target className="h-6 w-6 text-brand-600" />
            مستواي
          </h1>
          <p className="mt-1 text-sm text-ink-600">
            تحليل ذكي لأدائك في {PLATFORM.gradeShort} مع توصيات واضحة.
          </p>
        </header>

        <div className="card grid place-items-center p-10 text-center">
          <Lock className="h-9 w-9 text-ink-400" />
          <h2 className="mt-3 font-bold text-ink-900">
            التحليل الذكي متاح في الباقة المميزة
          </h2>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-600">
            يمنحك التحليل الذكي: نقاط قوتك، المهارات التي تحتاج مراجعة، وخطة
            عملية مرتّبة حسب الأولوية.
          </p>
          <ButtonLink href="/pricing" className="mt-5">
            عرض الباقات
          </ButtonLink>
        </div>
      </div>
    );
  }

  const analysis = userId ? await analyzeStudent(userId) : null;
  const o = analysis?.overall;

  // الزائر يرى وصف الخدمة، والتحليل الشخصي يحتاج حسابًا
  if (!analysis) {
    return (
      <ServiceGate
        section="analysis"
        title="مستواي — التحليل الذكي"
        description="تقرير مبني على أدائك الحقيقي: نسبة الإجابات الصحيحة لكل مهارة، تقييم كل وحدة، نقاط القوة والموضوعات التي تحتاج مراجعة، وتوصيات عملية مرتبطة بالدروس."
        benefits={[
          "نسبة الإجابة الصحيحة لكل مهارة",
          "تقييم مستوى كل وحدة",
          "نقاط القوة ونقاط الضعف",
          "خمس خطوات عملية لكل نقطة ضعف",
          "تحديث تلقائي مع كل محاولة",
          "ربط مباشر بالدروس والأوراق",
        ]}
        actionLabel="سجّل الدخول واعرف مستواك"
      />
    );
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <Target className="h-6 w-6 text-brand-600" />
          مستواي
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          تحليل أدائك في {PLATFORM.gradeNameAr} مبني على نتائج اختباراتك وتدريبك في
          بنك الأسئلة.
        </p>
      </header>

      {/* الملخص */}
      <div className="card p-6">
        <p className="text-sm leading-relaxed text-ink-700">{analysis.headline}</p>

        {o ? (
          <div className="mt-6 flex flex-wrap items-center gap-8">
            <ProgressRing
              percent={o.percentage}
              size={96}
              label="متوسط درجاتك"
              tone="brand"
            />
            <div className="grid flex-1 grid-cols-2 gap-4 sm:grid-cols-4">
              <div>
                <p className="text-xs text-ink-500">المستوى</p>
                <p className={`text-lg font-bold ${o.levelColor}`}>{o.level}</p>
              </div>
              <div>
                <p className="text-xs text-ink-500">محاولات خُضت</p>
                <p className="text-lg font-bold text-ink-900 tabular-nums">
                  {o.attempts}
                </p>
              </div>
              <div>
                <p className="text-xs text-ink-500">ناجح منها</p>
                <p className="text-lg font-bold text-ink-900 tabular-nums">
                  {o.passedCount}
                </p>
              </div>
              <div>
                <p className="text-xs text-ink-500">دروس مكتملة</p>
                <p className="text-lg font-bold text-ink-900 tabular-nums">
                  {o.lessonsCompleted}/{o.lessonsTotal}
                </p>
              </div>
            </div>
          </div>
        ) : null}

        {o ? (
          <div className="mt-6">
            <ProgressBar
              percent={o.curriculumPercent}
              label={`إنجاز المنهج: ${o.curriculumPercent}%`}
              showValue
            />
          </div>
        ) : null}
      </div>

      {/* التوصيات */}
      {analysis.recommendations.length > 0 ? (
        <section className="space-y-3">
          <h2 className="text-base font-bold text-ink-900">
            ماذا تفعل الآن؟ (بالترتيب)
          </h2>
          <ol className="space-y-3">
            {analysis.recommendations.map((r, idx) => {
              const Icon = REC_ICON[r.kind];
              return (
                <li key={`${r.priority}-${idx}`}>
                  <Link
                    href={r.href}
                    className="card flex items-start gap-4 p-4 transition-all hover:border-brand-300 hover:shadow-sm"
                  >
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-700">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-semibold text-ink-900">
                        {idx + 1}. {r.title}
                      </span>
                      <span className="mt-0.5 block text-sm leading-relaxed text-ink-600">
                        {r.reason}
                      </span>
                      <span className="mt-1.5 inline-flex items-center gap-1 text-xs font-semibold text-brand-700">
                        {r.cta}
                        <ArrowLeft className="h-3 w-3" />
                      </span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ol>
        </section>
      ) : null}

      {/* نقاط القوة والضعف */}
      {analysis.strengths.length > 0 || analysis.weaknesses.length > 0 ? (
        <div className="grid gap-4 lg:grid-cols-2">
          {analysis.strengths.length > 0 ? (
            <section className="card p-5">
              <h2 className="mb-3 flex items-center gap-2 font-bold text-emerald-700">
                <TrendingUp className="h-5 w-5" />
                نقاط القوة
              </h2>
              <ul className="space-y-2.5">
                {analysis.strengths.map((s) => (
                  <li key={s.skillId}>
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <span className="min-w-0 truncate text-ink-800">
                        {s.skillTitle}
                      </span>
                      <span className="shrink-0 font-bold text-emerald-700 tabular-nums">
                        {s.accuracy}%
                      </span>
                    </div>
                    <p className="text-xs text-ink-500">
                      {s.unitTitle} · {s.correct}/{s.attempted}
                    </p>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}

          {analysis.weaknesses.length > 0 ? (
            <section className="card p-5">
              <h2 className="mb-3 flex items-center gap-2 font-bold text-rose-700">
                <TrendingDown className="h-5 w-5" />
                يحتاج مراجعة
              </h2>
              <ul className="space-y-2.5">
                {analysis.weaknesses.map((s) => (
                  <li key={s.skillId}>
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <Link
                        href={`/dashboard/question-bank?skill=${s.skillId}`}
                        className="min-w-0 truncate font-medium text-brand-700 hover:underline"
                      >
                        {s.skillTitle}
                      </Link>
                      <span className="shrink-0 font-bold text-rose-700 tabular-nums">
                        {s.accuracy}%
                      </span>
                    </div>
                    <p className="text-xs text-ink-500">
                      {s.unitTitle} · {s.correct}/{s.attempted}
                    </p>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>
      ) : null}

      {/* تحليل الوحدات */}
      {analysis.units.length > 0 ? (
        <section className="space-y-3">
          <h2 className="text-base font-bold text-ink-900">أداؤك في الوحدات</h2>
          <ul className="space-y-3">
            {analysis.units.map((u) => (
              <li key={u.unitId} className="card p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold text-ink-900">{u.unitTitle}</p>
                    <p className="text-xs text-ink-500">
                      {u.termTitle} · دروس {u.lessonsCompleted}/{u.lessonsTotal}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-ink-600">
                    {u.skillAccuracy !== null ? (
                      <span className="font-bold tabular-nums">
                        دقة المهارات {u.skillAccuracy}%
                      </span>
                    ) : null}
                    {u.examAverage !== null ? (
                      <span className="font-bold tabular-nums">
                        الاختبارات {u.examAverage}%
                      </span>
                    ) : null}
                  </div>
                </div>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <ProgressBar
                    percent={u.lessonsTotal ? (u.lessonsCompleted / u.lessonsTotal) * 100 : 0}
                    label="الدروس المكتملة"
                    size="sm"
                  />
                  {u.skillAccuracy !== null ? (
                    <ProgressBar
                      percent={u.skillAccuracy}
                      label="دقة إجاباتك"
                      size="sm"
                      tone={u.skillAccuracy >= 70 ? "green" : "gold"}
                    />
                  ) : null}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Link
                    href={`/dashboard/question-bank?unit=${u.unitId}`}
                    className="text-xs font-semibold text-brand-700 hover:underline"
                  >
                    تدرّب على أسئلة الوحدة
                  </Link>
                  <Link
                    href={`/dashboard/exams?unit=${u.unitId}`}
                    className="text-xs font-semibold text-brand-700 hover:underline"
                  >
                    اختبارات الوحدة
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {!o ? (
        <Alert tone="info" title="لا توجد بيانات كافية بعد">
          خُض اختبارًا واحدًا على الأقل في{" "}
          <Link href="/dashboard/exams" className="font-semibold underline">
            صفحة الاختبارات
          </Link>{" "}
          لتظهر تحليلات مستواك وتوصياتك.
        </Alert>
      ) : null}
    </div>
  );
}