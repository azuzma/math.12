import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { saveProfileAction } from "@/app/actions/profile";
import { AdminForm, SaveButton, AdminSection } from "@/components/admin/ui";
import { TextField, TextareaField } from "@/components/ui/forms";
import { UserStatusBadge } from "@/components/ui/badges";
import { Alert } from "@/components/ui/buttons";
import { formatDateTime } from "@/lib/utils";
import { PLATFORM } from "@/lib/platform";
import { GraduationCap } from "lucide-react";

export const metadata = { title: "حسابي" };

export default async function ProfilePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/profile");

  const [profile, platformGrade, phone] = await Promise.all([
    prisma.studentProfile.findUnique({ where: { userId: user.id } }),
    prisma.grade.findUnique({ where: { slug: PLATFORM.gradeSlug } }),
    prisma.user.findUnique({
      where: { id: user.id },
      select: { phone: true },
    }),
  ]);

  const account = await prisma.user.findUnique({
    where: { id: user.id },
    select: {
      email: true,
      emailVerified: true,
      createdAt: true,
      lastLoginAt: true,
      status: true,
    },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">حسابي</h1>
        <p className="mt-1 text-sm text-ink-600">
          حدّث بياناتك الشخصية وبيانات المدرسة.
        </p>
      </header>

      {!account?.emailVerified ? (
        <Alert tone="warn" title="بريدك غير مؤكد">
          قد لا تستلم إشعارات المنصة. افتح رابط التأكيد الذي أُرسل إلى بريدك، أو
          تواصل مع الإدارة لإعادة الإرسال.
        </Alert>
      ) : null}

      <AdminForm action={saveProfileAction}>
        <input type="hidden" name="_checkboxes" value="" />
        <AdminSection title="البيانات الشخصية">
          <div className="space-y-5">
            <TextField
              label="الاسم الكامل"
              name="fullName"
              defaultValue={user.fullName}
              required
            />
            <TextField
              label="البريد الإلكتروني"
              name="email"
              defaultValue={account?.email}
              disabled
              hint="لا يمكن تغيير البريد. تواصل مع الإدارة إن كنت تحتاج ذلك."
              className="[&>input]:bg-ink-50"
            />
            <TextField
              label="رقم الهاتف"
              name="phone"
              dir="ltr"
              defaultValue={phone?.phone ?? ""}
              className="[&>input]:text-start"
            />
          </div>
        </AdminSection>

        <AdminSection title="المعلومات الدراسية">
          <div className="space-y-5">
            {/* الصف ثابت: المنصة لصف واحد فقط */}
            <input
              type="hidden"
              name="gradeId"
              value={platformGrade?.id ?? ""}
            />
            <div className="flex items-center gap-3 rounded-xl border border-brand-200 bg-brand-50 px-4 py-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
                <GraduationCap className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-bold text-brand-900">
                  {PLATFORM.subjectNameAr} — {PLATFORM.gradeNameAr}
                </p>
                <p className="mt-0.5 text-xs text-brand-700">
                  المنصة مخصصة لهذا الصف فقط، ولا يمكن تغييره.
                </p>
              </div>
            </div>
            <TextField
              label="اسم المدرسة"
              name="schoolName"
              defaultValue={profile?.schoolName ?? ""}
            />
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                label="الإمارة"
                name="emirate"
                defaultValue={profile?.emirate ?? ""}
                placeholder="دبي"
              />
              <TextField
                label="هدف اليوم (دقائق)"
                name="dailyGoalMinutes"
                type="number"
                defaultValue={profile?.dailyGoalMinutes ?? 30}
                min={0}
                max={600}
              />
            </div>
            <TextField
              label="اسم ولي الأمر"
              name="guardianName"
              defaultValue={profile?.guardianName ?? ""}
            />
            <TextField
              label="هاتف ولي الأمر"
              name="guardianPhone"
              dir="ltr"
              defaultValue={profile?.guardianPhone ?? ""}
              className="[&>input]:text-start"
            />
          </div>
        </AdminSection>

        <div>
          <SaveButton label="حفظ التغييرات" />
        </div>
      </AdminForm>

      <section className="card p-5">
        <h2 className="mb-3 text-base font-bold text-ink-900">معلومات الحساب</h2>
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-500">الحالة</dt>
            <dd>
              <UserStatusBadge status={account?.status ?? "ACTIVE"} />
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-500">تاريخ الإنشاء</dt>
            <dd className="text-ink-800">{formatDateTime(account?.createdAt)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-500">آخر تسجيل دخول</dt>
            <dd className="text-ink-800">{formatDateTime(account?.lastLoginAt)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-500">تأكيد البريد</dt>
            <dd className="text-ink-800">
              {account?.emailVerified ? "مؤكد ✓" : "غير مؤكد"}
            </dd>
          </div>
        </dl>
      </section>
    </div>
  );
}