import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { NotebookPen, CheckCircle2, Clock } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { getViewerContext } from "@/lib/auth/viewer";

export const metadata = { title: "الواجبات" };

export default async function AssignmentsPage() {
  const { user, userId, gradeId, ent } = await getViewerContext();

  const assignments = gradeId
    ? await prisma.assignment.findMany({
        where: {
          status: "PUBLISHED",
          lesson: { unit: { course: { subject: { gradeId: gradeId } } } },
        },
        orderBy: { createdAt: "desc" },
        include: {
          lesson: {
            select: {
              slug: true,
              title: true,
              unit: { select: { course: { select: { subject: { select: { nameAr: true } } } } } },
            },
          },
          _count: { select: { questions: true } },
          submissions: {
            where: { studentId: userId ?? "" },
            take: 1,
            select: { id: true, score: true, submittedAt: true },
          },
        },
      })
    : [];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">الواجبات</h1>
        <p className="mt-1 text-sm text-ink-600">
          الواجبات بلا وقت محدد — سلّم في أي وقت. الأسئلة الموضوعية تُصحَّح فورًا.
        </p>
      </header>

      {assignments.length === 0 ? (
        <EmptyState
          title="لا توجد واجبات"
          description="لم يُنشر واجب في صفك بعد."
          icon={<NotebookPen className="h-6 w-6" />}
          action={<ButtonLink href="/dashboard/lessons">تصفح الدروس</ButtonLink>}
        />
      ) : (
        <ul className="space-y-3">
          {assignments.map((a) => {
            const submission = a.submissions[0];
            const deadline = a.dueAfterDays
              ? new Date(a.createdAt.getTime() + a.dueAfterDays * 86400_000)
              : null;
            const overdue =
              deadline && !submission && deadline.getTime() < Date.now();

            return (
              <li key={a.id}>
                <Link
                  href={`/dashboard/assignments/${a.id}`}
                  className="card flex flex-wrap items-center justify-between gap-4 p-5 transition-all hover:border-brand-300 hover:shadow-sm"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-bold text-ink-900">{a.title}</h2>
                      {submission ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                          <CheckCircle2 className="h-3 w-3" />
                          تم التسليم
                        </span>
                      ) : overdue ? (
                        <span className="rounded-full bg-rose-50 px-2 py-0.5 text-[11px] font-semibold text-rose-700">
                          تجاوز الموعد
                        </span>
                      ) : deadline ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-semibold text-amber-700">
                          <Clock className="h-3 w-3" />
                          حتى {formatDate(deadline)}
                        </span>
                      ) : null}
                    </div>

                    <p className="mt-1 text-xs text-ink-500">
                      {a.lesson?.title ?? "واجب عام"} · {a._count.questions} سؤال
                    </p>

                    {a.instructions ? (
                      <p className="mt-1 line-clamp-2 text-xs text-ink-500">
                        {a.instructions}
                      </p>
                    ) : null}

                    {submission ? (
                      <p className="mt-1.5 text-xs font-semibold text-emerald-700">
                        درجتك: {submission.score} —{" "}
                        {formatDate(submission.submittedAt)}
                      </p>
                    ) : null}
                  </div>

                  <span className="shrink-0 rounded-lg bg-brand-50 px-3 py-2 text-xs font-semibold text-brand-700">
                    {submission ? "عرض الإجابة" : "حل الواجب"}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}