import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { gradeSubmission, gradeAnswer } from "@/lib/grading";
import { AssignmentRunner } from "@/components/exams/assignment-runner";
import { ButtonLink, Alert } from "@/components/ui/buttons";
import { formatDateTime } from "@/lib/utils";

export const metadata = { title: "حل واجب" };

export default async function AssignmentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/assignments/[id]");

  const assignment = await prisma.assignment.findFirst({
    where: { id, status: "PUBLISHED" },
    include: {
      lesson: { select: { slug: true, title: true } },
      questions: {
        orderBy: { order: "asc" },
        include: { question: true },
      },
      submissions: {
        where: { studentId: user.id },
        orderBy: { submittedAt: "desc" },
        take: 1,
      },
    },
  });

  if (!assignment) notFound();

  const ent = await getEntitlement(user.id);
  const locked = !assignment.isFree && !ent.canViewPaidContent;

  if (locked) {
    return (
      <div className="space-y-5">
        <Alert tone="warn" title="هذا الواجب متاح للمشتركين">
          فعّل اشتراكك لحل جميع الواجبات.
        </Alert>
        <ButtonLink href="/pricing">عرض الباقات</ButtonLink>
      </div>
    );
  }

  const submission = assignment.submissions[0];

  // عرض بعد التسليم
  if (submission) {
    const answers =
      submission.answers && typeof submission.answers === "object"
        ? (submission.answers as Record<string, unknown>)
        : {};

    const reviewed = assignment.questions.map((eq, i) => {
      const q = eq.question;
      const given = answers[q.id] ?? null;
      const graded = gradeAnswer(q.type, given, q.correct, q.options);
      const options = Array.isArray(q.options)
        ? (q.options as { id: string; text: string }[])
        : [];

      const textOf = (v: unknown) =>
        Array.isArray(v)
          ? v.map((cid) => options.find((o) => o.id === cid)?.text ?? String(cid)).join("، ")
          : options.find((o) => o.id === v)?.text ?? (v ? String(v) : "لم يُجب");

      return {
        index: i,
        text: q.text,
        points: eq.points,
        isCorrect: graded.isCorrect,
        needsReview: graded.needsReview,
        givenText: textOf(given),
        correctText: textOf(q.correct),
        solution: q.solution,
        type: q.type,
      };
    });

    return (
      <div className="mx-auto max-w-3xl space-y-6">
        <Alert
          tone="success"
          title="تم تسليم الواجب"
          action={
            <ButtonLink href="/dashboard/assignments" variant="outline" size="sm">
              كل الواجبات
            </ButtonLink>
          }
        >
          درجتك {submission.score} من {submission.maxScore} —{" "}
          {formatDateTime(submission.submittedAt)}
          {submission.gradedAt ? " (بعد التصحيح اليدوي)" : ""}
        </Alert>

        {submission.feedback ? (
          <div className="card border-brand-200 bg-brand-50 p-5">
            <p className="text-sm font-bold text-brand-900">ملاحظة الأستاذ</p>
            <p className="mt-1 text-sm text-brand-800">{submission.feedback}</p>
          </div>
        ) : null}

        <section className="space-y-4">
          <h2 className="text-base font-bold text-ink-900">مراجعة الإجابات</h2>
          {reviewed.map((r) => (
            <div
              key={r.index}
              className={`card border-s-4 p-5 ${
                r.isCorrect
                  ? "border-s-emerald-500"
                  : r.needsReview
                    ? "border-s-amber-500"
                    : "border-s-rose-500"
              }`}
            >
              <p className="text-xs font-medium text-ink-500">
                سؤال {r.index + 1} · {r.points} درجة
              </p>
              <p className="mt-1.5 leading-loose text-ink-900">{r.text}</p>

              <p className="mt-3 text-sm">
                <span className="font-semibold text-ink-500">إجابتك: </span>
                <span className={r.isCorrect ? "text-emerald-700" : "text-rose-700"}>
                  {r.givenText}
                </span>
              </p>

              {!r.isCorrect && !r.needsReview ? (
                <p className="text-sm">
                  <span className="font-semibold text-ink-500">الصحيحة: </span>
                  <span className="font-semibold text-emerald-700">
                    {r.correctText}
                  </span>
                </p>
              ) : null}

              {r.needsReview ? (
                <p className="text-xs text-amber-700">
                  يُصحّح هذا السؤال يدويًا من الأستاذ.
                </p>
              ) : null}

              {r.solution && ent.canViewSolutions ? (
                <div className="mt-3 rounded-xl border border-brand-100 bg-brand-50 p-3.5">
                  <p className="text-xs font-bold text-brand-800">الحل النموذجي</p>
                  <p className="mt-1 text-sm text-brand-900">{r.solution}</p>
                </div>
              ) : null}
            </div>
          ))}
        </section>
      </div>
    );
  }

  // عرض قبل التسليم
  const questions = assignment.questions.map((eq) => ({
    id: eq.question.id,
    type: eq.question.type,
    text: eq.question.text,
    options: Array.isArray(eq.question.options)
      ? (eq.question.options as { id: string; text: string }[])
      : [],
    points: eq.points,
    hint: eq.question.hint,
  }));

  const totalPoints = assignment.questions.reduce((s, q) => s + q.points, 0);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">
          {assignment.title}
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          {assignment.lesson?.title ?? "واجب عام"} · {questions.length} سؤال ·{" "}
          {totalPoints} درجة
        </p>
      </header>

      {assignment.instructions ? (
        <div className="rounded-xl border border-brand-100 bg-brand-50 p-4">
          <p className="text-sm font-semibold text-brand-900">تعليمات</p>
          <p className="mt-1 text-sm leading-relaxed text-brand-800">
            {assignment.instructions}
          </p>
        </div>
      ) : null}

      <AssignmentRunner
        assignmentId={assignment.id}
        questions={questions}
        totalPoints={totalPoints}
      />
    </div>
  );
}