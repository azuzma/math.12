import type { Metadata } from "next";
import Link from "next/link";
import { MessagesSquare, Lock, ArrowLeft, Sparkles } from "lucide-react";
import { getViewerContext } from "@/lib/auth/viewer";
import { PLATFORM } from "@/lib/platform";
import { TutorChat } from "./tutor-chat";
import { ServiceGate } from "@/components/dashboard/service-gate";

export const metadata: Metadata = { title: "مساعد الرياضيات" };

const EXAMPLES = [
  { q: "كيف أجد مشتقة الدالة f(x) = 3x² − 5x + 2؟", tag: "المشتقة" },
  { q: "اشرح لي التكامل بخطوات بسيطة.", tag: "التكامل" },
  { q: "ما معنى النهاية عندما يقترب س من 2؟", tag: "النهاية" },
  { q: "كيف أعرف الحد النوني للمتتالية؟", tag: "المتتاليات" },
];

export default async function TutorPage() {
  const { user, userId, ent } = await getViewerContext();

  // الزائر: يرى الخدمة كاملة (أمثلة وأسئلة مقترحة) — والمحادثة تحتاج حسابًا
  if (!user) {
    return (
      <ServiceGate
        section="tutor"
        title="مساعد الرياضيات"
        description={`مساعد متخصص في ${PLATFORM.gradeNameAr}. عند سؤالك يشرح الفكرة، يحدّد القانون المناسب، يخطّط الحل خطوة بخطوة، ثم يختبر فهمك بسؤال متابعة — ولا يعطيك الإجابة النهائية.`}
        benefits={[
          "شرح الفكرة بلغة الطالب",
          "تحديد القانون أو القاعدة",
          "خطوات مرقّمة للحل",
          "مثال مشابه بعد الحل",
          "سؤال متابعة للتقويم",
          "روابط للمنهج المرتبط",
        ]}
        actionLabel="سجّل الدخول وابدأ المحادثة"
      >
        <section className="card p-6">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <Sparkles className="h-4.5 w-4.5 text-brand-600" />
            أمثلة على أسئلة يطرحها المساعد
          </h2>

          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {EXAMPLES.map((ex) => (
              <li
                key={ex.q}
                className="rounded-xl border border-ink-200 bg-ink-50/60 p-4"
              >
                <p className="text-sm font-medium text-ink-800">{ex.q}</p>
                <span className="mt-2 inline-block rounded-full bg-white px-2.5 py-1 text-[11px] font-semibold text-brand-700 ring-1 ring-brand-100">
                  {ex.tag}
                </span>
              </li>
            ))}
          </ul>

          <div className="mt-6 rounded-xl border border-dashed border-ink-300 bg-white p-6 text-center">
            <Lock className="mx-auto h-7 w-7 text-ink-400" />
            <h3 className="mt-2 font-bold text-ink-900">
              لبدء المحادثة سجّل دخولك
            </h3>
            <p className="mx-auto mt-1.5 max-w-md text-sm text-ink-600">
              المحادثة تُحفظ في حسابك، فتتابع من حيث توقفت وتعود للشرح وقتما شئت.
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <Link href="/login?next=/dashboard/tutor" className="btn btn-primary">
                تسجيل الدخول
                <ArrowLeft className="h-4 w-4" />
              </Link>
              <Link href="/register" className="btn btn-outline">
                حساب مجاني
              </Link>
            </div>
          </div>
        </section>
      </ServiceGate>
    );
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <MessagesSquare className="h-6 w-6 text-brand-600" />
          مساعد الرياضيات
        </h1>
        <p className="mt-1 text-sm leading-relaxed text-ink-600">
          مساعد متخصص في {PLATFORM.gradeNameAr}. عند سؤالك يشرح الفكرة، يحدّد
          القانون، يشرح الخطوات، يعطي مثالًا مشابهًا، ثم يختبر فهمك — ولا يعطيك
          الإجابة النهائية مباشرة.
        </p>
      </header>

      <TutorChat locked={!ent.canUseTutor} />
    </div>
  );
}
