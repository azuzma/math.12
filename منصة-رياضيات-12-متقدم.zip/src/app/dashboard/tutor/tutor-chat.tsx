"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  Send,
  MessagesSquare,
  Loader2,
  Trash2,
  GraduationCap,
  Sparkles,
} from "lucide-react";

type Msg = {
  id: string;
  role: "USER" | "ASSISTANT" | "SYSTEM";
  text: string;
};

type TutorResponse = {
  understood: string;
  topic: string;
  law: string;
  idea: string;
  steps: { n: number; title: string; detail: string }[];
  example: { question: string; solution: string };
  check: { question: string; hint: string };
  related: { title: string; href: string }[];
  needsClarification?: string;
};

const EXAMPLES = [
  "أوجد مشتقة f(x) = (2x + 1)⁵",
  "احسب ∫ من 1 إلى 3 لـ (2x + 1) dx",
  "أوجد الحد العاشر في متتالية حسابية a₁ = 5 و d = 3",
  "أوجد cos θ إذا كان sin θ = 3/5",
  "ما هو الحد المتسلسل لمتتالية هندسية؟",
];

/** يحوّل رد المساعد إلى HTML آمن (نتحقق من النص على الخادم دائمًا) */
function TutorReply({
  r,
}: {
  r: TutorResponse;
}) {
  return (
    <div className="space-y-4">
      <div className="rounded-lg bg-brand-50 px-4 py-3">
        <p className="text-xs font-bold text-brand-800">{r.topic}</p>
        <p className="mt-1 text-sm text-brand-900">{r.understood}</p>
      </div>

      <section>
        <h4 className="text-sm font-bold text-ink-900">الفكرة</h4>
        <p className="mt-1 text-sm leading-relaxed whitespace-pre-line text-ink-700">
          {r.idea}
        </p>
      </section>

      <section>
        <h4 className="text-sm font-bold text-ink-900">القانون / القاعدة</h4>
        <p
          dir="auto"
          className="mt-1 rounded-lg bg-ink-50 px-3 py-2 text-sm leading-relaxed text-ink-800"
        >
          {r.law}
        </p>
      </section>

      {r.steps.length > 0 ? (
        <section>
          <h4 className="text-sm font-bold text-ink-900">الخطوات</h4>
          <ol className="mt-2 space-y-2.5">
            {r.steps.map((s) => (
              <li key={s.n} className="flex gap-3">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-brand-600 text-[11px] font-bold text-white">
                  {s.n}
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold text-ink-900">
                    {s.title}
                  </span>
                  <span className="block text-sm leading-relaxed text-ink-700">
                    {s.detail}
                  </span>
                </span>
              </li>
            ))}
          </ol>
        </section>
      ) : null}

      <section>
        <h4 className="text-sm font-bold text-ink-900">مثال مشابه</h4>
        <p className="mt-1 text-sm font-medium text-ink-900">{r.example.question}</p>
        <p className="mt-1 rounded-lg bg-ink-50 px-3 py-2 text-sm leading-relaxed whitespace-pre-line text-ink-700">
          {r.example.solution}
        </p>
      </section>

      <section className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3">
        <h4 className="text-sm font-bold text-emerald-900">
          لنجرّب نفسي — اختبر فهمك
        </h4>
        <p className="mt-1 text-sm text-emerald-900">{r.check.question}</p>
        {r.check.hint ? (
          <p className="mt-1.5 text-xs text-emerald-700">
            <strong>تلميح:</strong> {r.check.hint}
          </p>
        ) : null}
      </section>

      {r.needsClarification ? (
        <p className="rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <strong>تنبيه:</strong> {r.needsClarification}
        </p>
      ) : null}

      {r.related.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {r.related.map((rel) => (
            <Link
              key={rel.href + rel.title}
              href={rel.href}
              className="rounded-full border border-ink-200 px-3 py-1 text-xs font-medium text-ink-700 hover:border-brand-300 hover:text-brand-700"
            >
              {rel.title}
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function TutorChat({ locked }: { locked: boolean }) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [responses, setResponses] = useState<Record<string, TutorResponse>>({});
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const seq = useRef(0);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, sending]);

  if (locked) {
    return (
      <div className="card grid place-items-center p-10 text-center">
        <GraduationCap className="h-9 w-9 text-ink-400" />
        <h2 className="mt-3 font-bold text-ink-900">
          مساعد الرياضيات متاح في الباقة المميزة
        </h2>
        <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-600">
          المساعد يشرح الفكرة، يحدّد القانون، يشرح الخطوات، يعطي مثالًا مشابهًا،
          ثم يختبر فهمك — بدون إعطائك الإجابة النهائية.
        </p>
        <Link href="/pricing" className="btn btn-primary mt-5">
          عرض الباقات
        </Link>
      </div>
    );
  }

  async function send(text: string) {
    const q = text.trim();
    if (!q || sending) return;

    const userId = `u-${++seq.current}`;
    setMessages((m) => [...m, { id: userId, role: "USER", text: q }]);
    setInput("");
    setSending(true);

    try {
      const res = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: q,
          conversationId: conversationId ?? undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessages((m) => [
          ...m,
          {
            id: `a-${++seq.current}`,
            role: "ASSISTANT",
            text: data.error ?? "تعذّر الحصول على رد. حاول مرة أخرى.",
          },
        ]);
        return;
      }
      setConversationId(data.conversationId ?? null);
      const replyId = `a-${++seq.current}`;
      setResponses((r) => ({ ...r, [replyId]: data.response as TutorResponse }));
      setMessages((m) => [...m, { id: replyId, role: "ASSISTANT", text: "" }]);
    } catch {
      setMessages((m) => [
        ...m,
        {
          id: `a-${++seq.current}`,
          role: "ASSISTANT",
          text: "تعذّر الاتصال بالخادم. تحقق من اتصالك وحاول مجددًا.",
        },
      ]);
    } finally {
      setSending(false);
    }
  }

  function reset() {
    setMessages([]);
    setResponses({});
    setConversationId(null);
    void fetch("/api/tutor", { method: "DELETE" }).catch(() => undefined);
  }

  return (
    <div className="space-y-4">
      {/* بطاقات أمثلة */}
      {messages.length === 0 ? (
        <div className="card p-5">
          <h2 className="flex items-center gap-2 font-bold text-ink-900">
            <Sparkles className="h-5 w-5 text-brand-600" />
            جرّب أحد هذه الأمثلة
          </h2>
          <ul className="mt-3 space-y-2">
            {EXAMPLES.map((ex) => (
              <li key={ex}>
                <button
                  onClick={() => send(ex)}
                  className="w-full rounded-lg border border-ink-200 px-4 py-2.5 text-start text-sm text-ink-700 transition-colors hover:border-brand-300 hover:bg-ink-50"
                >
                  {ex}
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {/* المحادثة */}
      <div className="space-y-4">
        {messages.map((m) =>
          m.role === "USER" ? (
            <div key={m.id} className="flex justify-start">
              <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-brand-600 px-4 py-2.5 text-sm leading-relaxed text-white">
                {m.text}
              </div>
            </div>
          ) : (
            <div key={m.id} className="flex justify-end">
              <div className="w-full max-w-[95%] rounded-2xl rounded-tl-sm border border-ink-200 bg-white p-5">
                {responses[m.id] ? (
                  <TutorReply r={responses[m.id]!} />
                ) : sending && m.text === "" ? (
                  <div className="flex items-center gap-2 text-sm text-ink-500">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    يكتب شرحًا…
                  </div>
                ) : (
                  <p className="text-sm leading-relaxed whitespace-pre-line text-ink-700">
                    {m.text}
                  </p>
                )}
              </div>
            </div>
          ),
        )}
        <div ref={endRef} />
      </div>

      {/* شريط الإدخال */}
      <div className="sticky bottom-4 rounded-xl border border-ink-200 bg-white/95 p-3 shadow-lg backdrop-blur">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send(input);
          }}
          className="flex items-end gap-2"
        >
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send(input);
              }
            }}
            rows={2}
            placeholder="اكتب مسألتك… مثال: أوجد مشتقة f(x) = x³ − 4x + 2"
            dir="auto"
            className="input flex-1 resize-none"
          />
          <div className="flex flex-col gap-2">
            <button
              type="submit"
              disabled={sending || input.trim().length === 0}
              className="btn btn-primary h-10"
              aria-label="إرسال"
            >
              {sending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
            {messages.length > 0 ? (
              <button
                type="button"
                onClick={reset}
                className="btn btn-ghost h-10 px-2.5"
                aria-label="محادثة جديدة"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            ) : null}
          </div>
        </form>
        <p className="mt-2 flex items-center gap-1 text-[11px] text-ink-400">
          <MessagesSquare className="h-3 w-3" />
          المساعد يشرح ولا يعطي الإجابة النهائية — اكتب الحل بنفسك ثم قارن.
        </p>
      </div>
    </div>
  );
}