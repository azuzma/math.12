import { redirect } from "next/navigation";
import Link from "next/link";
import {
  BookOpen,
  ClipboardCheck,
  Trophy,
  CreditCard,
  ArrowLeft,
  PlayCircle,
  Clock,
  CheckCircle2,
  TrendingUp,
  Brain,
  Target,
  ClipboardList,
  MessagesSquare,
  FileText,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { getStudentStats } from "@/lib/content";
import { StatCard, Alert, EmptyState, ButtonLink } from "@/components/ui/buttons";
import { ScoreBadge, AccessBadge } from "@/components/ui/badges";
import { ProgressBar } from "@/components/dashboard/progress-bar";
import { formatDate, formatDuration } from "@/lib/utils";
import { PLATFORM } from "@/lib/platform";
import { ServiceGate } from "@/components/dashboard/service-gate";

/** مسار التعلم: شرح ← تدريب ← اختبار → تحليل ← مراجعة ← إتقان */
const LEARNING_LOOP = [
  { label: "شرح", hint: "شاهد الدروس", href: "/dashboard/lessons" },
  { label: "تدريب", hint: "أوراق العمل", href: "/dashboard/worksheets" },
  { label: "اختبار", href: "/dashboard/exams", hint: "خُض اختبارًا" },
  { label: "تدريب مباشر", href: "/dashboard/question-bank", hint: "بنك الأسئلة" },
  { label: "تحليل", href: "/dashboard/analysis", hint: "اعرف مستواك" },
  { label: "مراجعة", href: "/dashboard/study-plan", hint: "خطة الدراسة" },
] as const;

export const metadata = { title: "لوحة الطالب" };

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ welcome?: string; denied?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <ServiceGate
        section="lessons"
        title="لوحة الطالب"
        description="لوحة واحدة تجمع دروسك وتقدّمك وبنك الأسئلة والاختبارات والتحليل الذكي وخطة الدراسة ومساعد الرياضيات — كلها في مكان واحد."
        benefits={[
          "تابع من حيث توقفت",
          "نسبة إنجاز لكل وحدة",
          "تحليل ذكي لمستواك",
          "خطة دراسة أسبوعية",
          "بنك أسئلة لكل مهارة",
          "اختبارات بتصحيح فوري",
        ]}
        actionLabel="سجّل الدخول وابدأ رحلتك"
      >
        <section className="card p-6">
          <h2 className="text-base font-bold text-ink-900">
            مسار التعلّم في المنصة
          </h2>
          <ol className="mt-4 grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {LEARNING_LOOP.map((s) => (
              <li
                key={s.href}
                className="rounded-xl border border-ink-200 p-3 text-center"
              >
                <span className="block text-sm font-bold text-brand-700">
                  {s.label}
                </span>
                <span className="mt-0.5 block text-xs text-ink-500">{s.hint}</span>
              </li>
            ))}
          </ol>
        </section>
      </ServiceGate>
    );
  }

  const { welcome, denied } = await searchParams;
  const gradeId = user.gradeId;

  const [ent, stats] = await Promise.all([
    getEntitlement(user.id),
    getStudentStats(user.id),
  ]);

  const [
    recentProgress,
    recentAttempts,
    availableLessons,
    upcomingExams,
  ] = await Promise.all([
    prisma.lessonProgress.findMany({
      where: {
        studentId: user.id,
        lastViewedAt: { gte: new Date(Date.now() - 30 * 86400_000) },
      },
      orderBy: { lastViewedAt: "desc" },
      take: 5,
      include: {
        lesson: {
          include: { unit: { include: { course: { include: { subject: true } } } } },
        },
      },
    }),
    prisma.examAttempt.findMany({
      where: { studentId: user.id, submittedAt: { gte: new Date("2000-01-01") } },
      orderBy: { submittedAt: "desc" },
      take: 5,
      include: { exam: { select: { title: true, id: true } } },
    }),
    gradeId
      ? prisma.lesson.findMany({
          where: {
            status: "PUBLISHED",
            unit: { course: { subject: { gradeId } } },
          },
          orderBy: { updatedAt: "desc" },
          take: 4,
          include: {
            unit: { select: { title: true } },
            _count: { select: { videos: true, files: true, exams: true } },
          },
        })
      : Promise.resolve([]),
    gradeId
      ? prisma.exam.findMany({
          where: {
            status: "PUBLISHED",
            OR: [
              { unit: { course: { subject: { gradeId } } } },
              { term: { course: { subject: { gradeId } } } },
              { course: { subject: { gradeId } } },
            ],
          },
          orderBy: { createdAt: "desc" },
          take: 3,
          include: { _count: { select: { questions: true } } },
        })
      : Promise.resolve([]),
  ]);

  const daysLeft = ent.expiresAt
    ? Math.ceil((ent.expiresAt.getTime() - Date.now()) / 86400_000)
    : null;

  return (
    <div className="space-y-6">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-bl from-brand-700 via-brand-600 to-brand-800 p-6 text-white">
        <p className="text-sm text-white/80">
          أهلًا {user.fullName.split(" ")[0]} 👋
        </p>
        <h1 className="mt-1 text-xl font-bold sm:text-2xl">
          {PLATFORM.subjectNameAr} — {PLATFORM.gradeNameAr}
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/85">
          {PLATFORM.tagline}
        </p>

        {/* مسار الإتقان */}
        <ol className="mt-5 grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
          {LEARNING_LOOP.map((step, i) => (
            <li
              key={step.label}
              className="rounded-xl bg-white/10 px-3 py-2.5 backdrop-blur"
            >
              <span className="grid h-6 w-6 place-items-center rounded-lg bg-white/20 text-xs font-bold">
                {i + 1}
              </span>
              <span className="mt-1 block text-xs font-semibold">{step.label}</span>
              <Link
                href={step.href}
                className="mt-0.5 block text-[11px] text-white/70 hover:text-white hover:underline"
              >
                {step.hint}
              </Link>
            </li>
          ))}
        </ol>
      </div>

      {welcome ? (
        <Alert tone="success" title="تم إنشاء حسابك بنجاح">
          أرسلنا رسالة تأكيد إلى بريدك. ابدأ الآن بدروس صفك المجانية.
        </Alert>
      ) : null}

      {denied ? (
        <Alert tone="warn" title="لا تملك صلاحية للوصول">
          هذه الصفحة مخصصة للإدارة. يمكنك متابعة دروسك من لوحة الطالب.
        </Alert>
      ) : null}

      {!gradeId ? (
        <Alert
          tone="warn"
          title="لم يتم تحديد صفك الدراسي"
          action={
            <ButtonLink href="/dashboard/profile" size="sm">
              تحديد الصف
            </ButtonLink>
          }
        >
          اختر صفك لتظهر لك دروسه واختباراته.
        </Alert>
      ) : null}

      {!ent.isPaid ? (
        <Alert
          tone="info"
          title="أنت على الباقة المجانية"
          action={
            <ButtonLink href="/pricing" size="sm">
              عرض الباقات
            </ButtonLink>
          }
        >
          اشترك الآن لفتح جميع الدروس والاختبارات والحلول النموذجية لصفك بالكامل.
        </Alert>
      ) : null}

      {daysLeft !== null && daysLeft <= 7 ? (
        <Alert
          tone="warn"
          title={`اشتراكك ينتهي خلال ${daysLeft} يوم`}
          action={
            <ButtonLink href="/dashboard/subscription" size="sm">
              تجديد
            </ButtonLink>
          }
        >
          جدّد اشتراكك قبل {formatDate(ent.expiresAt)} حتى لا تفقد الوصول.
        </Alert>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="نسبة الإنجاز"
          value={`${stats.progressPercent}%`}
          hint={`${stats.completedLessons} من ${stats.totalLessons} درس`}
          icon={<TrendingUp className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="اختبارات منجزة"
          value={stats.examsTaken}
          hint={
            stats.examsTaken > 0 ? `متوسط ${stats.averageScore}%` : "لم تبدأ بعد"
          }
          icon={<ClipboardCheck className="h-5 w-5" />}
          tone="green"
        />
        <StatCard
          label="الدروس المكتملة"
          value={stats.completedLessons}
          hint={`إجمالي ${stats.totalLessons} درس في صفك`}
          icon={<Trophy className="h-5 w-5" />}
          tone="amber"
        />
        <StatCard
          label="الباقة الحالية"
          value={ent.planName}
          hint={ent.expiresAt ? `تنتهي ${formatDate(ent.expiresAt)}` : "دائم — مجاني"}
          icon={<CreditCard className="h-5 w-5" />}
          tone="ink"
        />
      </div>

      <section className="card p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <Trophy className="h-5 w-5 text-gold-500" />
            تقدمك في {user.gradeNameAr ?? "صفك"}
          </h2>
          <span className="text-sm font-bold text-brand-700 tabular-nums">
            {stats.progressPercent}%
          </span>
        </div>

        <div className="mt-4">
          <ProgressBar
            percent={stats.progressPercent}
            label={`أكملت ${stats.completedLessons} من ${stats.totalLessons} درس`}
          />
        </div>

        {stats.totalLessons === 0 ? (
          <p className="mt-4 text-sm text-ink-500">
            لم يتم نشر دروس في صفك بعد. تابع الإشعارات — عند نشر الأستاذ درسًا جديدًا
            سيصلك إشعار.
          </p>
        ) : null}
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-6">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <PlayCircle className="h-5 w-5 text-brand-600" />
              آخر دروس شاهدتها
            </h2>
            <Link
              href="/dashboard/lessons"
              className="text-xs font-semibold text-brand-700 hover:underline"
            >
              كل الدروس
            </Link>
          </div>

          {recentProgress.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center">
              <p className="text-sm text-ink-500">لم تبدأ أي درس بعد.</p>
              <ButtonLink
                href="/dashboard/lessons"
                variant="soft"
                size="sm"
                className="mt-3"
              >
                ابدأ أول درس
              </ButtonLink>
            </div>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {recentProgress.map((p) => (
                <li key={p.id}>
                  <Link
                    href={`/dashboard/lessons/${p.lesson.slug}`}
                    className="flex items-center gap-3 rounded-xl border border-ink-200 p-3 transition-colors hover:border-brand-300 hover:bg-brand-50/40"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink-900">
                        {p.lesson.title}
                      </p>
                      <p className="truncate text-xs text-ink-500">
                        {p.lesson.unit.course.subject.nameAr} · {p.lesson.unit.title}
                      </p>
                    </div>
                    {p.completed ? (
                      <span className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-emerald-600">
                        <CheckCircle2 className="h-4 w-4" />
                        مكتمل
                      </span>
                    ) : (
                      <span className="shrink-0 text-xs font-semibold text-brand-700 tabular-nums">
                        {Math.round(p.watchPercent)}%
                      </span>
                    )}
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card p-6">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <ClipboardCheck className="h-5 w-5 text-emerald-600" />
              آخر النتائج
            </h2>
            <Link
              href="/dashboard/results"
              className="text-xs font-semibold text-brand-700 hover:underline"
            >
              كل النتائج
            </Link>
          </div>

          {recentAttempts.length === 0 ? (
            <div className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center">
              <p className="text-sm text-ink-500">لم تخض أي اختبار بعد.</p>
              <ButtonLink
                href="/dashboard/exams"
                variant="soft"
                size="sm"
                className="mt-3"
              >
                اختر اختبارًا
              </ButtonLink>
            </div>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {recentAttempts.map((a) => (
                <li key={a.id}>
                  <Link
                    href={`/dashboard/exams/${a.examId}/result/${a.id}`}
                    className="flex items-center gap-3 rounded-xl border border-ink-200 p-3 transition-colors hover:border-brand-300"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-ink-900">
                        {a.exam.title}
                      </p>
                      <p className="text-xs text-ink-500">
                        {formatDate(a.submittedAt)} · {a.score} / {a.maxScore}
                      </p>
                    </div>
                    <ScoreBadge percentage={Math.round(a.percentage)} />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="card p-6">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <BookOpen className="h-5 w-5 text-brand-600" />
            دروس مقترحة لك
          </h2>
          <Link
            href="/dashboard/lessons"
            className="text-xs font-semibold text-brand-700 hover:underline"
          >
            تصفّح الكل
          </Link>
        </div>

        {availableLessons.length === 0 ? (
          <EmptyState
            title="لا توجد دروس متاحة في صفك"
            description="تأكد من اختيار صفك الصحيح من صفحة حسابي، أو انتظر نشر دروس جديدة."
            className="mt-4"
          />
        ) : (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {availableLessons.map((lesson) => (
              <Link
                key={lesson.id}
                href={`/dashboard/lessons/${lesson.slug}`}
                className="group rounded-xl border border-ink-200 p-4 transition-all hover:border-brand-300 hover:bg-brand-50/40"
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-semibold text-ink-900 group-hover:text-brand-700">
                    {lesson.title}
                  </p>
                  <ArrowLeft className="mt-0.5 h-4 w-4 shrink-0 text-ink-300 group-hover:text-brand-600" />
                </div>
                <p className="mt-1 truncate text-xs text-ink-500">{lesson.unit.title}</p>
                <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs text-ink-500">
                  <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
                  {lesson.durationSec ? (
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatDuration(lesson.durationSec)}
                    </span>
                  ) : null}
                  {lesson._count.exams > 0 ? (
                    <span className="inline-flex items-center gap-1">
                      <ClipboardCheck className="h-3 w-3" />
                      {lesson._count.exams}
                    </span>
                  ) : null}
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* روابط سريعة للميزات الجديدة */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <QuickLink
          href="/dashboard/question-bank"
          icon={<Brain className="h-5 w-5" />}
          title="بنك الأسئلة"
          desc="تدرّب على أسئلة كل مهارة مع تصحيح فوري"
          locked={!ent.canUseQuestionBank}
        />
        <QuickLink
          href="/dashboard/analysis"
          icon={<Target className="h-5 w-5" />}
          title="مستواي"
          desc="تحليل أدائك ونقاط قوتك وما يحتاج مراجعة"
          locked={!ent.canSeeAnalysis}
        />
        <QuickLink
          href="/dashboard/study-plan"
          icon={<ClipboardList className="h-5 w-5" />}
          title="خطة الدراسة"
          desc="خطة أسبوعية مبنية على ما أنجزته"
          locked={!ent.canSeeStudyPlan}
        />
        <QuickLink
          href="/dashboard/tutor"
          icon={<MessagesSquare className="h-5 w-5" />}
          title="مساعد الرياضيات"
          desc="اشرح الفكرة والقانون والخطوات دون إجابة نهائية"
          locked={!ent.canUseTutor}
        />
        <QuickLink
          href="/dashboard/worksheets"
          icon={<FileText className="h-5 w-5" />}
          title="أوراق العمل"
          desc="تمارين وملخصات قابلة للتنزيل والطباعة"
          locked={!ent.canDownloadAllFiles}
        />
        <QuickLink
          href="/dashboard/exams?type=MOCK"
          icon={<ClipboardCheck className="h-5 w-5" />}
          title="اختبارات تجريبية"
          desc="محاكاة امتحان نهاية الفصل بكامل المنهج"
          locked={!ent.canTakeExams}
        />
      </section>

      {upcomingExams.length > 0 ? (
        <section className="card p-6">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <ClipboardCheck className="h-5 w-5 text-brand-600" />
            اختبارات يمكنك خوضها الآن
          </h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {upcomingExams.map((exam) => (
              <Link
                key={exam.id}
                href={`/dashboard/exams/${exam.id}`}
                className="rounded-xl border border-ink-200 p-4 transition-colors hover:border-brand-300"
              >
                <p className="text-sm font-semibold text-ink-900">{exam.title}</p>
                <p className="mt-1 text-xs text-ink-500">
                  {exam._count.questions} سؤال · {exam.durationMinutes} دقيقة
                </p>
                <span className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-brand-700">
                  ابدأ الآن
                  <ArrowLeft className="h-3 w-3" />
                </span>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

/** رابط سريع لميزة من/features المنصة. */
function QuickLink({
  href,
  icon,
  title,
  desc,
  locked,
}: {
  href: string;
  icon: React.ReactNode;
  title: string;
  desc: string;
  locked: boolean;
}) {
  return (
    <Link
      href={locked ? "/pricing" : href}
      className="card flex items-start gap-3 p-4 transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-sm"
    >
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-700">
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2 font-semibold text-ink-900">
          {title}
          {locked ? (
            <span className="rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-medium text-ink-500">
              مميزة
            </span>
          ) : null}
        </span>
        <span className="mt-0.5 block text-xs leading-relaxed text-ink-600">
          {desc}
        </span>
      </span>
    </Link>
  );
}
