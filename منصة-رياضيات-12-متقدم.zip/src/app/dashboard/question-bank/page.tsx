import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { Brain, Lock, ArrowLeft } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { getBankFilterOptions, getDifficultyCounts } from "@/lib/question-bank";
import { PLATFORM } from "@/lib/platform";
import { ButtonLink, Alert } from "@/components/ui/buttons";
import { QuestionBankTrainer } from "./bank-trainer";
import { BankFilters } from "./bank-filters";
import { ServiceGate } from "@/components/dashboard/service-gate";

export const metadata: Metadata = { title: "بنك الأسئلة" };

export default async function QuestionBankPage({
  searchParams,
}: {
  searchParams: Promise<{
    term?: string;
    unit?: string;
    skill?: string;
    difficulty?: string;
  }>;
}) {
  const user = await getCurrentUser();
  const sp = await searchParams;

  const [options, counts] = await Promise.all([
    getBankFilterOptions(),
    getDifficultyCounts(),
  ]);

  const activeSkill = options.skills.find((s) => s.id === sp.skill);
  const activeUnit = options.units.find((u) => u.id === sp.unit);
  const total = [...counts.values()].reduce((s, n) => s + n, 0);

  const countMap: Record<string, number> = {};
  for (const [k, v] of counts) countMap[k] = v;

  // الزائر يرى الخدمة كاملة (الفلاتر والمحتوى) — والتسجيل مطلوب للتنفيذ
  if (!user) {
    return (
      <ServiceGate
        section="bank"
        title="بنك الأسئلة"
        description={`أسئلة ${PLATFORM.gradeNameAr} مصنّفة بالفصل والوحدة والمهارة ومستوى الصعوبة — ${total} سؤال في البنك، والتصحيح فوري بعد الإرسال.`}
        benefits={[
          "أسئلة مصنّفة بالوحدة والمهارة",
          "أربعة مستويات صعوبة",
          "تصحيح فوري وشرح للخطأ",
          "الحل النموذجي لكل سؤال",
          "جلسة سريعة 10 أسئلة",
          "تتبّع ما أخطأت فيه",
        ]}
        actionLabel="سجّل الدخول وابدأ التدريب"
      >
        <BankFilters
          terms={options.terms}
          units={options.units}
          skills={options.skills}
          current={{
            term: sp.term,
            unit: sp.unit,
            skill: sp.skill,
            difficulty: sp.difficulty,
          }}
          counts={countMap}
        />

        <div className="card p-8 text-center">
          <Lock className="mx-auto h-8 w-8 text-ink-400" />
          <h2 className="mt-3 font-bold text-ink-900">
            التدريب الفعلي يحتاج حسابًا
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-ink-600">
            اختر الوحدة أو المهارة من الأعلى لتعرف ما تتدرّب عليه، ثم سجّل دخولك
            المجاني لتبدأ الحل مباشرة.
          </p>
          <Link
            href="/login?next=/dashboard/question-bank"
            className="btn btn-primary mt-5"
          >
            تسجيل الدخول
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>

        {!activeUnit && options.units.length > 0 ? (
          <section className="space-y-3">
            <h2 className="text-base font-bold text-ink-900">
              تدرّب على وحدة محددة
            </h2>
            <ul className="grid gap-3 sm:grid-cols-2">
              {options.units.map((u) => (
                <li key={u.id}>
                  <Link
                    href={`/dashboard/question-bank?unit=${u.id}`}
                    className="card flex items-center justify-between gap-3 p-4 transition-all hover:border-brand-300"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-semibold text-ink-900">
                        {u.title}
                      </span>
                      <span className="text-xs text-ink-500">
                        {options.skills.filter((s) => s.unitId === u.id).length} مهارة
                      </span>
                    </span>
                    <Brain className="h-4 w-4 shrink-0 text-ink-300" />
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </ServiceGate>
    );
  }

  const ent = await getEntitlement(user.id);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <Brain className="h-6 w-6 text-brand-600" />
          بنك الأسئلة
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          أسئلة {PLATFORM.gradeNameAr} مصنّفة بالفصل والوحدة والمهارة ومستوى
          الصعوبة — {total} سؤال في البنك، والتصحيح فوري بعد الإرسال.
        </p>
      </header>

      <BankFilters
        terms={options.terms}
        units={options.units}
        skills={options.skills}
        current={{
          term: sp.term,
          unit: sp.unit,
          skill: sp.skill,
          difficulty: sp.difficulty,
        }}
        counts={countMap}
      />

      {!ent.canUseQuestionBank ? (
        <Alert
          tone="info"
          title="بنك الأسئلة متاح في الباقة المميزة"
          action={
            <ButtonLink href="/pricing" size="sm">
              عرض الباقات
            </ButtonLink>
          }
        >
          يتيح لك البنك تدريبًا مباشرًا على أسئلة {PLATFORM.gradeShort} مصنّفة
          بالمهارات مع تصحيح فوري والحلول النموذجية.
        </Alert>
      ) : null}

      <Suspense
        fallback={
          <div className="card grid place-items-center p-10 text-sm text-ink-500">
            جارٍ التحميل…
          </div>
        }
      >
        <QuestionBankTrainer
          locked={!ent.canUseQuestionBank}
          skillTitle={activeSkill?.title ?? undefined}
        />
      </Suspense>

      {!activeUnit && options.units.length > 0 ? (
        <section className="space-y-3">
          <h2 className="text-base font-bold text-ink-900">
            تدرّب على وحدة محددة
          </h2>
          <ul className="grid gap-3 sm:grid-cols-2">
            {options.units.map((u) => (
              <li key={u.id}>
                <Link
                  href={`/dashboard/question-bank?unit=${u.id}`}
                  className="card flex items-center justify-between gap-3 p-4 transition-all hover:border-brand-300"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-semibold text-ink-900">
                      {u.title}
                    </span>
                    <span className="text-xs text-ink-500">
                      {options.skills.filter((s) => s.unitId === u.id).length} مهارة
                    </span>
                  </span>
                  <Brain className="h-4 w-4 shrink-0 text-ink-300" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}