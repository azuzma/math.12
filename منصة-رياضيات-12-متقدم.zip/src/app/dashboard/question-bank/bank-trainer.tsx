"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  Brain,
  CheckCircle2,
  XCircle,
  Lightbulb,
  RefreshCw,
  Loader2,
  Lock,
} from "lucide-react";
import { DIFFICULTY_MAP } from "@/lib/platform";

type Q = {
  id: string;
  type: string;
  text: string;
  options: { id: string; text: string }[];
  points: number;
  difficulty: "EASY" | "MEDIUM" | "HARD" | "CHALLENGE";
  hint: string | null;
};

type ResultItem = {
  questionId: string;
  text: string;
  type: string;
  points: number;
  difficulty: Q["difficulty"];
  skillTitle: string | null;
  unitTitle: string | null;
  isCorrect: boolean;
  needsReview: boolean;
  given: unknown;
  correct: unknown;
  options: { id: string; text: string }[];
  solution: string | null;
  hint: string | null;
};

type Result = {
  score: number;
  maxScore: number;
  percentage: number;
  correctCount: number;
  totalCount: number;
  showSolutions: boolean;
  items: ResultItem[];
};

const isChoice = (t: string) =>
  t === "MCQ" || t === "TRUE_FALSE" || t === "MULTI_TRUE";

export function QuestionBankTrainer({
  locked,
  skillTitle,
}: {
  locked: boolean;
  skillTitle?: string;
}) {
  const params = useSearchParams();
  const [questions, setQuestions] = useState<Q[] | null>(null);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shownHints, setShownHints] = useState<Record<string, boolean>>({});
  const started = useRef(false);

  const termId = params.get("term") ?? "";
  const unitId = params.get("unit") ?? "";
  const skillId = params.get("skill") ?? "";
  const difficulty = params.get("difficulty") ?? "";

  const qs = new URLSearchParams();
  if (termId) qs.set("termId", termId);
  if (unitId) qs.set("unitId", unitId);
  if (skillId) qs.set("skillId", skillId);
  if (difficulty) qs.set("difficulty", difficulty);
  qs.set("limit", "10");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    setAnswers({});
    setShownHints({});
    try {
      const res = await fetch(`/api/question-bank?${qs.toString()}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "تعذّر تحميل الأسئلة");
        setQuestions(null);
        return;
      }
      setQuestions(data.questions ?? []);
    } catch {
      setError("تعذّر الاتصال. حاول مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }, [qs.toString()]);

  useEffect(() => {
    if (locked) return;
    if (started.current) return;
    started.current = true;
    void load();
  }, [locked, load]);

  async function submit() {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/question-bank", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionIds: questions?.map((q) => q.id) ?? [],
          answers,
          skillId: skillId || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "تعذّر تصحيح الإجابات");
        return;
      }
      setResult(data as Result);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setError("تعذّر الاتصال. حاول مرة أخرى.");
    } finally {
      setSubmitting(false);
    }
  }

  if (locked) {
    return (
      <div className="card p-8 text-center">
        <Lock className="mx-auto h-8 w-8 text-ink-400" />
        <h2 className="mt-3 font-bold text-ink-900">
          بنك الأسئلة متاح في الباقة المميزة
        </h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-ink-600">
         قم بالترقية لتفتح بنك أسئلة الصف 12 المتقدم كاملًا مع الحلول النموذجية.
        </p>
        <a href="/pricing" className="btn btn-primary mt-5">
          عرض الباقات
        </a>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="card grid place-items-center gap-3 p-10 text-ink-500">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="text-sm">جارٍ اختيار أسئلة…</span>
      </div>
    );
  }

  if (error && !questions) {
    return (
      <div className="card p-8 text-center">
        <p className="text-sm text-rose-600">{error}</p>
        <button onClick={load} className="btn btn-outline mt-4">
          إعادة المحاولة
        </button>
      </div>
    );
  }

  if (questions && questions.length === 0) {
    return (
      <div className="card p-8 text-center">
        <Brain className="mx-auto h-8 w-8 text-ink-400" />
        <h2 className="mt-3 font-bold text-ink-900">لا توجد أسئلة مطابقة</h2>
        <p className="mt-2 text-sm text-ink-600">
          غيّر الفلاتر أو اختر مهارة أخرى من القائمة أعلاه.
        </p>
      </div>
    );
  }

  const answeredCount = Object.keys(answers).length;

  return (
    <div className="space-y-5">
      {/* النتيجة */}
      {result ? (
        <div
          className={`card p-6 ${
            result.percentage >= 60
              ? "border-emerald-300 bg-emerald-50/50"
              : "border-amber-300 bg-amber-50/50"
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm text-ink-600">
                {skillTitle ? `مهارة: ${skillTitle}` : "نتيجة التدريب"}
              </p>
              <p className="text-3xl font-bold text-ink-900 tabular-nums">
                {Math.round(result.percentage)}%
              </p>
              <p className="mt-1 text-sm text-ink-600">
                {result.correctCount} إجابة صحيحة من {result.totalCount} ·{" "}
                {result.score} من {result.maxScore} درجة
              </p>
            </div>
            <button onClick={load} className="btn btn-outline">
              <RefreshCw className="h-4 w-4" />
              مجموعة جديدة
            </button>
          </div>
        </div>
      ) : null}

      {/* الأسئلة */}
      <ol className="space-y-4">
        {(result?.items ? [] : (questions ?? [])).map((raw, i) => {
          if (result) return null;
          const q = raw as Q;
          const diff = DIFFICULTY_MAP[q.difficulty];
          const multi = q.type === "MULTI_TRUE";

          return (
            <li key={q.id} className="card p-5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-ink-500">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-brand-600 text-[11px] font-bold text-white">
                  {i + 1}
                </span>
                <span className={`font-bold ${diff?.color ?? ""}`}>
                  {diff?.emoji} {diff?.label}
                </span>
                <span>· {q.points} درجة</span>
              </div>

              <p className="mt-3 leading-relaxed font-medium text-ink-900">
                {q.text}
              </p>

              {isChoice(q.type) ? (
                <div className="mt-3 space-y-2">
                  {q.options.map((o) => {
                    const checked = multi
                      ? Array.isArray(answers[q.id])
                        ? (answers[q.id] as string[]).includes(o.id)
                        : false
                      : answers[q.id] === o.id;
                    return (
                      <label
                        key={o.id}
                        className="flex cursor-pointer items-center gap-2.5 rounded-lg border border-ink-200 px-3 py-2 text-sm hover:bg-ink-50"
                      >
                        <input
                          type={multi ? "checkbox" : "radio"}
                          name={`q-${q.id}`}
                          checked={checked}
                          disabled={Boolean(result)}
                          onChange={(e) => {
                            setAnswers((prev) => {
                              if (!multi) return { ...prev, [q.id]: o.id };
                              const cur = Array.isArray(prev[q.id])
                                ? (prev[q.id] as string[])
                                : [];
                              return {
                                ...prev,
                                [q.id]: e.target.checked
                                  ? [...cur, o.id]
                                  : cur.filter((x) => x !== o.id),
                              };
                            });
                          }}
                          className="h-4 w-4 accent-brand-600"
                        />
                        <span>{o.text}</span>
                      </label>
                    );
                  })}
                </div>
              ) : (
                <input
                  type="text"
                  value={(answers[q.id] as string) ?? ""}
                  disabled={Boolean(result)}
                  onChange={(e) =>
                    setAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                  }
                  placeholder="اكتب إجابتك (رقم أو 1/3 مثلًا)"
                  dir="auto"
                  className="input mt-3"
                />
              )}

              {q.hint ? (
                <div className="mt-3">
                  {shownHints[q.id] ? (
                    <p className="flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-900">
                      <Lightbulb className="mt-0.5 h-4 w-4 shrink-0" />
                      {q.hint}
                    </p>
                  ) : (
                    <button
                      onClick={() =>
                        setShownHints((p) => ({ ...p, [q.id]: true }))
                      }
                      className="text-xs font-semibold text-amber-700 hover:underline"
                    >
                      أظهر تلميحًا
                    </button>
                  )}
                </div>
              ) : null}
            </li>
          );
        })}
      </ol>

      {/* مراجعة الأسئلة بعد التصحيح */}
      {result ? (
        <div className="space-y-3">
          <h2 className="font-bold text-ink-900">مراجعة الإجابات</h2>
          {result.items.map((item, i) => (
            <div
              key={item.questionId}
              className={`card p-5 ${
                item.isCorrect
                  ? "border-emerald-300"
                  : item.needsReview
                    ? "border-amber-300"
                    : "border-rose-300"
              }`}
            >
              <div className="flex items-start gap-2">
                {item.isCorrect ? (
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
                ) : (
                  <XCircle className="mt-0.5 h-5 w-5 shrink-0 text-rose-600" />
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-ink-500">
                    <span className="font-bold text-ink-700">{i + 1}.</span>
                    {item.skillTitle ? <span>{item.skillTitle}</span> : null}
                    <span
                      className={`font-bold ${
                        DIFFICULTY_MAP[item.difficulty]?.color ?? ""
                      }`}
                    >
                      {DIFFICULTY_MAP[item.difficulty]?.emoji}{" "}
                      {DIFFICULTY_MAP[item.difficulty]?.label}
                    </span>
                  </div>
                  <p className="mt-1 font-medium text-ink-900">{item.text}</p>

                  {!item.isCorrect ? (
                    <p className="mt-2 text-sm text-rose-700">
                      إجابتك:{" "}
                      {Array.isArray(item.given)
                        ? item.given.join("، ")
                        : (item.given as string) || "لم تجب"}
                    </p>
                  ) : null}

                  {item.solution ? (
                    <p className="mt-2 rounded-lg bg-ink-50 px-3 py-2 text-sm leading-relaxed text-ink-700">
                      <strong className="text-ink-900">الحل: </strong>
                      {item.solution}
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : null}

      {/* شريط الإرسال */}
      {!result ? (
        <div className="sticky bottom-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-200 bg-white/95 p-4 shadow-lg backdrop-blur">
          <span className="text-sm text-ink-600">
            أجبت على{" "}
            <strong className="text-ink-900 tabular-nums">{answeredCount}</strong>{" "}
            من {questions?.length ?? 0} سؤال
          </span>
          <div className="flex items-center gap-2">
            {error ? <span className="text-sm text-rose-600">{error}</span> : null}
            <button
              onClick={submit}
              disabled={submitting || answeredCount === 0}
              className="btn btn-primary"
            >
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CheckCircle2 className="h-4 w-4" />
              )}
              صحّح الإجابات
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}