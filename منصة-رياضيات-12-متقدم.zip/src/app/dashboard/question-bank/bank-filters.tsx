"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { DIFFICULTY_LEVELS } from "@/lib/platform";

type Props = {
  terms: { id: string; title: string }[];
  units: { id: string; title: string; termId: string }[];
  skills: { id: string; title: string; unitId: string; termId: string }[];
  current: {
    term?: string;
    unit?: string;
    skill?: string;
    difficulty?: string;
  };
  counts: Record<string, number>;
};

export function BankFilters({ terms, units, skills, current, counts }: Props) {
  const router = useRouter();

  function push(next: Record<string, string | undefined>) {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...current, ...next })) {
      if (v) p.set(k, v);
    }
    const s = p.toString();
    router.push(s ? `/dashboard/question-bank?${s}` : "/dashboard/question-bank");
  }

  function select(name: string, value: string) {
    // تغيير الفصل يُصفّي الوحدة والمهارة معه
    if (name === "term") push({ term: value || undefined, unit: undefined, skill: undefined });
    if (name === "unit") push({ unit: value || undefined, skill: undefined });
    if (name === "skill") push({ skill: value || undefined });
  }

  const visibleUnits = current.term
    ? units.filter((u) => u.termId === current.term)
    : units;
  const visibleSkills = current.unit
    ? skills.filter((s) => s.unitId === current.unit)
    : skills;

  return (
    <div className="card space-y-4 p-5">
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-ink-600">
            الفصل الدراسي
          </span>
          <select
            className="input w-full cursor-pointer"
            value={current.term ?? ""}
            onChange={(e) => select("term", e.target.value)}
          >
            <option value="">كل الفصول</option>
            {terms.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title}
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-ink-600">
            الوحدة
          </span>
          <select
            className="input w-full cursor-pointer"
            value={current.unit ?? ""}
            onChange={(e) => select("unit", e.target.value)}
          >
            <option value="">كل الوحدات</option>
            {visibleUnits.map((u) => (
              <option key={u.id} value={u.id}>
                {u.title}
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <span className="mb-1 block text-xs font-semibold text-ink-600">
            المهارة
          </span>
          <select
            className="input w-full cursor-pointer"
            value={current.skill ?? ""}
            onChange={(e) => select("skill", e.target.value)}
          >
            <option value="">كل المهارات</option>
            {visibleSkills.map((s) => (
              <option key={s.id} value={s.id}>
                {s.title}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-ink-600">الصعوبة:</span>
        <Link
          href="#"
          onClick={(e) => {
            e.preventDefault();
            push({ difficulty: undefined });
          }}
          className={`rounded-full border px-3 py-1 text-xs font-medium ${
            !current.difficulty
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل
        </Link>
        {DIFFICULTY_LEVELS.map((d) => (
          <Link
            key={d.value}
            href="#"
            onClick={(e) => {
              e.preventDefault();
              push({ difficulty: d.value });
            }}
            className={`rounded-full border px-3 py-1 text-xs font-medium ${
              current.difficulty === d.value
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {d.emoji} {d.label} ({counts[d.value] ?? 0})
          </Link>
        ))}
      </div>

      {current.term || current.unit || current.skill || current.difficulty ? (
        <Link
          href="/dashboard/question-bank"
          className="inline-block text-xs font-semibold text-ink-500 hover:text-ink-800 hover:underline"
        >
          مسح كل الفلاتر
        </Link>
      ) : null}
    </div>
  );
}