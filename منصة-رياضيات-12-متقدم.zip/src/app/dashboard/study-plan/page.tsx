import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import {
  ClipboardList,
  Lock,
  PlayCircle,
  FileText,
  ClipboardCheck,
  CheckCircle2,
  ArrowLeft,
  Calendar,
  Flame,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { buildStudyPlan } from "@/lib/analysis";
import { ProgressBar } from "@/components/dashboard/progress-bar";
import { ButtonLink, EmptyState } from "@/components/ui/buttons";
import { PLATFORM } from "@/lib/platform";
import { formatDuration } from "@/lib/utils";
import { getViewerContext } from "@/lib/auth/viewer";
import { ServiceGate } from "@/components/dashboard/service-gate";

export const metadata: Metadata = { title: "خطة الدراسة" };

export default async function StudyPlanPage() {
  const { user, userId, gradeId, ent } = await getViewerContext();

  // الزائر: يرى الخدمة ومزاياها — والخطة المخصّصة تحتاج حسابًا
  if (!user) {
    return (
      <ServiceGate
        section="plan"
        title="خطة الدراسة"
        description={`خطة مخصّصة لإنهاء ومراجعة ${PLATFORM.gradeShort} — تُبنى تلقائيًا من أدائك: الدروس التي بدأتها، الوحدات التي تحتاج مراجعة، وموعد الاختبارات.`}
        benefits={[
          "توزيع يومي للدروس والاختبارات",
          "أولوية للمهارات الضعيفة",
          "تتبّع ما أنجزته فعلًا",
          "قابلة للتعديل يدويًا",
          "تتحدّث مع أدائك",
          "تذكير بمواعيد الاختبارات",
        ]}
        actionLabel="سجّل الدخول واحصل على خطتك"
      >
        <section className="card p-6">
          <h2 className="text-base font-bold text-ink-900">شكل الخطة</h2>
          <ul className="mt-4 space-y-3">
            {["السبت", "الأحد", "الاثنين", "الثلاثاء"].map((day, i) => (
              <li
                key={day}
                className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 p-4"
              >
                <span className="font-semibold text-ink-900">{day}</span>
                <span className="text-sm text-ink-500">
                  {i === 0 ? "مراجعة درس + اختبار قصير" : "درس جديد + 10 أسئلة"}
                </span>
                <span className="rounded-lg bg-ink-100 px-2.5 py-1 text-xs font-semibold text-ink-600">
                  45 دقيقة
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-sm text-ink-500">
            هذا نموذج توضيحي — خطتك الحقيقية تُحسب من دروسك ونتائجك.
          </p>
        </section>
      </ServiceGate>
    );
  }

  if (!ent.canSeeStudyPlan) {
    return (
      <div className="space-y-6">
        <header>
          <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
            <ClipboardList className="h-6 w-6 text-brand-600" />
            خطة الدراسة
          </h1>
          <p className="mt-1 text-sm text-ink-600">
            خطة مخصّصة لإنهاء ومراجعة {PLATFORM.gradeShort}.
          </p>
        </header>

        <div className="card grid place-items-center p-10 text-center">
          <Lock className="h-9 w-9 text-ink-400" />
          <h2 className="mt-3 font-bold text-ink-900">
            خطة الدراسة متاحة في الباقة المميزة
          </h2>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-600">
            تُبنى الخطة تلقائيًا من أدائك: الدروس التي بدأتها، الوحدات التي
            تحتاج مراجعة، وموعد الاختبارات.
          </p>
          <ButtonLink href="/pricing" className="mt-5">
            عرض الباقات
          </ButtonLink>
        </div>
      </div>
    );
  }

  const plan = userId ? await buildStudyPlan(userId) : null;

  if (!plan) {
    return (
      <EmptyState
        title="لا توجد خطة بعد"
        description="أضف دروسًا إلى مقرّرك لتُبنى خطة الدراسة تلقائيًا."
        action={<ButtonLink href="/dashboard/lessons">تصفح الدروس</ButtonLink>}
      />
    );
  }

  const percent = plan.totalLessons
    ? Math.round((plan.completedCount / plan.totalLessons) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <ClipboardList className="h-6 w-6 text-brand-600" />
          خطة الدراسة
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          خطة {PLATFORM.gradeNameAr} مبنية على ما أنجزته وما تبقّى.
        </p>
      </header>

      {/* الملخص */}
      <div className="card p-5">
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <p className="text-xs text-ink-500">أنجزت</p>
            <p className="text-lg font-bold text-ink-900 tabular-nums">
              {plan.completedCount} / {plan.totalLessons} درس
            </p>
          </div>
          <div>
            <p className="text-xs text-ink-500">متبقٍ</p>
            <p className="text-lg font-bold text-ink-900 tabular-nums">
              {plan.pendingCount} درس
            </p>
          </div>
          <div>
            <p className="text-xs text-ink-500">عدد الأسابيع المتوقعة</p>
            <p className="text-lg font-bold text-ink-900 tabular-nums">
              {plan.weeks.length || 0} أسبوع
            </p>
          </div>
        </div>

        <div className="mt-5">
          <ProgressBar percent={percent} label="نسبة الإنجاز" showValue />
        </div>

        <p className="mt-4 flex items-start gap-2 rounded-lg bg-brand-50 px-4 py-3 text-sm leading-relaxed text-brand-900">
          <Flame className="mt-0.5 h-4 w-4 shrink-0" />
          {plan.advice}
        </p>
      </div>

      {/* دروس قيد المشاهدة */}
      {plan.inProgress.length > 0 ? (
        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <PlayCircle className="h-5 w-5 text-brand-600" />
            أكمل ما بدأت
          </h2>
          <ul className="space-y-2.5">
            {plan.inProgress.map((l) => (
              <li key={l.id}>
                <Link
                  href={`/dashboard/lessons/${l.slug}`}
                  className="card flex items-center gap-4 p-4 transition-all hover:border-brand-300"
                >
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold text-ink-900">
                      {l.title}
                    </span>
                    <span className="block text-xs text-ink-500">
                      {l.unitTitle} · {l.termTitle}
                    </span>
                    <span className="mt-2 block max-w-xs">
                      <ProgressBar percent={l.watchPercent} size="sm" />
                    </span>
                  </span>
                  <span className="shrink-0 text-xs font-bold text-brand-700 tabular-nums">
                    {l.watchPercent}%
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {/* الخطة الأسبوعية */}
      {plan.weeks.length > 0 ? (
        <section className="space-y-3">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <Calendar className="h-5 w-5 text-brand-600" />
            الخطة الأسبوعية
          </h2>
          <ol className="space-y-4">
            {plan.weeks.map((w) => (
              <li key={w.week} className="card p-5">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-bold text-ink-900">{w.title}</h3>
                  <span className="rounded-full bg-ink-100 px-3 py-1 text-xs font-medium text-ink-600">
                    {w.lessons.length} دروس · {w.focus}
                  </span>
                </div>
                <ul className="space-y-2">
                  {w.lessons.map((l) => (
                    <li key={l.id}>
                      <Link
                        href={`/dashboard/lessons/${l.slug}`}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-ink-200 px-4 py-3 transition-colors hover:border-brand-300 hover:bg-ink-50"
                      >
                        <span className="min-w-0 flex-1">
                          <span className="block font-medium text-ink-900">
                            {l.title}
                          </span>
                          <span className="block text-xs text-ink-500">
                            {l.unitTitle} · {l.termTitle}
                            {l.durationSec
                              ? ` · ${formatDuration(l.durationSec)}`
                              : ""}
                          </span>
                        </span>
                        <span className="flex shrink-0 items-center gap-2 text-xs text-ink-500">
                          {l.watchPercent > 0 ? (
                            <span className="font-bold text-brand-700 tabular-nums">
                              {l.watchPercent}%
                            </span>
                          ) : null}
                          {l.hasFiles ? (
                            <FileText className="h-4 w-4 text-ink-400" />
                          ) : null}
                          {l.hasExam ? (
                            <ClipboardCheck className="h-4 w-4 text-ink-400" />
                          ) : null}
                          <ArrowLeft className="h-3.5 w-3.5 text-ink-300" />
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ol>
        </section>
      ) : (
        <div className="card p-8 text-center">
          <CheckCircle2 className="mx-auto h-9 w-9 text-emerald-600" />
          <h2 className="mt-3 font-bold text-ink-900">أكملت كل الدروس!</h2>
          <p className="mt-2 text-sm text-ink-600">
            حان وقت المراجعة عبر الاختبارات الشاملة والتجريبية.
          </p>
          <ButtonLink href="/dashboard/exams" className="mt-4">
            الذهاب إلى الاختبارات
          </ButtonLink>
        </div>
      )}

      {/* ابدأ الآن */}
      {plan.notStarted.length > 0 ? (
        <section className="space-y-3">
          <h2 className="text-base font-bold text-ink-900">ابدأ من هنا</h2>
          <ul className="grid gap-3 sm:grid-cols-2">
            {plan.notStarted.slice(0, 4).map((l) => (
              <li key={l.id}>
                <Link
                  href={`/dashboard/lessons/${l.slug}`}
                  className="card flex h-full flex-col p-4 transition-all hover:border-brand-300"
                >
                  <span className="font-semibold text-ink-900">{l.title}</span>
                  <span className="mt-0.5 text-xs text-ink-500">
                    {l.unitTitle} · {l.termTitle}
                  </span>
                  {l.summary ? (
                    <span className="mt-2 line-clamp-2 flex-1 text-sm text-ink-600">
                      {l.summary}
                    </span>
                  ) : (
                    <span className="flex-1" />
                  )}
                  <span className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-brand-700">
                    ابدأ الدرس <ArrowLeft className="h-3 w-3" />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}