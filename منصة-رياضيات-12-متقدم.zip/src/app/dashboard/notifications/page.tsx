import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { EmptyState } from "@/components/ui/buttons";
import { formatDateTime, cn } from "@/lib/utils";
import { Bell, CheckCheck } from "lucide-react";

export const metadata = { title: "الإشعارات" };

const TYPE_STYLES: Record<string, string> = {
  NEW_LESSON: "bg-brand-50 text-brand-600",
  NEW_RESOURCE: "bg-ink-100 text-ink-600",
  EXAM_RESULT: "bg-emerald-50 text-emerald-600",
  SUBSCRIPTION: "bg-gold-400/15 text-gold-600",
  PAYMENT: "bg-emerald-50 text-emerald-600",
  ANNOUNCEMENT: "bg-amber-50 text-amber-600",
  SYSTEM: "bg-ink-100 text-ink-600",
  INFO: "bg-ink-100 text-ink-600",
};

export default async function NotificationsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>;
}) {
  const { filter } = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const notifications = await prisma.notification.findMany({
    where: {
      userId: user.id,
      ...(filter === "unread" ? { readAt: null } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  const unreadCount = notifications.filter((n) => !n.readAt).length;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">الإشعارات</h1>
          <p className="mt-1 text-sm text-ink-600">
            {unreadCount > 0 ? `${unreadCount} إشعار غير مقروء` : "لا توجد إشعارات جديدة"}
          </p>
        </div>
        {notifications.some((n) => !n.readAt) ? (
          <form action="/api/notifications/read-all" method="post">
            <button type="submit" className="btn btn-outline">
              <CheckCheck className="h-4 w-4" />
              تعليم الكل كمقروء
            </button>
          </form>
        ) : null}
      </header>

      <div className="flex flex-wrap gap-2">
        <Link
          href="/dashboard/notifications"
          className={cn(
            "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
            !filter
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300",
          )}
        >
          الكل
        </Link>
        <Link
          href="/dashboard/notifications?filter=unread"
          className={cn(
            "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
            filter === "unread"
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300",
          )}
        >
          غير المقروءة
        </Link>
      </div>

      {notifications.length === 0 ? (
        <EmptyState
          title="لا توجد إشعارات"
          description="ستصلك إشعارات عند نشر درس جديد أو ورقة عمل أو نتيجة اختبار."
          icon={<Bell className="h-6 w-6" />}
        />
      ) : (
        <ul className="space-y-2.5">
          {notifications.map((n) => {
            const content = (
              <div
                className={cn(
                  "card flex items-start gap-4 p-4 transition-colors",
                  !n.readAt && "border-brand-200 bg-brand-50/40",
                )}
              >
                <span
                  className={cn(
                    "grid h-10 w-10 shrink-0 place-items-center rounded-lg",
                    TYPE_STYLES[n.type] ?? TYPE_STYLES.INFO,
                  )}
                >
                  <Bell className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold text-ink-900">{n.title}</p>
                    {!n.readAt ? (
                      <span className="h-2 w-2 rounded-full bg-brand-600" />
                    ) : null}
                  </div>
                  {n.body ? (
                    <p className="mt-0.5 text-sm leading-relaxed text-ink-600">
                      {n.body}
                    </p>
                  ) : null}
                  <p className="mt-1 text-xs text-ink-400">
                    {formatDateTime(n.createdAt)}
                  </p>
                </div>
              </div>
            );

            return (
              <li key={n.id}>
                {n.link ? (
                  <Link
                    href={n.link}
                    onClick={() => {
                      void fetch("/api/notifications/read", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ id: n.id }),
                      });
                    }}
                  >
                    {content}
                  </Link>
                ) : (
                  content
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}