import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import {
  ArrowRight,
  ArrowLeft,
  FileText,
  ClipboardCheck,
  NotebookPen,
  CheckCircle2,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { getLessonBySlug, getLessonSiblings } from "@/lib/content";
import { KindBadge, AccessBadge } from "@/components/ui/badges";
import { Alert, ButtonLink, EmptyState } from "@/components/ui/buttons";
import { VideoPlayer } from "@/components/dashboard/video-player";
import { FileList } from "@/components/dashboard/file-list";
import { formatBytes } from "@/lib/utils";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const lesson = await prisma.lesson.findUnique({
    where: { slug },
    select: { title: true, summary: true },
  });
  return {
    title: lesson ? lesson.title : "الدرس",
    description: lesson?.summary ?? undefined,
    robots: { index: false, follow: false },
  };
}

export default async function LessonPlayerPage({ params }: Props) {
  const { slug } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/lessons/[slug]");

  const lesson = await getLessonBySlug(slug);
  if (!lesson) notFound();

  const ent = await getEntitlement(user.id);

  const [progress, siblings] = await Promise.all([
    prisma.lessonProgress.findUnique({
      where: { studentId_lessonId: { studentId: user.id, lessonId: lesson.id } },
    }),
    getLessonSiblings(lesson.id),
  ]);

  const hasAccess = lesson.isFree || ent.canViewPaidContent;
  const gradeName = lesson.unit.course.subject.grade.nameAr;

  return (
    <div className="space-y-6">
      {/* مسار التنقل */}
      <nav className="flex flex-wrap items-center gap-2 text-xs text-ink-500">
        <Link href="/dashboard/lessons" className="hover:text-brand-700">
          دروسي
        </Link>
        <span aria-hidden>/</span>
        <Link
          href={`/lessons?grade=${lesson.unit.course.subject.grade.slug}`}
          className="hover:text-brand-700"
        >
          {gradeName}
        </Link>
        <span aria-hidden>/</span>
        <span className="truncate text-ink-800">{lesson.unit.title}</span>
      </nav>

      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">
              {lesson.title}
            </h1>
            <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
          </div>
          {lesson.summary ? (
            <p className="mt-1.5 text-sm leading-relaxed text-ink-600">
              {lesson.summary}
            </p>
          ) : null}
        </div>

        {progress?.completed ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
            <CheckCircle2 className="h-4 w-4" />
            أكملت هذا الدرس
          </span>
        ) : null}
      </header>

      {/* الفيديو */}
      {lesson.videos.length > 0 ? (
        hasAccess ? (
          <VideoPlayer
            video={lesson.videos[0]!}
            lessonId={lesson.id}
            initialPosition={progress?.lastPositionSec ?? 0}
            watchPercent={progress?.watchPercent ?? 0}
            completed={progress?.completed ?? false}
            onCompleteHref={`/dashboard/lessons/${lesson.slug}?done=1`}
          />
        ) : (
          <LockPanel />
        )
      ) : (
        <div className="rounded-2xl border border-dashed border-ink-300 bg-white p-10 text-center">
          <p className="text-sm text-ink-500">لم يُرفع فيديو لهذا الدرس بعد.</p>
        </div>
      )}

      {/* الشرح */}
      {lesson.description ? (
        <section className="card p-6">
          <h2 className="text-base font-bold text-ink-900">شرح الدرس</h2>
          <div className="mt-3 space-y-3 leading-loose text-ink-700">
            {lesson.description.split("\n").map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </section>
      ) : null}

      {/* الملفات */}
      <section className="card p-6">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <FileText className="h-5 w-5 text-brand-600" />
            الملخصات وأوراق العمل
          </h2>
        </div>

        {lesson.files.length === 0 ? (
          <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
            لا توجد ملفات لهذا الدرس.
          </p>
        ) : (
          <FileList
            files={lesson.files.map((f) => ({
              id: f.id,
              title: f.title,
              description: f.description,
              kind: f.kind,
              sizeBytes: f.sizeBytes,
              pageCount: f.pageCount,
              isFree: f.isFree || lesson.isFree,
            }))}
            hasSubscription={ent.canViewPaidContent}
          />
        )}
      </section>

      {/* الواجبات والاختبارات */}
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-6">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <NotebookPen className="h-5 w-5 text-amber-600" />
            واجبات الدرس
          </h2>

          {lesson.assignments.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
              لا توجد واجبات لهذا الدرس.
            </p>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {lesson.assignments.map((a) => {
                const locked = !a.isFree && !ent.canViewPaidContent;
                return (
                  <li key={a.id}>
                    <Link
                      href={
                        locked
                          ? "/pricing"
                          : `/dashboard/assignments/${a.id}`
                      }
                      className="flex items-center gap-3 rounded-xl border border-ink-200 p-3.5 transition-colors hover:border-brand-300"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-ink-900">
                          {a.title}
                        </p>
                        <p className="text-xs text-ink-500">
                          {a._count.questions} سؤال
                          {a.dueAfterDays ? ` · خلال ${a.dueAfterDays} يوم` : ""}
                        </p>
                      </div>
                      {a.isFree ? (
                        <AccessBadge isFree />
                      ) : locked ? (
                        <AccessBadge isFree={false} />
                      ) : null}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="card p-6">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <ClipboardCheck className="h-5 w-5 text-emerald-600" />
            اختبارات الدرس
          </h2>

          {lesson.exams.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
              لا توجد اختبارات لهذا الدرس.
            </p>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {lesson.exams.map((exam) => {
                const locked =
                  (!exam.isFree && !ent.canViewPaidContent) && !ent.canTakeExams;
                return (
                  <li key={exam.id}>
                    <Link
                      href={locked ? "/pricing" : `/dashboard/exams/${exam.id}`}
                      className="flex items-center gap-3 rounded-xl border border-ink-200 p-3.5 transition-colors hover:border-brand-300"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-ink-900">
                          {exam.title}
                        </p>
                        <p className="text-xs text-ink-500">
                          {exam._count.questions} سؤال · {exam.durationMinutes} دقيقة ·{" "}
                          {exam.attemptsAllowed} محاولات
                        </p>
                      </div>
                      {exam.isFree ? (
                        <AccessBadge isFree />
                      ) : locked ? (
                        <AccessBadge isFree={false} />
                      ) : null}
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>

      {/* التنقل بين الدروس */}
      <nav className="flex items-center justify-between gap-3 border-t border-ink-200 pt-5">
        {siblings.prev ? (
          <Link
            href={`/dashboard/lessons/${siblings.prev.slug}`}
            className="flex items-center gap-2 rounded-xl border border-ink-200 px-4 py-2.5 text-sm font-medium text-ink-700 transition-colors hover:border-brand-300"
          >
            <ArrowRight className="h-4 w-4" />
            <span className="max-w-40 truncate">{siblings.prev.title}</span>
          </Link>
        ) : (
          <span />
        )}

        {siblings.next ? (
          <Link
            href={`/dashboard/lessons/${siblings.next.slug}`}
            className="flex items-center gap-2 rounded-xl border border-ink-200 px-4 py-2.5 text-sm font-medium text-ink-700 transition-colors hover:border-brand-300"
          >
            <span className="max-w-40 truncate">{siblings.next.title}</span>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        ) : (
          <span />
        )}
      </nav>
    </div>
  );
}

function LockPanel() {
  return (
    <div className="overflow-hidden rounded-2xl border border-ink-200 bg-white">
      <div className="relative aspect-video bg-gradient-to-br from-ink-800 to-ink-950">
        <div className="absolute inset-0 grid place-items-center px-6 text-center">
          <div>
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-white/10">
              <ClipboardCheck className="h-7 w-7 text-white/70" />
            </div>
            <p className="mt-4 text-white">هذا الدرس متاح للمشتركين</p>
            <p className="mt-1 text-sm text-white/60">
              فعّل اشتراكك لمشاهدة الفيديو وتنزيل أوراق العمل.
            </p>
          </div>
        </div>
      </div>
      <div className="p-5 text-center">
        <ButtonLink href="/pricing">عرض الباقات والأسعار</ButtonLink>
      </div>
    </div>
  );
}