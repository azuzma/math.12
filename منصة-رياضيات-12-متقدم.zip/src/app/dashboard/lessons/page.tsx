import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import {
  PlayCircle,
  Video,
  FileText,
  ClipboardCheck,
  CheckCircle2,
  Clock,
  ArrowLeft,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { AccessBadge } from "@/components/ui/badges";
import { ButtonLink, EmptyState } from "@/components/ui/buttons";
import { ProgressBar } from "@/components/dashboard/progress-bar";
import { formatDuration, formatDate } from "@/lib/utils";
import { getViewerContext } from "@/lib/auth/viewer";
import { PLATFORM } from "@/lib/platform";

export const metadata: Metadata = { title: "دروسي" };

export default async function MyLessonsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string }>;
}) {
  const { user, userId, gradeId, ent } = await getViewerContext();
  const { filter } = await searchParams;

  const lessons = gradeId
    ? await prisma.lesson.findMany({
        where: {
          status: "PUBLISHED",
          unit: { course: { subject: { gradeId } } },
          ...(filter === "free" ? { isFree: true } : {}),
          ...(filter === "paid" ? { isFree: false } : {}),
        },
        orderBy: [
          { unit: { term: { order: "asc" } } },
          { unit: { order: "asc" } },
          { order: "asc" },
        ],
        include: {
          skill: { select: { id: true, title: true } },
          unit: {
            include: {
              course: { include: { subject: true } },
              term: { select: { id: true, title: true } },
            },
          },
          progress: { where: { studentId: userId ?? "" } },
          _count: { select: { videos: true, files: true, exams: true, assignments: true } },
        },
      })
    : [];

  const completed = lessons.filter((l) => l.progress[0]?.completed).length;
  const inProgress = lessons.filter(
    (l) => l.progress[0] && !l.progress[0].completed && l.progress[0].watchPercent > 0,
  ).length;

  // التجميع حسب الفصل الدراسي ثم الوحدة
  type UnitGroup = { title: string; unitId: string; lessons: typeof lessons };
  type TermGroup = {
    termId: string | null;
    title: string;
    units: UnitGroup[];
  };

  const termMap = new Map<string, TermGroup>();
  const unitMap = new Map<string, UnitGroup>();

  for (const lesson of lessons) {
    const termId = lesson.unit.term?.id ?? null;
    const termKey = termId ?? "no-term";
    if (!termMap.has(termKey)) {
      termMap.set(termKey, {
        termId,
        title: lesson.unit.term?.title ?? "دون فصل دراسي",
        units: [],
      });
    }
    const unitKey = `${termKey}:${lesson.unitId}`;
    if (!unitMap.has(unitKey)) {
      const group: UnitGroup = {
        title: lesson.unit.title,
        unitId: lesson.unitId,
        lessons: [],
      };
      unitMap.set(unitKey, group);
      termMap.get(termKey)!.units.push(group);
    }
    unitMap.get(unitKey)!.lessons.push(lesson);
  }

  const terms = [...termMap.values()];

  if (!gradeId) {
    return (
      <EmptyState
        title="لم يتم تحديد صفك الدراسي"
        description="حدّث صفك من صفحة «حسابي» لتظهر لك دروس صفك."
        action={
          <ButtonLink href="/dashboard/profile">تحديث حسابي</ButtonLink>
        }
      />
    );
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">دروسي</h1>
        <p className="mt-1 text-sm text-ink-600">
          {lessons.length} درس في {PLATFORM.gradeNameAr} · {ent.planName}
        </p>
      </header>

      {/* ملخص */}
      <div className="card p-5">
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            { label: "مكتمل", value: completed, icon: CheckCircle2, color: "text-emerald-600" },
            { label: "قيد المشاهدة", value: inProgress, icon: PlayCircle, color: "text-brand-600" },
            { label: "لم يبدأ", value: lessons.length - completed - inProgress, icon: Clock, color: "text-ink-400" },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-3">
              <item.icon className={`h-5 w-5 ${item.color}`} />
              <div>
                <p className="text-lg font-bold text-ink-900 tabular-nums">
                  {item.value}
                </p>
                <p className="text-xs text-ink-500">{item.label}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5">
          <ProgressBar
            percent={lessons.length ? (completed / lessons.length) * 100 : 0}
            label="نسبة الإنجاز في صفك"
            showValue
          />
        </div>
      </div>

      {/* فلاتر */}
      <div className="flex flex-wrap gap-2">
        {[
          { value: "", label: "كل الدروس" },
          { value: "free", label: "المجانية" },
          { value: "paid", label: "المدفوعة" },
        ].map((f) => (
          <Link
            key={f.value}
            href={f.value ? `/dashboard/lessons?filter=${f.value}` : "/dashboard/lessons"}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              (filter ?? "") === f.value
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {lessons.length === 0 ? (
        <EmptyState
          title="لا توجد دروس"
          description="لم يُنشر دروس في صفك بعد، أو لا توجد نتائج لفلتر التصفية المختار."
          action={
            <ButtonLink href="/dashboard" variant="outline">
              العودة للوحة
            </ButtonLink>
          }
        />
      ) : (
        <div className="space-y-10">
          {terms.map((term) => (
            <section key={term.termId ?? "none"}>
              <div className="mb-4 flex items-center gap-3 rounded-xl bg-gradient-to-l from-brand-600 to-brand-700 px-4 py-3 text-white">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white/20 text-sm font-bold">
                  {term.units.reduce((s, u) => s + u.lessons.length, 0)}
                </span>
                <h2 className="text-base font-bold">{term.title}</h2>
                <span className="ms-auto text-xs text-white/80">
                  {term.units.length} وحدة
                </span>
              </div>

              <div className="space-y-8">
                {term.units.map((group) => (
            <section key={group.unitId}>
              <h3 className="mb-3 flex items-center gap-2 text-base font-bold text-ink-900">
                <span className="h-4 w-1 rounded-full bg-brand-500" />
                {group.title}
                <span className="text-xs font-normal text-ink-500">
                  ({group.lessons.length} درس)
                </span>
              </h3>

              <ul className="space-y-2.5">
                {group.lessons.map((lesson) => {
                  const progress = lesson.progress[0];
                  const locked = !lesson.isFree && !ent.canViewPaidContent;

                  return (
                    <li key={lesson.id}>
                      <Link
                        href={
                          locked
                            ? "/pricing"
                            : `/dashboard/lessons/${lesson.slug}`
                        }
                        className="card flex items-center gap-4 p-4 transition-all hover:border-brand-300 hover:shadow-sm"
                      >
                        <span className="relative grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-white">
                          <PlayCircle className="h-6 w-6" />
                          {progress?.completed ? (
                            <span className="absolute -top-1 -left-1 grid h-5 w-5 place-items-center rounded-full bg-emerald-500">
                              <CheckCircle2 className="h-3 w-3" />
                            </span>
                          ) : null}
                        </span>

                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="font-semibold text-ink-900">{lesson.title}</p>
                            <AccessBadge
                              isFree={lesson.isFree}
                              isPreview={lesson.isPreview}
                            />
                          </div>

                          {lesson.skill ? (
                            <p className="mt-0.5 text-[11px] font-medium text-brand-600">
                              مهارة: {lesson.skill.title}
                            </p>
                          ) : null}

                          {lesson.summary ? (
                            <p className="mt-0.5 line-clamp-1 text-xs text-ink-500">
                              {lesson.summary}
                            </p>
                          ) : null}

                          <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                            {lesson.durationSec ? (
                              <span className="inline-flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {formatDuration(lesson.durationSec)}
                              </span>
                            ) : null}
                            {lesson._count.videos > 0 ? (
                              <span className="inline-flex items-center gap-1">
                                <Video className="h-3 w-3" />
                                {lesson._count.videos}
                              </span>
                            ) : null}
                            {lesson._count.files > 0 ? (
                              <span className="inline-flex items-center gap-1">
                                <FileText className="h-3 w-3" />
                                {lesson._count.files}
                              </span>
                            ) : null}
                            {lesson._count.exams > 0 ? (
                              <span className="inline-flex items-center gap-1">
                                <ClipboardCheck className="h-3 w-3" />
                                {lesson._count.exams}
                              </span>
                            ) : null}
                            {progress?.lastViewedAt && !progress.completed ? (
                              <span>آخر مشاهدة {formatDate(progress.lastViewedAt)}</span>
                            ) : null}
                          </div>

                          {progress && !progress.completed && progress.watchPercent > 0 ? (
                            <div className="mt-2 max-w-xs">
                              <ProgressBar
                                percent={progress.watchPercent}
                                size="sm"
                                tone="green"
                              />
                            </div>
                          ) : null}
                        </div>

                        <ArrowLeft className="h-4 w-4 shrink-0 text-ink-300" />
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </section>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}