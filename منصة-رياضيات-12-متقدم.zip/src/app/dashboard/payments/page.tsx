import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { DataTable } from "@/components/admin/ui";
import { PaymentBadge } from "@/components/ui/badges";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { Wallet } from "lucide-react";
import { formatDateTime, formatPrice } from "@/lib/utils";

export const metadata = { title: "المدفوعات" };

export default async function PaymentsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/payments");

  const payments = await prisma.payment.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { plan: { select: { nameAr: true } } },
  });

  const total = payments
    .filter((p) => p.status === "SUCCEEDED")
    .reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">
            سجل المدفوعات
          </h1>
          <p className="mt-1 text-sm text-ink-600">
            كل عمليات الدفع الخاصة بك.
          </p>
        </div>
        <div className="rounded-xl bg-emerald-50 px-4 py-2.5 text-center">
          <p className="text-xs text-emerald-700">الإجمالي المدفوع</p>
          <p className="text-lg font-bold text-emerald-800 tabular-nums">
            {formatPrice(total)}
          </p>
        </div>
      </header>

      {payments.length === 0 ? (
        <EmptyState
          title="لا توجد مدفوعات"
          description="ستظهر هنا كل عمليات الاشتراك والفواتير."
          icon={<Wallet className="h-6 w-6" />}
          action={<ButtonLink href="/pricing">عرض الباقات</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["التاريخ", "الباقة", "المبلغ", "الحالة", "المرجع"]}
          >
            {payments.map((p) => (
              <tr key={p.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3 text-xs text-ink-600">
                  {formatDateTime(p.paidAt ?? p.createdAt)}
                </td>
                <td className="px-4 py-3 font-medium text-ink-900">
                  {p.plan?.nameAr ?? "—"}
                </td>
                <td className="px-4 py-3 font-semibold text-ink-900 tabular-nums">
                  {formatPrice(p.amount, p.currency)}
                </td>
                <td className="px-4 py-3">
                  <PaymentBadge status={p.status} />
                </td>
                <td className="px-4 py-3 text-xs text-ink-400" dir="ltr">
                  {p.providerRef?.slice(0, 16) ?? "—"}
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}