import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { ProgressBar, ProgressRing } from "@/components/dashboard/progress-bar";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { Alert } from "@/components/ui/buttons";
import { formatDuration, formatDate } from "@/lib/utils";
import { Trophy, Target, Flame, Clock } from "lucide-react";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

export const metadata = { title: "تقدمي" };

export default async function ProgressPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/progress");

  const gradeId = user.gradeId;

  const lessons = gradeId
    ? await prisma.lesson.findMany({
        where: {
          status: "PUBLISHED",
          unit: { course: { subject: { gradeId } } },
        },
        select: {
          id: true,
          title: true,
          durationSec: true,
          unit: { select: { title: true } },
          _count: { select: { exams: true } },
        },
      })
    : [];

  const progress = await prisma.lessonProgress.findMany({
    where: { studentId: user.id },
    select: {
      lessonId: true,
      completed: true,
      watchPercent: true,
      lastViewedAt: true,
      lastPositionSec: true,
    },
  });

  const progressMap = new Map(progress.map((p) => [p.lessonId, p]));

  const completedCount = progress.filter((p) => p.completed).length;
  const percent = lessons.length
    ? Math.round((completedCount / lessons.length) * 100)
    : 0;

  const watchSeconds = lessons.reduce((s, l) => {
    const p = progressMap.get(l.id);
    if (!p) return s;
    if (p.completed) return s + (l.durationSec ?? 0);
    return s + Math.round(((l.durationSec ?? 0) * p.watchPercent) / 100);
  }, 0);

  const attempts = await prisma.examAttempt.findMany({
    where: { studentId: user.id, submittedAt: { gte: SUBMITTED_EPOCH } },
    select: { percentage: true, passed: true, submittedAt: true },
  });

  // سلسلة الأيام المتتالية
  let streak = 0;
  if (attempts.length > 0 || progress.length > 0) {
    const days = new Set<string>();
    for (const p of progress) {
      days.add(new Date(p.lastViewedAt ?? Date.now()).toISOString().slice(0, 10));
    }
    for (const a of attempts) {
      if (a.submittedAt) days.add(new Date(a.submittedAt).toISOString().slice(0, 10));
    }
    const sorted = [...days].sort().reverse();
    let cursor = new Date();
    const today = cursor.toISOString().slice(0, 10);
    if (sorted[0] !== today) {
      cursor.setDate(cursor.getDate() - 1);
    }
    const check = cursor.toISOString().slice(0, 10);
    if (sorted[0] === check) {
      streak = 1;
      for (let i = 1; i < sorted.length; i++) {
        const prev = new Date(sorted[i - 1]!);
        prev.setDate(prev.getDate() - 1);
        if (sorted[i] === prev.toISOString().slice(0, 10)) streak++;
        else break;
      }
    }
  }

  const last30 = attempts.filter(
    (a) =>
      a.submittedAt &&
      a.submittedAt.getTime() > Date.now() - 30 * 86400_000,
  );
  const avg30 = last30.length
    ? Math.round(last30.reduce((s, a) => s + a.percentage, 0) / last30.length)
    : 0;

  const goalMinutes = 30;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">تقدمي</h1>
        <p className="mt-1 text-sm text-ink-600">
          {user.gradeNameAr ?? "صفك"} · هدفك اليومي {goalMinutes} دقيقة
        </p>
      </header>

      {!gradeId ? (
        <Alert tone="warn" title="لم يتم تحديد صفك">
          حدّث صفك من صفحة «حسابي» لتتبع تقدمك.
        </Alert>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[auto_1fr]">
        <div className="card flex flex-col items-center p-6">
          <ProgressRing percent={percent} size={150} stroke={13} label="مكتمل" />
          <p className="mt-3 text-sm text-ink-600">
            {completedCount} من {lessons.length} درس
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {[
            {
              label: "سلسلة الأيام",
              value: `${streak} يوم`,
              hint: streak > 0 ? "استمر!" : "ابدأ اليوم",
              icon: Flame,
              tone: "text-orange-600 bg-orange-50",
            },
            {
              label: "وقت المشاهدة",
              value: formatDuration(watchSeconds),
              hint: "إجمالي دروس المشاهدة",
              icon: Clock,
              tone: "text-brand-600 bg-brand-50",
            },
            {
              label: "متوسط آخر 30 يوم",
              value: `${avg30}%`,
              hint: `${last30.length} محاولة`,
              icon: Target,
              tone: "text-emerald-600 bg-emerald-50",
            },
            {
              label: "اختبارات نجحت فيها",
              value: `${attempts.filter((a) => a.passed).length} / ${attempts.length}`,
              hint: "من كل المحاولات",
              icon: Trophy,
              tone: "text-gold-600 bg-gold-400/15",
            },
          ].map((s) => (
            <div key={s.label} className="card flex items-center gap-4 p-5">
              <span
                className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl ${s.tone}`}
              >
                <s.icon className="h-6 w-6" />
              </span>
              <div className="min-w-0">
                <p className="text-xl font-bold text-ink-900 tabular-nums">
                  {s.value}
                </p>
                <p className="text-xs font-semibold text-ink-600">{s.label}</p>
                <p className="text-xs text-ink-400">{s.hint}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* حالة كل درس */}
      {lessons.length === 0 ? (
        <EmptyState
          title="لا توجد دروس في صفك"
          description="حدّث صفك أو انتظر نشر دروس جديدة."
          action={<ButtonLink href="/dashboard/profile">تحديث حسابي</ButtonLink>}
        />
      ) : (
        <section className="card p-5">
          <h2 className="mb-4 text-base font-bold text-ink-900">
            حالة الدروس
          </h2>
          <ul className="space-y-3">
            {lessons.map((lesson) => {
              const p = progressMap.get(lesson.id);
              return (
                <li key={lesson.id}>
                  <div className="rounded-xl border border-ink-200 p-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-ink-900">
                          {lesson.title}
                        </p>
                        <p className="text-xs text-ink-500">
                          {lesson.unit.title}
                          {p?.lastViewedAt
                            ? ` · آخر مشاهدة ${formatDate(p.lastViewedAt)}`
                            : ""}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 text-xs font-bold tabular-nums ${
                          p?.completed
                            ? "text-emerald-700"
                            : p
                              ? "text-brand-700"
                              : "text-ink-400"
                        }`}
                      >
                        {p?.completed
                          ? "مكتمل ✓"
                          : p
                            ? `${Math.round(p.watchPercent)}%`
                            : "لم يبدأ"}
                      </span>
                    </div>
                    <div className="mt-2">
                      <ProgressBar
                        percent={p?.completed ? 100 : (p?.watchPercent ?? 0)}
                        size="sm"
                        tone={p?.completed ? "green" : "brand"}
                      />
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      )}
    </div>
  );
}