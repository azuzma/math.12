import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { DashboardShell } from "@/components/dashboard/sidebar";
import { studentNav } from "@/lib/navigation";
import { PLATFORM } from "@/lib/platform";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  // الأستاذ والمدير لهم لوحتهم الخاصة
  if (user?.role === "ADMIN" || user?.role === "TEACHER" || user?.role === "OWNER") {
    redirect("/admin");
  }

  // الزائر غير المسجّل: نعرض له المنصة بشكلها العام بدل redirect قاسٍ،
  // فيتصفّح الأقسام كما في الموقع الحكومي، والتسجيل مطلوب فقط عند التفاعل.
  if (!user) {
    return (
      <DashboardShell
        user={{
          fullName: "زائر",
          role: "GUEST",
          gradeNameAr: PLATFORM.gradeNameAr,
          planName: "زائر",
          isPaid: false,
        }}
        groups={studentNav(0)}
        title="لوحة الطالب"
        subtitle={PLATFORM.gradeShort}
        guest
      >
        {children}
      </DashboardShell>
    );
  }

  const [unread, ent] = await Promise.all([
    prisma.notification.count({ where: { userId: user.id, readAt: null } }),
    getEntitlement(user.id),
  ]);

  return (
    <DashboardShell
      user={{
        fullName: user.fullName,
        role: user.role,
        gradeNameAr: user.gradeNameAr,
        planName: ent.planName,
        isPaid: ent.isPaid,
      }}
      groups={studentNav(unread)}
      title="لوحة الطالب"
      subtitle={PLATFORM.gradeShort}
    >
      {children}
    </DashboardShell>
  );
}
