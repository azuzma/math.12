import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import {
  FileText,
  Download,
  Printer,
  BookMarked,
  Lock,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { AccessBadge } from "@/components/ui/badges";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { FileActions } from "@/components/dashboard/file-actions";
import { formatBytes } from "@/lib/utils";
import { PLATFORM } from "@/lib/platform";
import { getViewerContext } from "@/lib/auth/viewer";

export const metadata: Metadata = { title: "أوراق العمل" };

const KIND_LABELS: Record<string, string> = {
  WORKSHEET: "ورقة عمل",
  SUMMARY: "ملخص",
  ANSWERS: "حل نموذجي",
  ASSIGNMENT: "واجب",
  OTHER: "ملف",
};

export default async function WorksheetsPage({
  searchParams,
}: {
  searchParams: Promise<{ kind?: string; unit?: string }>;
}) {
  const { user, userId, gradeId, ent } = await getViewerContext();

  const sp = await searchParams;

  if (!ent.canDownloadAllFiles) {
    return (
      <div className="space-y-6">
        <header>
          <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
            <FileText className="h-6 w-6 text-brand-600" />
            أوراق العمل
          </h1>
          <p className="mt-1 text-sm text-ink-600">
            أوراق عمل وملخصات {PLATFORM.gradeShort} قابلة للتنزيل والطباعة.
          </p>
        </header>

        <div className="card grid place-items-center p-10 text-center">
          <Lock className="h-9 w-9 text-ink-400" />
          <h2 className="mt-3 font-bold text-ink-900">
            أوراق العمل متاحة في الباقة الأساسية فما فوق
          </h2>
          <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-600">
            أوراق العمل والملخصات من منهج {PLATFORM.gradeShort} مع التحميل
            والطباعة — اشترك لتفتحها كاملة.
          </p>
          <ButtonLink href="/pricing" className="mt-5">
            عرض الباقات
          </ButtonLink>
        </div>
      </div>
    );
  }

  const files = await prisma.fileAsset.findMany({
    where: {
      status: "PUBLISHED",
      ...(sp.kind ? { kind: sp.kind as "WORKSHEET" } : {}),
      ...(sp.unit ? { unitId: sp.unit } : {}),
    },
    orderBy: [{ unit: { order: "asc" } }, { createdAt: "desc" }],
    take: 200,
    include: {
      lesson: { select: { slug: true, title: true } },
      unit: {
        select: {
          title: true,
          term: { select: { title: true } },
        },
      },
    },
  });

  const units = await prisma.unit.findMany({
    where: { status: "PUBLISHED" },
    orderBy: { order: "asc" },
    select: { id: true, title: true },
  });

  const kinds = ["WORKSHEET", "SUMMARY", "ANSWERS", "OTHER"] as const;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <BookMarked className="h-6 w-6 text-brand-600" />
          أوراق العمل
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          أوراق عمل وملخصات وحلول {PLATFORM.gradeShort} — مربوطة بالوحدات
          والدروس.
        </p>
      </header>

      {/* فلاتر */}
      <form className="flex flex-wrap gap-2">
        <select name="kind" defaultValue={sp.kind ?? ""} className="input w-auto cursor-pointer">
          <option value="">كل الأنواع</option>
          {kinds.map((k) => (
            <option key={k} value={k}>
              {KIND_LABELS[k]}
            </option>
          ))}
        </select>
        <select name="unit" defaultValue={sp.unit ?? ""} className="input w-auto min-w-56 cursor-pointer">
          <option value="">كل الوحدات</option>
          {units.map((u) => (
            <option key={u.id} value={u.id}>
              {u.title}
            </option>
          ))}
        </select>
        <button type="submit" className="btn btn-outline">
          تصفية
        </button>
      </form>

      {files.length === 0 ? (
        <EmptyState
          title="لا توجد أوراق عمل"
          description="لم يُنشر أي ملف في هذه التصفية بعد."
          icon={<FileText className="h-6 w-6" />}
          action={<ButtonLink href="/dashboard/lessons">تصفح الدروس</ButtonLink>}
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {files.map((file) => {
            const locked = !file.isFree && !ent.canDownloadAllFiles;
            return (
              <li key={file.id}>
                <div className="card flex h-full flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="font-bold text-ink-900">{file.title}</h2>
                        <AccessBadge isFree={file.isFree} />
                      </div>
                      <p className="mt-1 text-xs text-ink-500">
                        {KIND_LABELS[file.kind] ?? file.kind}
                        {file.lesson ? ` · ${file.lesson.title}` : ""}
                        {file.unit ? ` · ${file.unit.title}` : ""}
                      </p>
                      {file.unit?.term ? (
                        <p className="text-xs text-ink-400">
                          {file.unit.term.title}
                        </p>
                      ) : null}
                    </div>
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-rose-50 text-rose-600">
                      <FileText className="h-5 w-5" />
                    </span>
                  </div>

                  {file.description ? (
                    <p className="mt-2 line-clamp-2 flex-1 text-sm text-ink-600">
                      {file.description}
                    </p>
                  ) : (
                    <div className="flex-1" />
                  )}

                  <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                    {file.sizeBytes > 0 ? (
                      <span>{formatBytes(file.sizeBytes)}</span>
                    ) : null}
                    {file.pageCount ? (
                      <span className="inline-flex items-center gap-1">
                        <Printer className="h-3 w-3" />
                        {file.pageCount} صفحة
                      </span>
                    ) : null}
                    <span className="inline-flex items-center gap-1">
                      <Download className="h-3 w-3" />
                      {file.downloadCount} تحميل
                    </span>
                  </div>

                  <div className="mt-4">
                    <FileActions
                      fileId={file.id}
                      locked={locked}
                      lessonSlug={file.lesson?.slug ?? null}
                    />
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}