import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { ButtonLink, Alert, EmptyState } from "@/components/ui/buttons";
import { SubscriptionBadge } from "@/components/ui/badges";
import { isPaymentConfigured, activeProvider } from "@/lib/payments/provider";
import { formatDate, formatDateTime, formatPrice } from "@/lib/utils";

export const metadata = { title: "الاشتراك" };

export default async function SubscriptionPage({
  searchParams,
}: {
  searchParams: Promise<{ checkout?: string }>;
}) {
  const { checkout } = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/subscription");

  const [ent, subs] = await Promise.all([
    getEntitlement(user.id),
    prisma.subscription.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      include: { plan: true },
      take: 10,
    }),
  ]);

  const current = subs.find(
    (s) =>
      (s.status === "ACTIVE" || s.status === "TRIAL") &&
      s.currentPeriodEnd > new Date(),
  );

  const daysLeft = current
    ? Math.ceil((current.currentPeriodEnd.getTime() - Date.now()) / 86400_000)
    : null;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">الاشتراك</h1>
        <p className="mt-1 text-sm text-ink-600">
          حالة اشتراكك وتاريخ التجديد.
        </p>
      </header>

      {checkout === "success" ? (
        <Alert tone="success" title="تم استلام الدفع">
          جارٍ تفعيل اشتراكك. إن لم تتحدث الحالة خلال دقيقة، أعد تحميل الصفحة. في حال
          خصم المبلغ ولم يُفعَّل الاشتراك تواصل معنا عبر زر التواصل في أسفل الموقع.
        </Alert>
      ) : null}

      {/* الحالة الحالية */}
      <section className="card overflow-hidden">
        <div
          className={`px-6 py-8 text-white ${
            ent.isPaid
              ? "bg-gradient-to-l from-brand-700 to-brand-500"
              : "bg-gradient-to-l from-ink-700 to-ink-500"
          }`}
        >
          <p className="text-sm text-white/70">باقتك الحالية</p>
          <h2 className="mt-1 text-2xl font-bold">{ent.planName}</h2>

          {ent.expiresAt ? (
            <p className="mt-2 text-sm text-white/80">
              {daysLeft !== null && daysLeft > 0
                ? `متبقٍ ${daysLeft} يوم — تنتهي في ${formatDate(ent.expiresAt)}`
                : `تنتهي في ${formatDate(ent.expiresAt)}`}
            </p>
          ) : (
            <p className="mt-2 text-sm text-white/80">
              اشتراك دائم — لا يحتاج تجديدًا
            </p>
          )}
        </div>

        <div className="grid gap-4 p-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              label: "الدروس والفيديوهات",
              ok: ent.canViewPaidContent,
              note: ent.canViewPaidContent ? "كل الدروس مفتوحة" : "الوحدة الأولى مجانية",
            },
            {
              label: "أوراق العمل والملفات",
              ok: ent.canDownloadAllFiles,
              note: ent.canDownloadAllFiles ? "قابلة للتنزيل والطباعة" : "الباقة الأساسية فما فوق",
            },
            {
              label: "الاختبارات الكاملة",
              ok: ent.canTakeExams,
              note: ent.canTakeExams ? "كل الأنواع متاحة" : "اختبارات الدرس المجانية فقط",
            },
            {
              label: "بنك الأسئلة",
              ok: ent.canUseQuestionBank,
              note: ent.canUseQuestionBank ? "تدريب بلا حدود" : "الباقة المميزة",
            },
            {
              label: "التحليل الذكي (مستواي)",
              ok: ent.canSeeAnalysis,
              note: ent.canSeeAnalysis ? "نقاط القوة وما يحتاج مراجعة" : "الباقة المميزة",
            },
            {
              label: "خطة الدراسة",
              ok: ent.canSeeStudyPlan,
              note: ent.canSeeStudyPlan ? "خطة أسبوعية مخصّصة" : "الباقة المميزة",
            },
            {
              label: "مساعد الرياضيات",
              ok: ent.canUseTutor,
              note: ent.canUseTutor ? "شرح خطوة بخطوة" : "الباقة المميزة",
            },
            {
              label: "الحلول النموذجية",
              ok: ent.canViewSolutions,
              note: ent.canViewSolutions ? "بعد كل اختبار" : "الباقة المميزة",
            },
          ].map((f) => (
            <div key={f.label} className="rounded-xl bg-ink-50 p-4">
              <p
                className={`text-sm font-bold ${
                  f.ok ? "text-emerald-700" : "text-ink-500"
                }`}
              >
                {f.ok ? "✓" : "✕"} {f.label}
              </p>
              <p className="mt-1 text-xs text-ink-500">{f.note}</p>
            </div>
          ))}
        </div>

        <div className="border-t border-ink-100 p-6 text-center">
          {ent.isPaid ? (
            <ButtonLink href="/pricing" variant="outline">
              ترقية أو تغيير الباقة
            </ButtonLink>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-ink-600">
                اشترك الآن لفتح كل الدروس والاختبارات والحلول النموذجية.
              </p>
              <ButtonLink href="/pricing">عرض الباقات</ButtonLink>
            </div>
          )}
        </div>
      </section>

      {!isPaymentConfigured() ? (
        <Alert tone="warn" title="الدفع الإلكتروني غير مفعّل بعد">
          الدفع الإلكتروني غير مفعّل بعد — تواصل مع إدارة المنصة لتفعيل اشتراكك.
        </Alert>
      ) : null}

      {/* سجل الاشتراكات */}
      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">سجل الاشتراكات</h2>

        {subs.length === 0 ? (
          <EmptyState
            title="لم تشترك بعد"
            description="اختر باقة مناسبة من صفحة الاشتراكات."
          />
        ) : (
          <ul className="space-y-2.5">
            {subs.map((s) => (
              <li
                key={s.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-200 p-4"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-ink-900">{s.plan.nameAr}</p>
                  <p className="text-xs text-ink-500">
                    {s.billingCycle === "monthly" ? "شهري" : "سنوي"} ·{" "}
                    {formatDate(s.currentPeriodStart)} — {formatDate(s.currentPeriodEnd)}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-ink-900 tabular-nums">
                    {formatPrice(s.amount, s.currency)}
                  </span>
                  <SubscriptionBadge status={s.status} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ملاحظات */}
      <section className="card p-5">
        <h2 className="mb-3 text-base font-bold text-ink-900">ملاحظات مهمة</h2>
        <ul className="space-y-2 text-sm leading-relaxed text-ink-600">
          <li>• يتم التجديد تلقائيًا عند اكتمال الفترة إذا كان الاشتراك شهريًا أو سنويًا.</li>
          <li>• يمكنك الإلغاء في أي وقت، وتحتفظ بوصولك حتى نهاية الفترة المدفوعة.</li>
          <li>• إذا فشل الدفع، يتوقف الوصول تلقائيًا حتى تُحدّث بيانات البطاقة.</li>
          <li>• سجل المدفوعات الكامل متاح في صفحة «المدفوعات».</li>
        </ul>
        {subs[0] ? (
          <p className="mt-4 text-xs text-ink-400">
            آخر تحديث: {formatDateTime(subs[0].updatedAt)}
          </p>
        ) : null}
      </section>
    </div>
  );
}