import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { ClipboardCheck, Clock, Trophy, ArrowLeft, Lock } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { AccessBadge, ScoreBadge } from "@/components/ui/badges";
import { EmptyState, ButtonLink, Alert } from "@/components/ui/buttons";
import { formatDate } from "@/lib/utils";
import { EXAM_TYPES, EXAM_TYPE_MAP } from "@/lib/platform";
import type { ExamType } from "@/generated/prisma/client";
import { getViewerContext } from "@/lib/auth/viewer";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

export const metadata: Metadata = { title: "الاختبارات" };

export default async function ExamsPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string; unit?: string; term?: string }>;
}) {
  const { user, userId, gradeId, ent } = await getViewerContext();

  const sp = await searchParams;

  const activeType = EXAM_TYPES.find((t) => t.value === sp.type)?.value;

  const [exams, typeCounts] = await Promise.all([
    gradeId
      ? prisma.exam.findMany({
          where: {
            status: "PUBLISHED",
            ...(activeType ? { type: activeType as ExamType } : {}),
            ...(sp.unit ? { unitId: sp.unit } : {}),
            ...(sp.term ? { termId: sp.term } : {}),
            OR: [
              { unit: { course: { subject: { gradeId: gradeId } } } },
              {
                lesson: {
                  unit: { course: { subject: { gradeId: gradeId } } },
                },
              },
              { term: { course: { subject: { gradeId: gradeId } } } },
            ],
          },
          orderBy: [{ type: "asc" }, { createdAt: "desc" }],
          include: {
            lesson: { select: { slug: true, title: true } },
            unit: { select: { title: true } },
            term: { select: { title: true } },
            _count: { select: { questions: true } },
            attempts: {
              where: {
                studentId: userId ?? "",
                submittedAt: { gte: SUBMITTED_EPOCH },
              },
              orderBy: { submittedAt: "desc" },
              take: 1,
            },
          },
        })
      : Promise.resolve([]),

    gradeId
      ? prisma.exam.groupBy({
          by: ["type"],
          where: {
            status: "PUBLISHED",
            OR: [
              { unit: { course: { subject: { gradeId: gradeId } } } },
              {
                lesson: {
                  unit: { course: { subject: { gradeId: gradeId } } },
                },
              },
              { term: { course: { subject: { gradeId: gradeId } } } },
            ],
          },
          _count: { type: true },
        })
      : Promise.resolve([]),
  ]);

  const totalCount = typeCounts.reduce((s, c) => s + c._count.type, 0);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">الاختبارات</h1>
        <p className="mt-1 text-sm text-ink-600">
          ستة أنواع: درس، وحدة، فصل دراسي، شامل، مراجعة، وتجريبي — اختر ما يناسب
          مرحلتك.
        </p>
      </header>

      {/* فلتر النوع */}
      <div className="flex flex-wrap gap-2">
        <Link
          href="/dashboard/exams"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !activeType
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل ({totalCount})
        </Link>
        {EXAM_TYPES.map((t) => {
          const count = typeCounts.find((c) => c.type === t.value)?._count.type ?? 0;
          return (
            <Link
              key={t.value}
              href={`/dashboard/exams?type=${t.value}`}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                activeType === t.value
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {t.icon} {t.label} ({count})
            </Link>
          );
        })}
      </div>

      {!ent.canTakeExams ? (
        <Alert
          tone="info"
          title="الباقة الحالية لا تشمل الاختبارات الكاملة"
          action={
            <ButtonLink href="/pricing" size="sm">
              ترقية الباقة
            </ButtonLink>
          }
        >
          يمكنك خوض الاختبارات المجانية فقط، أو الترقية لفتح جميع الاختبارات
          والحلول النموذجية.
        </Alert>
      ) : null}

      {exams.length === 0 ? (
        <EmptyState
          title="لا توجد اختبارات"
          description={
            gradeId
              ? "لم يُنشر اختبار في هذا التصنيف بعد."
              : "حدّث بياناتك من صفحة حسابي لتظهر لك الاختبارات."
          }
          icon={<ClipboardCheck className="h-6 w-6" />}
          action={<ButtonLink href="/dashboard/profile">تحديث حسابي</ButtonLink>}
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {exams.map((exam) => {
            const lastAttempt = exam.attempts[0];
            const typeMeta = EXAM_TYPE_MAP[exam.type];
            const locked = !exam.isFree && !ent.canTakeExams;
            // للزائر: تسجيل الدخول مطلوب قبل بدء الاختبار
            const href = !user
              ? "/login?next=/dashboard/exams"
              : locked
                ? "/pricing"
                : `/dashboard/exams/${exam.id}`;

            return (
              <li key={exam.id}>
                <Link
                  href={href}
                  className="card flex h-full flex-col p-5 transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="font-bold text-ink-900">{exam.title}</h2>
                        <AccessBadge isFree={exam.isFree} />
                      </div>
                      <p className="mt-1 truncate text-xs text-ink-500">
                        {typeMeta ? `${typeMeta.icon} ${typeMeta.label} · ` : ""}
                        {exam.lesson?.title ??
                          exam.unit?.title ??
                          exam.term?.title ??
                          "اختبار عام"}
                      </p>
                    </div>
                    {locked ? (
                      <Lock className="h-4 w-4 shrink-0 text-ink-400" />
                    ) : (
                      <ClipboardCheck className="h-5 w-5 shrink-0 text-emerald-600" />
                    )}
                  </div>

                  {exam.description ? (
                    <p className="mt-2 line-clamp-2 flex-1 text-sm text-ink-600">
                      {exam.description}
                    </p>
                  ) : (
                    <div className="flex-1" />
                  )}

                  <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                    <span className="inline-flex items-center gap-1">
                      <Trophy className="h-3.5 w-3.5" />
                      {exam._count.questions} سؤال
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {exam.durationMinutes} دقيقة
                    </span>
                    <span>
                      {exam.attemptsAllowed} محاولات
                      {lastAttempt ? " · استخدمت 1" : ""}
                    </span>
                  </div>

                  {lastAttempt ? (
                    <div className="mt-3 flex items-center justify-between rounded-lg bg-ink-50 px-3 py-2">
                      <span className="text-xs text-ink-500">
                        آخر محاولة {formatDate(lastAttempt.submittedAt)}
                      </span>
                      <ScoreBadge percentage={Math.round(lastAttempt.percentage)} />
                    </div>
                  ) : null}

                  <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-700">
                    {locked ? "يتطلب باقة" : "ابدأ الاختبار"}
                    <ArrowLeft className="h-4 w-4" />
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}