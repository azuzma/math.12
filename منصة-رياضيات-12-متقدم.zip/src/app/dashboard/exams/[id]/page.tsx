import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ClipboardCheck, Clock, Trophy, ArrowLeft, Lock } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { AccessBadge, ScoreBadge } from "@/components/ui/badges";
import { Alert, ButtonLink, EmptyState } from "@/components/ui/buttons";
import { ExamStartButton } from "@/app/api/exams/[id]/start/start-form";
import { formatDateTime } from "@/lib/utils";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const exam = await prisma.exam.findUnique({
    where: { id },
    select: { title: true },
  });
  return { title: exam?.title ?? "اختبار", robots: { index: false, follow: false } };
}

export default async function ExamStartPage({ params }: Props) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/exams/[id]");

  const exam = await prisma.exam.findFirst({
    where: { id, status: "PUBLISHED" },
    include: {
      lesson: { select: { slug: true, title: true } },
      unit: { select: { title: true, course: { include: { subject: true } } } },
      questions: { select: { points: true, question: { select: { points: true } } } },
      attempts: {
        where: { studentId: user.id },
        orderBy: { attemptNumber: "desc" },
      },
    },
  });

  if (!exam) notFound();

  const ent = await getEntitlement(user.id);

  if (!exam.isFree && !ent.canTakeExams) {
    return (
      <div className="space-y-5">
        <Alert tone="warn" title="هذا الاختبار متاح في الباقة المميزة">
          باقتك الحالية لا تشمل الاختبارات الكاملة. يمكنك ترقية باقتك أو خوض
          الاختبارات المجانية.
        </Alert>
        <div className="flex flex-wrap gap-3">
          <ButtonLink href="/pricing">عرض الباقات</ButtonLink>
          <ButtonLink href="/dashboard/exams" variant="outline">
            الاختبارات المتاحة لي
          </ButtonLink>
        </div>
      </div>
    );
  }

  const totalPoints = exam.questions.reduce(
    (sum, q) => sum + (q.points || q.question.points),
    0,
  );
  const submitted = exam.attempts.filter((a) => a.submittedAt !== null);
  const attemptsLeft = Math.max(0, exam.attemptsAllowed - submitted.length);
  const best = submitted.reduce((m, a) => Math.max(m, a.percentage), 0);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <nav className="flex items-center gap-2 text-xs text-ink-500">
        <Link href="/dashboard/exams" className="hover:text-brand-700">
          الاختبارات
        </Link>
        <span aria-hidden>/</span>
        <span className="truncate text-ink-800">{exam.title}</span>
      </nav>

      <div className="card overflow-hidden">
        <div className="bg-gradient-to-l from-brand-600 to-brand-700 px-6 py-8 text-white sm:px-8">
          <div className="flex flex-wrap items-center gap-2">
            <ClipboardCheck className="h-5 w-5" />
            <AccessBadge isFree={exam.isFree} />
          </div>
          <h1 className="mt-3 text-2xl font-bold">{exam.title}</h1>
          {exam.lesson ? (
            <p className="mt-1 text-sm text-white/70">على درس: {exam.lesson.title}</p>
          ) : exam.unit ? (
            <p className="mt-1 text-sm text-white/70">
              {exam.unit.course.subject.nameAr} · {exam.unit.title}
            </p>
          ) : null}
        </div>

        <div className="p-6 sm:p-8">
          {exam.description ? (
            <p className="leading-relaxed text-ink-700">{exam.description}</p>
          ) : null}

          <dl className="mt-6 grid gap-4 sm:grid-cols-4">
            {[
              { label: "عدد الأسئلة", value: exam.questions.length, icon: Trophy },
              { label: "الدرجة الكلية", value: totalPoints, icon: ClipboardCheck },
              { label: "المدة", value: `${exam.durationMinutes} دقيقة`, icon: Clock },
              { label: "المحاولات المتبقية", value: attemptsLeft, icon: Clock },
            ].map((item) => (
              <div key={item.label} className="rounded-xl bg-ink-50 p-4">
                <item.icon className="h-4 w-4 text-brand-600" />
                <dd className="mt-1.5 text-lg font-bold text-ink-900 tabular-nums">
                  {item.value}
                </dd>
                <dt className="text-xs text-ink-500">{item.label}</dt>
              </div>
            ))}
          </dl>

          {exam.instructions ? (
            <div className="mt-6 rounded-xl border border-brand-100 bg-brand-50 p-4">
              <p className="text-sm font-semibold text-brand-900">تعليمات</p>
              <p className="mt-1 text-sm leading-relaxed text-brand-800">
                {exam.instructions}
              </p>
            </div>
          ) : null}

          <div className="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-4">
            <p className="text-sm font-semibold text-amber-900">قبل أن تبدأ</p>
            <ul className="mt-2 space-y-1.5 text-sm text-amber-800">
              <li>• يبدأ المؤقت فور الضغط على زر البدء ولا يتوقف.</li>
              <li>
                • الدرجة تُحتسب تلقائيًا عن طريق الخادم، ولا يمكن التلاعب بها.
              </li>
              <li>• يمكنك مغادرة الصفحة والعودة — إجاباتك محفوظة تلقائيًا.</li>
              <li>• نسبة النجاح {exam.passingScore}%.</li>
            </ul>
          </div>

          {/* المحاولات السابقة */}
          {submitted.length > 0 ? (
            <section className="mt-6">
              <h2 className="text-sm font-bold text-ink-900">محاولاتك السابقة</h2>
              <ul className="mt-3 space-y-2">
                {submitted.map((a) => (
                  <li key={a.id}>
                    <Link
                      href={`/dashboard/exams/${exam.id}/result/${a.id}`}
                      className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 p-3.5 transition-colors hover:border-brand-300"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-ink-900">
                          المحاولة {a.attemptNumber} — {a.passed ? "ناجح" : "لم تجتز"}
                        </p>
                        <p className="text-xs text-ink-500">
                          {formatDateTime(a.submittedAt)} · {a.score} / {a.maxScore}
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <ScoreBadge percentage={Math.round(a.percentage)} />
                        <ArrowLeft className="h-4 w-4 text-ink-300" />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
              {best >= exam.passingScore ? (
                <p className="mt-3 text-sm font-medium text-emerald-700">
                  أفضل نتيجة لك: {Math.round(best)}% — تجاوزت نسبة النجاح.
                </p>
              ) : null}
            </section>
          ) : null}

          <div className="mt-8">
            {attemptsLeft > 0 ? (
              <ExamStartButton examId={exam.id} />
            ) : (
              <EmptyState
                title="استنفدت كل المحاولات"
                description={`يمكنك مراجعة إجاباتك السابقة من القائمة أعلاه. الحد الأقصى ${exam.attemptsAllowed} محاولات.`}
                icon={<Lock className="h-6 w-6" />}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}