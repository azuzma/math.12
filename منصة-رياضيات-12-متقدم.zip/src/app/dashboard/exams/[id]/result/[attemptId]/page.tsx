import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { Trophy, CheckCircle2, XCircle, Clock, RotateCcw, ArrowLeft, FileText } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { ButtonLink, Alert, EmptyState } from "@/components/ui/buttons";
import { ProgressRing } from "@/components/dashboard/progress-bar";
import { formatDateTime } from "@/lib/utils";
import { gradeAnswer } from "@/lib/grading";
import { cn } from "@/lib/utils";

type Props = { params: Promise<{ id: string; attemptId: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { attemptId } = await params;
  const attempt = await prisma.examAttempt.findUnique({
    where: { id: attemptId },
    select: { exam: { select: { title: true } } },
  });
  return {
    title: attempt ? `نتيجة: ${attempt.exam.title}` : "نتيجة الاختبار",
    robots: { index: false, follow: false },
  };
}

export default async function ExamResultPage({ params }: Props) {
  const { id: examId, attemptId } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/exams/[id]/result/[attemptId]");

  const attempt = await prisma.examAttempt.findFirst({
    where: { id: attemptId, examId, studentId: user.id },
    include: {
      exam: {
        include: {
          questions: {
            orderBy: { order: "asc" },
            include: { question: true },
          },
          lesson: { select: { slug: true, title: true } },
        },
      },
    },
  });

  if (!attempt) notFound();

  if (!attempt.submittedAt) {
    redirect(`/dashboard/exams/${examId}/take/${attemptId}`);
  }

  const ent = await getEntitlement(user.id);
  const exam = attempt.exam;
  const answers =
    attempt.answers && typeof attempt.answers === "object"
      ? (attempt.answers as Record<string, unknown>)
      : {};

  const canSeeAnswers = exam.showCorrectAnswers;
  const canSeeSolutions = exam.showSolutions && ent.canViewSolutions;

  // مراجعة كل سؤال
  const reviewed = exam.questions.map((eq, index) => {
    const q = eq.question;
    const given = answers[q.id] ?? null;
    const graded = gradeAnswer(q.type, given, q.correct, q.options);

    const optionList = Array.isArray(q.options)
      ? (q.options as { id: string; text: string }[])
      : [];

    const correctText =
      q.type === "MULTI_TRUE"
        ? (Array.isArray(q.correct) ? (q.correct as string[]) : [])
            .map((cid) => optionList.find((o) => o.id === cid)?.text ?? cid)
            .join("، ")
        : optionList.find((o) => o.id === q.correct)?.text ??
          (q.correct !== null && q.correct !== undefined ? String(q.correct) : "—");

    const givenText =
      q.type === "MULTI_TRUE"
        ? (Array.isArray(given) ? (given as string[]) : [])
            .map((cid) => optionList.find((o) => o.id === cid)?.text ?? String(cid))
            .join("، ")
        : optionList.find((o) => o.id === given)?.text ??
          (given !== null && given !== undefined && given !== ""
            ? String(given)
            : "لم يُجب");

    return {
      index,
      id: q.id,
      text: q.text,
      type: q.type,
      points: eq.points || q.points,
      isCorrect: graded.isCorrect,
      needsReview: graded.needsReview,
      givenText,
      correctText,
      solution: q.solution,
      hint: q.hint,
      options: optionList,
      given,
      correct: q.correct,
    };
  });

  const correctCount = reviewed.filter((r) => r.isCorrect).length;
  const wrongCount = reviewed.filter((r) => !r.isCorrect && !r.needsReview).length;
  const reviewCount = reviewed.filter((r) => r.needsReview).length;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <nav className="flex items-center gap-2 text-xs text-ink-500">
        <Link href="/dashboard/exams" className="hover:text-brand-700">
          الاختبارات
        </Link>
        <span aria-hidden>/</span>
        <span className="truncate text-ink-800">{exam.title}</span>
      </nav>

      {/* بطاقة النتيجة */}
      <div
        className={cn(
          "overflow-hidden rounded-2xl border",
          attempt.passed
            ? "border-emerald-200 bg-emerald-50"
            : "border-amber-200 bg-amber-50",
        )}
      >
        <div className="flex flex-col items-center gap-6 p-8 sm:flex-row sm:justify-center">
          <ProgressRing
            percent={attempt.percentage}
            size={140}
            stroke={12}
            label="النسبة"
          />

          <div className="text-center sm:text-start">
            <span
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold",
                attempt.passed
                  ? "bg-emerald-600 text-white"
                  : "bg-amber-600 text-white",
              )}
            >
              {attempt.passed ? (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  مبروك — اجتزت الاختبار
                </>
              ) : (
                <>
                  <XCircle className="h-3.5 w-3.5" />
                  لم تجتز بعد — نسبة النجاح {exam.passingScore}%
                </>
              )}
            </span>

            <h1 className="mt-3 text-2xl font-bold text-ink-900">
              {attempt.score} / {attempt.maxScore}
            </h1>

            <p className="mt-1.5 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-sm text-ink-600 sm:justify-start">
              <span className="inline-flex items-center gap-1.5">
                <Trophy className="h-4 w-4" />
                {correctCount} صحيحة
              </span>
              <span className="inline-flex items-center gap-1.5 text-rose-700">
                <XCircle className="h-4 w-4" />
                {wrongCount} خاطئة
              </span>
              {reviewCount > 0 ? (
                <span className="inline-flex items-center gap-1.5 text-amber-700">
                  {reviewCount} للتصحيح اليدوي
                </span>
              ) : null}
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                {Math.round(attempt.timeSpentSec / 60)} دقيقة
              </span>
            </p>

            <p className="mt-2 text-xs text-ink-500">
              {formatDateTime(attempt.submittedAt)} · المحاولة {attempt.attemptNumber}
            </p>
          </div>
        </div>
      </div>

      {!attempt.passed ? (
        <Alert
          tone="info"
          title="نصيحة للتطوير"
          action={
            exam.lesson ? (
              <ButtonLink href={`/dashboard/lessons/${exam.lesson.slug}`} size="sm" variant="outline">
                أعد مراجعة الدرس
              </ButtonLink>
            ) : undefined
          }
        >
          راجع الأخطاء في الإجابات أسفل الصفحة، ثم أعد المحاولة. تكرار المحاولة مهم
          لتثبيت المفهوم.
        </Alert>
      ) : null}

      {/* الأزرار */}
      <div className="flex flex-wrap gap-3">
        <ButtonLink href="/dashboard/exams" variant="outline">
          <ArrowLeft className="h-4 w-4" />
          كل الاختبارات
        </ButtonLink>
        <ButtonLink href={`/dashboard/exams/${examId}`} variant="soft">
          <RotateCcw className="h-4 w-4" />
          {attempt.attemptNumber < exam.attemptsAllowed
            ? "محاولة أخرى"
            : "تفاصيل الاختبار"}
        </ButtonLink>
        {exam.lesson ? (
          <ButtonLink href={`/dashboard/lessons/${exam.lesson.slug}`} variant="outline">
            <FileText className="h-4 w-4" />
            أوراق عمل الدرس
          </ButtonLink>
        ) : null}
      </div>

      {/* مراجعة الأسئلة */}
      <section className="space-y-4">
        <h2 className="text-base font-bold text-ink-900">مراجعة الإجابات</h2>

        {reviewed.map((item) => (
          <div
            key={item.id}
            className={cn(
              "card border-s-4 p-5",
              item.isCorrect
                ? "border-s-emerald-500"
                : item.needsReview
                  ? "border-s-amber-500"
                  : "border-s-rose-500",
            )}
          >
            <div className="flex items-start gap-3">
              <span
                className={cn(
                  "grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-bold",
                  item.isCorrect
                    ? "bg-emerald-50 text-emerald-700"
                    : item.needsReview
                      ? "bg-amber-50 text-amber-700"
                      : "bg-rose-50 text-rose-700",
                )}
              >
                {item.isCorrect ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <XCircle className="h-4 w-4" />
                )}
              </span>

              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-ink-500">
                  السؤال {item.index + 1} · {item.points} درجة
                </p>
                <p className="mt-1 leading-loose text-ink-900">{item.text}</p>

                <div className="mt-3 space-y-1.5 text-sm">
                  <p className="flex items-start gap-2">
                    <span className="font-semibold text-ink-500">إجابتك:</span>
                    <span
                      className={cn(
                        "font-medium",
                        item.isCorrect ? "text-emerald-700" : "text-rose-700",
                      )}
                    >
                      {item.givenText}
                    </span>
                  </p>

                  {canSeeAnswers && !item.isCorrect ? (
                    <p className="flex items-start gap-2">
                      <span className="font-semibold text-ink-500">الصحيحة:</span>
                      <span className="font-semibold text-emerald-700">
                        {item.correctText}
                      </span>
                    </p>
                  ) : null}

                  {item.needsReview ? (
                    <p className="text-xs text-amber-700">
                      يُصحّح هذا السؤال يدويًا من قِبل الأستاذ.
                    </p>
                  ) : null}
                </div>

                {canSeeSolutions && item.solution ? (
                  <div className="mt-3 rounded-xl border border-brand-100 bg-brand-50 p-3.5">
                    <p className="text-xs font-bold text-brand-800">الحل النموذجي</p>
                    <p className="mt-1 text-sm leading-relaxed text-brand-900">
                      {item.solution}
                    </p>
                  </div>
                ) : null}

                {!canSeeSolutions && item.solution && !item.isCorrect ? (
                  <p className="mt-2 text-xs text-ink-400">
                    الحل النموذجي متاح في الباقة المميزة.
                  </p>
                ) : null}
              </div>
            </div>
          </div>
        ))}
      </section>

      {attempt.needsReview ? (
        <Alert tone="warn" title="بعض الأسئلة تحتاج تصحيح يدوي">
          الأسئلة المقالية والإجابات القصيرة يراجعها الأستاذ. ستصلك نتيجة نهائية بعد
          التصحيح.
        </Alert>
      ) : null}
    </div>
  );
}