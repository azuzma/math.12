import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { ExamRunner } from "@/components/exams/exam-runner";
import { normalizeOptions } from "@/lib/question-options";

type Props = { params: Promise<{ id: string; attemptId: string }> };

export const metadata: Metadata = {
  title: "أداء الاختبار",
  robots: { index: false, follow: false },
};

export default async function TakeExamPage({ params }: Props) {
  const { id, attemptId } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/dashboard/exams/[id]/take/[attemptId]");

  const attempt = await prisma.examAttempt.findFirst({
    where: { id: attemptId, examId: id, studentId: user.id },
    include: {
      exam: {
        include: {
          questions: {
            orderBy: { order: "asc" },
            include: {
              question: {
                select: {
                  id: true,
                  type: true,
                  text: true,
                  options: true,
                  points: true,
                  hint: true,
                },
              },
            },
          },
        },
      },
    },
  });

  if (!attempt) notFound();

  // مُرسَل مسبقًا → صفحة النتيجة
  if (attempt.submittedAt) {
    redirect(`/dashboard/exams/${id}/result/${attemptId}`);
  }

  const questions = attempt.exam.questions.map((eq) => ({
    id: eq.question.id,
    type: eq.question.type,
    text: eq.question.text,
    options: normalizeOptions(eq.question.type, eq.question.options),
    points: eq.points,
    hint: eq.question.hint,
  }));

  const answers =
    attempt.answers && typeof attempt.answers === "object"
      ? (attempt.answers as Record<string, unknown>)
      : {};

  // الوقت المتبقي محسوب من وقت البدء (يُحفظ في الخادم)
  const deadline = new Date(
    attempt.startedAt.getTime() + attempt.exam.durationMinutes * 60 * 1000,
  );

  return (
    <ExamRunner
      examId={attempt.examId}
      attemptId={attempt.id}
      title={attempt.exam.title}
      durationMinutes={attempt.exam.durationMinutes}
      deadline={deadline.toISOString()}
      startedAt={attempt.startedAt.toISOString()}
      passingScore={attempt.exam.passingScore}
      showCorrectAnswers={attempt.exam.showCorrectAnswers}
      questions={questions}
      initialAnswers={answers}
      resultHref={`/dashboard/exams/${attempt.examId}/result/${attempt.id}`}
    />
  );
}