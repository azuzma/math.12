import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { startCheckout, isPaymentConfigured, activeProvider } from "@/lib/payments/provider";
import { appUrl } from "@/lib/env";

const schema = z.object({
  planSlug: z.string().min(1),
  cycle: z.enum(["monthly", "yearly"]).default("monthly"),
});

/**
 * بدء عملية الشراء. يُنشئ جلسة دفع عند المزوّد ويعيد رابط الدفع.
 * لا يتم تفعيل الاشتراك هنا — التفعيل يتم من الـ webhook بعد نجاح الدفع.
 */
export async function POST(req: Request) {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });
  }

  const { planSlug, cycle } = parsed.data;

  const plan = await prisma.plan.findFirst({
    where: { slug: planSlug, isActive: true },
  });
  if (!plan) {
    return NextResponse.json({ error: "الباقة غير متاحة" }, { status: 404 });
  }

  const amount = cycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice;
  if (amount <= 0) {
    return NextResponse.json(
      { error: "هذه الباقة مجانية — سجّل حسابك مجانًا" },
      { status: 400 },
    );
  }

  if (!isPaymentConfigured()) {
    return NextResponse.json(
      {
        error:
          "لم يتم ربط بوابة دفع بعد. أضف مفاتيح Stripe أو Telr في إعدادات البيئة (راجع دليل الإعداد).",
        code: "PAYMENT_NOT_CONFIGURED",
      },
      { status: 503 },
    );
  }

  // ابحث عن اشتراك سابق لنفس الباقة لنستخدم معرّف العميل
  const existingSub = await prisma.subscription.findFirst({
    where: { userId: guard.user.id, provider: activeProvider() },
    orderBy: { createdAt: "desc" },
    select: { providerCustId: true },
  });

  try {
    const checkout = await startCheckout({
      userId: guard.user.id,
      email: guard.user.email,
      planSlug: plan.slug,
      planName: plan.nameAr,
      cycle,
      amount,
      currency: plan.currency,
      stripePriceId:
        cycle === "monthly" ? plan.stripeMonthlyPriceId : plan.stripeYearlyPriceId,
      telrClientKey:
        cycle === "monthly" ? plan.telrMonthlyClientKey : plan.telrYearlyClientKey,
      successUrl: `${appUrl()}/dashboard/subscription?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancelUrl: `${appUrl()}/pricing?canceled=1`,
    });

    return NextResponse.json({
      url: checkout.url,
      provider: checkout.provider,
    });
  } catch (e) {
    console.error("[billing] فشل إنشاء جلسة الدفع:", e);
    return NextResponse.json(
      {
        error:
          (e as Error).message || "تعذّر بدء عملية الدفع. حاول مرة أخرى.",
      },
      { status: 502 },
    );
  }
}