import { NextResponse } from "next/server";
import { checkEnv } from "@/lib/env";
import { prisma } from "@/lib/db/prisma";

/**
 * فحص صحة الخدمة.
 * - يعرض حالة متغيرات البيئة وقاعدة البيانات.
 * - مفيد لـ Cloud Run وVercel للتأكد أن الإعداد صحيح.
 */
export async function GET() {
  const env = checkEnv();

  let db: { ok: boolean; message: string } = { ok: false, message: "غير متاح" };
  if (env.missing.length === 0) {
    try {
      await prisma.$queryRaw`SELECT 1`;
      db = { ok: true, message: "متصل" };
    } catch (e) {
      db = { ok: false, message: (e as Error).message };
    }
  } else {
    db = { ok: false, message: "DATABASE_URL غير موجود" };
  }

  return NextResponse.json(
    {
      ok: env.missing.length === 0 && db.ok,
      env: { missing: env.missing, warnings: env.warnings },
      database: db,
      ts: new Date().toISOString(),
    },
    { status: 200 },
  );
}
