import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { canAccessLessonContent } from "@/lib/auth/entitlements";
import { storageDriver, createLocalSignedUrl } from "@/lib/storage/provider";
import { z } from "zod";

const schema = z.object({
  fileId: z.string().min(1),
  /** view = عرض داخل المتصفح، download = تنزيل */
  disposition: z.enum(["view", "download"]).default("download"),
});

/**
 * تنزيل ملف PDF / ورقة عمل.
 * 1) تحقق من المستخدم.
 * 2) تحقق من صلاحية الوصول للملف (مجاني / معاينة / اشتراك).
 * 3) أعد رابطًا موقّعًا صالحًا 5 دقائق فقط.
 */
export async function POST(req: Request) {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "معرّف الملف مطلوب" }, { status: 400 });
  }

  const file = await prisma.fileAsset.findUnique({
    where: { id: parsed.data.fileId },
    select: {
      id: true,
      title: true,
      fileName: true,
      storageKey: true,
      isFree: true,
      status: true,
      lesson: { select: { isFree: true, isPreview: true, status: true } },
    },
  });

  if (!file || file.status !== "PUBLISHED") {
    return NextResponse.json({ error: "الملف غير متاح" }, { status: 404 });
  }

  const access = await canAccessLessonContent(guard.user.id, {
    isFree: file.isFree || file.lesson?.isFree || false,
    isPreview: file.lesson?.isPreview,
  });

  if (!access.allowed) {
    return NextResponse.json(
      {
        error: "هذا الملف متاح للمشتركين فقط.",
        code: "SUBSCRIPTION_REQUIRED",
      },
      { status: 403 },
    );
  }

  await prisma.fileAsset.update({
    where: { id: file.id },
    data: { downloadCount: { increment: 1 } },
  });

  await prisma.auditLog.create({
    data: {
      userId: guard.user.id,
      action: "file_download",
      entity: "FileAsset",
      entityId: file.id,
      meta: { title: file.title },
    },
  });

  if (storageDriver() === "supabase") {
    // /render/sign يعيد الملف داخل المتصفح، و/object/sign يُنزّله
    const action = parsed.data.disposition === "view" ? "render/sign" : "object/sign";
    const res = await fetch(
      `${process.env.SUPABASE_URL}/storage/v1/${action}/platform-files/${file.storageKey}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ expiresIn: 300 }),
      },
    );
    if (!res.ok) {
      return NextResponse.json(
        { error: "تعذّر تجهيز رابط التنزيل" },
        { status: 500 },
      );
    }
    const data = (await res.json()) as { signedURL: string };
    const url = data.signedURL.startsWith("http")
      ? data.signedURL
      : `${process.env.SUPABASE_URL}/storage/v1${data.signedURL}`;

    return NextResponse.json({
      url,
      expiresIn: 300,
      fileName: file.fileName,
      title: file.title,
    });
  }

  // التخزين المحلي
  const url = await createLocalSignedUrl(file.storageKey, file.fileName, 300);
  return NextResponse.json({
    url,
    expiresIn: 300,
    fileName: file.fileName,
    title: file.title,
  });
}