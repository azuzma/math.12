import { NextResponse } from "next/server";
import { verifyLocalToken, storageDriver } from "@/lib/storage/provider";
import { prisma } from "@/lib/db/prisma";

/**
 * بثّ ملف من التخزين المحلي بعد التحقق من التوقيع.
 * (يُستخدم فقط عند عدم إعداد Supabase — على VPS أو في التطوير)
 */
export async function GET(req: Request) {
  if (storageDriver() === "supabase") {
    return new NextResponse("Not found", { status: 404 });
  }

  const url = new URL(req.url);
  const key = url.searchParams.get("key") ?? "";
  const token = url.searchParams.get("token") ?? "";
  const download = url.searchParams.get("dl");

  if (!key || !verifyLocalToken(key, token, 300)) {
    return new NextResponse("رابط غير صالح أو منتهي الصلاحية", {
      status: 403,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  // نتحقق أن الملف ما زال موجودًا في قاعدة البيانات
  const file = await prisma.fileAsset.findFirst({
    where: { storageKey: key, status: "PUBLISHED" },
    select: { mimeType: true, fileName: true },
  });
  if (!file) {
    return new NextResponse("الملف غير متاح", { status: 404 });
  }

  const { readObject } = await import("@/lib/storage/provider");
  try {
    const buffer = await readObject(key);
    const asciiName = download?.replace(/[^\x20-\x7E]/g, "_") ?? file.fileName;
    const encoded = encodeURIComponent(download ?? file.fileName);

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": file.mimeType,
        "Content-Length": String(buffer.byteLength),
        "Content-Disposition": `inline; filename="${asciiName}"; filename*=UTF-8''${encoded}`,
        "Cache-Control": "private, max-age=0, no-store",
      },
    });
  } catch {
    return new NextResponse("تعذر قراءة الملف", { status: 404 });
  }
}