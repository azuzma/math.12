import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";

export async function POST(req: Request) {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  let id = "";
  try {
    const body = (await req.json()) as { id?: string };
    id = body.id ?? "";
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  if (!id) {
    return NextResponse.json({ error: "المعرّف مطلوب" }, { status: 400 });
  }

  await prisma.notification.updateMany({
    where: { id, userId: guard.user.id, readAt: null },
    data: { readAt: new Date() },
  });

  return NextResponse.json({ ok: true });
}