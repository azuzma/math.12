import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";

/** تعليم كل إشعارات المستخدم كمقروءة. */
export async function POST() {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  const result = await prisma.notification.updateMany({
    where: { userId: guard.user.id, readAt: null },
    data: { readAt: new Date() },
  });

  revalidatePath("/dashboard/notifications");
  revalidatePath("/dashboard");

  return NextResponse.json({ ok: true, count: result.count });
}