import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { gradeSubmission } from "@/lib/grading";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

const schema = z.object({
  answers: z.record(z.string(), z.unknown()).default({}),
});

type Params = { params: Promise<{ id: string }> };

/** تسليم الواجب وتصحيحه على الخادم. */
export async function POST(req: Request, { params }: Params) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const { id } = await params;

  let body: unknown = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const assignment = await prisma.assignment.findFirst({
    where: { id, status: "PUBLISHED" },
    select: {
      id: true,
      questions: {
        orderBy: { order: "asc" },
        include: {
          question: {
            select: { id: true, type: true, correct: true, points: true },
          },
        },
      },
      submissions: {
        where: { studentId: guard.user.id, submittedAt: { gte: SUBMITTED_EPOCH } },
        select: { id: true },
      },
    },
  });

  if (!assignment) {
    return NextResponse.json({ error: "الواجب غير متاح" }, { status: 404 });
  }

  if (assignment.submissions.length > 0) {
    return NextResponse.json({ error: "تم تسليم هذا الواجب من قبل" }, { status: 409 });
  }

  const questions = assignment.questions.map((eq) => ({
    id: eq.question.id,
    type: eq.question.type,
    correct: eq.question.correct,
    points: eq.points || eq.question.points,
  }));

  const result = gradeSubmission(questions, parsed.data.answers);

  const submission = await prisma.assignmentSubmission.create({
    data: {
      assignmentId: assignment.id,
      studentId: guard.user.id,
      answers: parsed.data.answers as never,
      score: result.score,
      maxScore: result.maxScore,
      autoScore: result.score,
      needsReview: result.needsReview,
    },
  });

  return NextResponse.json({
    ok: true,
    submissionId: submission.id,
    score: result.score,
    maxScore: result.maxScore,
    needsReview: result.needsReview,
  });
}