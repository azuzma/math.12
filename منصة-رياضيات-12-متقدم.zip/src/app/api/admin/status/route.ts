import { NextResponse } from "next/server";
import { changeStatusAction } from "@/app/actions/admin";
import { emptyState } from "@/lib/actions";
import type { NextRequest } from "next/server";

/** تغيير حالة المحتوى (مسودة / منشور / مؤرشف). */
export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const result = await changeStatusAction(emptyState, formData);

  if (!result.ok) {
    return NextResponse.json(
      { ok: false, error: result.message ?? "تعذّر تغيير الحالة" },
      { status: 400 },
    );
  }
  return NextResponse.json({ ok: true, message: result.message });
}