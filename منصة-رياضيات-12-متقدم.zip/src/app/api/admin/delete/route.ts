import { NextResponse } from "next/server";
import { deleteEntityAction } from "@/app/actions/admin";
import { emptyState } from "@/lib/actions";
import type { NextRequest } from "next/server";

/** حذف عنصر — محمي بصلاحية الإدارة على مستوى الخادم. */
export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const result = await deleteEntityAction(emptyState, formData);

  if (!result.ok) {
    return NextResponse.json(
      { ok: false, error: result.message ?? "تعذّر الحذف" },
      { status: result.status ?? 400 },
    );
  }
  return NextResponse.json({ ok: true, message: result.message });
}