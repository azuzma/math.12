import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { getEntitlement } from "@/lib/auth/entitlements";
import { gradeAnswer } from "@/lib/grading";
import { PLATFORM } from "@/lib/platform";
import { normalizeOptions } from "@/lib/question-options";
import { checkQuota, QUOTA_HTTP_STATUS } from "@/lib/quotas";

/**
 * بنك الأسئلة — جلب أسئلة للتدريب.
 *
 * الإجابات الصحيحة لا تُرسل للمتصفح إطلاقًا.
 * التصحيح يتم على الخادم في POST.
 */

const querySchema = z.object({
  termId: z.string().optional(),
  unitId: z.string().optional(),
  skillId: z.string().optional(),
  difficulty: z.enum(["EASY", "MEDIUM", "HARD", "CHALLENGE"]).optional(),
  limit: z.coerce.number().int().min(1).max(30).default(10),
});

const submitSchema = z.object({
  questionIds: z.array(z.string()).min(1).max(30),
  answers: z.record(z.string(), z.unknown()),
  skillId: z.string().optional(),
});

/** للتأكد أن الأسئلة تخص صف المنصة */
const gradeScope = {
  OR: [
    { term: { course: { subject: { grade: { slug: PLATFORM.gradeSlug } } } } },
    { lesson: { unit: { course: { subject: { grade: { slug: PLATFORM.gradeSlug } } } } } },
  ],
};

export async function GET(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const ent = await getEntitlement(guard.user.id);
  if (!ent.canUseQuestionBank) {
    return NextResponse.json(
      {
        error: "بنك الأسئلة متاح في الباقة المميزة.",
        code: "UPGRADE_REQUIRED",
      },
      { status: 403 },
    );
  }

  const quota = await checkQuota(guard.user.id, "questionsPerDay");
  if (!quota.allowed) {
    return NextResponse.json(
      { error: quota.message, code: "QUOTA_EXCEEDED", quota: quota.state },
      { status: QUOTA_HTTP_STATUS.questionsPerDay },
    );
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse({
    termId: url.searchParams.get("termId") ?? undefined,
    unitId: url.searchParams.get("unitId") ?? undefined,
    skillId: url.searchParams.get("skillId") ?? undefined,
    difficulty: url.searchParams.get("difficulty") ?? undefined,
    limit: url.searchParams.get("limit") ?? 10,
  });
  if (!parsed.success) {
    return NextResponse.json({ error: "معايير التصفية غير صالحة" }, { status: 400 });
  }
  const f = parsed.data;

  const rows = await prisma.question.findMany({
    where: {
      isActive: true,
      ...gradeScope,
      ...(f.termId ? { termId: f.termId } : {}),
      ...(f.skillId ? { skillId: f.skillId } : {}),
      ...(f.difficulty ? { difficulty: f.difficulty } : {}),
      ...(f.unitId
        ? {
            OR: [
              { lesson: { unitId: f.unitId } },
              { skill: { unitId: f.unitId } },
            ],
          }
        : {}),
    },
    select: {
      id: true,
      type: true,
      text: true,
      options: true,
      points: true,
      difficulty: true,
      hint: true,
    },
    orderBy: [{ difficulty: "asc" }, { createdAt: "desc" }],
    take: f.limit,
  });

  return NextResponse.json({
    questions: rows.map((q) => ({
      id: q.id,
      type: q.type,
      text: q.text,
      options: normalizeOptions(q.type, q.options),
      points: q.points,
      difficulty: q.difficulty,
      hint: q.hint,
    })),
  });
}

export async function POST(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const ent = await getEntitlement(guard.user.id);
  if (!ent.canUseQuestionBank) {
    return NextResponse.json(
      {
        error: "بنك الأسئلة متاح في الباقة المميزة.",
        code: "UPGRADE_REQUIRED",
      },
      { status: 403 },
    );
  }

  const quota = await checkQuota(guard.user.id, "questionsPerDay");
  if (!quota.allowed) {
    return NextResponse.json(
      { error: quota.message, code: "QUOTA_EXCEEDED", quota: quota.state },
      { status: QUOTA_HTTP_STATUS.questionsPerDay },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = submitSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "أرسل الأسئلة وإجاباتها" }, { status: 400 });
  }
  const { questionIds, answers, skillId } = parsed.data;

  // نجلب الأسئلة ونصّحّها على الخادم — لا نثق بإرسال الدرجة من العميل
  const questions = await prisma.question.findMany({
    where: { id: { in: questionIds }, isActive: true, ...gradeScope },
    select: {
      id: true,
      type: true,
      text: true,
      points: true,
      options: true,
      correct: true,
      solution: true,
      hint: true,
      difficulty: true,
      skillId: true,
      skill: { select: { title: true, unit: { select: { title: true } } } },
    },
  });

  if (questions.length === 0) {
    return NextResponse.json({ error: "لا توجد أسئلة صالحة" }, { status: 400 });
  }

  const showSolutions = ent.canViewSolutions;

  let score = 0;
  let maxScore = 0;
  let correctCount = 0;

  const items = questions.map((q) => {
    const given = answers[q.id] ?? null;
    const graded = gradeAnswer(q.type, given, q.correct, q.options);
    maxScore += q.points;
    if (graded.isCorrect) {
      score += q.points;
      correctCount += 1;
    }
    return {
      questionId: q.id,
      text: q.text,
      type: q.type,
      points: q.points,
      difficulty: q.difficulty,
      skillTitle: q.skill?.title ?? null,
      unitTitle: q.skill?.unit.title ?? null,
      isCorrect: graded.isCorrect,
      needsReview: graded.needsReview,
      given,
      correct: q.correct,
      options: normalizeOptions(q.type, q.options),
      solution: showSolutions ? q.solution : null,
      hint: q.hint,
    };
  });

  const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0;

  // نحفظ الجلسة لتغذية التحليل الذكي
  await prisma.practiceSession.create({
    data: {
      studentId: guard.user.id,
      skillId: skillId ?? questions.find((q) => q.skillId)?.skillId ?? null,
      questionIds: questions.map((q) => q.id),
      answers: answers as never,
      score,
      maxScore,
      correctCount,
      totalCount: questions.length,
      submittedAt: new Date(),
    },
  });

  return NextResponse.json({
    score,
    maxScore,
    percentage,
    correctCount,
    totalCount: questions.length,
    showSolutions,
    items,
  });
}