import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { prisma } from "@/lib/db/prisma";
import { activateSubscription, syncSubscriptionStatus } from "@/lib/payments/activate";
import { notifyExamResult } from "@/lib/notifications";
import { sendReceiptEmail } from "@/lib/email/mailer";

/**
 * استخراج معرّف الاشتراك من الفاتورة.
 * يغطي الحقل القديم (invoice.subscription) والحقل الجديد (parent.subscription_details).
 */
function extractSubscriptionId(invoice: Stripe.Invoice): string | null {
  const legacy = (invoice as unknown as { subscription?: string | { id: string } | null })
    .subscription;
  if (typeof legacy === "string") return legacy;
  if (legacy && typeof legacy === "object" && legacy.id) return legacy.id;

  const parent = (invoice as unknown as {
    parent?: { subscription_details?: { subscription?: string | { id: string } | null } };
  }).parent;
  const fromParent = parent?.subscription_details?.subscription;
  if (typeof fromParent === "string") return fromParent;
  if (fromParent && typeof fromParent === "object" && fromParent.id) return fromParent.id;

  return null;
}

/**
 * Webhook Stripe.
 * إعداد في لوحة Stripe:
 *   URL: https://<نطاقك>/api/webhooks/stripe
 *   Events: checkout.session.completed, customer.subscription.created,
 *           customer.subscription.updated, customer.subscription.deleted,
 *           invoice.payment_succeeded, invoice.payment_failed
 *   Signing secret: يُحفظ في STRIPE_WEBHOOK_SECRET
 */
export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const key = process.env.STRIPE_SECRET_KEY;
  if (!secret || !key) {
    return NextResponse.json(
      { error: "Stripe غير مُعد" },
      { status: 503 },
    );
  }

  const signature = req.headers.get("stripe-signature");
  if (!signature) {
    return NextResponse.json({ error: "توقيع مفقود" }, { status: 400 });
  }

  const raw = await req.text();
  const { default: StripeLib } = await import("stripe");
  const stripe = new StripeLib(key);

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(raw, signature, secret);
  } catch (e) {
    console.error("[stripe:webhook] توقيع غير صالح:", (e as Error).message);
    return NextResponse.json({ error: "توقيع غير صالح" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.userId ?? session.client_reference_id;
        const planSlug = session.metadata?.planSlug;
        if (userId && planSlug) {
          const result = await activateSubscription({
            userId,
            planSlug,
            cycle: (session.metadata?.cycle as "monthly" | "yearly") ?? "monthly",
            amount: Number(session.metadata?.amount ?? 0),
            currency: session.metadata?.currency ?? "AED",
            provider: "stripe",
            providerRef: session.payment_intent?.toString() ?? session.id,
            providerCustId:
              typeof session.customer === "string" ? session.customer : session.customer?.id,
            providerSubId:
              typeof session.subscription === "string"
                ? session.subscription
                : session.subscription?.id,
            invoiceRef: session.id,
            status: "ACTIVE",
          });

          // إيصال بريد
          const user = await prisma.user.findUnique({
            where: { id: userId },
            select: { email: true, fullName: true },
          });
          if (user) {
            await sendReceiptEmail(user.email, user.fullName, {
              planName: result.plan.nameAr,
              amount: Number(session.metadata?.amount ?? 0),
              currency: session.metadata?.currency ?? "AED",
              invoiceRef: session.id,
              date: new Date(),
            }).catch(() => undefined);
          }
        }
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const meta = sub.metadata ?? {};
        const map: Record<string, "ACTIVE" | "TRIAL" | "PAST_DUE" | "CANCELED" | "EXPIRED" | "INCOMPLETE"> =
          {
            active: "ACTIVE",
            trialing: "TRIAL",
            past_due: "PAST_DUE",
            canceled: "CANCELED",
            unpaid: "EXPIRED",
            incomplete: "INCOMPLETE",
            incomplete_expired: "EXPIRED",
            paused: "PAST_DUE",
          };

        //ابحث بالمعرّف المخزّن مسبقًا، وإلا ننشئ الاشتراك من بيانات الـ metadata
        const stored = await prisma.subscription.findFirst({
          where: { providerSubId: sub.id },
        });

        if (stored) {
          await syncSubscriptionStatus({
            providerSubId: sub.id,
            status: map[sub.status] ?? "ACTIVE",
            periodStart: new Date(sub.start_date * 1000),
            periodEnd: new Date(
              (sub.items.data[0]?.current_period_end ?? sub.start_date) * 1000,
            ),
          });
        } else if (meta.userId && meta.planSlug) {
          // اشتراك أُنشئ من لوحة Stripe مباشرة
          await activateSubscription({
            userId: meta.userId,
            planSlug: meta.planSlug,
            cycle: (meta.cycle as "monthly" | "yearly") ?? "monthly",
            amount: Number(meta.amount ?? 0),
            currency: meta.currency ?? "AED",
            provider: "stripe",
            providerSubId: sub.id,
            providerCustId:
              typeof sub.customer === "string" ? sub.customer : sub.customer?.id,
            status: map[sub.status] ?? "ACTIVE",
            periodStart: new Date(sub.start_date * 1000),
            periodEnd: new Date(
              (sub.items.data[0]?.current_period_end ?? sub.start_date) * 1000,
            ),
          });
        }
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        // في الإصدارات الحديثة من Stripe انتقل حقل الاشتراك إلى parent
        const subId = extractSubscriptionId(invoice);

        if (subId) {
          await prisma.subscription.updateMany({
            where: { providerSubId: subId },
            data: {
              status: "ACTIVE",
              currentPeriodStart: new Date(
                (invoice.period_start ?? Math.floor(Date.now() / 1000)) * 1000,
              ),
              currentPeriodEnd: new Date(
                (invoice.period_end ?? Math.floor(Date.now() / 1000)) * 1000,
              ),
            },
          });

          const sub = await prisma.subscription.findFirst({
            where: { providerSubId: subId },
            include: { user: { select: { email: true, fullName: true } }, plan: true },
          });
          if (sub) {
            await prisma.payment.create({
              data: {
                userId: sub.userId,
                subscriptionId: sub.id,
                planId: sub.planId,
                planSnapshot: {
                  slug: sub.plan.slug,
                  nameAr: sub.plan.nameAr,
                  tier: sub.plan.tier,
                } as never,
                provider: "stripe",
                providerRef: invoice.id,
                invoiceRef: invoice.number,
                amount: (invoice.amount_paid ?? 0) / 100,
                currency: (invoice.currency ?? "aed").toUpperCase(),
                status: "SUCCEEDED",
                paidAt: new Date(),
              },
            });

            await sendReceiptEmail(sub.user.email, sub.user.fullName, {
              planName: sub.plan.nameAr,
              amount: (invoice.amount_paid ?? 0) / 100,
              currency: (invoice.currency ?? "aed").toUpperCase(),
              invoiceRef: invoice.number ?? invoice.id,
              date: new Date(),
            }).catch(() => undefined);
          }
        }
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const subId = extractSubscriptionId(invoice);
        if (subId) {
          await syncSubscriptionStatus({
            providerSubId: subId,
            status: "PAST_DUE",
          });
        }
        break;
      }

      default:
        break;
    }
  } catch (e) {
    console.error(`[stripe:webhook] فشل معالجة ${event.type}:`, e);
    // نعيد 500 حتى يعيد Stripe المحاولة
    return NextResponse.json({ error: "خطأ في المعالجة" }, { status: 500 });
  }

  void notifyExamResult; // مستخدم في webhooks أخرى
  return NextResponse.json({ received: true });
}