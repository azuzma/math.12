import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/db/prisma";
import { activateSubscription, syncSubscriptionStatus } from "@/lib/payments/activate";
import { sendReceiptEmail } from "@/lib/email/mailer";

/**
 * Webhook Telr.
 * إعداد في لوحة Telr:
 *   Callback URL: https://<نطاقك>/api/webhooks/telr
 *   Secret: يُحفظ في TELR_WEBHOOK_SECRET (تتحقق منه في التوقيع)
 *
 * ملاحظة: توثيق Telr يختلف حسب نوع الحساب. في بعض الحسابات يُرسل التوقيع
 * في الترويسة `Signature` كرابط base64 لـ HMAC-SHA1 من الحقول.
 * إن لم يكن لديك سر توقيع، فعّل TELR_WEBHOOK_SECRET وأرسل نفس القيمة
 * من لوحة Telr للتحقق من المصدر.
 */

function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

export async function POST(req: Request) {
  const apiKey = process.env.TELR_API_KEY;
  if (!apiKey) {
    return NextResponse.json({ error: "Telr غير مُعد" }, { status: 503 });
  }

  const raw = await req.text();
  const signature = req.headers.get("signature") ?? req.headers.get("x-signature");

  // التحقق من التوقيع إن كان السر مضبوطًا
  if (process.env.TELR_WEBHOOK_SECRET) {
    if (!signature) {
      return NextResponse.json({ error: "توقيع مفقود" }, { status: 401 });
    }
    const expected = createHmac(
      "sha256",
      process.env.TELR_WEBHOOK_SECRET,
    )
      .update(raw)
      .digest("base64");
    if (!safeEqual(signature, expected)) {
      // نحاول SHA1 أيضًا لأن بعض إعدادات Telr تستخدمه
      const expectedSha1 = createHmac("sha1", process.env.TELR_WEBHOOK_SECRET)
        .update(raw)
        .digest("base64");
      if (!safeEqual(signature, expectedSha1)) {
        return NextResponse.json({ error: "توقيع غير صالح" }, { status: 401 });
      }
    }
  }

  let data: Record<string, unknown>;
  try {
    data = JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: "صيغة غير صالحة" }, { status: 400 });
  }

  // تحليل استجابة Telr المتداخلة
  const inner =
    (data.response as Record<string, unknown> | undefined) ??
    (data.data as Record<string, unknown> | undefined) ??
    data;

  const orderId = String(
    (inner.order_id as string) ?? (inner.orderId as string) ?? "",
  );
  const tranId = String(
    (inner.tran_id as string) ?? (inner.transaction_id as string) ?? "",
  );
  const resultCode = String(
    (inner.result_code as string) ?? (inner.status as string) ?? "",
  ).toUpperCase();

  // نجاح = codes مخصصة لـ Telr
  const successCodes = ["A", "P", "H", "V", "SUCCESS", "200", "CAPTURED"];
  const isSuccess = successCodes.includes(resultCode);

  // بيانات المستخدم المخصصة التي أرسلناها عند إنشاء الطلب
  const define = (inner.user_define ?? inner.userDefine) as
    | Record<string, string>
    | undefined;
  const userId = define?.userId ?? (inner.customer_id as string | undefined);
  const planSlug = define?.planSlug;
  const cycle = (define?.cycle as "monthly" | "yearly") ?? "monthly";

  if (!userId || !planSlug) {
    // لا نعرف صاحب العملية — نسجلها كمرجع فقط
    console.warn("[telr:webhook] الطلب بدون بيانات مستخدم:", orderId);
    return NextResponse.json({ received: true, matched: false });
  }

  if (!isSuccess) {
    await prisma.payment.create({
      data: {
        userId,
        provider: "telr",
        providerRef: tranId || orderId,
        invoiceRef: orderId,
        amount: Number(define?.amount ?? 0),
        currency: define?.currency ?? "AED",
        status: "FAILED",
        failureReason: resultCode || "unknown",
      },
    });
    return NextResponse.json({ received: true, matched: true, activated: false });
  }

  const amount = Number(define?.amount ?? 0);
  const result = await activateSubscription({
    userId,
    planSlug,
    cycle,
    amount,
    currency: define?.currency ?? "AED",
    provider: "telr",
    providerRef: tranId || orderId,
    invoiceRef: orderId,
    method: String((inner.card_type as string) ?? "card").slice(0, 30),
    cardLast4:
      typeof inner.card_last4 === "string" ? inner.card_last4.slice(-4) : null,
    cardBrand:
      typeof inner.card_type === "string" ? inner.card_type.slice(0, 30) : null,
    status: "ACTIVE",
  });

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { email: true, fullName: true },
  });
  if (user) {
    await sendReceiptEmail(user.email, user.fullName, {
      planName: result.plan.nameAr,
      amount,
      currency: define?.currency ?? "AED",
      invoiceRef: orderId,
      date: new Date(),
    }).catch(() => undefined);
  }

  void syncSubscriptionStatus;
  return NextResponse.json({ received: true, matched: true, activated: true });
}