import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { searchContent } from "@/lib/content";

const schema = z.object({
  q: z.string().trim().min(1).max(120),
});

/** بحث موحّد: دروس، وحدات، اختبارات، ملفات. */
export async function GET(req: Request) {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  const url = new URL(req.url);
  const parsed = schema.safeParse({ q: url.searchParams.get("q") ?? "" });
  if (!parsed.success) {
    return NextResponse.json({ query: "", total: 0, hits: [] });
  }

  const result = await searchContent(parsed.data.q);
  return NextResponse.json(result, {
    headers: { "Cache-Control": "private, max-age=30" },
  });
}