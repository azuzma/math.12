"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, PlayCircle } from "lucide-react";

export function ExamStartButton({ examId }: { examId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function start() {
    setBusy(true);
    try {
      const res = await fetch(`/api/exams/${examId}/start`, { method: "POST" });
      const data = (await res.json()) as {
        attemptId?: string;
        error?: string;
      };

      if (!res.ok || !data.attemptId) {
        toast.error(data.error ?? "تعذّر بدء الاختبار");
        setBusy(false);
        return;
      }
      router.push(`/dashboard/exams/${examId}/take/${data.attemptId}`);
    } catch {
      toast.error("حدث خطأ في الاتصال");
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      onClick={start}
      disabled={busy}
      className="btn btn-primary w-full py-3 text-base sm:w-auto sm:px-10"
    >
      {busy ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          جارٍ البدء…
        </>
      ) : (
        <>
          <PlayCircle className="h-5 w-5" />
          ابدأ الاختبار الآن
        </>
      )}
    </button>
  );
}