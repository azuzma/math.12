import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { getEntitlement } from "@/lib/auth/entitlements";
import { checkQuota, QUOTA_HTTP_STATUS } from "@/lib/quotas";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

type Params = { params: Promise<{ id: string }> };

/** بدء محاولة اختبار: يتحقق من الصلاحيات وعدد المحاولات وينشئ المحاولة. */
export async function POST(req: Request, { params }: Params) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const { id } = await params;

  const exam = await prisma.exam.findFirst({
    where: { id, status: "PUBLISHED" },
    select: {
      id: true,
      title: true,
      isFree: true,
      attemptsAllowed: true,
      durationMinutes: true,
      _count: { select: { questions: true } },
    },
  });

  if (!exam) {
    return NextResponse.json({ error: "الاختبار غير متاح" }, { status: 404 });
  }

  if (exam._count.questions === 0) {
    return NextResponse.json(
      { error: "لا توجد أسئلة في هذا الاختبار بعد" },
      { status: 409 },
    );
  }

  if (!exam.isFree) {
    const ent = await getEntitlement(guard.user.id);
    if (!ent.canTakeExams) {
      return NextResponse.json(
        { error: "هذا الاختبار متاح في الباقة المميزة" },
        { status: 403 },
      );
    }
  }

  // الاختبارات المجانية تجريبية للجميع — لا تخضع لحصة الاختبارات اليومية
  if (!exam.isFree) {
    const quota = await checkQuota(guard.user.id, "examsPerDay");
    if (!quota.allowed) {
      return NextResponse.json(
        { error: quota.message, code: "QUOTA_EXCEEDED", quota: quota.state },
        { status: QUOTA_HTTP_STATUS.examsPerDay },
      );
    }
  }

  const used = await prisma.examAttempt.count({
    where: { examId: exam.id, studentId: guard.user.id, submittedAt: { gte: SUBMITTED_EPOCH } },
  });

  if (used >= exam.attemptsAllowed) {
    return NextResponse.json(
      { error: "استنفدت عدد المحاولات المسموح بها" },
      { status: 429 },
    );
  }

  // محاولة غير مُرسلة موجودة؟ نُعيدها بدل إنشاء محاولة جديدة
  const draft = await prisma.examAttempt.findFirst({
    where: { examId: exam.id, studentId: guard.user.id, submittedAt: null },
    orderBy: { startedAt: "desc" },
    select: { id: true },
  });

  if (draft) {
    return NextResponse.json({ attemptId: draft.id, redirect: `/dashboard/exams/${exam.id}/take/${draft.id}` });
  }

  const attemptNumber = used + 1;

  const attempt = await prisma.examAttempt.create({
    data: {
      examId: exam.id,
      studentId: guard.user.id,
      attemptNumber,
      startedAt: new Date(),
      answers: {},
    },
    select: { id: true },
  });

  return NextResponse.json(
    { attemptId: attempt.id },
    { status: 201 },
  );
}