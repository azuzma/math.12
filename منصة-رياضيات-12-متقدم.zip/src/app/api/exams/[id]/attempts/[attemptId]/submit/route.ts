import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { gradeSubmission } from "@/lib/grading";
import { notifyExamResult } from "@/lib/notifications";

const schema = z.object({
  answers: z.record(z.string(), z.unknown()).default({}),
  timeSpentSec: z.coerce.number().int().min(0).max(86400).default(0),
});

type Params = { params: Promise<{ id: string; attemptId: string }> };

/**
 * إرسال الاختبار وتصحيحه على الخادم.
 * الدرجة تُحسب من قاعدة البيانات لا من المتصفح.
 */
export async function POST(req: Request, { params }: Params) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const { id: examId, attemptId } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const attempt = await prisma.examAttempt.findFirst({
    where: { id: attemptId, examId, studentId: guard.user.id },
    include: {
      exam: {
        include: {
          questions: {
            include: {
              question: {
                select: { id: true, type: true, correct: true, points: true },
              },
            },
          },
        },
      },
    },
  });

  if (!attempt) {
    return NextResponse.json({ error: "المحاولة غير موجودة" }, { status: 404 });
  }

  // idempotent: إذا أُرسل مسبقًا نُعيد النتيجة دون إعادة التصحيح
  if (attempt.submittedAt) {
    return NextResponse.json({
      ok: true,
      alreadySubmitted: true,
      attemptId: attempt.id,
      score: attempt.score,
      maxScore: attempt.maxScore,
      percentage: attempt.percentage,
      passed: attempt.passed,
    });
  }

  const questions = attempt.exam.questions.map((eq) => ({
    id: eq.question.id,
    type: eq.question.type,
    correct: eq.question.correct,
    points: eq.points || eq.question.points,
  }));

  const result = gradeSubmission(questions, parsed.data.answers);

  const passed = result.percentage >= attempt.exam.passingScore;

  const updated = await prisma.examAttempt.update({
    where: { id: attempt.id },
    data: {
      answers: parsed.data.answers as never,
      score: result.score,
      maxScore: result.maxScore,
      percentage: result.percentage,
      passed,
      needsReview: result.needsReview,
      timeSpentSec: parsed.data.timeSpentSec,
      submittedAt: new Date(),
    },
    select: {
      id: true,
      score: true,
      maxScore: true,
      percentage: true,
      passed: true,
    },
  });

  await notifyExamResult({
    userId: guard.user.id,
    examTitle: attempt.exam.title,
    percentage: result.percentage,
    passed,
    link: `/dashboard/exams/${examId}/result/${attempt.id}`,
  });

  return NextResponse.json({
    ok: true,
    attemptId: updated.id,
    score: updated.score,
    maxScore: updated.maxScore,
    percentage: updated.percentage,
    passed: updated.passed,
    needsReview: result.needsReview,
  });
}