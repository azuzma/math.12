import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";

const schema = z.object({
  answers: z.record(z.string(), z.unknown()),
});

type Params = { params: Promise<{ id: string; attemptId: string }> };

/** حفظ تلقائي لإجابات الطالب أثناء الاختبار. */
export async function POST(req: Request, { params }: Params) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const { attemptId } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const attempt = await prisma.examAttempt.findFirst({
    where: { id: attemptId, studentId: guard.user.id },
    select: { id: true, submittedAt: true },
  });

  if (!attempt) {
    return NextResponse.json({ error: "المحاولة غير موجودة" }, { status: 404 });
  }

  // لا يمكن التعديل بعد الإرسال
  if (attempt.submittedAt) {
    return NextResponse.json({ error: "تم إرسال الاختبار بالفعل" }, { status: 409 });
  }

  await prisma.examAttempt.update({
    where: { id: attemptId },
    data: { answers: parsed.data.answers as never },
  });

  return NextResponse.json({ ok: true, savedAt: new Date().toISOString() });
}