import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { getEntitlement } from "@/lib/auth/entitlements";
import { checkQuota, QUOTA_HTTP_STATUS } from "@/lib/quotas";
import { activeTutor, tutorGreeting } from "@/lib/tutor";

const schema = z.object({
  question: z.string().trim().min(1).max(2000),
  conversationId: z.string().optional(),
});

export async function GET(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const url = new URL(req.url);
  const conversationId = url.searchParams.get("conversationId");

  if (!conversationId) {
    // قائمة المحادثات
    const conversations = await prisma.tutorConversation.findMany({
      where: { studentId: guard.user.id },
      orderBy: { updatedAt: "desc" },
      take: 30,
      select: { id: true, title: true, messageCount: true, updatedAt: true },
    });
    return NextResponse.json({ conversations });
  }

  const conversation = await prisma.tutorConversation.findFirst({
    where: { id: conversationId, studentId: guard.user.id },
    include: {
      messages: { orderBy: { createdAt: "asc" }, take: 100 },
    },
  });

  if (!conversation) {
    return NextResponse.json({ error: "المحادثة غير موجودة" }, { status: 404 });
  }

  return NextResponse.json({
    id: conversation.id,
    title: conversation.title,
    messages: conversation.messages.map((m) => ({
      role: m.role,
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    })),
  });
}

export async function POST(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const ent = await getEntitlement(guard.user.id);

  // المساعد متاح في الباقة المميزة (أو أثناء التجربة)
  if (!ent.canUseTutor) {
    return NextResponse.json(
      {
        error: "مساعد الرياضيات متاح في الباقة المميزة.",
        code: "UPGRADE_REQUIRED",
        canTrial: false,
      },
      { status: 403 },
    );
  }

  const quota = await checkQuota(guard.user.id, "tutorPerDay");
  if (!quota.allowed) {
    return NextResponse.json(
      { error: quota.message, code: "QUOTA_EXCEEDED", quota: quota.state },
      { status: QUOTA_HTTP_STATUS.tutorPerDay },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "اكتب سؤالك" }, { status: 400 });
  }

  const { question, conversationId } = parsed.data;

  // محادثة جديدة أو متابعة لمحادثة قائمة
  let conversation = conversationId
    ? await prisma.tutorConversation.findFirst({
        where: { id: conversationId, studentId: guard.user.id },
      })
    : null;

  if (!conversation) {
    conversation = await prisma.tutorConversation.create({
      data: {
        studentId: guard.user.id,
        title: question.slice(0, 60),
      },
    });
  }

  // ترحيب في أول محادثة
  if (conversation.messageCount === 0) {
    const greeting = tutorGreeting();
    await prisma.tutorMessage.create({
      data: {
        conversationId: conversation.id,
        role: "SYSTEM",
        content: greeting.idea,
      },
    });
  }

  // حفظ سؤال الطالب
  await prisma.tutorMessage.create({
    data: {
      conversationId: conversation.id,
      role: "USER",
      content: question,
    },
  });

  // توليد الرد
  const response = await activeTutor(question);

  const replyText = [
    `**${response.topic}**`,
    response.understood,
    "",
    `**الفكرة:** ${response.idea}`,
    "",
    `**القانون:** ${response.law}`,
    "",
    "**الخطوات:**",
    ...response.steps.map((s) => `${s.n}. **${s.title}** — ${s.detail}`),
    "",
    `**مثال مشابه:** ${response.example.question}\n${response.example.solution}`,
    "",
    `**لنجرّب نفسي:** ${response.check.question}`,
    response.check.hint ? `_تلميح: ${response.check.hint}_` : "",
    response.needsClarification ? `\n⚠ ${response.needsClarification}` : "",
  ]
    .filter(Boolean)
    .join("\n");

  await prisma.tutorMessage.create({
    data: {
      conversationId: conversation.id,
      role: "ASSISTANT",
      content: replyText,
      intent: response.topic,
      confidence: response.needsClarification ? 0.4 : 0.9,
    },
  });

  await prisma.tutorConversation.update({
    where: { id: conversation.id },
    data: { messageCount: { increment: 2 } },
  });

  return NextResponse.json({
    conversationId: conversation.id,
    response,
    reply: replyText,
  });
}

export async function DELETE(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  const url = new URL(req.url);
  const conversationId = url.searchParams.get("conversationId");

  if (conversationId) {
    await prisma.tutorConversation.deleteMany({
      where: { id: conversationId, studentId: guard.user.id },
    });
  } else {
    await prisma.tutorConversation.deleteMany({
      where: { studentId: guard.user.id },
    });
  }

  return NextResponse.json({ ok: true });
}