import { NextResponse } from "next/server";
import { verifyLocalToken, storageDriver } from "@/lib/storage/provider";
import { prisma } from "@/lib/db/prisma";

/**
 * بثّ فيديو محلي بعد التحقق من التوقيع.
 * يُستخدم عندما تكون المنصة في وضع التخزين المحلي (LOCAL)
 * أو كمسار احتياطي عند عدم إعداد Bunny Stream.
 */
export async function GET(req: Request) {
  if (storageDriver() === "supabase") {
    return new NextResponse("Not found", { status: 404 });
  }

  const url = new URL(req.url);
  const key = url.searchParams.get("key") ?? "";
  const token = url.searchParams.get("token") ?? "";

  if (!key || !verifyLocalToken(key, token, 600)) {
    return new NextResponse("رابط غير صالح أو منتهي الصلاحية", {
      status: 403,
      headers: { "Content-Type": "text/plain; charset=utf-8" },
    });
  }

  const video = await prisma.videoAsset.findFirst({
    where: { playbackId: key, status: "PUBLISHED" },
    select: { id: true },
  });
  if (!video) {
    return new NextResponse("الفيديو غير متاح", { status: 404 });
  }

  const { readObject } = await import("@/lib/storage/provider");
  try {
    const buffer = await readObject(key);
    const safePath = key.split("/").pop() ?? "video.mp4";
    const encoded = encodeURIComponent(safePath);
    const ext = safePath.split(".").pop()?.toLowerCase() ?? "mp4";
    const mime =
      ext === "webm"
        ? "video/webm"
        : ext === "mov"
          ? "video/quicktime"
          : "video/mp4";

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": mime,
        "Content-Length": String(buffer.byteLength),
        "Content-Disposition": `inline; filename="${safePath}"; filename*=UTF-8''${encoded}`,
        "Cache-Control": "private, max-age=0, no-store",
      },
    });
  } catch {
    return new NextResponse("تعذر قراءة الفيديو", { status: 404 });
  }
}
