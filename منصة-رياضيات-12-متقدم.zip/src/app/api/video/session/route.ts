import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { canAccessLessonContent } from "@/lib/auth/entitlements";
import { getSignedPlaybackUrl, bunnyThumbnail } from "@/lib/storage/video";
import { youTubeEmbedUrl, youTubeThumbnail } from "@/lib/youtube";
import { z } from "zod";

const schema = z.object({ videoId: z.string().min(1) });

/**
 * يصد رابط تشغيل موقّع لفيديو بعد التحقق من:
 *  1) أن المستخدم مسجّل الدخول.
 *  2) أن الدرس مجاني أو معاينة أو أن اشتراكه فعّال.
 * الرابط صالح 10 دقائق فقط — لا يمكن نسخه واستخدامه دائمًا.
 */
export async function POST(req: Request) {
  const guard = await requireApi();
  if (!guard.ok) return guard.response;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "معرّف الفيديو مطلوب" }, { status: 400 });
  }

  const video = await prisma.videoAsset.findUnique({
    where: { id: parsed.data.videoId },
    select: {
      id: true,
      playbackId: true,
      provider: true,
      providerId: true,
      isFree: true,
      status: true,
      lesson: { select: { isFree: true, isPreview: true, status: true } },
    },
  });

  if (!video || video.status !== "PUBLISHED" || video.lesson.status !== "PUBLISHED") {
    return NextResponse.json({ error: "الفيديو غير متاح" }, { status: 404 });
  }

  const access = await canAccessLessonContent(guard.user.id, {
    isFree: video.isFree || video.lesson.isFree,
    isPreview: video.lesson.isPreview,
  });

  if (!access.allowed) {
    return NextResponse.json(
      {
        error: "هذا الدرس مدفوع. فعّل اشتراكك للمشاهدة.",
        code: "SUBSCRIPTION_REQUIRED",
      },
      { status: 403 },
    );
  }

  // مزوّد خارجي: نُرجع الرابط كما هو (لا يمكن حمايته أكثر)
  if (video.provider === "EXTERNAL") {
    return NextResponse.json({
      url: video.providerId,
      provider: "external",
      expiresAt: null,
      thumbnail: null,
    });
  }

  // YouTube: رابط التضمين الرسمي مع تتبّع المشاهدة
  if (video.provider === "YOUTUBE") {
    if (!video.playbackId) {
      return NextResponse.json(
        { error: "لم يتم ربط فيديو YouTube بعد" },
        { status: 409 },
      );
    }
    return NextResponse.json({
      url: youTubeEmbedUrl(video.playbackId),
      provider: "youtube",
      videoId: video.playbackId,
      expiresAt: null,
      thumbnail: youTubeThumbnail(video.playbackId),
    });
  }

  if (video.provider === "LOCAL") {
    if (!video.playbackId) {
      return NextResponse.json(
        { error: "لم يتم ربط ملف الفيديو بعد" },
        { status: 409 },
      );
    }
    const expiresAt = Date.now() + 600 * 1000;
    const { signLocalToken } = await import("@/lib/storage/provider");
    const token = signLocalToken(video.playbackId, expiresAt);
    const url = `/api/video/stream?key=${encodeURIComponent(video.playbackId)}&token=${encodeURIComponent(token)}`;
    return NextResponse.json({
      url,
      provider: "local",
      expiresAt: new Date(expiresAt).toISOString(),
      thumbnail: null,
      videoId: video.id,
    });
  }

  if (!video.playbackId) {
    return NextResponse.json(
      { error: "لم يتم ربط ملف الفيديو بعد" },
      { status: 409 },
    );
  }

  const signed = await getSignedPlaybackUrl(video.playbackId, guard.user.id);
  if (!signed) {
    return NextResponse.json(
      {
        error:
          "خدمة الفيديو غير مُعدة. أضف BUNNY_STREAM_AUTH_KEY في متغيرات البيئة.",
        code: "VIDEO_NOT_CONFIGURED",
      },
      { status: 503 },
    );
  }

  return NextResponse.json({
    ...signed,
    thumbnail: bunnyThumbnail(video.playbackId),
    videoId: video.id,
  });
}