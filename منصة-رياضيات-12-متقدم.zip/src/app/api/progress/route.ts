import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";

const schema = z.object({
  lessonId: z.string().min(1),
  positionSec: z.coerce.number().int().min(0).max(86400),
  durationSec: z.coerce.number().int().min(0).max(86400).default(0),
  completed: z.boolean().default(false),
  watchedRanges: z
    .array(z.object({ start: z.number(), end: z.number() }))
    .max(60)
    .optional(),
});

/** حفظ تقدم مشاهدة الدرس. */
export async function POST(req: Request) {
  const guard = await requireApi({ roles: ["STUDENT"] });
  if (!guard.ok) return guard.response;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "طلب غير صالح" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات التقدم غير صالحة" }, { status: 400 });
  }

  const { lessonId, positionSec, durationSec, completed, watchedRanges } = parsed.data;

  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    select: { id: true, durationSec: true, status: true },
  });
  if (!lesson || lesson.status !== "PUBLISHED") {
    return NextResponse.json({ error: "الدرس غير متاح" }, { status: 404 });
  }

  const total = durationSec || lesson.durationSec || 0;

  // نسبة المشاهدة = مجموع المقاطع المشاهدة فعليًا / المدة
  let watchPercent: number;
  if (completed) {
    watchPercent = 100;
  } else if (total > 0 && watchedRanges && watchedRanges.length > 0) {
    const covered = watchedRanges.reduce((sum, r) => {
      const start = Math.max(0, Math.min(r.start, total));
      const end = Math.max(start, Math.min(r.end, total));
      return sum + (end - start);
    }, 0);
    watchPercent = Math.min(100, Math.round((covered / total) * 100));
    // لا يمكن أن تقل النسبة عن نسبة الموضع الحالي أبدًا (لتفادي فقد التقدّم)
    const positionPercent = Math.min(100, Math.round((positionSec / total) * 100));
    watchPercent = Math.max(watchPercent, positionPercent);
  } else if (total > 0) {
    watchPercent = Math.min(100, Math.round((positionSec / total) * 100));
  } else {
    watchPercent = 0;
  }

  // يُعتبر الدرس مكتملًا عند 90% مشاهدة أو عند انتهاء الفيديو
  const isCompleted = completed || watchPercent >= 90;

  const existing = await prisma.lessonProgress.findUnique({
    where: { studentId_lessonId: { studentId: guard.user.id, lessonId } },
  });

  const progress = await prisma.lessonProgress.upsert({
    where: { studentId_lessonId: { studentId: guard.user.id, lessonId } },
    create: {
      studentId: guard.user.id,
      lessonId,
      lastPositionSec: positionSec,
      watchPercent,
      completed: isCompleted,
      completedAt: isCompleted ? new Date() : null,
      lastViewedAt: new Date(),
    },
    update: {
      lastPositionSec: positionSec,
      watchPercent: Math.max(existing?.watchPercent ?? 0, watchPercent),
      completed: (existing?.completed ?? false) || isCompleted,
      completedAt:
        (existing?.completed ?? false) || !isCompleted
          ? existing?.completedAt ?? null
          : new Date(),
      lastViewedAt: new Date(),
    },
  });

  return NextResponse.json({
    ok: true,
    watchPercent: progress.watchPercent,
    completed: progress.completed,
  });
}