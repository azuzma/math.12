"use server";

import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db/prisma";
import {
  createSessionToken,
  setSessionCookie,
  clearSessionCookie,
} from "@/lib/auth/session";
import { rateLimit, clearRateLimit, clientIp } from "@/lib/auth/guard";
import {
  registerStudentSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "@/lib/validation";
import { formToObject, validate, firstError, type FormState } from "@/lib/actions";
import { randomCode } from "@/lib/utils";
import {
  sendWelcomeEmail,
  sendPasswordResetEmail,
  sendVerificationEmail,
} from "@/lib/email/mailer";
import { PLATFORM } from "@/lib/platform";
import { headers } from "next/headers";

/** تسجيل حساب طالب جديد. */
export async function registerStudentAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const parsed = validate(registerStudentSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const input = parsed.data;

  const ip = clientIp((await headers()) as never);
  const limit = rateLimit(`register:${ip}`, 5, 15 * 60 * 1000);
  if (!limit.allowed) {
    return {
      ok: false,
      message: "محاولات كثيرة خلال وقت قصير. حاول مرة أخرى بعد قليل.",
    };
  }

  const email = input.email.toLowerCase().trim();
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return {
      ok: false,
      message: "هذا البريد مسجّل مسبقًا. سجّل الدخول أو استخدم استعادة كلمة المرور.",
    };
  }

  // المنصة لصف واحد فقط — يُسند الطالب تلقائيًا إلى صف المنصة
  const grade = await prisma.grade.findUnique({
    where: { slug: PLATFORM.gradeSlug },
    select: { id: true, nameAr: true },
  });
  if (!grade) {
    return {
      ok: false,
      message:
        "تعذّر تحديد صف المنصة. شغّل `npm run db:seed` لتهيئة البيانات أولًا.",
    };
  }

  const verifyCode = randomCode(6);
  const passwordHash = await bcrypt.hash(input.password, 12);

  const user = await prisma.user.create({
    data: {
      email,
      passwordHash,
      fullName: input.fullName.trim(),
      phone: input.phone || null,
      role: "STUDENT",
      status: "ACTIVE",
      emailVerified: false,
      emailVerifyCode: verifyCode,
      studentProfile: {
        create: {
          gradeId: grade.id,
          schoolName: input.schoolName || null,
          guardianName: input.guardianName || null,
          guardianPhone: input.guardianPhone || null,
        },
      },
    },
  });

  await sendWelcomeEmail(email, input.fullName, grade.nameAr);
  await sendVerificationEmail(email, verifyCode).catch(() => undefined);

  // جلسة فورية بعد التسجيل
  const token = await createSessionToken({ id: user.id, role: "STUDENT" });
  await setSessionCookie(token);

  redirect("/dashboard?welcome=1");
}

/** تسجيل الدخول (طلاب / أولياء أمور / إدارة). */
export async function loginAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const parsed = validate(loginSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const { email, password } = parsed.data;

  const ip = clientIp((await headers()) as never);
  const limit = rateLimit(`login:${ip}`, 10, 10 * 60 * 1000);
  if (!limit.allowed) {
    return {
      ok: false,
      message: "محاولات دخول كثيرة. انتظر قليلًا ثم أعد المحاولة.",
    };
  }

  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() },
    include: { studentProfile: { select: { gradeId: true } } },
  });

  // رسالة موحّدة حتى لا نكشف الحسابات الموجودة
  const invalid: FormState = { ok: false, message: "البريد الإلكتروني أو كلمة المرور غير صحيحة" };
  if (!user) return invalid;

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    const perUser = rateLimit(`login:user:${user.id}`, 5, 10 * 60 * 1000);
    if (!perUser.allowed) {
      return { ok: false, message: "تم إيقاف المحاولات مؤقتًا على هذا الحساب." };
    }
    return invalid;
  }

  if (user.status !== "ACTIVE") {
    return {
      ok: false,
      message: "الحساب موقوف. تواصل مع إدارة المنصة لإعادة التفعيل.",
    };
  }

  clearRateLimit(`login:${ip}`);
  clearRateLimit(`login:user:${user.id}`);

  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  await prisma.auditLog.create({
    data: { userId: user.id, action: "login", ip, entity: "User", entityId: user.id },
  });

  const token = await createSessionToken({ id: user.id, role: user.role });
  await setSessionCookie(token);

  const next = (formData.get("next") ?? "").toString();
  if (next.startsWith("/")) redirect(next);
  redirect(
    user.role === "ADMIN" || user.role === "TEACHER" || user.role === "OWNER"
      ? "/admin"
      : "/dashboard",
  );
}

/** تسجيل الخروج. */
export async function logoutAction(): Promise<void> {
  await clearSessionCookie();
  redirect("/");
}

/** طلب رمز استعادة كلمة المرور. */
export async function forgotPasswordAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const parsed = validate(forgotPasswordSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }

  const email = parsed.data.email.toLowerCase().trim();
  const user = await prisma.user.findUnique({ where: { email } });

  // نعرض نفس الرسالة سواء وُجد الحساب أم لا (أمان)
  if (user) {
    const code = randomCode(6);
    await prisma.user.update({
      where: { id: user.id },
      data: {
        resetCode: code,
        resetCodeExpiry: new Date(Date.now() + 60 * 60 * 1000),
      },
    });
    await sendPasswordResetEmail(email, code).catch((e) =>
      console.error("[auth] فشل إرسال بريد الاستعادة:", e),
    );
  }

  return {
    ok: true,
    message:
      "إذا كان البريد مسجّلًا لدينا فسيصلك رمز إعادة التعيين خلال دقائق. تحقق من صندوق الوارد ومجلد الرسائل غير المرغوبة.",
  };
}

/** تعيين كلمة مرور جديدة بالرمز. */
export async function resetPasswordAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const parsed = validate(resetPasswordSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const { code, password } = parsed.data;

  const user = await prisma.user.findFirst({
    where: { resetCode: code, resetCodeExpiry: { gt: new Date() } },
  });
  if (!user) {
    return { ok: false, message: "الرمز غير صحيح أو منتهي الصلاحية. اطلب رمزًا جديدًا." };
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      passwordHash: await bcrypt.hash(password, 12),
      resetCode: null,
      resetCodeExpiry: null,
    },
  });

  return {
    ok: true,
    message: "تم تغيير كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.",
    redirectTo: "/login",
  };
}

/** تأكيد البريد الإلكتروني. */
export async function verifyEmailAction(code: string): Promise<boolean> {
  const user = await prisma.user.findFirst({
    where: { emailVerifyCode: code },
  });
  if (!user) return false;

  await prisma.user.update({
    where: { id: user.id },
    data: { emailVerified: true, emailVerifyCode: null },
  });
  return true;
}