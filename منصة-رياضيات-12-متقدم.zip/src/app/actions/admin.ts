"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db/prisma";
import { requireStaffApi } from "@/lib/auth/permissions";
import { audit } from "@/lib/auth/permissions";
import { formToObject, validate, firstError, type FormState } from "@/lib/actions";
import {
  gradeSchema,
  subjectSchema,
  courseSchema,
  unitSchema,
  lessonSchema,
  videoSchema,
  fileSchema,
  questionSchema,
  assignmentSchema,
  examSchema,
  planSchema,
  announcementSchema,
  studentUpdateSchema,
  manualSubscriptionSchema,
  termSchema,
  skillSchema,
} from "@/lib/validation";
import { slugify, randomCode } from "@/lib/utils";
import { notifyNewLesson, broadcast } from "@/lib/notifications";
import { uploadObject, deleteObject, storageDriver } from "@/lib/storage/provider";
import { uploadToBunny, deleteFromBunny, bunnyConfig } from "@/lib/storage/video";
import { extractYouTubeId } from "@/lib/youtube";
import { saveSettings, DEFAULT_SETTINGS } from "@/lib/settings";
import { sendAccountSuspendedEmail } from "@/lib/email/mailer";
import { activateSubscription } from "@/lib/payments/activate";

/** قراءة معرّف العنصر المحرَّر (فارغ = إنشاء جديد). */
function entityId(formData: FormData): string | undefined {
  const id = (formData.get("id") ?? "").toString().trim();
  return id ? id : undefined;
}

/** توليد slug تلقائيًا عند ترك الحقل فارغًا. */
function withAutoSlug(data: Record<string, unknown>, field: string): void {
  const source = (data.title ?? data.nameAr) as string | undefined;
  if (!data.slug && source) data.slug = slugify(String(source));
}

/* ================= الصفوف ================= */

export async function saveGradeAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  withAutoSlug(raw, "nameAr");

  const parsed = validate(gradeSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    nameAr: d.nameAr,
    nameEn: d.nameEn,
    stageAr: d.stageAr,
    stageSlug: d.stageSlug,
    order: d.order,
    description: d.description || null,
  };

  try {
    if (id) {
      await prisma.grade.update({ where: { id }, data });
    } else {
      await prisma.grade.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "grade", entityId: id });
  revalidatePath("/admin/grades");
  revalidatePath("/lessons");
  revalidatePath("/");
  return { ok: true, message: "تم حفظ الصف", redirectTo: "/admin/grades" };
}

/* ================= المواد ================= */

export async function saveSubjectAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  withAutoSlug(raw, "nameAr");

  const parsed = validate(subjectSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    nameAr: d.nameAr,
    nameEn: d.nameEn,
    gradeId: d.gradeId,
    description: d.description || null,
    order: d.order,
  };

  try {
    if (id) {
      await prisma.subject.update({ where: { id }, data });
    } else {
      await prisma.subject.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "subject", entityId: id });
  revalidatePath("/admin/subjects");
  revalidatePath("/lessons");
  return { ok: true, message: "تم حفظ المادة", redirectTo: "/admin/subjects" };
}

/* ================= المقررات ================= */

export async function saveCourseAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  withAutoSlug(raw, "title");

  const parsed = validate(courseSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    subtitle: d.subtitle || null,
    description: d.description || null,
    subjectId: d.subjectId,
    status: d.status,
    isFree: d.isFree,
    order: d.order,
  };

  try {
    if (id) {
      await prisma.course.update({ where: { id }, data });
    } else {
      await prisma.course.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "course", entityId: id });
  revalidatePath("/admin/courses");
  revalidatePath("/lessons");
  return { ok: true, message: "تم حفظ المقرر", redirectTo: "/admin/courses" };
}

/* ================= الوحدات ================= */

export async function saveUnitAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  withAutoSlug(raw, "title");

  const parsed = validate(unitSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    description: d.description || null,
    courseId: d.courseId,
    termId: d.termId,
    status: d.status,
    isFree: d.isFree,
    order: d.order,
  };

  try {
    if (id) {
      await prisma.unit.update({ where: { id }, data });
    } else {
      await prisma.unit.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "unit", entityId: id });
  revalidatePath("/admin/units");
  revalidatePath("/admin/terms");
  revalidatePath("/lessons");
  return { ok: true, message: "تم حفظ الوحدة", redirectTo: "/admin/units" };
}

/* ================= الفصول الدراسية ================= */

export async function saveTermAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  if (!raw.slug && raw.title) raw.slug = slugify(String(raw.title));

  const parsed = validate(termSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    description: d.description || null,
    courseId: d.courseId,
    status: d.status,
    isFree: d.isFree,
    order: d.order,
  };

  try {
    if (id) {
      await prisma.term.update({ where: { id }, data });
    } else {
      await prisma.term.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({
    userId: guard.user.id,
    action: id ? "update" : "create",
    entity: "term",
    entityId: id,
  });

  revalidatePath("/admin/terms");
  revalidatePath("/admin/units");
  return { ok: true, message: "تم حفظ الفصل الدراسي", redirectTo: "/admin/terms" };
}

/* ================= المهارات ================= */

export async function saveSkillAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  if (!raw.slug && raw.title) raw.slug = slugify(String(raw.title));

  const parsed = validate(skillSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    description: d.description || null,
    unitId: d.unitId,
    status: d.status,
    order: d.order,
  };

  try {
    if (id) {
      await prisma.skill.update({ where: { id }, data });
    } else {
      await prisma.skill.create({ data: { ...data, slug: d.slug } });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({
    userId: guard.user.id,
    action: id ? "update" : "create",
    entity: "skill",
    entityId: id,
  });

  revalidatePath("/admin/skills");
  revalidatePath("/admin/questions");
  return { ok: true, message: "تم حفظ المهارة", redirectTo: "/admin/skills" };
}

/* ================= الدروس ================= */

export async function saveLessonAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  withAutoSlug(raw, "title");

  const parsed = validate(lessonSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    summary: d.summary || null,
    description: d.description || null,
    unitId: d.unitId,
    status: d.status,
    isFree: d.isFree,
    isPreview: d.isPreview,
    order: d.order,
  };

  let lessonId = id;
  let lessonTitle = d.title;

  try {
    if (id) {
      const previous = await prisma.lesson.findUnique({
        where: { id },
        select: { status: true },
      });
      const lesson = await prisma.lesson.update({ where: { id }, data });
      lessonId = lesson.id;
      lessonTitle = lesson.title;

      // إشعار عند أول نشر فقط
      if (lesson.status === "PUBLISHED" && previous?.status !== "PUBLISHED") {
        await notifyNewLesson(lesson.id, lesson.title).catch(() => undefined);
      }
    } else {
      const lesson = await prisma.lesson.create({
        data: { ...data, slug: d.slug },
      });
      lessonId = lesson.id;
      lessonTitle = lesson.title;

      if (lesson.status === "PUBLISHED") {
        await notifyNewLesson(lesson.id, lesson.title).catch(() => undefined);
      }
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({
    userId: guard.user.id,
    action: id ? "update" : "create",
    entity: "lesson",
    entityId: lessonId ?? null,
    meta: { title: lessonTitle },
  });

  revalidatePath("/admin/lessons");
  revalidatePath("/lessons");
  revalidatePath("/");

  return {
    ok: true,
    message: "تم حفظ الدرس",
    redirectTo: lessonId ? `/admin/lessons/${lessonId}` : "/admin/lessons",
  };
}

/* ================= الفيديو ================= */

export async function saveVideoAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const parsed = validate(videoSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    title: d.title,
    description: d.description || null,
    status: d.status,
    isFree: d.isFree,
    durationSec: d.durationSec,
    allowSeeking: d.allowSeeking,
  };

  try {
    if (d.provider === "YOUTUBE") {
      // نستخرج معرّف الفيديو من الرابط الذي لصقه الأستاذ
      const ytId = extractYouTubeId(d.providerId ?? "");
      if (!ytId) {
        return {
          ok: false,
          message:
            "رابط YouTube غير صحيح. تأكد من نسخ الرابط كاملًا (مثال: https://www.youtube.com/watch?v=XXXXXXXXXXX).",
        };
      }

      if (id) {
        await prisma.videoAsset.update({
          where: { id },
          data: {
            ...data,
            provider: "YOUTUBE",
            providerId: d.providerId || null,
            playbackId: ytId,
          },
        });
      } else {
        await prisma.videoAsset.create({
          data: {
            ...data,
            provider: "YOUTUBE",
            providerId: d.providerId || null,
            playbackId: ytId,
            lessonId: d.lessonId,
          },
        });
      }
    } else if (id) {
      await prisma.videoAsset.update({ where: { id }, data });
    } else {
      await prisma.videoAsset.create({
        data: {
          ...data,
          provider: d.provider,
          providerId: d.providerId || null,
          playbackId: d.playbackId || null,
          lessonId: d.lessonId,
        },
      });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "video", entityId: id });
  revalidatePath("/admin/videos");
  return { ok: true, message: "تم حفظ الفيديو", redirectTo: "/admin/videos" };
}

/** رفع ملف فيديو إلى Bunny ثم ربطه بدرس. */
export async function uploadVideoFileAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const lessonId = (formData.get("lessonId") ?? "").toString();
  const title = (formData.get("title") ?? "").toString().trim();
  const file = formData.get("file");

  if (!lessonId) return { ok: false, message: "اختر الدرس أولًا" };
  if (!title) return { ok: false, message: "اكتب عنوان الفيديو" };
  if (!(file instanceof File) || file.size === 0) {
    return { ok: false, message: "اختر ملف فيديو" };
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const hasBunny = Boolean(bunnyConfig().apiKey && bunnyConfig().authKey);

    let createdFields: {
      provider: "BUNNY" | "LOCAL";
      providerId: string;
      playbackId: string;
    };
    if (hasBunny) {
      const { playbackId, assetId } = await uploadToBunny(
        file.name,
        file.type || "video/mp4",
        buffer,
      );
      createdFields = {
        provider: "BUNNY" as const,
        providerId: String(assetId),
        playbackId,
      };
    } else {
      // رفع محلي على الخادم نفسه (بدون الاعتماد على Bunny)
      const safeName = file.name.replace(/[^\w.\-\u0600-\u06FF ]/g, "_");
      const storagePath = `videos/${Date.now()}-${safeName}`;
      await uploadObject(storagePath, buffer, file.type || "video/mp4");
      createdFields = {
        provider: "LOCAL" as const,
        providerId: storagePath,
        playbackId: storagePath,
      };
    }

    const created = await prisma.videoAsset.create({
      data: {
        title,
        description: (formData.get("description") ?? "").toString() || null,
        ...createdFields,
        durationSec: Number(formData.get("durationSec") ?? 0) || 0,
        sizeBytes: buffer.byteLength,
        status: "PUBLISHED",
        isFree: formData.get("isFree") === "on",
        allowSeeking: formData.get("allowSeeking") !== "off",
        lessonId,
      },
    });

    await audit({
      userId: guard.user.id,
      action: "upload_video",
      entity: "video",
      entityId: created.id,
    });

    revalidatePath("/admin/videos");
    return { ok: true, message: "تم رفع الفيديو بنجاح", redirectTo: "/admin/videos" };
  } catch (e) {
    return { ok: false, message: `فشل الرفع: ${(e as Error).message}` };
  }
}

/** إضافة فيديو من قناة يوتيوب — يلصق الأستاذ الرابط فقط. */
export async function addYouTubeVideoAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const lessonId = (formData.get("lessonId") ?? "").toString();
  const title = (formData.get("title") ?? "").toString().trim();
  const url = (formData.get("url") ?? "").toString().trim();
  const description = (formData.get("description") ?? "").toString().trim();

  if (!lessonId) return { ok: false, message: "اختر الدرس أولًا" };
  if (!title) return { ok: false, message: "اكتب عنوان الفيديو" };

  const ytId = extractYouTubeId(url);
  if (!ytId) {
    return {
      ok: false,
      message:
        "رابط YouTube غير صحيح. انسخ الرابط كاملًا من زر «مشاركة» في يوتيوب.",
    };
  }

  try {
    const created = await prisma.videoAsset.create({
      data: {
        title,
        description: description || null,
        provider: "YOUTUBE",
        providerId: url,
        playbackId: ytId,
        durationSec: Number(formData.get("durationSec") ?? 0) || 0,
        sizeBytes: null,
        status: (formData.get("status") ?? "PUBLISHED").toString() as
          | "PUBLISHED"
          | "DRAFT"
          | "ARCHIVED",
        isFree: formData.get("isFree") === "on",
        allowSeeking: formData.get("allowSeeking") !== "off",
        lessonId,
      },
    });

    await audit({
      userId: guard.user.id,
      action: "add_youtube_video",
      entity: "video",
      entityId: created.id,
    });

    revalidatePath("/admin/videos");
    return { ok: true, message: "تمت إضافة فيديو YouTube بنجاح", redirectTo: "/admin/videos" };
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }
}

/* ================= الملفات ================= */

export async function uploadFileAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const file = formData.get("file");
  const title = (formData.get("title") ?? "").toString().trim();

  if (!(file instanceof File) || file.size === 0) {
    return { ok: false, message: "اختر ملف PDF" };
  }
  if (!title) return { ok: false, message: "اكتب عنوان الملف" };

  const parsed = validate(fileSchema, {
    title,
    description: (formData.get("description") ?? "").toString(),
    kind: (formData.get("kind") ?? "OTHER").toString(),
    lessonId: (formData.get("lessonId") ?? "").toString(),
    unitId: (formData.get("unitId") ?? "").toString(),
    courseId: (formData.get("courseId") ?? "").toString(),
    status: (formData.get("status") ?? "PUBLISHED").toString(),
    isFree: formData.get("isFree") === "on",
  });

  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const safeName = file.name.replace(/[^\w.\-\u0600-\u06FF ]/g, "_");
    const path = `files/${Date.now()}-${safeName}`;

    await uploadObject(path, buffer, file.type || "application/pdf");

    const created = await prisma.fileAsset.create({
      data: {
        title: d.title,
        description: d.description || null,
        kind: d.kind,
        storageKey: path,
        fileName: file.name,
        mimeType: file.type || "application/pdf",
        sizeBytes: buffer.byteLength,
        status: d.status,
        isFree: d.isFree,
        lessonId: d.lessonId,
        unitId: d.unitId,
        courseId: d.courseId,
      },
    });

    await audit({
      userId: guard.user.id,
      action: "upload_file",
      entity: "file",
      entityId: created.id,
      meta: { driver: storageDriver() },
    });

    revalidatePath("/admin/files");
    return { ok: true, message: "تم رفع الملف بنجاح", redirectTo: "/admin/files" };
  } catch (e) {
    return { ok: false, message: `فشل الرفع: ${(e as Error).message}` };
  }
}

/* ================= الأسئلة ================= */

export async function saveQuestionAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  const type = String(raw.type ?? "MCQ");
  const optionsRaw = Array.isArray(raw.options) ? (raw.options as string[]) : [];

  const optionObjects = optionsRaw
    .filter((o) => o && String(o).trim())
    .map((text, idx) => ({ id: String.fromCharCode(97 + idx), text: String(text).trim() }));

  let correct: unknown = raw.correct;
  if (type === "MCQ" || type === "TRUE_FALSE") {
    const idx = optionObjects.findIndex((o) => o.text === String(raw.correct));
    correct = idx >= 0 ? optionObjects[idx]!.id : optionObjects[0]?.id ?? "";
  } else if (type === "MULTI_TRUE") {
    const picked = Array.isArray(raw.correctMulti) ? (raw.correctMulti as string[]) : [];
    correct = optionObjects.filter((o) => picked.includes(o.text)).map((o) => o.id);
  } else {
    correct = String(raw.correct ?? "");
  }

  const parsed = validate(questionSchema, {
    ...raw,
    options: optionObjects.map((o) => o.text),
    correct: type === "MULTI_TRUE" ? "" : String(raw.correct ?? correct ?? ""),
  });

  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const data = {
    type: d.type,
    text: d.text,
    options: optionObjects.length > 0 ? (optionObjects as never) : undefined,
    correct: correct as never,
    solution: d.solution || null,
    hint: d.hint || null,
    points: d.points,
    difficulty: d.difficulty,
    lessonId: d.lessonId,
    skillId: d.skillId,
    termId: d.termId,
    autoGrade: d.autoGrade,
    isActive: d.isActive,
  };

  try {
    if (id) {
      await prisma.question.update({ where: { id }, data });
    } else {
      await prisma.question.create({ data });
    }
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  await audit({ userId: guard.user.id, action: id ? "update" : "create", entity: "question", entityId: id });
  revalidatePath("/admin/questions");
  revalidatePath("/admin/exams");
  revalidatePath("/admin/assignments");
  return { ok: true, message: "تم حفظ السؤال", redirectTo: "/admin/questions" };
}

/* ================= الواجبات ================= */

export async function saveAssignmentAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  const questionIds = Array.isArray(raw.questionIds) ? (raw.questionIds as string[]) : [];

  const parsed = validate(assignmentSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  try {
    const base = {
      title: d.title,
      instructions: d.instructions || null,
      status: d.status,
      isFree: d.isFree,
      dueAfterDays: d.dueAfterDays,
      lessonId: d.lessonId,
    };

    const assignment = id
      ? await prisma.assignment.update({ where: { id }, data: base })
      : await prisma.assignment.create({ data: base });

    await prisma.assignmentQuestion.deleteMany({
      where: { assignmentId: assignment.id },
    });
    if (questionIds.length > 0) {
      await prisma.assignmentQuestion.createMany({
        data: questionIds.map((questionId, idx) => ({
          assignmentId: assignment.id,
          questionId,
          order: idx,
        })),
      });
    }

    await audit({
      userId: guard.user.id,
      action: id ? "update" : "create",
      entity: "assignment",
      entityId: assignment.id,
    });
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  revalidatePath("/admin/assignments");
  return { ok: true, message: "تم حفظ الواجب", redirectTo: "/admin/assignments" };
}

/* ================= الاختبارات ================= */

export async function saveExamAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  const questionIds = Array.isArray(raw.questionIds) ? (raw.questionIds as string[]) : [];

  // المعرّف يُولَّد تلقائيًا من العنوان إن لم يُكتب
  if (!raw.slug && raw.title) raw.slug = slugify(String(raw.title));

  const parsed = validate(examSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  try {
    const base = {
      title: d.title,
      type: d.type,
      description: d.description || null,
      instructions: d.instructions || null,
      status: d.status,
      isFree: d.isFree,
      durationMinutes: d.durationMinutes,
      attemptsAllowed: d.attemptsAllowed,
      passingScore: d.passingScore,
      shuffleQuestions: d.shuffleQuestions,
      showCorrectAnswers: d.showCorrectAnswers,
      showSolutions: d.showSolutions,
      lessonId: d.lessonId,
      unitId: d.unitId,
      termId: d.termId,
      courseId: d.courseId,
    };

    const exam = id
      ? await prisma.exam.update({ where: { id }, data: base })
      : await prisma.exam.create({
          data: { ...base, slug: d.slug || slugify(d.title) },
        });

    await prisma.examQuestion.deleteMany({ where: { examId: exam.id } });
    if (questionIds.length > 0) {
      const questions = await prisma.question.findMany({
        where: { id: { in: questionIds } },
        select: { id: true, points: true },
      });
      await prisma.examQuestion.createMany({
        data: questionIds.map((questionId, idx) => ({
          examId: exam.id,
          questionId,
          points: questions.find((q) => q.id === questionId)?.points ?? 1,
          order: idx,
        })),
      });
    }

    await audit({
      userId: guard.user.id,
      action: id ? "update" : "create",
      entity: "exam",
      entityId: exam.id,
    });
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  revalidatePath("/admin/exams");
  revalidatePath("/dashboard/exams");
  return { ok: true, message: "تم حفظ الاختبار", redirectTo: "/admin/exams" };
}

/* ================= الباقات والأسعار ================= */

export async function savePlanAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const id = entityId(formData);
  const raw = formToObject(formData);
  const gradeIds = Array.isArray(raw.gradeIds) ? (raw.gradeIds as string[]) : [];

  const parsed = validate(planSchema, raw);
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const base = {
    nameAr: d.nameAr,
    nameEn: d.nameEn,
    tagline: d.tagline || null,
    description: d.description || null,
    tier: d.tier,
    monthlyPrice: d.monthlyPrice,
    yearlyPrice: d.yearlyPrice,
    currency: d.currency,
    trialDays: d.trialDays,
    features: d.features as never,
    limits: d.limits as never,
    isActive: d.isActive,
    isFeatured: d.isFeatured,
    sortOrder: d.sortOrder,
    stripeMonthlyPriceId: d.stripeMonthlyPriceId || null,
    stripeYearlyPriceId: d.stripeYearlyPriceId || null,
    telrMonthlyClientKey: d.telrMonthlyClientKey || null,
    telrYearlyClientKey: d.telrYearlyClientKey || null,
  };

  try {
    const plan = id
      ? await prisma.plan.update({ where: { id }, data: base })
      : await prisma.plan.create({ data: { ...base, slug: d.slug } });

    await prisma.planGrade.deleteMany({ where: { planId: plan.id } });
    if (gradeIds.length > 0) {
      await prisma.planGrade.createMany({
        data: gradeIds.map((gradeId) => ({ planId: plan.id, gradeId })),
      });
    }

    await audit({
      userId: guard.user.id,
      action: id ? "update" : "create",
      entity: "plan",
      entityId: plan.id,
    });
  } catch (e) {
    return { ok: false, message: describeError(e) };
  }

  revalidatePath("/admin/plans");
  revalidatePath("/pricing");
  revalidatePath("/");
  return { ok: true, message: "تم حفظ الباقة", redirectTo: "/admin/plans" };
}

/* ================= الطلاب ================= */

export async function updateStudentAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const userId = (formData.get("userId") ?? "").toString();
  const parsed = validate(studentUpdateSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  if (!userId) return { ok: false, message: "معرّف الطالب مطلوب" };

  try {
    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        status: d.status,
        ...(d.newPassword
          ? { passwordHash: await bcrypt.hash(d.newPassword, 12) }
          : {}),
        studentProfile: {
          upsert: {
            create: {
              gradeId: d.gradeId || null,
              schoolName: d.schoolName || null,
              dailyGoalMinutes: d.dailyGoalMinutes,
            },
            update: {
              ...(d.gradeId ? { gradeId: d.gradeId } : {}),
              ...(d.schoolName !== undefined ? { schoolName: d.schoolName || null } : {}),
              dailyGoalMinutes: d.dailyGoalMinutes,
            },
          },
        },
      },
      select: { email: true, fullName: true },
    });

    if (d.status === "SUSPENDED") {
      await sendAccountSuspendedEmail(user.email, user.fullName).catch(() => undefined);
    }

    await audit({
      userId: guard.user.id,
      action: "update_student",
      entity: "User",
      entityId: userId,
      meta: { status: d.status },
    });
  } catch (e) {
    return { ok: false, message: `تعذّر التحديث: ${(e as Error).message}` };
  }

  revalidatePath("/admin/students");
  return { ok: true, message: "تم تحديث بيانات الطالب" };
}

export async function createStudentAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const email = (formData.get("email") ?? "").toString().trim().toLowerCase();
  const fullName = (formData.get("fullName") ?? "").toString().trim();
  const password = (formData.get("password") ?? "").toString();
  const gradeId = (formData.get("gradeId") ?? "").toString();
  const schoolName = (formData.get("schoolName") ?? "").toString();
  const phone = (formData.get("phone") ?? "").toString();

  if (!email.includes("@") || !fullName) {
    return { ok: false, message: "الاسم والبريد الإلكتروني مطلوبان" };
  }
  if (password.length < 8) {
    return { ok: false, message: "كلمة المرور 8 أحرف على الأقل" };
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return { ok: false, message: "هذا البريد مسجّل بالفعل" };

  try {
    const created = await prisma.user.create({
      data: {
        email,
        fullName,
        passwordHash: await bcrypt.hash(password, 12),
        phone: phone || null,
        role: "STUDENT",
        status: "ACTIVE",
        emailVerified: true,
        studentProfile: {
          create: { gradeId: gradeId || null, schoolName: schoolName || null },
        },
      },
      select: { id: true },
    });

    await audit({
      userId: guard.user.id,
      action: "create_student",
      entity: "User",
      entityId: created.id,
    });
  } catch (e) {
    return { ok: false, message: `تعذّر الإنشاء: ${(e as Error).message}` };
  }

  revalidatePath("/admin/students");
  return { ok: true, message: "تم إنشاء حساب الطالب بنجاح" };
}

/* ================= تفعيل اشتراك يدوي ================= */

export async function grantSubscriptionAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const parsed = validate(manualSubscriptionSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  const plan = await prisma.plan.findUnique({ where: { id: d.planId } });
  if (!plan) return { ok: false, message: "الباقة غير موجودة" };

  const periodEnd = new Date(Date.now() + d.days * 86400_000);

  try {
    await activateSubscription({
      userId: d.userId,
      planSlug: plan.slug,
      cycle: d.billingCycle,
      amount: 0,
      currency: plan.currency,
      provider: "manual",
      providerRef: `manual_${randomCode(10)}`,
      invoiceRef: `MANUAL-${new Date().toISOString().slice(0, 10)}`,
      periodEnd,
      status: "ACTIVE",
    });

    await audit({
      userId: guard.user.id,
      action: "grant_subscription",
      entity: "Subscription",
      meta: { userId: d.userId, plan: plan.slug, days: d.days },
    });
  } catch (e) {
    return { ok: false, message: `تعذّر التفعيل: ${(e as Error).message}` };
  }

  revalidatePath("/admin/subscriptions");
  revalidatePath("/admin/students");
  return { ok: true, message: `تم تفعيل باقة ${plan.nameAr} لمدة ${d.days} يوم` };
}

/* ================= الإعلانات ================= */

export async function sendAnnouncementAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const parsed = validate(announcementSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  try {
    const count = await broadcast({
      title: d.title,
      body: d.body,
      audience: d.audience,
      link: (formData.get("link") ?? "").toString() || null,
    });

    await audit({
      userId: guard.user.id,
      action: "announcement",
      entity: "Notification",
      meta: { audience: d.audience, count },
    });

    revalidatePath("/admin/notifications");
    return {
      ok: true,
      message:
        count > 0
          ? `تم إرسال الإعلان إلى ${count} طالب`
          : "لم يوجد طلاب مطابقون لهذا الجمهور",
    };
  } catch (e) {
    return { ok: false, message: `فشل الإرسال: ${(e as Error).message}` };
  }
}

/* ================= الإعدادات ================= */

export async function saveSettingsAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const data = formToObject(formData);
  const patch: Record<string, unknown> = {};

  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    if (data[key] === undefined) continue;
    if (key === "vatPercent") {
      patch[key] = Number(data[key] ?? 5);
    } else if (key === "vatIncluded") {
      patch[key] = data[key] === true || data[key] === "on";
    } else {
      patch[key] = String(data[key] ?? "");
    }
  }

  try {
    await saveSettings(patch as never);
    await audit({ userId: guard.user.id, action: "update_settings", entity: "SiteSetting" });
  } catch (e) {
    return { ok: false, message: `تعذّر الحفظ: ${(e as Error).message}` };
  }

  revalidatePath("/admin/settings");
  revalidatePath("/");
  return { ok: true, message: "تم حفظ الإعدادات" };
}

export async function changeAdminPasswordAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const current = (formData.get("currentPassword") ?? "").toString();
  const next = (formData.get("newPassword") ?? "").toString();
  const confirm = (formData.get("confirmPassword") ?? "").toString();

  if (next.length < 8) {
    return { ok: false, message: "كلمة المرور الجديدة 8 أحرف على الأقل" };
  }
  if (next !== confirm) {
    return { ok: false, message: "كلمتا المرور غير متطابقتين" };
  }

  const user = await prisma.user.findUnique({
    where: { id: guard.user.id },
    select: { passwordHash: true },
  });
  if (!user) return { ok: false, message: "الحساب غير موجود" };

  const ok = await bcrypt.compare(current, user.passwordHash);
  if (!ok) return { ok: false, message: "كلمة المرور الحالية غير صحيحة" };

  await prisma.user.update({
    where: { id: guard.user.id },
    data: { passwordHash: await bcrypt.hash(next, 12) },
  });

  await audit({ userId: guard.user.id, action: "change_password", entity: "User" });
  return { ok: true, message: "تم تغيير كلمة المرور بنجاح" };
}

/* ================= الحذف ================= */

export async function deleteEntityAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState & { status?: number }> {
  const guard = await requireStaffApi();
  if (!guard.ok) {
    const status = guard.response.status === 401 ? 401 : 403;
    return { ok: false, message: "ليس لديك صلاحية", status };
  }

  const entity = (formData.get("entity") ?? "").toString();
  const id = (formData.get("id") ?? "").toString();

  if (!entity || !id) return { ok: false, message: "بيانات الحذف غير مكتملة" };

  try {
    switch (entity) {
      case "grade":
        await prisma.grade.delete({ where: { id } });
        break;
      case "subject":
        await prisma.subject.delete({ where: { id } });
        break;
      case "course":
        await prisma.course.delete({ where: { id } });
        break;
      case "term":
        await prisma.term.delete({ where: { id } });
        break;
      case "skill":
        await prisma.skill.delete({ where: { id } });
        break;
      case "unit":
        await prisma.unit.delete({ where: { id } });
        break;
      case "lesson":
        await prisma.lesson.delete({ where: { id } });
        break;
      case "video": {
        const video = await prisma.videoAsset.findUnique({
          where: { id },
          select: { providerId: true, provider: true },
        });
        await prisma.videoAsset.delete({ where: { id } });
        if (video?.provider === "BUNNY" && video.providerId) {
          await deleteFromBunny(Number(video.providerId)).catch(() => undefined);
        }
        break;
      }
      case "file": {
        const file = await prisma.fileAsset.findUnique({
          where: { id },
          select: { storageKey: true },
        });
        await prisma.fileAsset.delete({ where: { id } });
        if (file) await deleteObject(file.storageKey).catch(() => undefined);
        break;
      }
      case "question":
        await prisma.question.delete({ where: { id } });
        break;
      case "assignment":
        await prisma.assignment.delete({ where: { id } });
        break;
      case "exam":
        await prisma.exam.delete({ where: { id } });
        break;
      case "plan":
        await prisma.plan.delete({ where: { id } });
        break;
      case "student":
        await prisma.user.delete({ where: { id } });
        break;
      default:
        return { ok: false, message: `نوع غير مدعوم: ${entity}` };
    }
  } catch (e) {
    return { ok: false, message: `تعذّر الحذف: ${(e as Error).message}` };
  }

  await audit({ userId: guard.user.id, action: "delete", entity, entityId: id });

  const revalidateMap: Record<string, string[]> = {
    grade: ["/admin/grades", "/lessons"],
    subject: ["/admin/subjects", "/lessons"],
    course: ["/admin/courses", "/lessons"],
    term: ["/admin/terms", "/admin/units"],
    skill: ["/admin/skills", "/admin/questions"],
    unit: ["/admin/units", "/lessons"],
    lesson: ["/admin/lessons", "/lessons", "/"],
    video: ["/admin/videos"],
    file: ["/admin/files"],
    question: ["/admin/questions", "/admin/exams"],
    assignment: ["/admin/assignments"],
    exam: ["/admin/exams"],
    plan: ["/admin/plans", "/pricing"],
    student: ["/admin/students"],
  };

  for (const path of revalidateMap[entity] ?? ["/admin"]) revalidatePath(path);

  return { ok: true, message: "تم الحذف بنجاح" };
}

/* ================= تغيير الحالة ================= */

const STATUS_MODEL: Record<string, string> = {
  course: "course",
  term: "term",
  skill: "skill",
  unit: "unit",
  lesson: "lesson",
  video: "videoAsset",
  file: "fileAsset",
  assignment: "assignment",
  exam: "exam",
};

const STATUS_LIST = ["DRAFT", "PUBLISHED", "ARCHIVED"];

export async function changeStatusAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const entity = (formData.get("entity") ?? "").toString();
  const id = (formData.get("id") ?? "").toString();
  const status = (formData.get("status") ?? "").toString().toUpperCase();

  const model = STATUS_MODEL[entity];
  if (!model) return { ok: false, message: "نوع غير مدعوم" };
  if (!STATUS_LIST.includes(status)) return { ok: false, message: "حالة غير صالحة" };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const db = prisma as any;
  await db[model].update({ where: { id }, data: { status } });

  if (entity === "lesson" && status === "PUBLISHED") {
    const lesson = await prisma.lesson.findUnique({
      where: { id },
      select: { id: true, title: true },
    });
    if (lesson) await notifyNewLesson(lesson.id, lesson.title).catch(() => undefined);
  }

  await audit({
    userId: guard.user.id,
    action: "change_status",
    entity,
    entityId: id,
    meta: { status },
  });

  revalidatePath("/admin");
  revalidatePath("/lessons");
  return { ok: true, message: "تم تحديث الحالة" };
}

/* ================= تصحيح الواجبات ================= */

export async function gradeSubmissionAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireStaffApi();
  if (!guard.ok) return { ok: false, message: "ليس لديك صلاحية" };

  const submissionId = (formData.get("submissionId") ?? "").toString();
  const score = Number(formData.get("score") ?? 0);
  const feedback = (formData.get("feedback") ?? "").toString();

  const submission = await prisma.assignmentSubmission.findUnique({
    where: { id: submissionId },
    select: { id: true },
  });
  if (!submission) return { ok: false, message: "التسليم غير موجود" };

  await prisma.assignmentSubmission.update({
    where: { id: submissionId },
    data: {
      score,
      feedback: feedback || null,
      gradedAt: new Date(),
      needsReview: false,
    },
  });

  await audit({
    userId: guard.user.id,
    action: "grade_submission",
    entity: "AssignmentSubmission",
    entityId: submissionId,
  });

  revalidatePath("/admin/assignments");
  return { ok: true, message: "تم حفظ التصحيح" };
}

/* ============ أدوات ============ */

function describeError(e: unknown): string {
  const message = (e as Error).message ?? "";
  if (message.includes("Unique constraint")) {
    return "هذا المعرّف (slug) مستخدم بالفعل. اختر معرفًا آخر.";
  }
  if (message.includes("Foreign key")) {
    return "لا يمكن الحفظ: العنصر مرتبط ببيانات أخرى. احذف العناصر التابعة أولًا.";
  }
  return `تعذّر الحفظ: ${message}`;
}