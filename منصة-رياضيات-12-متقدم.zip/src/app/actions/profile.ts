"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db/prisma";
import { requireApi } from "@/lib/auth/guard";
import { profileSchema } from "@/lib/validation";
import { formToObject, validate, firstError, type FormState } from "@/lib/actions";

export async function saveProfileAction(
  _prev: FormState,
  formData: FormData,
): Promise<FormState> {
  const guard = await requireApi();
  if (!guard.ok) return { ok: false, message: "يجب تسجيل الدخول" };

  const parsed = validate(profileSchema, formToObject(formData));
  if (!parsed.ok) {
    return { ok: false, message: firstError(parsed.errors), errors: parsed.errors };
  }
  const d = parsed.data;

  try {
    await prisma.user.update({
      where: { id: guard.user.id },
      data: {
        fullName: d.fullName,
        phone: d.phone || null,
        studentProfile: {
          upsert: {
            create: {
              gradeId: d.gradeId || null,
              schoolName: d.schoolName || null,
              emirate: d.emirate || null,
              guardianName: d.guardianName || null,
              guardianPhone: d.guardianPhone || null,
              dailyGoalMinutes: d.dailyGoalMinutes ?? 30,
            },
            update: {
              ...(d.gradeId ? { gradeId: d.gradeId } : {}),
              schoolName: d.schoolName || null,
              emirate: d.emirate || null,
              guardianName: d.guardianName || null,
              guardianPhone: d.guardianPhone || null,
              ...(d.dailyGoalMinutes !== undefined
                ? { dailyGoalMinutes: d.dailyGoalMinutes }
                : {}),
            },
          },
        },
      },
    });
  } catch (e) {
    return { ok: false, message: `تعذّر الحفظ: ${(e as Error).message}` };
  }

  revalidatePath("/dashboard/profile");
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/lessons");

  return { ok: true, message: "تم حفظ بياناتك" };
}