"use client";

import { useActionState } from "react";
import { registerStudentAction } from "@/app/actions/auth";
import { emptyState } from "@/lib/actions";
import { TextField, PasswordField } from "@/components/ui/forms";
import {
  ActionErrors,
  ActionFeedback,
  SubmitButton,
} from "@/components/forms/form-helpers";
import { PLATFORM } from "@/lib/platform";
import { GraduationCap } from "lucide-react";

export function RegisterForm() {
  const [state, formAction] = useActionState(registerStudentAction, emptyState);

  return (
    <form action={formAction} className="card mt-8 space-y-5 p-6 sm:p-8">
      <input type="hidden" name="_checkboxes" value="terms" />

      <ActionFeedback state={state} />
      <ActionErrors state={state} />

      {/* الصف ثابت — لا اختيار */}
      <div className="flex items-center gap-3 rounded-xl border border-brand-200 bg-brand-50 px-4 py-3.5">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
          <GraduationCap className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-bold text-brand-900">
            أنت على وشك الانضمام إلى
          </p>
          <p className="text-sm font-semibold text-brand-700">
            {PLATFORM.subjectNameAr} — {PLATFORM.gradeNameAr}
          </p>
          <p className="mt-0.5 text-xs text-brand-600">
            كل محتوى المنصة مخصص لهذا الصف — لا حاجة لاختيار صف.
          </p>
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <TextField
          label="الاسم الكامل"
          name="fullName"
          autoComplete="name"
          placeholder="محمد أحمد"
          required
          error={state.errors?.fullName?.[0]}
          className="sm:col-span-2"
        />

        <TextField
          label="البريد الإلكتروني"
          name="email"
          type="email"
          dir="ltr"
          autoComplete="email"
          placeholder="name@example.com"
          required
          error={state.errors?.email?.[0]}
          className="[&>input]:text-start"
        />

        <PasswordField
          label="كلمة المرور"
          name="password"
          dir="ltr"
          autoComplete="new-password"
          placeholder="8 أحرف على الأقل مع رقم"
          required
          error={state.errors?.password?.[0]}
          hint="استخدم 8 أحرف على الأقل وتحتوي على رقم"
          className="[&>input]:text-start"
        />

        <TextField
          label="رقم الهاتف (اختياري)"
          name="phone"
          type="tel"
          dir="ltr"
          autoComplete="tel"
          placeholder="0501234567"
          error={state.errors?.phone?.[0]}
          className="[&>input]:text-start"
        />

        <TextField
          label="المدرسة (اختياري)"
          name="schoolName"
          placeholder="مدرسة الإمارات"
          error={state.errors?.schoolName?.[0]}
        />

        <TextField
          label="اسم ولي الأمر (اختياري)"
          name="guardianName"
          placeholder="أحمد محمد"
          error={state.errors?.guardianName?.[0]}
        />

        <TextField
          label="هاتف ولي الأمر (اختياري)"
          name="guardianPhone"
          type="tel"
          dir="ltr"
          placeholder="0507654321"
          error={state.errors?.guardianPhone?.[0]}
          className="[&>input]:text-start sm:col-span-2"
        />
      </div>

      <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-ink-200 p-3">
        <input
          type="checkbox"
          name="terms"
          value="on"
          required
          className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded border-ink-300 accent-brand-600"
        />
        <span className="text-sm leading-relaxed text-ink-700">
          أوافق على شروط الاستخدام وسياسة الخصوصية، وأوافق على استلام إشعارات
          المنصة عبر البريد الإلكتروني.
        </span>
      </label>
      {state.errors?.terms?.[0] ? (
        <p className="text-xs font-medium text-rose-600">{state.errors.terms[0]}</p>
      ) : null}

      <SubmitButton className="w-full" pendingText="جارٍ إنشاء الحساب…">
        إنشاء حسابي في {PLATFORM.gradeShort}
      </SubmitButton>

      <p className="text-center text-xs leading-relaxed text-ink-500">
        بإنشائك حسابًا فأنت توافق على أن الدروس والملفات محمية بحقوق النشر.
        الحساب مجاني تمامًا ولا نطلب بطاقة ائتمانية.
      </p>
    </form>
  );
}