import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { RegisterForm } from "./register-form";
import { PLATFORM } from "@/lib/platform";
import { CheckCircle2 } from "lucide-react";

export const metadata: Metadata = {
  title: `إنشاء حساب طالب — رياضيات ${PLATFORM.gradeShort}`,
  description: `أنشئ حسابًا مجانيًا في منصة رياضيات ${PLATFORM.gradeNameAr}: دروس فيديو، ملخصات، أوراق عمل، بنك أسئلة، واختبارات بتصحيح فوري.`,
};

const highlights = [
  "كل الدروس بالفيديو لكل وحدات المنهج",
  "ملخصات وأوراق عمل قابلة للتنزيل والطباعة",
  "بنك أسئلة مصنّف بالمهارات ومستويات الصعوبة",
  "اختبارات بستة أنواع مع تصحيح فوري",
  "تحليل ذكي لمستوك ونقاط تحتاج مراجعة",
  "خطة دراسة مخصصة وخطة مراجعة",
];

export default async function RegisterPage() {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <div className="container-app py-12 sm:py-16">
      <div className="mx-auto grid max-w-4xl items-start gap-10 lg:grid-cols-[1fr_1.15fr]">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-xs font-bold text-brand-700">
            {PLATFORM.subjectNameAr} · {PLATFORM.gradeNameAr}
          </span>

          <h1 className="mt-5 text-2xl font-bold leading-tight text-ink-900 sm:text-3xl">
            انضم إلى منصة{" "}
            <span className="text-brand-700">رياضيات {PLATFORM.gradeShort}</span>
          </h1>

          <p className="mt-3 leading-relaxed text-ink-600">{PLATFORM.tagline}</p>

          <ul className="mt-7 space-y-3">
            {highlights.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm text-ink-700">
                <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-emerald-600" />
                {item}
              </li>
            ))}
          </ul>

          <div className="mt-8 rounded-2xl border border-brand-100 bg-gradient-to-br from-brand-50 to-white p-5">
            <p className="text-sm font-bold text-brand-900">الحساب مجاني</p>
            <p className="mt-1 text-sm leading-relaxed text-brand-800">
              يمكنك تجربة الدروس المجانية واختبارات الدرس قبل الاشتراك. لا نطلب
              بطاقة ائتمانية.
            </p>
          </div>
        </div>

        <div>
          <RegisterForm />

          <p className="mt-6 text-center text-sm text-ink-600">
            لديك حساب بالفعل؟{" "}
            <Link
              href="/login"
              className="font-semibold text-brand-700 hover:text-brand-800 hover:underline"
            >
              تسجيل الدخول
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}