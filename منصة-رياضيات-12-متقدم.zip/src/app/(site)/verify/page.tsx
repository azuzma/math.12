import type { Metadata } from "next";
import { verifyEmailAction } from "@/app/actions/auth";
import { Alert, ButtonLink } from "@/components/ui/buttons";

export const metadata: Metadata = {
  title: "تأكيد البريد الإلكتروني",
  robots: { index: false, follow: false },
};

export default async function VerifyPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const { code } = await searchParams;

  if (!code) {
    return (
      <div className="container-app flex min-h-[70vh] items-center justify-center py-12">
        <div className="w-full max-w-md">
          <Alert tone="warn" title="الرمز مفقود">
            افتح رابط التأكيد الذي وصلك في البريد الإلكتروني. إذا لم تجد الرابط،{" "}
            <ButtonLink href="/register" variant="ghost" size="sm" className="h-auto p-0">
              سجّل حسابًا جديدًا
            </ButtonLink>
          </Alert>
        </div>
      </div>
    );
  }

  const ok = await verifyEmailAction(code);

  return (
    <div className="container-app flex min-h-[70vh] items-center justify-center py-12">
      <div className="w-full max-w-md space-y-5">
        {ok ? (
          <Alert tone="success" title="تم تأكيد بريدك الإلكتروني">
            حسابك الآن مُفعّل بالكامل. يمكنك متابعة الدروس واختبار الوحدة.
          </Alert>
        ) : (
          <Alert tone="error" title="رابط غير صالح">
            هذا الرمز غير صحيح أو تم استخدامه من قبل. اطلب رمزًا جديدًا.
          </Alert>
        )}

        <ButtonLink
          href={ok ? "/dashboard" : "/register"}
          className="w-full"
        >
          {ok ? "الذهاب إلى لوحة التحكم" : "إنشاء حساب جديد"}
        </ButtonLink>
      </div>
    </div>
  );
}