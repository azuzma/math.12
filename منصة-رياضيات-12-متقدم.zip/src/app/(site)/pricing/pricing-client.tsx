"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Sparkles } from "lucide-react";
import { cn, formatPrice } from "@/lib/utils";
import { Alert } from "@/components/ui/buttons";

type Plan = {
  slug: string;
  nameAr: string;
  tagline: string;
  description: string;
  tier: "FREE" | "BASIC" | "PREMIUM";
  monthlyPrice: number;
  yearlyPrice: number;
  currency: string;
  trialDays: number;
  features: string[];
  limits: Record<string, unknown>;
  isFeatured: boolean;
};

export function PricingClient({
  plans,
  isLoggedIn,
  selectedPlan,
}: {
  plans: Plan[];
  isLoggedIn: boolean;
  selectedPlan: string;
}) {
  const [cycle, setCycle] = useState<"monthly" | "yearly">("monthly");
  const [loading, setLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const hasPaid = plans.some((p) => p.monthlyPrice > 0 || p.yearlyPrice > 0);

  async function subscribe(plan: Plan) {
    setError(null);
    setLoading(plan.slug);

    if (!isLoggedIn) {
      router.push(`/login?next=${encodeURIComponent(`/pricing?plan=${plan.slug}`)}`);
      return;
    }

    try {
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planSlug: plan.slug, cycle }),
      });
      const data = (await res.json()) as { url?: string; error?: string };

      if (!res.ok || !data.url) {
        setError(data.error ?? "تعذّر بدء عملية الدفع");
        setLoading(null);
        return;
      }
      window.location.href = data.url;
    } catch {
      setError("حدث خطأ في الاتصال. حاول مرة أخرى.");
      setLoading(null);
    }
  }

  if (plans.length === 0) {
    return (
      <Alert tone="info" title="لم تُضَف الباقات بعد">
        يمكن للأستاذ إضافة الباقات وتعديل الأسعار من لوحة الإدارة ← الاشتراكات.
      </Alert>
    );
  }

  return (
    <>
      {/* مبدّل الفترة */}
      {hasPaid ? (
        <div className="mt-8 flex justify-center">
          <div className="inline-flex rounded-xl border border-ink-200 bg-white p-1">
            {(["monthly", "yearly"] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCycle(c)}
                className={cn(
                  "rounded-lg px-5 py-2 text-sm font-semibold transition-colors",
                  cycle === c
                    ? "bg-brand-600 text-white shadow-sm"
                    : "text-ink-600 hover:text-ink-900",
                )}
              >
                {c === "monthly" ? "شهري" : "سنوي"}
                {c === "yearly" ? (
                  <span className="mr-1.5 text-emerald-600">— وفر شهرين</span>
                ) : null}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      {error ? (
        <div className="mt-6">
          <Alert tone="error" title="تعذّر إتمام الطلب">
            {error}
          </Alert>
        </div>
      ) : null}

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        {plans.map((plan) => {
          const price = cycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice;
          const isFree = price === 0;
          const isSelected = selectedPlan === plan.slug;

          return (
            <div
              key={plan.slug}
              className={cn(
                "relative flex flex-col rounded-2xl border bg-white p-7 transition-shadow",
                plan.isFeatured
                  ? "border-brand-500 shadow-xl shadow-brand-500/10"
                  : "border-ink-200 shadow-sm",
                isSelected && "ring-2 ring-brand-400 ring-offset-2",
              )}
            >
              {plan.isFeatured ? (
                <span className="absolute -top-3 right-1/2 flex translate-x-1/2 items-center gap-1 rounded-full bg-brand-600 px-4 py-1 text-xs font-bold text-white">
                  <Sparkles className="h-3 w-3" />
                  الأكثر اختيارًا
                </span>
              ) : null}

              <h2 className="text-lg font-bold text-ink-900">{plan.nameAr}</h2>
              <p className="mt-1 text-sm text-ink-500">{plan.tagline}</p>
              {plan.description ? (
                <p className="mt-2 text-xs leading-relaxed text-ink-500">
                  {plan.description}
                </p>
              ) : null}

              <div className="mt-6 flex items-baseline gap-2">
                <span className="text-3xl font-bold text-ink-900 tabular-nums">
                  {formatPrice(price, plan.currency)}
                </span>
                {!isFree ? (
                  <span className="text-sm text-ink-500">
                    / {cycle === "monthly" ? "شهريًا" : "سنويًا"}
                  </span>
                ) : null}
              </div>

              {cycle === "yearly" && plan.monthlyPrice > 0 ? (
                <p className="mt-1 text-xs text-emerald-700">
                  بما يعادل {formatPrice(Math.round(plan.yearlyPrice / 12), plan.currency)} شهريًا
                </p>
              ) : null}

              {plan.trialDays > 0 && !isFree ? (
                <p className="mt-1 text-xs text-brand-700">
                  يشمل {plan.trialDays} أيام تجربة مجانية
                </p>
              ) : null}

              <ul className="mt-6 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-ink-700">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                    {f}
                  </li>
                ))}
              </ul>

              {isFree ? (
                <Link
                  href={isLoggedIn ? "/dashboard" : "/register"}
                  className="btn btn-primary mt-7 w-full"
                >
                  ابدأ مجانًا
                </Link>
              ) : (
                <button
                  type="button"
                  onClick={() => subscribe(plan)}
                  disabled={loading !== null}
                  className={cn(
                    "btn mt-7 w-full",
                    plan.isFeatured ? "btn-primary" : "btn-outline",
                  )}
                >
                  {loading === plan.slug ? "جارٍ التحويل…" : "اشترك الآن"}
                </button>
              )}
            </div>
          );
        })}
      </div>

      <p className="mt-8 text-center text-xs leading-relaxed text-ink-500">
        الدفع يتم عبر بوابة آمنة تدعم البطاقات الائتمانية (Visa / Mastercard) وApple Pay وTelr.
        لا نحتفظ ببيانات البطاقة على خوادم المنصة. الأسعار شاملة ما تذكره لوحة الإدارة،
        وقد تتغير بإعلان مسبق.
      </p>
    </>
  );
}