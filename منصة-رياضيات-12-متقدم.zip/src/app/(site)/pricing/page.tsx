import type { Metadata } from "next";
import { getActivePlans } from "@/lib/content";
import { getCurrentUser } from "@/lib/auth/session";
import { PricingClient } from "./pricing-client";

export const metadata: Metadata = {
  title: "الاشتراكات والأسعار",
  description:
    "باقات اشتراك منصة الرياضيات: أساسية ومميزة. أسعار واضحة بالدرهم الإماراتي مع اشتراك شهري وسنوي.",
  alternates: { canonical: "/pricing" },
};

export default async function PricingPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string }>;
}) {
  const { plan } = await searchParams;
  const [plans, user] = await Promise.all([getActivePlans(), getCurrentUser()]);

  return (
    <div className="container-app py-12 sm:py-16">
      <div className="mx-auto max-w-5xl">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">
            اختر باقتك
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-ink-600">
            ابدأ مجانًا وارتقِ متى شئت. جميع الأسعار بالدرهم الإماراتي، ويمكنك الإلغاء
            في أي وقت مع الاحتفاظ بوصولك حتى نهاية الفترة المدفوعة.
          </p>
        </div>

        <PricingClient
          plans={plans.map((p) => ({
            slug: p.slug,
            nameAr: p.nameAr,
            tagline: p.tagline ?? "",
            description: p.description ?? "",
            tier: p.tier,
            monthlyPrice: p.monthlyPrice,
            yearlyPrice: p.yearlyPrice,
            currency: p.currency,
            trialDays: p.trialDays,
            features: Array.isArray(p.features) ? (p.features as string[]) : [],
            limits: (p.limits ?? {}) as Record<string, unknown>,
            isFeatured: p.isFeatured,
          }))}
          isLoggedIn={Boolean(user)}
          selectedPlan={plan ?? ""}
        />
      </div>
    </div>
  );
}