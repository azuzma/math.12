import Link from "next/link";
import { getSettings } from "@/lib/settings";
import { getCurrentUser } from "@/lib/auth/session";
import { getActivePlans } from "@/lib/content";
import { formatPrice } from "@/lib/utils";
import { ButtonLink } from "@/components/ui/buttons";

// لا تُبنى مسبقًا — Prisma (نسخة Cloudflare) لا يعمل وقت البناء
export const dynamic = "force-dynamic";

export default async function NotFound() {
  // الصفحة تُبنى مسبقًا (static) — يجب ألا تفشل إن لم تكن قاعدة البيانات متاحة
  const [settings, user, plans] = await Promise.all([
    getSettings(),
    getCurrentUser().catch(() => null),
    getActivePlans().catch(() => []),
  ]);

  return (
    <div className="container-app flex min-h-[70vh] flex-col items-center justify-center py-16 text-center">
      <p className="text-6xl font-bold text-brand-600">404</p>
      <h1 className="mt-4 text-2xl font-bold text-ink-900">الصفحة غير موجودة</h1>
      <p className="mt-3 max-w-md leading-relaxed text-ink-600">
        ربما تم نقل الصفحة أو حذفها أو أن الرابط مكتوب بشكل غير صحيح. يمكنك العودة
        للرئيسية أو تصفّح الدروس المتاحة.
      </p>

      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <ButtonLink href="/">الصفحة الرئيسية</ButtonLink>
        <ButtonLink href="/lessons" variant="outline">
          تصفّح الدروس
        </ButtonLink>
        <Link
          href="/search"
          className="btn btn-ghost"
        >
          ابحث في المنصة
        </Link>
      </div>

      <div className="mt-12 w-full max-w-md rounded-2xl border border-ink-200 bg-white p-6">
        <p className="text-sm font-semibold text-ink-900">روابط مفيدة</p>
        <ul className="mt-3 space-y-2 text-sm">
          {[
            { href: "/lessons", label: "كل الدروس" },
            { href: "/pricing", label: "الاشتراكات والأسعار" },
            { href: "/search", label: "البحث في المنصة" },
            {
              href: user ? ((user.role === "ADMIN" || user.role === "TEACHER" || user.role === "OWNER") ? "/admin" : "/dashboard") : "/login",
              label: user ? "لوحة التحكم" : "تسجيل الدخول",
            },
          ].map((l) => (
            <li key={l.href}>
              <Link href={l.href} className="text-brand-700 hover:underline">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>

      {plans.length > 0 ? (
        <div className="mt-12 w-full max-w-md rounded-2xl border border-ink-200 bg-white p-6">
          <p className="text-sm font-semibold text-ink-900">الباقات المتاحة</p>
          <ul className="mt-3 space-y-2 text-sm">
            {plans.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3">
                <span className="text-ink-700">{p.nameAr}</span>
                <span className="font-semibold tabular-nums text-ink-900">
                  {formatPrice(p.monthlyPrice, settings.currency)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="mt-10 text-xs text-ink-400">{settings.siteName}</p>
    </div>
  );
}