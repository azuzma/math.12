import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { loginAction } from "@/app/actions/auth";
import { getCurrentUser } from "@/lib/auth/session";
import { LoginForm } from "./login-form";

export const metadata: Metadata = {
  title: "تسجيل الدخول",
  description: "سجّل الدخول إلى منصة الرياضيات لمتابعة دروسك ونتائجك واشتراكك.",
  robots: { index: false, follow: true },
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string }>;
}) {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  const { next } = await searchParams;

  return (
    <div className="container-app flex min-h-[calc(100vh-4rem)] items-center justify-center py-12">
      <div className="w-full max-w-md">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ink-900">تسجيل الدخول</h1>
          <p className="mt-2 text-sm text-ink-600">
            أدخل بريدك الإلكتروني وكلمة المرور للمتابعة
          </p>
        </div>

        <LoginForm nextPath={next} />

        <p className="mt-6 text-center text-sm text-ink-600">
          ليس لديك حساب؟{" "}
          <Link
            href="/register"
            className="font-semibold text-brand-700 hover:text-brand-800 hover:underline"
          >
            أنشئ حسابًا مجانيًا
          </Link>
        </p>

        <p className="mt-3 text-center text-sm text-ink-600">
          نسيت كلمة المرور؟{" "}
          <Link
            href="/forgot-password"
            className="font-semibold text-brand-700 hover:text-brand-800 hover:underline"
          >
            استعادتها
          </Link>
        </p>
      </div>
    </div>
  );
}