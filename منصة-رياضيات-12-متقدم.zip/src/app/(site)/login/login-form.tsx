"use client";

import { useActionState, useEffect } from "react";
import { loginAction } from "@/app/actions/auth";
import { emptyState } from "@/lib/actions";
import { TextField, PasswordField } from "@/components/ui/forms";
import {
  ActionErrors,
  ActionFeedback,
  SubmitButton,
} from "@/components/forms/form-helpers";

export function LoginForm({ nextPath }: { nextPath?: string }) {
  const [state, formAction] = useActionState(loginAction, emptyState);

  useEffect(() => {
    if (state.ok && state.redirectTo) {
      window.location.href = state.redirectTo;
    }
  }, [state]);

  return (
    <form action={formAction} className="card mt-8 space-y-4 p-6 sm:p-7">
      {nextPath ? <input type="hidden" name="next" value={nextPath} /> : null}

      <ActionFeedback state={state} />
      <ActionErrors state={state} />

      <TextField
        label="البريد الإلكتروني"
        name="email"
        type="email"
        dir="ltr"
        autoComplete="email"
        placeholder="name@example.com"
        required
        className="[&>input]:text-start"
      />

      <PasswordField
        label="كلمة المرور"
        name="password"
        dir="ltr"
        autoComplete="current-password"
        placeholder="••••••••"
        required
        className="[&>input]:text-start"
      />

      <SubmitButton className="w-full" pendingText="جارٍ تسجيل الدخول…">
        تسجيل الدخول
      </SubmitButton>
    </form>
  );
}