import type { Metadata } from "next";
import { ForgotForm } from "./forgot-form";

export const metadata: Metadata = {
  title: "استعادة كلمة المرور",
  description: "أرسل رمز إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.",
  robots: { index: false, follow: true },
};

export default function ForgotPasswordPage() {
  return (
    <div className="container-app flex min-h-[calc(100vh-4rem)] items-center justify-center py-12">
      <div className="w-full max-w-md">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ink-900">استعادة كلمة المرور</h1>
          <p className="mt-2 text-sm text-ink-600">
            أدخل بريدك المسجّل وسنرسل لك رمزًا لتعيين كلمة مرور جديدة
          </p>
        </div>
        <ForgotForm />
      </div>
    </div>
  );
}