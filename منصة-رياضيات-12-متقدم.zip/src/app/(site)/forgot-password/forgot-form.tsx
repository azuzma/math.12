"use client";

import { useActionState } from "react";
import { forgotPasswordAction } from "@/app/actions/auth";
import { emptyState } from "@/lib/actions";
import { TextField } from "@/components/ui/forms";
import {
  ActionErrors,
  ActionFeedback,
  SubmitButton,
} from "@/components/forms/form-helpers";

export function ForgotForm() {
  const [state, formAction] = useActionState(forgotPasswordAction, emptyState);

  return (
    <form action={formAction} className="card mt-8 space-y-4 p-6 sm:p-7">
      <ActionFeedback state={state} />
      <ActionErrors state={state} />

      <TextField
        label="البريد الإلكتروني"
        name="email"
        type="email"
        dir="ltr"
        autoComplete="email"
        placeholder="name@example.com"
        required
        error={state.errors?.email?.[0]}
        className="[&>input]:text-start"
      />

      <SubmitButton className="w-full" pendingText="جارٍ الإرسال…">
        إرسال رمز الاستعادة
      </SubmitButton>
    </form>
  );
}