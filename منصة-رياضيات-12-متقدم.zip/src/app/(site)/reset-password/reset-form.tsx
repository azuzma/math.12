"use client";

import { useActionState, useEffect } from "react";
import { resetPasswordAction } from "@/app/actions/auth";
import { emptyState } from "@/lib/actions";
import { TextField, PasswordField } from "@/components/ui/forms";
import {
  ActionErrors,
  ActionFeedback,
  SubmitButton,
} from "@/components/forms/form-helpers";

export function ResetForm({ defaultCode }: { defaultCode: string }) {
  const [state, formAction] = useActionState(resetPasswordAction, emptyState);

  useEffect(() => {
    if (state.ok && state.redirectTo) {
      window.location.href = state.redirectTo;
    }
  }, [state]);

  return (
    <form action={formAction} className="card mt-8 space-y-4 p-6 sm:p-7">
      <ActionFeedback state={state} />
      <ActionErrors state={state} />

      <TextField
        label="رمز التحقق"
        name="code"
        defaultValue={defaultCode}
        placeholder="000000"
        required
        inputMode="numeric"
        dir="ltr"
        error={state.errors?.code?.[0]}
        className="[&>input]:text-center [&>input]:text-lg [&>input]:tracking-[0.4em] [&>input]:font-bold"
      />

      <PasswordField
        label="كلمة المرور الجديدة"
        name="password"
        dir="ltr"
        autoComplete="new-password"
        required
        error={state.errors?.password?.[0]}
        hint="8 أحرف على الأقل وتحتوي على رقم"
        className="[&>input]:text-start"
      />

      <PasswordField
        label="تأكيد كلمة المرور"
        name="confirm"
        dir="ltr"
        autoComplete="new-password"
        required
        error={state.errors?.confirm?.[0]}
        className="[&>input]:text-start"
      />

      <SubmitButton className="w-full" pendingText="جارٍ التغيير…">
        تعيين كلمة المرور
      </SubmitButton>
    </form>
  );
}