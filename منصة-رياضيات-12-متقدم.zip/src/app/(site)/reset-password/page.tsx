import type { Metadata } from "next";
import { ResetForm } from "./reset-form";

export const metadata: Metadata = {
  title: "تعيين كلمة مرور جديدة",
  robots: { index: false, follow: true },
};

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const { code } = await searchParams;

  return (
    <div className="container-app flex min-h-[calc(100vh-4rem)] items-center justify-center py-12">
      <div className="w-full max-w-md">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ink-900">
            تعيين كلمة مرور جديدة
          </h1>
          <p className="mt-2 text-sm text-ink-600">
            {code
              ? "أدخل كلمة المرور الجديدة لتأكيد التغيير"
              : "أدخل الرمز الذي وصلك عبر البريد الإلكتروني"}
          </p>
        </div>
        <ResetForm defaultCode={code ?? ""} />
      </div>
    </div>
  );
}