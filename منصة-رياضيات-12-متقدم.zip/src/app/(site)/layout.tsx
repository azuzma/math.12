import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { getSettings } from "@/lib/settings";

export default async function SiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // بدون قاعدة بيانات لا تعمل المنصة — نعرض صفحة إعداد بدل خطأ 500
  if (!process.env.DATABASE_URL) {
    const { SetupRequired } = await import("@/components/setup-required");
    return <SetupRequired />;
  }

  const [user, settings] = await Promise.all([
    getCurrentUser().catch(() => null),
    getSettings(),
  ]);

  let unreadCount = 0;
  if (user) {
    unreadCount = await prisma.notification
      .count({
        where: { userId: user.id, readAt: null },
      })
      .catch(() => 0);
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader
        isLoggedIn={Boolean(user)}
        user={user ? { fullName: user.fullName, role: user.role } : null}
        unreadCount={unreadCount}
      />
      <main className="flex-1">{children}</main>
      <SiteFooter settings={settings} />
    </div>
  );
}