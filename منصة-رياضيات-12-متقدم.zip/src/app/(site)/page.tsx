import Link from "next/link";
import {
  PlayCircle,
  FileText,
  ClipboardCheck,
  BarChart3,
  Bell,
  Smartphone,
  Search,
  Sparkles,
  Brain,
  MessagesSquare,
  Video,
  Timer,
  Award,
  ArrowLeft,
  CheckCircle2,
} from "lucide-react";
import { ButtonLink } from "@/components/ui/buttons";
import { AccessBadge } from "@/components/ui/badges";
import { getSettings } from "@/lib/settings";
import { getGrades, getFeaturedLessons, getActivePlans } from "@/lib/content";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { formatPrice, formatDuration } from "@/lib/utils";
import { PLATFORM } from "@/lib/platform";

// صفحة ديناميكية: لا تُبنى مسبقًا — لأن Prisma (نسخة Cloudflare) لا يعمل وقت البناء
export const dynamic = "force-dynamic";

export default async function HomePage() {
  // الصفحة تُبنى أثناء `next build` — لا نريد أن يفشل البناء لغياب قاعدة البيانات
  const [settings, grades, lessons, plans, user] = await Promise.all([
    getSettings(),
    getGrades().catch(() => []),
    getFeaturedLessons(6).catch(() => []),
    getActivePlans().catch(() => []),
    getCurrentUser().catch(() => null),
  ]);

  const features = [
    {
      icon: Video,
      title: "دروس فيديو لكل وحدات المنهج",
      description:
        "شرح مبسّط خطوة بخطوة، مع إيقاف ومتابعة من حيث توقفت، ومقسّمة إلى فصول ووحدات ومهارات.",
    },
    {
      icon: FileText,
      title: "ملخصات وأوراق عمل PDF",
      description:
        "ملخص الدرس في صفحة واحدة، وورقة عمل قابلة للطباعة، مع تنزيل مباشر على الهاتف أو الكمبيوتر.",
    },
    {
      icon: Brain,
      title: "بنك أسئلة مصنّف بالمهارات",
      description:
        "كل سؤال مرتبط بالوحدة والمهارة ومستوى الصعوبة: سهل، متوسط، صعب، تحدي.",
    },
    {
      icon: ClipboardCheck,
      title: "ستة أنواع من الاختبارات",
      description:
        "اختبار درس، وحدة، فصل دراسي، شامل، مراجعة، وتجريبي — بتصحيح فوري وعرض الحل النموذجي.",
    },
    {
      icon: BarChart3,
      title: "تحليل ذكي لمستواك",
      description:
        "يحدد نقاط قوتك والمهارات التي تحتاج مراجعة، ثم يقترح خطوة تالية عملية.",
    },
    {
      icon: MessagesSquare,
      title: "مساعد رياضيات",
      description:
        "يشرح الفكرة والقانون والخطوات، ويعطي مثالًا مشابهًا ثم يختبر فهمك — بدون إجابة نهائية.",
    },
  ];

  const steps = [
    {
      n: "1",
      title: "أنشئ حسابك",
      description:
        `تسجيل واحد فقط — حسابك يُسند تلقائيًا إلى ${PLATFORM.gradeNameAr}. لا تختار صفًا ولا تبحث عن صف آخر.`
    },
    {
      n: "2",
      title: "شاهد الدرس المجاني",
      description:
        "جرّب أول وحدة كاملة بالفيديو مع الملخص وورقة العمل، بدون أي دفع.",
    },
    {
      n: "3",
      title: "اختر باقتك",
      description:
        "اشتراك شهري أو سنوي يفتح بنك الأسئلة والاختبارات والتحليل الذكي وخطة الدراسة والمساعد.",
    },
  ];

  const faq = [
    {
      q: "هل المنصة لصف واحد فقط؟",
      a: `نعم، المنصة مخصصة حصريًا لمادة الرياضيات للصف الثاني عشر المتقدم وفق منهج دولة الإمارات. تسجيل الحساب يُسندك تلقائيًا إلى هذا الصف، ولا يوجد اختيار صف أو مادة أخرى.`,
    },
    {
      q: "هل أحتاج إلى بطاقة ائتمانية لأجرب المنصة؟",
      a: "لا. الوحدة الأولى كاملة متاحة مجانًا بالفيديو مع الملخص وأوراق العمل واختبارات الدرس، لتقيّم المنصة قبل الاشتراك.",
    },
    {
      q: "كيف تعمل الاشتراكات؟",
      a: "الاشتراك شهري أو سنوي، ويُفعّل فور إتمام الدفع. عند انتهاء المدة يتوقف الوصول للمحتوى المدفوع تلقائيًا، ويمكنك التجديد في أي وقت. كما يمكنك الإلغاء مع الاحتفاظ بوصولك حتى نهاية الفترة المدفوعة.",
    },
    {
      q: "هل يمكن لأولياء الأمور متابعة مستوى الأبناء؟",
      a: "نعم. حساب ولي الأمر يتيح متابعة الدروس المكتملة ونتائج الاختبارات ونسبة التقدم. يتم ربط الحساب بطلب من إدارة المنصة.",
    },
    {
      q: "هل الدرجات تُصحّح تلقائيًا؟",
      a: "نعم، كل الأسئلة الموضوعية (اختيار من متعدد، صح وخطأ، إجابة رقمية) تُصحّح فورًا. الأسئلة المقالية والإجابات القصيرة يصححها الأستاذ يدويًا من لوحة التحكم.",
    },
    {
      q: "هل يمكنني مشاهدة الدروس على الهاتف؟",
      a: "نعم، المنصة مصممة للعمل على الهاتف من البداية، وتشمل تشغيل الفيديو وتنزيل الملفات وحل الاختبارات دون مشاكل في العربية أو الاتجاه.",
    },
    {
      q: "كيف أحمي محتوى الدروس المدفوع؟",
      a: "روابط الفيديو تُولّد من الخادم عند الطلب فقط وتحصل على صلاحية قصيرة، ولا يوجد رابط دائم يمكن نسخه. كذلك ملفات PDF لا تُتاح إلا عبر رابط موقّع بعد التحقق من اشتراكك.",
    },
    {
      q: "ما طرق الدفع المتاحة؟",
      a: "الدفع عبر البطاقات الائتمانية والخصم (Visa / Mastercard) وApple Pay، ووتيلر (Telr). تُعالج بيانات البطاقة لدى مزوّد الدفع ولا تُخزَّن على خوادم المنصة إطلاقًا.",
    },
  ];

  const gradeCards = grades.filter((g) => g._count.subjects > 0);

  // أرقام حقيقية تُقرأ من قاعدة البيانات — صفر يعني صفر
  const [lessonCount, questionCount, examCount, terms] = await Promise.all([
    prisma.lesson.count({ where: { status: "PUBLISHED" } }).catch(() => 0),
    prisma.question.count({ where: { isActive: true } }).catch(() => 0),
    prisma.exam.count({ where: { status: "PUBLISHED" } }).catch(() => 0),
    prisma.term.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { order: "asc" },
      select: {
        id: true,
        title: true,
        order: true,
        units: {
          where: { status: "PUBLISHED" },
          orderBy: { order: "asc" },
          select: {
            id: true,
            slug: true,
            title: true,
            description: true,
            _count: { select: { lessons: true, skills: true, exams: true } },
          },
        },
      },
    }).catch(() => []),
  ]);

  return (
    <>
      {/* ============ البطل ============ */}
      <section className="relative overflow-hidden bg-gradient-to-b from-brand-50/70 via-white to-white">
        <div
          className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[42rem] -translate-x-1/2 rounded-full bg-brand-200/30 blur-3xl"
          aria-hidden
        />
        <div className="container-app relative py-14 sm:py-20 lg:py-24">
          <div className="mx-auto max-w-3xl text-center">
            <span className="animate-fade-in inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white px-4 py-1.5 text-xs font-semibold text-brand-700">
              <Sparkles className="h-3.5 w-3.5" />
              {settings.tagline}
            </span>

            <h1 className="mt-6 text-3xl font-bold leading-tight tracking-tight text-ink-900 sm:text-4xl lg:text-5xl">
              كل ما تحتاجه لإتقان{" "}
              <span className="bg-gradient-to-l from-brand-600 to-brand-400 bg-clip-text text-transparent">
                رياضيات الصف 12 متقدم
              </span>{" "}
              في مكان واحد
            </h1>

            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-ink-600 sm:text-lg">
              شرح ← تدريب ← اختبار → تحليل ← مراجعة ← إتقان. دروس فيديو لكل وحدات
              المنهج، ملخصات وأوراق عمل، بنك أسئلة مصنّف بالمهارات، اختبارات
              بتصحيح فوري، وتحليل ذكي لمستواك.
            </p>

            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <ButtonLink href={user ? "/dashboard" : "/register"} size="lg">
                ابدأ الآن
                <ArrowLeft className="h-4 w-4" />
              </ButtonLink>
              <ButtonLink href="/lessons" variant="outline" size="lg">
                <PlayCircle className="h-4 w-4" />
                استكشف الدروس
              </ButtonLink>
            </div>

            <p className="mt-4 text-xs text-ink-500">
              مجاني للتجربة — لا حاجة لبطاقة ائتمانية
            </p>

            {/* أرقام حقيقية من قاعدة البيانات */}
            <dl className="mx-auto mt-12 grid max-w-2xl grid-cols-3 gap-4">
              {[
                { label: "درس منشور", value: `${lessonCount}` },
                { label: "سؤال في البنك", value: `${questionCount}` },
                { label: "اختبار", value: `${examCount}` },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-ink-200/80 bg-white/70 px-3 py-4 backdrop-blur"
                >
                  <dd className="text-2xl font-bold text-ink-900 tabular-nums">
                    {stat.value}
                  </dd>
                  <dt className="mt-0.5 text-xs text-ink-500">{stat.label}</dt>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* ============ نبذة الأستاذ ============ */}
      <section className="border-y border-ink-200 bg-ink-50/60">
        <div className="container-app grid items-center gap-10 py-16 lg:grid-cols-[1fr_1.2fr]">
          <div className="mx-auto w-full max-w-sm">
            <div className="relative aspect-4/3 overflow-hidden rounded-3xl bg-gradient-to-br from-brand-600 to-brand-800 shadow-lg">
              <div className="absolute inset-0 grid place-items-center">
                <div className="text-center text-white/90">
                  <div className="mx-auto grid h-24 w-24 place-items-center rounded-full bg-white/15 text-4xl font-bold backdrop-blur">
                    {settings.logoText || "ر"}
                  </div>
                  <p className="mt-4 text-lg font-semibold">{settings.teacherName}</p>
                  <p className="text-sm text-white/70">{settings.teacherTitle}</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              عن الأستاذ
            </h2>
            <p className="mt-2 text-sm font-semibold text-brand-700">
              {settings.teacherName} — {settings.teacherTitle}
            </p>
            <p className="mt-5 leading-loose text-ink-600">
              {settings.teacherBio ||
                "أستاذ رياضيات متخصص في المرحلة الثانوية بالمنهج الإماراتي. أبدأ من الفكرة الأساسية وأشرحها بأمثلة محسوسة، ثم أنتقل للتمارين المتدرجة، وأخيرًا اختبار قصير يثبّت الفهم. منصتي مصممة كي يتعلم الطالب بنفسه وبإيقاعه، مع تصحيح فوري لكل إجابة ومتابعة دقيقة لما أتقنه وما يحتاج مراجعة."}
            </p>

            <ul className="mt-6 space-y-2.5">
              {[
                "شرح بلغة بسيطة بعيدًا عن الحشو",
                "تمارين متدرجة من السهل إلى المتقدم",
                "حلول نموذجية لكل سؤال",
                "متابعة أسبوعية لمستوى الطالب",
              ].map((item) => (
                <li key={item} className="flex items-center gap-2.5 text-sm text-ink-700">
                  <CheckCircle2 className="h-4.5 w-4.5 shrink-0 text-emerald-600" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* ============ المنهج: فصول ← وحدات ============ */}
      <section className="container-app py-16 sm:py-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
            منهج {PLATFORM.gradeNameAr}
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-ink-600">
            مقسّم إلى فصلين دراسيين، كل فصل يجمع وحدات، وكل وحدة تشرحها مهارات
            محددة ثم دروس وأوراق عمل واختبارات.
          </p>
        </div>

        {terms.length === 0 ? (
          <p className="mt-8 text-center text-sm text-ink-500">
            لم تُنشر وحدات بعد. يمكن إضافتها من لوحة الإدارة ← الفصول الدراسية.
          </p>
        ) : (
          <div className="mt-10 space-y-8">
            {terms.map((term) => (
              <div key={term.id}>
                <div className="mb-4 flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-600 text-sm font-bold text-white">
                    {term.order}
                  </span>
                  <h3 className="text-lg font-bold text-ink-900">{term.title}</h3>
                  <span className="text-xs text-ink-500">
                    {term.units.length} وحدة
                  </span>
                </div>

                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {term.units.map((unit) => (
                    <Link
                      key={unit.id}
                      href={`/lessons?unit=${unit.slug}`}
                      className="group card flex flex-col p-5 transition-all hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-bold text-ink-900 group-hover:text-brand-700">
                          {unit.title}
                        </h4>
                        <ArrowLeft className="h-4 w-4 shrink-0 text-ink-300 group-hover:text-brand-600" />
                      </div>

                      {unit.description ? (
                        <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-ink-600">
                          {unit.description}
                        </p>
                      ) : (
                        <span className="flex-1" />
                      )}

                      <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                        <span>{unit._count.lessons} درس</span>
                        <span>{unit._count.skills} مهارة</span>
                        <span>{unit._count.exams} اختبار</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ============ المميزات ============ */}
      <section id="features" className="scroll-mt-20 border-y border-ink-200 bg-ink-50/60">
        <div className="container-app py-16 sm:py-20">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              كل ما تحتاجه في منصة واحدة
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-ink-600">
              من الدرس إلى الدرجة — لا حاجة لتضيع وقتك بين منصات متعددة.
            </p>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="card p-6 transition-shadow hover:shadow-md">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand-50 text-brand-600">
                  <f.icon className="h-6 w-6" />
                </span>
                <h3 className="mt-4 text-base font-bold text-ink-900">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-600">
                  {f.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ أمثلة من الدروس ============ */}
      <section className="container-app py-16 sm:py-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              مناهج رياضيات الصف 12 متقدم
            </h2>
            <p className="mt-3 max-w-2xl text-ink-600">
              الوحدات والدروس كاملة مع الملخص وأوراق العمل — بعد الاشتراك.
            </p>
          </div>
          <ButtonLink href="/lessons" variant="outline">
            كل الدروس
            <ArrowLeft className="h-4 w-4" />
          </ButtonLink>
        </div>

        {lessons.length === 0 ? (
          <div className="mt-10 rounded-2xl border border-dashed border-ink-300 bg-white p-10 text-center">
            <p className="text-sm text-ink-500">
              لم يُنشر أي درس مجاني بعد. أضف أول درس من لوحة الإدارة ← الدروس
              مع تحديد «مجاني».
            </p>
          </div>
        ) : (
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {lessons.map((lesson) => (
              <article key={lesson.id} className="card group overflow-hidden">
                <div className="relative aspect-video bg-gradient-to-br from-brand-500 to-brand-700">
                  <div className="absolute inset-0 grid place-items-center">
                    <PlayCircle className="h-14 w-14 text-white/85 transition-transform group-hover:scale-110" />
                  </div>
                  <div className="absolute top-3 right-3">
                    <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
                  </div>
                  {lesson.durationSec ? (
                    <span className="absolute bottom-3 left-3 rounded bg-black/60 px-2 py-0.5 text-xs font-medium text-white tabular-nums">
                      {formatDuration(lesson.durationSec)}
                    </span>
                  ) : null}
                </div>

                <div className="p-5">
                  <p className="text-xs font-semibold text-brand-600">
                    {lesson.unit.course.subject.grade.nameAr} · {lesson.unit.title}
                  </p>
                  <h3 className="mt-1.5 font-bold text-ink-900">{lesson.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-500">
                    {lesson.summary}
                  </p>

                  <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                    <span className="inline-flex items-center gap-1">
                      <Video className="h-3.5 w-3.5" />
                      {lesson._count.videos} فيديو
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <FileText className="h-3.5 w-3.5" />
                      {lesson._count.files} ملف
                    </span>
                    {lesson._count.exams > 0 ? (
                      <span className="inline-flex items-center gap-1">
                        <ClipboardCheck className="h-3.5 w-3.5" />
                        {lesson._count.exams} اختبار
                      </span>
                    ) : null}
                  </div>

                  <ButtonLink
                    href={`/lessons/${lesson.slug}`}
                    variant="soft"
                    size="sm"
                    className="mt-4 w-full"
                  >
                    عرض الدرس
                  </ButtonLink>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* ============ أمثلة من أوراق العمل ============ */}
      <section className="border-y border-ink-200 bg-ink-50/60">
        <div className="container-app py-16 sm:py-20">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
                أوراق عمل جاهزة للطباعة
              </h2>
              <p className="mt-4 leading-loose text-ink-600">
                كل درس مرفق بورقة عمل تغطي المهام نفسها، مع ملخص في صفحة واحدة
                ي recap أهم القواعد قبل الاختبار. الأوراق بصيغة PDF وتُنزّل مباشرة
                على جهازك.
              </p>

              <ul className="mt-6 space-y-3">
                {[
                  { icon: FileText, text: "ورقة عمل لكل درس مع خطوات الحل" },
                  { icon: Timer, text: "تدريبات متدرجة مرتبة حسب الصعوبة" },
                  { icon: Award, text: "حلول نموذجية للمهام الصعبة" },
                  { icon: Smartphone, text: "تعمل على الهاتف والكمبيوتر والطباعة" },
                ].map((item) => (
                  <li key={item.text} className="flex items-center gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-white text-brand-600 shadow-sm">
                      <item.icon className="h-5 w-5" />
                    </span>
                    <span className="text-sm text-ink-700">{item.text}</span>
                  </li>
                ))}
              </ul>

              <ButtonLink href="/lessons" variant="outline" className="mt-8">
                تصفّح أوراق العمل
                <ArrowLeft className="h-4 w-4" />
              </ButtonLink>
            </div>

            <div className="card p-6">
              <div className="flex items-center justify-between border-b border-ink-200 pb-4">
                <div>
                  <p className="text-sm font-bold text-ink-900">
                    ورقة عمل — قواعد الاشتقاق
                  </p>
                  <p className="text-xs text-ink-500">
                    {PLATFORM.gradeShort} · 6 أسئلة
                  </p>
                </div>
                <FileText className="h-8 w-8 text-brand-500" />
              </div>

              <ol className="mt-5 space-y-4">
                {[
                  "إذا كانت f(x) = x³ − 4x + 2 فأوجد f′(x).",
                  "أوجد مشتقة g(x) = (3x + 1)⁴.",
                  "إذا كان h(x) = 4x² − 3x فأوجد h′(2).",
                  "أوجد مشتقة y = sin(x²).",
                ].map((q, i) => (
                  <li key={i} className="flex gap-3 text-sm text-ink-700">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-brand-50 text-xs font-bold text-brand-700">
                      {i + 1}
                    </span>
                    <span className="leading-relaxed">{q}</span>
                  </li>
                ))}
              </ol>

              <p className="mt-5 border-t border-dashed border-ink-200 pt-4 text-xs text-ink-400">
                نموذج توضيحي لطريقة تنسيق أوراق العمل داخل المنصة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ============ كيف تبدأ ============ */}
      <section className="container-app py-16 sm:py-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
            ثلاث خطوات وتبدأ
          </h2>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {steps.map((step) => (
            <div key={step.n} className="relative card p-6">
              <span className="absolute -top-4 right-6 grid h-9 w-9 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white shadow">
                {step.n}
              </span>
              <h3 className="mt-3 text-base font-bold text-ink-900">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-600">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ============ الاشتراكات ============ */}
      <section id="pricing" className="scroll-mt-20 border-y border-ink-200 bg-ink-50/60">
        <div className="container-app py-16 sm:py-20">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              الاشتراكات
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-ink-600">
              اختر ما يناسبك — جميع الأسعار بالدرهم الإماراتي ويمكنك الإلغاء في أي وقت.
            </p>
          </div>

          {plans.length === 0 ? (
            <p className="mt-8 text-center text-sm text-ink-500">
              لم تُضَف الباقات بعد من لوحة الإدارة ← الاشتراكات.
            </p>
          ) : (
            <div className="mt-12 grid gap-6 lg:grid-cols-3">
              {plans.map((plan) => {
                const features = Array.isArray(plan.features)
                  ? (plan.features as string[])
                  : [];
                const isFeatured = plan.isFeatured;

                return (
                  <div
                    key={plan.id}
                    className={`relative flex flex-col rounded-2xl border bg-white p-7 ${
                      isFeatured
                        ? "border-brand-500 shadow-xl shadow-brand-500/10"
                        : "border-ink-200 shadow-sm"
                    }`}
                  >
                    {isFeatured ? (
                      <span className="absolute -top-3 right-1/2 translate-x-1/2 rounded-full bg-brand-600 px-4 py-1 text-xs font-bold text-white">
                        الأكثر اختيارًا
                      </span>
                    ) : null}

                    <h3 className="text-lg font-bold text-ink-900">{plan.nameAr}</h3>
                    <p className="mt-1 text-sm text-ink-500">{plan.tagline}</p>

                    <div className="mt-6 flex items-baseline gap-2">
                      <span className="text-3xl font-bold text-ink-900 tabular-nums">
                        {formatPrice(plan.monthlyPrice, plan.currency)}
                      </span>
                      {plan.monthlyPrice > 0 ? (
                        <span className="text-sm text-ink-500">/ شهريًا</span>
                      ) : null}
                    </div>

                    {plan.yearlyPrice > 0 ? (
                      <p className="mt-1 text-xs text-ink-500">
                        أو {formatPrice(plan.yearlyPrice, plan.currency)} سنويًا
                      </p>
                    ) : null}

                    <ul className="mt-6 flex-1 space-y-3">
                      {features.map((f) => (
                        <li key={f} className="flex items-start gap-2.5 text-sm text-ink-700">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                          {f}
                        </li>
                      ))}
                    </ul>

                    <ButtonLink
                      href={plan.monthlyPrice === 0 ? "/register" : `/pricing?plan=${plan.slug}`}
                      variant={isFeatured ? "primary" : "outline"}
                      className="mt-7 w-full"
                    >
                      {plan.monthlyPrice === 0 ? "ابدأ مجانًا" : "اشترك الآن"}
                    </ButtonLink>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* ============ آراء الطلاب ============ */}
      <section className="container-app py-16 sm:py-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
            ماذا يقول طلابنا
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-ink-600">
            ستُضاف آراء حقيقية هنا فور بدء استخدام المنصة مع الطلاب.
          </p>
        </div>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[
            {
              title: "آراء الطلاب",
              body: "سيظهر هنا رأي أول طالب يشاركه عبر لوحة الإدارة ← آراء الطلاب.",
              tone: "from-brand-500/10 to-brand-500/5",
            },
            {
              title: "آراء أولياء الأمور",
              body: "يمكن لولي الأمر إرسال تقييمه من حسابه بعد الشهر الأول.",
              tone: "from-emerald-500/10 to-emerald-500/5",
            },
            {
              title: "نتائج ملموسة",
              body: "نسبة تحسن في درجات الاختبارات قبل وبعد استخدام المنصة.",
              tone: "from-amber-500/10 to-amber-500/5",
            },
          ].map((item) => (
            <div
              key={item.title}
              className={`rounded-2xl border border-dashed border-ink-300 bg-gradient-to-br ${item.tone} p-7 text-center`}
            >
              <p className="text-sm font-bold text-ink-800">{item.title}</p>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ============ الأسئلة الشائعة ============ */}
      <section id="faq" className="scroll-mt-20 border-y border-ink-200 bg-ink-50/60">
        <div className="container-app py-16 sm:py-20">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              الأسئلة الشائعة
            </h2>
          </div>

          <div className="mx-auto mt-10 max-w-3xl space-y-3">
            {faq.map((item) => (
              <details
                key={item.q}
                className="group card overflow-hidden [&_summary::-webkit-details-marker]:hidden"
              >
                <summary className="flex cursor-pointer items-center justify-between gap-4 px-5 py-4 font-semibold text-ink-900 transition-colors hover:bg-ink-50">
                  {item.q}
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-ink-100 text-ink-600 transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <div className="border-t border-ink-100 px-5 py-4 text-sm leading-loose text-ink-600">
                  {item.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* ============ دعوة أخيرة ============ */}
      <section className="container-app py-16 sm:py-20">
        <div className="overflow-hidden rounded-3xl bg-gradient-to-l from-brand-700 via-brand-600 to-brand-500 px-6 py-14 text-center sm:px-12">
          <h2 className="text-2xl font-bold text-white sm:text-3xl">
            ابدأ رحلتك في الرياضيات اليوم
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-50">
            أنشئ حسابك مجانًا وجرّب أول درس خلال دقيقة واحدة. لا نطلب بطاقة ائتمانية.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink
              href={user ? "/dashboard" : "/register"}
              size="lg"
              className="bg-white text-brand-700 hover:bg-brand-50"
            >
              {user ? "اذهب إلى لوحة التحكم" : "أنشئ حسابك المجاني"}
            </ButtonLink>
            <ButtonLink
              href="/pricing"
              variant="outline"
              size="lg"
              className="border-white/40 bg-transparent text-white hover:border-white hover:text-white"
            >
              مقارنة الباقات
            </ButtonLink>
          </div>
        </div>
      </section>

      {/* ============ التواصل ============ */}
      <section id="contact" className="scroll-mt-20 border-t border-ink-200">
        <div className="container-app py-16">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">
              تواصل معنا
            </h2>
            <p className="mx-auto mt-3 max-w-2xl text-ink-600">
              لأي استفسار عن المنصة أو طلب إضافة صف أو مقترحات لتحسين الدروس.
            </p>
          </div>

          <div className="mx-auto mt-10 grid max-w-3xl gap-4 sm:grid-cols-3">
            {[
              {
                icon: "mail",
                label: "البريد الإلكتروني",
                value: settings.contactEmail || "غير محدد بعد",
                href: settings.contactEmail ? `mailto:${settings.contactEmail}` : null,
              },
              {
                icon: "phone",
                label: "الهاتف / واتساب",
                value: settings.contactPhone || "غير محدد بعد",
                href: settings.contactPhone ? `tel:${settings.contactPhone}` : null,
              },
              {
                icon: "map",
                label: "الموقع",
                value: settings.address || "دولة الإمارات العربية المتحدة",
                href: null,
              },
            ].map((item) => {
              const Icon =
                item.icon === "mail"
                  ? Search
                  : item.icon === "phone"
                    ? Bell
                    : ClipboardCheck;
              const inner = (
                <div className="card h-full p-6 text-center transition-shadow hover:shadow-md">
                  <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-brand-50 text-brand-600">
                    <Icon className="h-6 w-6" />
                  </span>
                  <p className="mt-4 text-sm font-semibold text-ink-900">{item.label}</p>
                  <p className="mt-1 text-sm text-ink-500" dir="auto">
                    {item.value}
                  </p>
                </div>
              );
              return item.href ? (
                <a key={item.label} href={item.href} className="block">
                  {inner}
                </a>
              ) : (
                <div key={item.label}>{inner}</div>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}