import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { getCurrentUser } from "@/lib/auth/session";
import { getActivePlans, getFeaturedLessons } from "@/lib/content";
import { ButtonLink } from "@/components/ui/buttons";
import {
  Brain,
  ClipboardCheck,
  BarChart3,
  MessagesSquare,
  CalendarClock,
  Lock,
  ArrowLeft,
  FileText,
  Video,
  PlayCircle,
} from "lucide-react";
import { PLATFORM } from "@/lib/platform";
import { DIFFICULTY_LEVELS, EXAM_TYPES } from "@/lib/platform";
import { formatPrice } from "@/lib/utils";

export const metadata: Metadata = {
  title: "استكشف المنصة",
  description: `تعرّف على أدوات منصة ${PLATFORM.gradeNameAr}: بنك الأسئلة، الاختبارات، التحليل الذكي، خطة الدراسة، ومساعد الرياضيات — كلّه browsable قبل تسجيل الدخول.`,
  alternates: { canonical: "/explore" },
};

/**
 * صفحة عامة تحاكي شكل المنصة الداخلية (كالموقع الحكومي) — يستطيع الزائر
 * تصفّح كل الأقسام دون حساب، ويبدأ فقط عند التفاعل الحقيقي.
 */
export default async function ExplorePage() {
  const [user, plans, lessons, questionCount, examCount, skillCount] =
    await Promise.all([
      getCurrentUser().catch(() => null),
      getActivePlans().catch(() => []),
      getFeaturedLessons(4).catch(() => []),
      prisma.question
        .count({ where: { isActive: true } })
        .catch(() => 0),
      prisma.exam.count({ where: { status: "PUBLISHED" } }).catch(() => 0),
      prisma.skill.count().catch(() => 0),
    ]);

  const byDifficulty = await Promise.all(
    DIFFICULTY_LEVELS.map(async (d) => ({
      ...d,
      count: await prisma.question
        .count({ where: { isActive: true, difficulty: d.value } })
        .catch(() => 0),
    })),
  );

  const tools = [
    {
      icon: Brain,
      title: "بنك الأسئلة",
      desc: "تدريب فوري على أي مهارة مع تصحيح على الخادم وحل نموذجي لكل سؤال.",
      href: "/dashboard/question-bank",
      stat: `${questionCount} سؤالًا مصنّفًا بالمهارات`,
      points: [
        "فلترة بالوحدة والمهارة ومستوى الصعوبة",
        "تصحيح فوري وشرح سبب الخطأ",
        "جلسة سريعة: 10 أسئلة في دقائق",
      ],
    },
    {
      icon: ClipboardCheck,
      title: "الاختبارات",
      desc: "ستة أنواع من الاختبارات بتصحيح فوري ودرجة نجاح ومؤقّت.",
      href: "/dashboard/exams",
      stat: `${examCount} اختبارًا منشورًا`,
      points: [
        "اختبار درس أو وحدة أو فصل دراسي",
        "اختبارات شاملة ومراجعة وتجريبية",
        "تحليل للأخطاء بعد التسليم",
      ],
    },
    {
      icon: BarChart3,
      title: "مستواي (التحليل الذكي)",
      desc: "تقرير مبني على أدائك الحقيقي: نقاط قوة، نقاط تحتاج مراجعة، وتوصيات.",
      href: "/dashboard/analysis",
      stat: `${skillCount} مهارة تُقاس`,
      points: [
        "نسبة الإجابات الصحيحة لكل مهارة",
        "توصيات مرتبطة بالدروس والأوراق",
        "خمس خطوات عملية لكل نقطة ضعف",
      ],
    },
    {
      icon: CalendarClock,
      title: "خطة الدراسة",
      desc: "خطة أسبوعية مرنة تغطي ما لم يُنجَز وما يحتاج مراجعة.",
      href: "/dashboard/study-plan",
      stat: "خطة تتجدّد مع أدائك",
      points: [
        "توزيع يومي للدروس والاختبارات",
        "أولوية للمهارات الضعيفة",
        "قابلة لإعادة التوليد في أي وقت",
      ],
    },
    {
      icon: MessagesSquare,
      title: "مساعد الرياضيات",
      desc: "يشرح الفكرة ويحدّد القانون ويخطّط الحل ثم يختبر فهمك — لا يعطي الإجابة فقط.",
      href: "/dashboard/tutor",
      stat: "شرح خطوة بخطوة",
      points: [
        "تحديد القانون المناسب للسؤال",
        "خطوات مرقّمة ومثال مشابه",
        "سؤال متابعة للتأكد من الفهم",
      ],
    },
  ];

  return (
    <div className="container-app py-10 sm:py-14">
      <div className="mx-auto max-w-5xl">
        <header className="mb-10 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-xs font-semibold text-brand-700">
            استكشف كل شيء قبل أن تسجّل
          </span>
          <h1 className="mt-4 text-2xl font-bold text-ink-900 sm:text-3xl">
            أدوات المنصة — متاحة للتصفح بلا حساب
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-relaxed text-ink-600 sm:text-base">
            تصفّح كما لو كنت داخل المنصة: بنك الأسئلة والاختبارات والتحليل وخطة
            الدراسة والمساعد. كل ما يتفاعل فعليًا (حل سؤال، تقديم اختبار، فتح
            تحليل) يحتاج حسابًا — سجّل الدخول مجانًا.
          </p>
        </header>

        {/* الأدوات */}
        <div className="grid gap-4 sm:grid-cols-2">
          {tools.map((t) => {
            const Icon = t.icon;
            return (
              <section key={t.href} className="card p-6">
                <div className="flex items-start gap-3">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600">
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <h2 className="text-base font-bold text-ink-900">{t.title}</h2>
                    <p className="mt-0.5 text-xs font-semibold text-brand-700">
                      {t.stat}
                    </p>
                  </div>
                </div>

                <p className="mt-3 text-sm leading-relaxed text-ink-600">
                  {t.desc}
                </p>

                <ul className="mt-3 space-y-1.5 text-sm text-ink-600">
                  {t.points.map((p) => (
                    <li key={p} className="flex items-start gap-2">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-400" />
                      {p}
                    </li>
                  ))}
                </ul>

                <div className="mt-4 flex flex-wrap gap-2">
                  {user ? (
                    <ButtonLink href={t.href} size="sm">
                      افتح {t.title}
                      <ArrowLeft className="h-4 w-4" />
                    </ButtonLink>
                  ) : (
                    <>
                      <ButtonLink href={`/login?next=${t.href}`} size="sm">
                        <Lock className="h-3.5 w-3.5" />
                        سجّل الدخول للاستخدام
                      </ButtonLink>
                      <Link
                        href={t.href}
                        className="inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-semibold text-ink-600 transition-colors hover:bg-ink-50"
                      >
                        معاينة
                        <ArrowLeft className="h-3.5 w-3.5" />
                      </Link>
                    </>
                  )}
                </div>
              </section>
            );
          })}
        </div>

        {/* مستويات الصعوبة — بيانات حقيقية */}
        <section className="card mt-6 p-6">
          <h2 className="text-base font-bold text-ink-900">
            بنك الأسئلة حسب الصعوبة
          </h2>
          <p className="mt-1 text-sm text-ink-600">
            كل مستوى مربوط بمهارات المنهج — هكذا تتدرّب على النقطة التي تحتاجها
            بالضبط.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {byDifficulty.map((d) => (
              <div key={d.value} className="rounded-xl border border-ink-200 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-ink-800">
                    {d.emoji} {d.label}
                  </span>
                  <span className="text-lg font-extrabold tabular-nums text-ink-900">
                    {d.count}
                  </span>
                </div>
                <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
                  <div
                    className={`h-full rounded-full ${d.dot}`}
                    style={{
                      width: `${Math.min(
                        100,
                        (d.count / Math.max(1, questionCount)) * 100
                      )}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* أنواع الاختبارات */}
        <section className="card mt-6 p-6">
          <h2 className="text-base font-bold text-ink-900">أنواع الاختبارات</h2>
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {EXAM_TYPES.map((e) => (
              <div
                key={e.value}
                className="flex items-center gap-2 rounded-lg border border-ink-200 px-3 py-2.5 text-sm"
              >
                <span aria-hidden>{e.icon}</span>
                <span className="font-semibold text-ink-800">{e.label}</span>
              </div>
            ))}
          </div>
        </section>

        {/* دروس و-paper */}
        <section className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="card p-6">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Video className="h-4.5 w-4.5 text-brand-600" />
              دروس فيديو وملخصات
            </h2>
            <ul className="mt-3 space-y-2">
              {lessons.map((l) => (
                <li key={l.id} className="text-sm">
                  <Link
                    href={`/lessons/${l.slug}`}
                    className="font-semibold text-brand-700 hover:underline"
                  >
                    {l.title}
                  </Link>
                  <p className="text-xs text-ink-500">{l.summary}</p>
                </li>
              ))}
            </ul>
            <Link
              href="/lessons"
              className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:underline"
            >
              كل الدروس
              <ArrowLeft className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="card p-6">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <FileText className="h-4.5 w-4.5 text-brand-600" />
              الاشتراكات والأسعار
            </h2>
            <ul className="mt-3 space-y-2.5">
              {plans.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3 text-sm"
                >
                  <span className="font-semibold text-ink-800">{p.nameAr}</span>
                  <span className="tabular-nums text-ink-900">
                    {formatPrice(p.monthlyPrice, "AED")}
                    <span className="text-xs text-ink-500"> / شهريًا</span>
                  </span>
                </li>
              ))}
            </ul>
            <Link
              href="/pricing"
              className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:underline"
            >
              تفاصيل الباقات
              <ArrowLeft className="h-3.5 w-3.5" />
            </Link>
          </div>
        </section>

        {/* دعوة للتسجيل */}
        <section className="mt-8 overflow-hidden rounded-2xl bg-gradient-to-l from-brand-700 to-brand-500 p-8 text-center text-white">
          <PlayCircle className="mx-auto h-9 w-9" />
          <h2 className="mt-3 text-xl font-bold">
            جرّب المنصة كاملة — الحساب مجاني
          </h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-brand-100">
            سجّل حسابك وابدأ رحلتك: شرح ← تدريب ← اختبار → تحليل ← مراجعة ←
            إتقان.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <ButtonLink href={user ? "/dashboard" : "/register"} variant="outline">
              {user ? "لوحتي" : "أنشئ حسابًا مجانيًا"}
              <ArrowLeft className="h-4 w-4" />
            </ButtonLink>
            <Link
              href="/lessons"
              className="inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold text-white/90 transition-colors hover:bg-white/10"
            >
              تصفّح الدروس
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
