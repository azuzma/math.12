"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { PlayCircle, Video, FileText, ClipboardCheck, Lock } from "lucide-react";
import { AccessBadge } from "@/components/ui/badges";
import { ButtonLink, EmptyState } from "@/components/ui/buttons";
import { formatDuration, cn } from "@/lib/utils";

export type CatalogLesson = {
  id: string;
  slug: string;
  title: string;
  summary: string | null;
  isFree: boolean;
  isPreview: boolean;
  durationSec: number | null;
  updatedAt: Date | string;
  skill: { id: string; title: string } | null;
  unit: {
    title: string;
    term: { id: string; title: string } | null;
    course: {
      subject: { grade: { nameAr: string; slug: string } };
    };
  };
  _count: { videos: number; files: number; exams: number };
};

export type CatalogResult = {
  items: CatalogLesson[];
  total: number;
  page: number;
  perPage: number;
  pages: number;
};

export function LessonCatalog({
  grades,
  terms,
  initialGrade,
  initialTerm,
  initialUnit,
  initialFree,
  result,
  isLoggedIn,
}: {
  grades: { value: string; label: string }[];
  terms: { value: string; label: string }[];
  initialGrade: string;
  initialTerm: string;
  initialUnit: string;
  initialFree: boolean;
  result: CatalogResult;
  isLoggedIn: boolean;
}) {
  const router = useRouter();
  const grade = initialGrade;
  const term = initialTerm;
  const unit = initialUnit;
  const freeOnly = initialFree;

  function navigate(
    nextGrade: string,
    nextFree: boolean,
    nextTerm = term,
    nextUnit = unit,
    page = 1,
  ) {
    const sp = new URLSearchParams();
    if (nextGrade) sp.set("grade", nextGrade);
    if (nextTerm) sp.set("term", nextTerm);
    if (nextUnit) sp.set("unit", nextUnit);
    if (nextFree) sp.set("free", "1");
    if (page > 1) sp.set("page", String(page));
    const qs = sp.toString();
    router.push(qs ? `/lessons?${qs}` : "/lessons");
  }

  if (result.items.length === 0) {
    return (
      <>
        <Filters
          grade={grade}
          term={term}
          unit={unit}
          freeOnly={freeOnly}
          grades={grades}
          terms={terms}
          onChange={navigate}
        />
        <div className="mt-8">
          <EmptyState
            title="لا توجد دروس في هذا الاختيار"
            description="جرّب اختيار صف مختلف أو أزل فلتر «المجانية فقط». يمكن للأستاذ إضافة الدروس من لوحة الإدارة."
          />
        </div>
      </>
    );
  }

  return (
    <>
      <Filters
        grade={grade}
        term={term}
        unit={unit}
        freeOnly={freeOnly}
        grades={grades}
        terms={terms}
        onChange={navigate}
        total={result.total}
      />

      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {result.items.map((lesson) => {
          const href = isLoggedIn ? `/dashboard/lessons/${lesson.slug}` : `/lessons/${lesson.slug}`;

          return (
            <article key={lesson.id} className="card group flex flex-col overflow-hidden">
              <div className="relative aspect-video bg-gradient-to-br from-brand-500 to-brand-700">
                <div className="absolute inset-0 grid place-items-center">
                  <PlayCircle className="h-12 w-12 text-white/85 transition-transform group-hover:scale-110" />
                </div>
                <div className="absolute top-3 right-3">
                  <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
                </div>
                {!lesson.isFree && !isLoggedIn ? (
                  <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1.5 bg-ink-950/70 py-2 text-xs font-medium text-white">
                    <Lock className="h-3.5 w-3.5" />
                    يتطلب تسجيل الدخول
                  </div>
                ) : lesson.durationSec ? (
                  <span className="absolute bottom-3 left-3 rounded bg-black/60 px-2 py-0.5 text-xs font-medium text-white tabular-nums">
                    {formatDuration(lesson.durationSec)}
                  </span>
                ) : null}
              </div>

              <div className="flex flex-1 flex-col p-5">
                <p className="text-xs font-semibold text-brand-600">
                  {lesson.unit.term?.title ?? "المنهج"} · {lesson.unit.title}
                </p>
                <h2 className="mt-1.5 font-bold text-ink-900">{lesson.title}</h2>
                {lesson.skill ? (
                  <p className="mt-0.5 text-[11px] font-medium text-ink-400">
                    مهارة: {lesson.skill.title}
                  </p>
                ) : null}
                <p className="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-ink-500">
                  {lesson.summary}
                </p>

                <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-ink-500">
                  <span className="inline-flex items-center gap-1">
                    <Video className="h-3.5 w-3.5" />
                    {lesson._count.videos}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <FileText className="h-3.5 w-3.5" />
                    {lesson._count.files}
                  </span>
                  {lesson._count.exams > 0 ? (
                    <span className="inline-flex items-center gap-1">
                      <ClipboardCheck className="h-3.5 w-3.5" />
                      {lesson._count.exams}
                    </span>
                  ) : null}
                </div>

                <ButtonLink
                  href={href}
                  variant="soft"
                  size="sm"
                  className="mt-4 w-full"
                >
                  عرض الدرس
                </ButtonLink>
              </div>
            </article>
          );
        })}
      </div>

      {result.pages > 1 ? (
        <Pagination
          page={result.page}
          pages={result.pages}
          onGo={(p) => navigate(grade, freeOnly, term, unit, p)}
        />
      ) : null}
    </>
  );
}

function Filters({
  grade,
  term,
  unit,
  freeOnly,
  grades,
  terms,
  onChange,
  total,
}: {
  grade: string;
  term: string;
  unit: string;
  freeOnly: boolean;
  grades: { value: string; label: string }[];
  terms: { value: string; label: string }[];
  onChange: (
    grade: string,
    free: boolean,
    term?: string,
    unit?: string,
    page?: number,
  ) => void;
  total?: number;
}) {
  return (
    <div className="mt-8 space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {terms.map((t) => (
          <FilterChip
            key={t.value}
            active={term === t.value}
            onClick={() => onChange(grade, freeOnly, t.value, "")}
          >
            {t.label}
          </FilterChip>
        ))}
        <FilterChip active={term === ""} onClick={() => onChange(grade, freeOnly, "", "")}>
          كل الفصول
        </FilterChip>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <label className="flex cursor-pointer items-center gap-2 text-sm text-ink-700">
          <input
            type="checkbox"
            checked={freeOnly}
            onChange={(e) => onChange(grade, e.target.checked, term, unit)}
            className="h-4 w-4 rounded border-ink-300 accent-brand-600"
          />
          المجانية فقط
        </label>

        {total !== undefined ? (
          <span className="text-sm text-ink-500 tabular-nums">{total} درس</span>
        ) : null}

        {unit ? (
          <Link
            href={term ? `/lessons?term=${term}` : "/lessons"}
            className="text-xs font-semibold text-ink-500 hover:text-ink-800 hover:underline"
          >
            مسح الوحدة
          </Link>
        ) : null}
      </div>
    </div>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
        active
          ? "border-brand-600 bg-brand-600 text-white"
          : "border-ink-200 bg-white text-ink-700 hover:border-brand-300 hover:text-brand-700",
      )}
    >
      {children}
    </button>
  );
}

function Pagination({
  page,
  pages,
  onGo,
}: {
  page: number;
  pages: number;
  onGo: (p: number) => void;
}) {
  const nums: number[] = [];
  const start = Math.max(1, page - 2);
  for (let i = start; i <= Math.min(pages, start + 4); i++) nums.push(i);

  return (
    <nav className="mt-10 flex items-center justify-center gap-1.5" aria-label="التنقل بين الصفحات">
      <button
        type="button"
        onClick={() => onGo(page - 1)}
        disabled={page <= 1}
        className="btn btn-outline h-9 px-3 text-sm disabled:opacity-40"
      >
        السابق
      </button>

      {nums.map((n) => (
        <button
          key={n}
          type="button"
          onClick={() => onGo(n)}
          aria-current={n === page ? "page" : undefined}
          className={cn(
            "h-9 w-9 rounded-lg text-sm font-semibold tabular-nums transition-colors",
            n === page
              ? "bg-brand-600 text-white"
              : "text-ink-700 hover:bg-ink-100",
          )}
        >
          {n}
        </button>
      ))}

      <button
        type="button"
        onClick={() => onGo(page + 1)}
        disabled={page >= pages}
        className="btn btn-outline h-9 px-3 text-sm disabled:opacity-40"
      >
        التالي
      </button>
    </nav>
  );
}