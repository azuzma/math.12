import type { Metadata } from "next";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { getGrades, getLessonsForCatalog } from "@/lib/content";
import { prisma } from "@/lib/db/prisma";
import { PLATFORM } from "@/lib/platform";
import { LessonCatalog } from "./lesson-catalog";

export const metadata: Metadata = {
  title: "كل الدروس",
  description: `تصفح دروس ${PLATFORM.gradeNameAr} بالفيديو، مقسّمة إلى فصول دراسية ووحدات ومهارات، مع الملخصات وأوراق العمل والاختبارات القصيرة.`,
  alternates: { canonical: "/lessons" },
};

export default async function LessonsPage({
  searchParams,
}: {
  searchParams: Promise<{
    grade?: string;
    term?: string;
    unit?: string;
    page?: string;
    free?: string;
  }>;
}) {
  const sp = await searchParams;
  const currentPage = Math.max(1, Number(sp.page ?? "1") || 1);

  const [grades, user, terms] = await Promise.all([
    getGrades(),
    getCurrentUser(),
    prisma.term.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { order: "asc" },
      select: { id: true, slug: true, title: true },
    }),
  ]);

  const grade = sp.grade ? grades.find((g) => g.slug === sp.grade) : undefined;

  const result = await getLessonsForCatalog({
    gradeId: grade?.id,
    termSlug: sp.term,
    unitSlug: sp.unit,
    page: currentPage,
    perPage: 12,
    freeOnly: sp.free === "1",
  });

  const activeTerm = terms.find((t) => t.slug === sp.term);
  const activeUnit = sp.unit
    ? await prisma.unit.findUnique({
        where: { slug: sp.unit },
        select: { title: true },
      })
    : null;

  return (
    <div className="container-app py-10 sm:py-14">
      <div className="mx-auto max-w-5xl">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">
            {activeUnit
              ? activeUnit.title
              : activeTerm
                ? `دروس ${activeTerm.title}`
                : `دروس ${PLATFORM.gradeNameAr}`}
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-ink-600">
            {result.total > 0
              ? `${result.total} درس متاح. الدروس المجانية يمكن مشاهدتها بالكامل بدون تسجيل.`
              : "لم يُنشر دروس بعد في هذا القسم."}
          </p>
        </div>

        <LessonCatalog
          grades={grades.map((g) => ({ value: g.slug, label: g.nameAr }))}
          terms={terms.map((t) => ({ value: t.slug, label: t.title }))}
          initialGrade={sp.grade ?? ""}
          initialTerm={sp.term ?? ""}
          initialUnit={sp.unit ?? ""}
          initialFree={sp.free === "1"}
          result={result}
          isLoggedIn={Boolean(user)}
        />

        <div className="mt-10 text-center">
          <Link href="/register" className="btn btn-primary">
            أنشئ حسابك وابدأ التعلم
          </Link>
        </div>
      </div>
    </div>
  );
}