import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { getCurrentUser } from "@/lib/auth/session";
import { getEntitlement } from "@/lib/auth/entitlements";
import { getLessonBySlug } from "@/lib/content";
import { AccessBadge, KindBadge } from "@/components/ui/badges";
import { Alert, ButtonLink, EmptyState } from "@/components/ui/buttons";
import { FileText, ClipboardCheck, PlayCircle, Lock, ArrowLeft } from "lucide-react";
import { formatBytes, formatDuration } from "@/lib/utils";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const lesson = await prisma.lesson.findUnique({
    where: { slug },
    select: {
      title: true,
      summary: true,
      isFree: true,
      status: true,
      unit: {
        select: {
          title: true,
          course: { select: { subject: { select: { grade: { select: { nameAr: true } } } } } },
        },
      },
    },
  });

  if (!lesson || lesson.status !== "PUBLISHED") {
    return { title: "الدرس غير متاح" };
  }

  return {
    title: `${lesson.title} — ${lesson.unit.course.subject.grade.nameAr}`,
    description:
      lesson.summary ??
      `شرح درس ${lesson.title} في ${lesson.unit.title} مع ملخص وأوراق عمل واختبار قصير.`,
    openGraph: {
      title: lesson.title,
      description: lesson.summary ?? "",
      type: "article",
    },
  };
}

export default async function PublicLessonPage({ params }: Props) {
  const { slug } = await params;
  const lesson = await getLessonBySlug(slug);
  if (!lesson) notFound();

  const user = await getCurrentUser();
  const ent = user ? await getEntitlement(user.id) : null;

  const hasAccess = lesson.isFree || Boolean(ent?.canViewPaidContent);
  const gradeName = lesson.unit.course.subject.grade.nameAr;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "LearningResource",
    name: lesson.title,
    description: lesson.summary ?? lesson.title,
    inLanguage: "ar-AE",
    educationalLevel: gradeName,
    learningResourceType: "Lesson",
    isAccessibleForFree: lesson.isFree,
    provider: { "@type": "Organization", name: "منصة أستاذ الرياضيات" },
  };

  return (
    <div className="container-app py-8 sm:py-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="mx-auto max-w-4xl">
        {/* مسار التنقل */}
        <nav className="flex flex-wrap items-center gap-2 text-sm text-ink-500" aria-label="مسار التنقل">
          <Link href="/lessons" className="hover:text-brand-700">
            الدروس
          </Link>
          <span aria-hidden>/</span>
          <Link href={`/lessons?grade=${lesson.unit.course.subject.grade.slug}`} className="hover:text-brand-700">
            {gradeName}
          </Link>
          <span aria-hidden>/</span>
          <span className="text-ink-800">{lesson.unit.title}</span>
        </nav>

        <header className="mt-4">
          <div className="flex flex-wrap items-center gap-2">
            <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
            {lesson.durationSec ? (
              <span className="text-xs text-ink-500">
                مدة الفيديو {formatDuration(lesson.durationSec)}
              </span>
            ) : null}
          </div>
          <h1 className="mt-3 text-2xl font-bold text-ink-900 sm:text-3xl">
            {lesson.title}
          </h1>
          {lesson.summary ? (
            <p className="mt-3 text-base leading-relaxed text-ink-600">
              {lesson.summary}
            </p>
          ) : null}
        </header>

        {/* الفيديو */}
        <section className="mt-8">
          {lesson.videos.length > 0 ? (
            <div className="overflow-hidden rounded-2xl bg-ink-950">
              <div className="aspect-video">
                <div className="grid h-full place-items-center">
                  <div className="text-center text-white/70">
                    <PlayCircle className="mx-auto h-16 w-16" />
                    <p className="mt-3 text-sm">
                      {hasAccess
                        ? "شغّل الدرس من لوحة التحكم لمتابعة تقدمك"
                        : "هذا الدرس متاح للمشتركين"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-ink-300 bg-ink-50 p-8 text-center">
              <p className="text-sm text-ink-500">
                لم يُرفع فيديو لهذا الدرس بعد.
              </p>
            </div>
          )}
        </section>

        {/* الشرح */}
        {lesson.description ? (
          <section className="mt-8">
            <h2 className="text-lg font-bold text-ink-900">شرح الدرس</h2>
            <div className="mt-3 space-y-3 leading-loose text-ink-700">
              {lesson.description.split("\n").map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </section>
        ) : null}

        {/* الملفات */}
        <section id="files" className="mt-10 scroll-mt-24">
          <h2 className="text-lg font-bold text-ink-900">
            الملخصات وأوراق العمل
          </h2>

          {lesson.files.length === 0 ? (
            <div className="mt-3 rounded-xl border border-dashed border-ink-300 p-6 text-center">
              <p className="text-sm text-ink-500">لا توجد ملفات لهذا الدرس.</p>
            </div>
          ) : (
            <ul className="mt-3 space-y-2.5">
              {lesson.files.map((file) => {
                const fileHasAccess = file.isFree || lesson.isFree || hasAccess;
                return (
                  <li key={file.id}>
                    <div className="card flex items-center gap-4 p-4">
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-600">
                        <FileText className="h-5 w-5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="font-semibold text-ink-900">{file.title}</p>
                          <KindBadge kind={file.kind} />
                          {!file.isFree && !lesson.isFree ? (
                            <AccessBadge isFree={false} />
                          ) : null}
                        </div>
                        {file.description ? (
                          <p className="mt-0.5 text-xs text-ink-500">{file.description}</p>
                        ) : null}
                        <p className="mt-0.5 text-xs text-ink-400">
                          {file.pageCount ? `${file.pageCount} صفحة · ` : ""}
                          {formatBytes(file.sizeBytes)}
                        </p>
                      </div>

                      {fileHasAccess ? (
                        <ButtonLink
                          href={user ? "/dashboard" : "/register"}
                          variant="soft"
                          size="sm"
                        >
                          فتح
                        </ButtonLink>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-ink-500">
                          <Lock className="h-3.5 w-3.5" />
                          مدفوع
                        </span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {/* الاختبارات */}
        <section id="exams" className="mt-10 scroll-mt-24">
          <h2 className="text-lg font-bold text-ink-900">اختبارات الدرس</h2>

          {lesson.exams.length === 0 ? (
            <div className="mt-3 rounded-xl border border-dashed border-ink-300 p-6 text-center">
              <p className="text-sm text-ink-500">لا توجد اختبارات لهذا الدرس.</p>
            </div>
          ) : (
            <ul className="mt-3 grid gap-3 sm:grid-cols-2">
              {lesson.exams.map((exam) => (
                <li key={exam.id} className="card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold text-ink-900">{exam.title}</p>
                      <p className="mt-1 text-xs text-ink-500">
                        {exam._count.questions} سؤال · {exam.durationMinutes} دقيقة ·{" "}
                        {exam.attemptsAllowed} محاولات
                      </p>
                    </div>
                    <ClipboardCheck className="h-5 w-5 shrink-0 text-brand-600" />
                  </div>

                  <ButtonLink
                    href={
                      exam.isFree || hasAccess
                        ? user
                          ? `/dashboard/exams/${exam.id}`
                          : "/register"
                        : "/pricing"
                    }
                    variant={exam.isFree ? "soft" : "outline"}
                    size="sm"
                    className="mt-4 w-full"
                  >
                    {exam.isFree || hasAccess ? "ابدأ الاختبار" : "يتطلب اشتراكًا"}
                  </ButtonLink>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* دعوة للتسجيل */}
        {!hasAccess ? (
          <div className="mt-10">
            <Alert
              tone="info"
              title="هذا الدرس متاح للمشتركين"
              action={
                <ButtonLink href="/pricing" size="sm">
                  عرض الباقات
                </ButtonLink>
              }
            >
              سجّل حسابك المجاني لتجرب المنصة، أو اشترك في إحدى الباقات لفتح كل
              الدروس والاختبارات والحلول النموذجية.
            </Alert>
          </div>
        ) : !user ? (
          <div className="mt-10">
            <Alert
              tone="success"
              title="هذا الدرس مجاني"
              action={
                <ButtonLink href="/register" size="sm">
                  إنشاء حساب
                </ButtonLink>
              }
            >
              أنشئ حسابًا مجانيًا لحفظ تقدمك في هذا الدرس ومتابعة بقية الوحدة.
            </Alert>
          </div>
        ) : (
          <div className="mt-10">
            <ButtonLink href={`/dashboard/lessons/${lesson.slug}`} className="w-full sm:w-auto">
              متابعة الدرس في لوحة التحكم
              <ArrowLeft className="h-4 w-4" />
            </ButtonLink>
          </div>
        )}

        {/* روابط الدروس المجانية الأخرى */}
        <RelatedLessons currentSlug={slug} gradeSlug={lesson.unit.course.subject.grade.slug} />
      </div>
    </div>
  );
}

async function RelatedLessons({
  currentSlug,
  gradeSlug,
}: {
  currentSlug: string;
  gradeSlug: string;
}) {
  const lessons = await prisma.lesson.findMany({
    where: {
      slug: { not: currentSlug },
      status: "PUBLISHED",
      isFree: true,
      unit: { course: { subject: { grade: { slug: gradeSlug } } } },
    },
    take: 4,
    orderBy: { updatedAt: "desc" },
    select: { slug: true, title: true, summary: true },
  });

  if (lessons.length === 0) return null;

  return (
    <section className="mt-12 border-t border-ink-200 pt-8">
      <h2 className="text-base font-bold text-ink-900">دروس مجانية أخرى</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {lessons.map((l) => (
          <Link
            key={l.slug}
            href={`/lessons/${l.slug}`}
            className="card p-4 transition-colors hover:border-brand-300"
          >
            <p className="font-semibold text-ink-900">{l.title}</p>
            {l.summary ? (
              <p className="mt-1 line-clamp-2 text-xs text-ink-500">{l.summary}</p>
            ) : null}
          </Link>
        ))}
      </div>
    </section>
  );
}