"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { Search, Loader2 } from "lucide-react";

export function SearchInput({
  basePath,
  initialQuery,
  initialGrade,
  gradeOptions,
}: {
  basePath: string;
  initialQuery: string;
  initialGrade: string;
  gradeOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [query, setQuery] = useState(initialQuery);
  const [grade, setGrade] = useState(initialGrade);
  const [pending, setPending] = useState(false);

  function go(nextQuery: string, nextGrade: string) {
    const sp = new URLSearchParams();
    if (nextQuery.trim()) sp.set("q", nextQuery.trim());
    if (nextGrade) sp.set("grade", nextGrade);
    setPending(true);
    router.push(`${basePath}?${sp.toString()}`);
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        go(query, grade);
      }}
      className="flex flex-col gap-3 sm:flex-row"
      role="search"
    >
      <div className="relative flex-1">
        <Search className="pointer-events-none absolute top-1/2 right-3.5 h-4.5 w-4.5 -translate-y-1/2 text-ink-400" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="اكتب كلمة البحث…"
          className="input pr-11"
          aria-label="كلمة البحث"
          autoComplete="off"
        />
      </div>

      <select
        value={grade}
        onChange={(e) => {
          setGrade(e.target.value);
          go(query, e.target.value);
        }}
        className="input cursor-pointer sm:w-52"
        aria-label="تصفية حسب الصف"
      >
        {gradeOptions.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>

      <button type="submit" className="btn btn-primary sm:px-6" disabled={pending}>
        {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
        بحث
      </button>
    </form>
  );
}