import Link from "next/link";
import {
  FileText,
  FolderTree,
  ClipboardCheck,
  Search as SearchIcon,
  Lock,
} from "lucide-react";
import { searchContent, type SearchHit } from "@/lib/content";
import { AccessBadge } from "@/components/ui/badges";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";

const typeMeta: Record<SearchHit["type"], { label: string; icon: typeof FileText }> = {
  lesson: { label: "درس", icon: FolderTree },
  unit: { label: "وحدة", icon: FolderTree },
  exam: { label: "اختبار", icon: ClipboardCheck },
  file: { label: "ملف", icon: FileText },
};

export async function SearchResults({
  query,
  grade,
  isLoggedIn,
}: {
  query: string;
  grade?: string;
  isLoggedIn: boolean;
}) {
  if (!query || query.trim().length < 2) {
    return (
      <EmptyState
        title="ابدأ البحث"
        description="اكتب كلمة مفتاحية مثل «مشتقات» أو «مصفوفات» أو «ورقة عمل المتجهات»."
        icon={<SearchIcon className="h-6 w-6" />}
      />
    );
  }

  const result = await searchContent(query);

  // تصفية حسب الصف عبر breadcrumb
  let hits = result.hits;
  if (grade) {
    const gradeName = await getGradeNameBySlug(grade);
    if (gradeName) {
      hits = hits.filter((h) => h.breadcrumb.includes(gradeName));
    }
  }

  const needsLogin = hits.filter((h) => !h.isFree);

  if (hits.length === 0) {
    return (
      <EmptyState
        title={`لا توجد نتائج لـ «${query}»`}
        description="جرّب كلمة أقصر أو أعم، أو تصفّح كل الدروس من صفحة الدروس."
        icon={<SearchIcon className="h-6 w-6" />}
        action={
          <ButtonLink href="/lessons" variant="outline">
            تصفّح كل الدروس
          </ButtonLink>
        }
      />
    );
  }

  return (
    <div className="mt-8">
      <p className="mb-4 text-sm text-ink-600">
        عُثر على <span className="font-bold text-ink-900">{hits.length}</span> نتيجة
        {needsLogin.length > 0 ? (
          <span className="text-ink-500">
            {" "}
            — {needsLogin.length} منها للمشتركين
          </span>
        ) : null}
      </p>

      <ul className="space-y-3">
        {hits.map((hit, i) => {
          const meta = typeMeta[hit.type];
          const Icon = meta.icon;
          const href = hit.isFree || isLoggedIn ? hit.href : "/register";

          return (
            <li key={`${hit.type}-${hit.href}-${i}`}>
              <Link
                href={href}
                className="card flex items-start gap-4 p-4 transition-all hover:border-brand-300 hover:shadow-sm"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-600">
                  <Icon className="h-5 w-5" />
                </span>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-semibold text-ink-900">{hit.title}</h3>
                    <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[11px] font-medium text-ink-600">
                      {meta.label}
                    </span>
                    {!hit.isFree ? (
                      <AccessBadge isFree={false} />
                    ) : (
                      <AccessBadge isFree />
                    )}
                  </div>

                  <p className="mt-1 text-xs text-ink-500">{hit.breadcrumb}</p>

                  {hit.description ? (
                    <p className="mt-1.5 line-clamp-2 text-sm leading-relaxed text-ink-600">
                      {hit.description}
                    </p>
                  ) : null}
                </div>

                {!hit.isFree && !isLoggedIn ? (
                  <Lock className="mt-1 h-4 w-4 shrink-0 text-ink-400" />
                ) : null}
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

async function getGradeNameBySlug(slug: string): Promise<string | null> {
  const { prisma } = await import("@/lib/db/prisma");
  const grade = await prisma.grade.findUnique({
    where: { slug },
    select: { nameAr: true },
  });
  return grade?.nameAr ?? null;
}