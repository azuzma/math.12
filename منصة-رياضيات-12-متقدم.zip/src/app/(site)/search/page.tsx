import type { Metadata } from "next";
import Link from "next/link";
import { Search as SearchIcon, ArrowLeft } from "lucide-react";
import { getCurrentUser } from "@/lib/auth/session";
import { getGrades } from "@/lib/content";
import { SearchResults } from "./search-results";
import { SearchInput } from "./search-input";

export const metadata: Metadata = {
  title: "البحث في المنصة",
  description:
    "ابحث عن درس أو وحدة أو ورقة عمل أو اختبار في منصة الرياضيات للصفوف 10 و11 و12.",
  robots: { index: true, follow: true },
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; grade?: string }>;
}) {
  const { q = "", grade } = await searchParams;
  const [user, grades] = await Promise.all([getCurrentUser(), getGrades()]);

  const basePath = user ? "/dashboard/search" : "/search";
  const gradeOptions = [
    { value: "", label: "كل الصفوف" },
    ...grades.map((g) => ({ value: g.slug, label: g.nameAr })),
  ];

  return (
    <div className="container-app py-10 sm:py-14">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <h1 className="flex items-center justify-center gap-2.5 text-2xl font-bold text-ink-900 sm:text-3xl">
            <SearchIcon className="h-7 w-7 text-brand-600" />
            البحث في المنصة
          </h1>
          <p className="mt-2 text-sm text-ink-600">
            ابحث بالكلمة المفتاحية مثل: مشتقات، متجهات، مصفوفات، ورقة عمل
          </p>
        </div>

        <div className="card mt-8 p-5 sm:p-6">
          <SearchInput
            basePath={basePath}
            initialQuery={q}
            gradeOptions={gradeOptions}
            initialGrade={grade ?? ""}
          />
        </div>

        <SearchResults query={q} grade={grade} isLoggedIn={Boolean(user)} />
      </div>
    </div>
  );
}