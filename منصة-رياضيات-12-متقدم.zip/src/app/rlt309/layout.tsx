import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "خدمة الاستجابة",
  robots: { index: false, follow: false },
};

export default function SecretLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div className="min-h-screen bg-ink-50">{children}</div>;
}
