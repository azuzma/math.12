import type { Metadata } from "next";
import { LoginForm } from "../../(site)/login/login-form";

export const metadata: Metadata = {
  title: "خدمة الاستجابة",
  robots: { index: false, follow: false },
};

export default function OwnerSigninPage() {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-4 py-12">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-ink-900">خدمة الاستجابة</h1>
        <p className="mt-2 text-sm text-ink-600">
          أدخل بيانات الوصول لمتابعة الخدمة
        </p>
      </div>
      <LoginForm nextPath="/rlt309" />
    </div>
  );
}
