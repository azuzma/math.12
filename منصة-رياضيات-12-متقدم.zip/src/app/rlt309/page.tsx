import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";

export const metadata: Metadata = { title: "خدمة الاستجابة" };

export default async function OwnerGatePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/rlt309/signin");
  if (user.role !== "OWNER") redirect("/");
  redirect("/admin");
}
