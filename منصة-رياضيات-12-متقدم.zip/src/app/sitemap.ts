import type { MetadataRoute } from "next";
import { prisma } from "@/lib/db/prisma";

export const revalidate = 3600;

// لا تُبنى مسبقًا — Prisma (نسخة Cloudflare) لا يعمل وقت البناء
export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = (process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000").replace(
    /\/$/,
    "",
  );

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${base}/`, changeFrequency: "daily", priority: 1 },
    { url: `${base}/lessons`, changeFrequency: "daily", priority: 0.9 },
    { url: `${base}/pricing`, changeFrequency: "weekly", priority: 0.9 },
    { url: `${base}/register`, changeFrequency: "monthly", priority: 0.7 },
    { url: `${base}/login`, changeFrequency: "yearly", priority: 0.3 },
  ];

  try {
    const [grades, lessons] = await Promise.all([
      prisma.grade.findMany({
        orderBy: { order: "asc" },
        select: { slug: true, updatedAt: true },
      }),
      prisma.lesson.findMany({
        where: { status: "PUBLISHED" },
        select: { slug: true, updatedAt: true },
        take: 2000,
      }),
    ]);

    return [
      ...staticPages,
      ...grades.map((g) => ({
        url: `${base}/lessons?grade=${g.slug}`,
        lastModified: g.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.7,
      })),
      ...lessons.map((l) => ({
        url: `${base}/lessons/${l.slug}`,
        lastModified: l.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.8,
      })),
    ];
  } catch {
    return staticPages;
  }
}