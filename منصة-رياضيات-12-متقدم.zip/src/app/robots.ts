import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = (process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000").replace(
    /\/$/,
    "",
  );

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/admin",
          "/dashboard",
          "/api/",
          "/login",
          "/register",
          "/reset-password",
          "/forgot-password",
          "/verify",
          "/rlt309",
        ],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}