import type { Metadata, Viewport } from "next";
import { IBM_Plex_Sans_Arabic, Noto_Sans_Arabic } from "next/font/google";
import "./globals.css";
import { getSettings } from "@/lib/settings";
import { Toaster } from "@/components/ui/toaster";

const plexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-plex-ar",
  display: "swap",
  preload: true,
});

const notoArabic = Noto_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-noto-ar",
  display: "swap",
  preload: false,
});

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  return {
    metadataBase: new URL(base),
    title: {
      default: `${s.siteName} | ${s.tagline}`,
      template: `%s | ${s.siteName}`,
    },
    description: `${s.tagline}. دروس فيديو لكل وحدات المنهج، ملخصات وأوراق عمل، بنك أسئلة مصنّف بالمهارات، اختبارات بتصحيح فوري، وتحليل ذكي لمستوى الطالب.`,
    keywords: [
      "رياضيات الصف الثاني عشر",
      "رياضيات 12 متقدم",
      "رياضيات الإمارات",
      "شرح التفاضل والتكامل",
      "شرح المتتاليات",
      "النسب المثلثية",
      "اختبارات رياضيات",
      "بنك أسئلة رياضيات",
      "أوراق عمل رياضيات",
      "دروس رياضيات",
      "منصة تعليمية",
    ],
    authors: [{ name: s.teacherName }],
    creator: s.teacherName,
    openGraph: {
      type: "website",
      locale: "ar_AE",
      siteName: s.siteName,
      title: `${s.siteName} | ${s.tagline}`,
      description: `${s.tagline}. دروس فيديو وأوراق عمل واختبارات إلكترونية.`,
    },
    twitter: {
      card: "summary_large_image",
      title: s.siteName,
      description: s.tagline,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true, "max-image-preview": "large" },
    },
    alternates: { canonical: "/" },
  };
}

export const viewport: Viewport = {
  themeColor: "#2445eb",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "منصة رياضيات الصف الثاني عشر المتقدم",
  description:
    "منصة تعليمية متخصصة حصريًا في رياضيات الصف الثاني عشر المتقدم وفق منهج دولة الإمارات: المتتاليات، كثيرات الحدود، التفاضل، التكامل، والنسب المثلثية.",
  areaServed: "AE",
  teaches: [
    "الرياضيات — الصف الثاني عشر المتقدم",
    "المتتاليات",
    "كثيرات الحدود والأعداد المركبة",
    "التفاضل",
    "التكامل",
    "النسب المثلثية والدوال العكسية",
    "المتجهات في المستوي",
  ],
  audience: {
    "@type": "EducationalAudience",
    educationalRole: "student",
    audienceType: "طالب الصف الثاني عشر المتقدم",
  },
  inLanguage: "ar-AE",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body
        className={`${plexArabic.variable} ${notoArabic.variable} font-sans antialiased`}
        style={{
          fontFamily:
            "var(--font-plex-ar), var(--font-noto-ar), system-ui, sans-serif",
        }}
      >
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
        <Toaster />
      </body>
    </html>
  );
}