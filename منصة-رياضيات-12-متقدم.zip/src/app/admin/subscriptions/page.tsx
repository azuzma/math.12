import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, Alert } from "@/components/ui/buttons";
import { DataTable } from "@/components/admin/ui";
import { SubscriptionBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { formatDate, formatPrice } from "@/lib/utils";
import { isPaymentConfigured, activeProvider } from "@/lib/payments/provider";

export const metadata = { title: "الاشتراكات" };

export default async function SubscriptionsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; q?: string }>;
}) {
  const { status, q } = await searchParams;
  const query = (q ?? "").trim();

  const where = {
    ...(status &&
    ["ACTIVE", "TRIAL", "PAST_DUE", "CANCELED", "EXPIRED", "INCOMPLETE"].includes(status)
      ? { status: status as "ACTIVE" }
      : {}),
    ...(query
      ? {
          user: {
            OR: [
              { fullName: { contains: query, mode: "insensitive" as const } },
              { email: { contains: query, mode: "insensitive" as const } },
            ],
          },
        }
      : {}),
  };

  const [subscriptions, counts] = await Promise.all([
    prisma.subscription.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 150,
      include: {
        user: { select: { id: true, fullName: true, email: true } },
        plan: { select: { nameAr: true, tier: true } },
        _count: { select: { payments: true } },
      },
    }),
    prisma.subscription.groupBy({ by: ["status"], _count: { status: true } }),
  ]);

  const countOf = (s: string) => counts.find((c) => c.status === s)?._count.status ?? 0;
  const configured = isPaymentConfigured();

  const statuses = [
    { value: "", label: "الكل" },
    { value: "ACTIVE", label: "فعّال" },
    { value: "TRIAL", label: "تجربة" },
    { value: "PAST_DUE", label: "متأخر" },
    { value: "CANCELED", label: "ملغى" },
    { value: "EXPIRED", label: "منتهي" },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الاشتراكات"
        description={`${countOf("ACTIVE")} فعّال · ${countOf("TRIAL")} تجريبي`}
      />

      {!configured ? (
        <Alert tone="warn" title="بوابة الدفع غير مُعدة">
          المزوّد الحالي:{" "}
          <strong>{activeProvider() === "manual" ? "غير محدد" : activeProvider()}</strong>.
          أضف مفاتيح Stripe أو Telr لتفعيل الدفع التلقائي. يمكنك تفعيل الاشتراكات
          يدويًا من صفحة أي طالب.
        </Alert>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {statuses.map((s) => (
          <Link
            key={s.value}
            href={`/admin/subscriptions${s.value ? `?status=${s.value}` : ""}`}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              (status ?? "") === s.value
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {s.label}
            {s.value ? ` (${countOf(s.value)})` : ""}
          </Link>
        ))}
      </div>

      <form className="flex gap-2">
        <input
          type="search"
          name="q"
          defaultValue={query}
          placeholder="ابحث بالاسم أو البريد…"
          className="input max-w-md"
        />
        {status ? <input type="hidden" name="status" value={status} /> : null}
        <button type="submit" className="btn btn-outline">
          بحث
        </button>
      </form>

      {subscriptions.length === 0 ? (
        <EmptyState
          title="لا توجد اشتراكات"
          description="ستظهر هنا كل عمليات الاشتراك مع حالتها وتواريخ التجديد."
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الطالب", "الباقة", "الحالة", "الفترة", "المبلغ", "المزوّد"]}
          >
            {subscriptions.map((s) => (
              <tr key={s.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/students/${s.user.id}`}
                    className="font-semibold text-ink-900 hover:text-brand-700"
                  >
                    {s.user.fullName}
                  </Link>
                  <p className="text-xs text-ink-400" dir="ltr">
                    {s.user.email}
                  </p>
                </td>
                <td className="px-4 py-3 text-ink-600">
                  {s.plan.nameAr}
                  <p className="text-xs text-ink-400">
                    {s.billingCycle === "monthly" ? "شهري" : "سنوي"}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <SubscriptionBadge status={s.status} />
                  {s.cancelAtPeriodEnd ? (
                    <p className="mt-1 text-[11px] text-amber-700">
                      سيُلغى عند الانتهاء
                    </p>
                  ) : null}
                </td>
                <td className="px-4 py-3 text-xs text-ink-600">
                  {formatDate(s.currentPeriodStart)} —{" "}
                  {formatDate(s.currentPeriodEnd)}
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {formatPrice(s.amount, s.currency)}
                </td>
                <td className="px-4 py-3 text-xs text-ink-500">
                  {s.provider}
                  <p className="text-ink-400">{s._count.payments} دفعة</p>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}