import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveGradeAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { GradeFields } from "@/components/admin/forms/grade-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل صف" };

export default async function EditGradePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const grade = await prisma.grade.findUnique({ where: { id } });
  if (!grade) notFound();

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <PageHeader
        title={`تعديل: ${grade.nameAr}`}
        backHref="/admin/grades"
      />

      <AdminForm action={saveGradeAction}>
        <input type="hidden" name="id" value={grade.id} />
        <input type="hidden" name="_checkboxes" value="" />
        <GradeFields
          defaults={{
            id: grade.id,
            slug: grade.slug,
            nameAr: grade.nameAr,
            nameEn: grade.nameEn,
            stageAr: grade.stageAr,
            stageSlug: grade.stageSlug,
            order: grade.order,
            description: grade.description,
          }}
        />
      </AdminForm>
    </div>
  );
}