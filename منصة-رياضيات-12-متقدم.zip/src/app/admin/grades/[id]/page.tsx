import { notFound } from "next/navigation";
import Link from "next/link";
import { Plus, BookOpen, Layers } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { saveSubjectAction } from "@/app/actions/admin";
import { AdminForm, SaveButton, AdminSection, DeleteButton, DataTable } from "@/components/admin/ui";
import {
  TextField,
  TextareaField,
  SelectField,
} from "@/components/ui/forms";
import { ButtonLink, EmptyState, Alert } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إدارة صف" };

export default async function GradeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const grade = await prisma.grade.findUnique({
    where: { id },
    include: {
      subjects: {
        orderBy: { order: "asc" },
        include: {
          courses: {
            orderBy: { order: "asc" },
            include: { _count: { select: { units: true } } },
          },
        },
      },
    },
  });
  if (!grade) notFound();

  const lessonsCount = await prisma.lesson.count({
    where: { unit: { course: { subject: { gradeId: grade.id } } } },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title={grade.nameAr}
        description={`${grade.stageAr} · ${grade.description ?? ""}`}
        backHref="/admin/grades"
        action={
          <div className="flex gap-2">
            <Link
              href={`/admin/grades/${grade.id}/edit`}
              className="btn btn-outline"
            >
              تعديل بيانات الصف
            </Link>
            <ButtonLink href={`/admin/subjects/new?gradeId=${grade.id}`}>
              <Plus className="h-4 w-4" />
              إضافة مادة
            </ButtonLink>
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "المواد", value: grade.subjects.length, icon: BookOpen },
          {
            label: "المقررات",
            value: grade.subjects.reduce((s, x) => s + x.courses.length, 0),
            icon: Layers,
          },
          { label: "الدروس", value: lessonsCount, icon: BookOpen },
        ].map((stat) => (
          <div key={stat.label} className="card flex items-center gap-3 p-4">
            <span className="grid h-10 w-10 place-items-center rounded-lg bg-brand-50 text-brand-600">
              <stat.icon className="h-5 w-5" />
            </span>
            <div>
              <p className="text-xl font-bold text-ink-900 tabular-nums">
                {stat.value}
              </p>
              <p className="text-xs text-ink-500">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {grade.subjects.length === 0 ? (
        <Alert tone="info" title="الخطوة التالية">
          أضف مادة (مثال: الرياضيات) لهذا الصف، ثم أضف المقرر، ثم الوحدة، ثم الدرس.
        </Alert>
      ) : null}

      {grade.subjects.map((subject) => (
        <section key={subject.id} className="card p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-ink-900">{subject.nameAr}</h2>
              <p className="text-xs text-ink-500" dir="ltr">
                {subject.nameEn}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Link
                href={`/admin/subjects/${subject.id}/edit`}
                className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
              >
                تعديل
              </Link>
              <ButtonLink href={`/admin/courses/new?subjectId=${subject.id}`} size="sm" variant="soft">
                <Plus className="h-3.5 w-3.5" />
                مقرر
              </ButtonLink>
              <DeleteButton
                entity="subject"
                id={subject.id}
                confirmText={`سيتم حذف مادة «${subject.nameAr}» وكل المقررات والوحدات والدروس التابعة لها.`}
              />
            </div>
          </div>

          {subject.courses.length === 0 ? (
            <p className="mt-4 rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
              لا توجد مقررات. أضف مقررًا (مثال: الجبر والدوال).
            </p>
          ) : (
            <ul className="mt-4 space-y-2.5">
              {subject.courses.map((course) => (
                <li
                  key={course.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 p-3.5"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-ink-900">{course.title}</p>
                    <p className="text-xs text-ink-500">
                      {course._count.units} وحدة
                      {course.subtitle ? ` · ${course.subtitle}` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Link
                      href={`/admin/courses/${course.id}`}
                      className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                    >
                      إدارة
                    </Link>
                    <Link
                      href={`/admin/courses/${course.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton
                      entity="course"
                      id={course.id}
                      confirmText={`سيتم حذف المقرر «${course.title}» وكل وحداته ودروسه.`}
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  );
}