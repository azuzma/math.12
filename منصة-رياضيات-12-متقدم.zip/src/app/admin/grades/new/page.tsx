import { saveGradeAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { GradeFields } from "@/components/admin/forms/grade-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة صف" };

export default function NewGradePage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <PageHeader
        title="إضافة صف دراسي"
        description="الصف هو نقطة البداية — تُبنى عليه المواد ثم الوحدات ثم الدروس."
        backHref="/admin/grades"
      />

      <AdminForm action={saveGradeAction}>
        <input type="hidden" name="_checkboxes" value="" />
        <GradeFields />
      </AdminForm>
    </div>
  );
}