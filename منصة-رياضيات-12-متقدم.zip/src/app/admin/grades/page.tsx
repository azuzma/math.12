import Link from "next/link";
import { Plus, Search } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge } from "@/components/ui/badges";

export const metadata = { title: "الصفوف" };

export default async function GradesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const query = (q ?? "").trim();

  const grades = await prisma.grade.findMany({
    where: query
      ? {
          OR: [
            { nameAr: { contains: query, mode: "insensitive" } },
            { nameEn: { contains: query, mode: "insensitive" } },
          ],
        }
      : undefined,
    orderBy: { order: "asc" },
    include: {
      _count: {
        select: { subjects: true },
      },
      subjects: {
        select: {
          id: true,
          _count: {
            select: { courses: true },
          },
        },
      },
    },
  });

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">الصفوف الدراسية</h1>
          <p className="mt-1 text-sm text-ink-600">
            ابدأ بالصفوف، ثم أضف المواد، ثم الوحدات والدروس.
          </p>
        </div>
        <ButtonLink href="/admin/grades/new">
          <Plus className="h-4 w-4" />
          إضافة صف
        </ButtonLink>
      </header>

      <form className="relative max-w-md">
        <Search className="pointer-events-none absolute top-1/2 right-3.5 h-4 w-4 -translate-y-1/2 text-ink-400" />
        <input
          type="search"
          name="q"
          defaultValue={query}
          placeholder="ابحث عن صف…"
          className="input pr-10"
        />
      </form>

      {grades.length === 0 ? (
        <EmptyState
          title={query ? "لا توجد نتائج" : "لم تُضَف الصفوف بعد"}
          description={
            query
              ? "جرّب كلمة بحث أخرى."
              : "ابدأ بإضافة الصفوف الدراسية التي تريد نشر دروسها (مثال: الصف الثاني عشر متقدم)."
          }
          action={
            <ButtonLink href="/admin/grades/new">
              <Plus className="h-4 w-4" />
              إضافة أول صف
            </ButtonLink>
          }
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الصف", "المرحلة", "المواد", "المقررات", "الترتيب", "الإجراءات"]}
          >
            {grades.map((grade) => {
              const courses = grade.subjects.reduce(
                (sum, s) => sum + s._count.courses,
                0,
              );
              return (
                <tr key={grade.id} className="hover:bg-ink-50/50">
                  <td className="px-4 py-3">
                    <Link
                      href={`/admin/grades/${grade.id}`}
                      className="font-semibold text-ink-900 hover:text-brand-700"
                    >
                      {grade.nameAr}
                    </Link>
                    <p className="text-xs text-ink-400" dir="ltr">
                      {grade.nameEn}
                    </p>
                  </td>
                  <td className="px-4 py-3 text-ink-600">{grade.stageAr}</td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">
                    {grade._count.subjects}
                  </td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">{courses}</td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">{grade.order}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/admin/grades/${grade.id}`}
                        className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                      >
                        إدارة
                      </Link>
                      <Link
                        href={`/admin/grades/${grade.id}/edit`}
                        className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                      >
                        تعديل
                      </Link>
                      <DeleteButton
                        entity="grade"
                        id={grade.id}
                        confirmText={`سيتم حذف صف «${grade.nameAr}» وكل المواد والوحدات والدروس المرتبطة به نهائيًا.`}
                      />
                    </div>
                  </td>
                </tr>
              );
            })}
          </DataTable>
        </div>
      )}
    </div>
  );
}