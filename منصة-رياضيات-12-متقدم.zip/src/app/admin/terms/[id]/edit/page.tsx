import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveTermAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { TermFields } from "@/components/admin/forms/term-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل فصل دراسي" };

export default async function EditTermPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const term = await prisma.term.findUnique({
    where: { id },
    include: { course: true },
  });
  if (!term) notFound();

  const courses = await prisma.course.findMany({
    orderBy: { order: "asc" },
    include: { subject: { include: { grade: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={`تعديل: ${term.title}`} backHref="/admin/terms" />

      <AdminForm action={saveTermAction}>
        <input type="hidden" name="id" value={term.id} />
        <input type="hidden" name="_checkboxes" value="isFree" />
        <TermFields
          courses={courses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          defaults={{
            id: term.id,
            slug: term.slug,
            title: term.title,
            description: term.description,
            courseId: term.courseId,
            status: term.status,
            isFree: term.isFree,
            order: term.order,
          }}
        />
      </AdminForm>
    </div>
  );
}