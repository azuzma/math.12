import { prisma } from "@/lib/db/prisma";
import { saveTermAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { TermFields } from "@/components/admin/forms/term-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة فصل دراسي" };

export default async function NewTermPage({
  searchParams,
}: {
  searchParams: Promise<{ courseId?: string }>;
}) {
  const { courseId } = await searchParams;

  const courses = await prisma.course.findMany({
    orderBy: { order: "asc" },
    include: { subject: { include: { grade: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة فصل دراسي"
        description="الفصل الدراسي يجمع الوحدات تحت رتبة واحدة في تسلسل المنهج."
        backHref="/admin/terms"
      />

      <AdminForm action={saveTermAction}>
        <input type="hidden" name="_checkboxes" value="isFree" />
        <TermFields
          courses={courses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          defaults={{ courseId: courseId ?? "" }}
        />
      </AdminForm>
    </div>
  );
}