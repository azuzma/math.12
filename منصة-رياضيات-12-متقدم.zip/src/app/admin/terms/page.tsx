import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState } from "@/components/ui/buttons";
import { DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { formatDate } from "@/lib/utils";
import { PLATFORM } from "@/lib/platform";

export const metadata = { title: "الفصول الدراسية" };

export default async function TermsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status } = await searchParams;

  const terms = await prisma.term.findMany({
    where: status && ["DRAFT", "PUBLISHED", "ARCHIVED"].includes(status)
      ? { status: status as "DRAFT" | "PUBLISHED" | "ARCHIVED" }
      : {},
    orderBy: [{ course: { order: "asc" } }, { order: "asc" }],
    include: {
      course: { include: { subject: { include: { grade: true } } } },
      _count: { select: { units: true } },
      units: {
        orderBy: { order: "asc" },
        select: { id: true, title: true, _count: { select: { lessons: true } } },
      },
    },
  });

  const stats = await prisma.term.groupBy({
    by: ["status"],
    _count: { status: true },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="الفصول الدراسية"
        description={`تقسيم منهج ${PLATFORM.gradeNameAr} إلى فصول، كل فصل يجمع وحدات.`}
        action={
          <Link href="/admin/terms/new" className="btn btn-primary">
            <Plus className="h-4 w-4" />
            إضافة فصل دراسي
          </Link>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/terms"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !status
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل ({stats.reduce((s, x) => s + x._count.status, 0)})
        </Link>
        {(["PUBLISHED", "DRAFT", "ARCHIVED"] as const).map((st) => {
          const count = stats.find((s) => s.status === st)?._count.status ?? 0;
          const label =
            st === "PUBLISHED" ? "منشور" : st === "DRAFT" ? "مسودة" : "مؤرشف";
          return (
            <Link
              key={st}
              href={`/admin/terms?status=${st}`}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                status === st
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {label} ({count})
            </Link>
          );
        })}
      </div>

      {terms.length === 0 ? (
        <EmptyState
          title="لا توجد فصول دراسية"
          description="أضف فصلًا دراسيًا ثم أنشئ وحداته."
          action={
            <Link href="/admin/terms/new" className="btn btn-primary">
              إضافة فصل دراسي
            </Link>
          }
        />
      ) : (
        <ul className="space-y-4">
          {terms.map((term) => (
            <li key={term.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-bold text-ink-900">{term.title}</h2>
                    <StatusBadge status={term.status} />
                    <AccessBadge isFree={term.isFree} />
                  </div>
                  <p className="mt-1 text-xs text-ink-500">
                    {term.course.title} · {term._count.units} وحدة ·{" "}
                    {formatDate(term.updatedAt)}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <StatusSwitcher entity="term" id={term.id} current={term.status} />
                  <Link
                    href={`/admin/terms/${term.id}/edit`}
                    className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                  >
                    تعديل
                  </Link>
                  <Link
                    href="/admin/units/new"
                    className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                  >
                    + وحدة
                  </Link>
                  <DeleteButton entity="term" id={term.id} />
                </div>
              </div>

              {term.units.length > 0 ? (
                <ul className="mt-4 space-y-1.5 border-t border-ink-100 pt-3">
                  {term.units.map((u, idx) => (
                    <li
                      key={u.id}
                      className="flex items-center justify-between gap-3 text-sm"
                    >
                      <span className="truncate text-ink-700">
                        <span className="me-2 font-semibold text-ink-400">
                          {idx + 1}.
                        </span>
                        {u.title}
                      </span>
                      <span className="shrink-0 text-xs text-ink-500">
                        {u._count.lessons} درس
                      </span>
                    </li>
                  ))}
                </ul>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}