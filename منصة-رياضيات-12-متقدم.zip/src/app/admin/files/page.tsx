import { prisma } from "@/lib/db/prisma";
import { EmptyState, Alert } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge, KindBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { FileUploader } from "@/components/admin/file-uploader";
import { storageDriver } from "@/lib/storage/provider";
import { formatBytes, formatDate } from "@/lib/utils";

export const metadata = { title: "الملفات وأوراق العمل" };

export default async function FilesPage() {
  const [files, lessons, units, courses] = await Promise.all([
    prisma.fileAsset.findMany({
      orderBy: { createdAt: "desc" },
      take: 150,
      include: {
        lesson: {
          select: {
            title: true,
            unit: { select: { course: { select: { subject: { select: { nameAr: true } } } } } },
          },
        },
      },
    }),
    prisma.lesson.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      include: {
        unit: { select: { title: true, course: { select: { subject: { select: { nameAr: true } } } } } },
      },
    }),
    prisma.unit.findMany({
      orderBy: { order: "asc" },
      include: { course: { include: { subject: { select: { nameAr: true } } } } },
    }),
    prisma.course.findMany({
      orderBy: { order: "asc" },
      include: { subject: { include: { grade: { select: { nameAr: true } } } } },
    }),
  ]);

  const totalDownloads = files.reduce((s, f) => s + f.downloadCount, 0);
  const driver = storageDriver();

  return (
    <div className="space-y-6">
      <PageHeader
        title="الملفات وأوراق العمل"
        description="ملخصات، أوراق عمل، حلول نموذجية — تُقدَّم للطالب بروابط موقّعة تنتهي بعد 5 دقائق."
      />

      {driver === "local" ? (
        <Alert tone="warn" title="التخزين المحلي مُفعّل">
          يعمل على جهازك أو سيرفر خاص. للنشر على Vercel (حيث الملفات مؤقتة) أضف
          مفاتيح Supabase Storage — الخطوات في <code>SETUP.md</code>.
        </Alert>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "عدد الملفات", value: files.length },
          { label: "مرات التنزيل", value: totalDownloads },
          {
            label: "ملفات مجانية",
            value: files.filter((f) => f.isFree).length,
          },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">رفع ملف جديد</h2>
        <FileUploader
          lessons={lessons.map((l) => ({
            value: l.id,
            label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
          }))}
          units={units.map((u) => ({
            value: u.id,
            label: `${u.course.subject.nameAr} › ${u.title}`,
          }))}
          courses={courses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
        />
      </section>

      {files.length === 0 ? (
        <EmptyState
          title="لا توجد ملفات"
          description="ارفع أول ورقة عمل أو ملخص من النموذج أعلاه."
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الملف", "الربط", "النوع", "الحجم", "التنزيلات", "الحالة", ""]}
          >
            {files.map((f) => (
              <tr key={f.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink-900">{f.title}</p>
                  <p className="text-xs text-ink-400">
                    {formatDate(f.createdAt)} · {f.fileName}
                  </p>
                </td>
                <td className="max-w-44 px-4 py-3 text-xs text-ink-600">
                  {f.lesson?.title ?? "—"}
                  <p className="text-ink-400">
                    {f.lesson?.unit.course.subject.nameAr ?? ""}
                  </p>
                </td>
                <td className="px-4 py-3">
                  <KindBadge kind={f.kind} />
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {formatBytes(f.sizeBytes)}
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {f.downloadCount}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <StatusBadge status={f.status} />
                    <AccessBadge isFree={f.isFree} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="file" id={f.id} current={f.status} />
                    <DeleteButton entity="file" id={f.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}