import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveSubjectAction } from "@/app/actions/admin";
import { AdminForm, SaveButton } from "@/components/admin/ui";
import { SubjectFields } from "@/components/admin/forms/subject-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل مادة" };

export default async function EditSubjectPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const subject = await prisma.subject.findUnique({ where: { id } });
  if (!subject) notFound();

  const grades = await prisma.grade.findMany({
    orderBy: { order: "asc" },
    select: { id: true, nameAr: true },
  });

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <PageHeader title={`تعديل: ${subject.nameAr}`} backHref="/admin/subjects" />

      <AdminForm action={saveSubjectAction}>
        <input type="hidden" name="id" value={subject.id} />
        <input type="hidden" name="_checkboxes" value="" />
        <SubjectFields
          grades={grades.map((g) => ({ value: g.id, label: g.nameAr }))}
          defaults={{
            id: subject.id,
            slug: subject.slug,
            nameAr: subject.nameAr,
            nameEn: subject.nameEn,
            gradeId: subject.gradeId,
            description: subject.description,
            order: subject.order,
          }}
        />
        <div className="mt-4">
          <SaveButton />
        </div>
      </AdminForm>
    </div>
  );
}