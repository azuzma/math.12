import { prisma } from "@/lib/db/prisma";
import { saveSubjectAction } from "@/app/actions/admin";
import { AdminForm, SaveButton } from "@/components/admin/ui";
import { SubjectFields } from "@/components/admin/forms/subject-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة مادة" };

export default async function NewSubjectPage({
  searchParams,
}: {
  searchParams: Promise<{ gradeId?: string }>;
}) {
  const { gradeId } = await searchParams;

  const grades = await prisma.grade.findMany({
    orderBy: { order: "asc" },
    select: { id: true, nameAr: true },
  });

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <PageHeader
        title="إضافة مادة دراسية"
        description="المادة مرتبطة بصف. أضف بعدها المقرر ثم الوحدة ثم الدرس."
        backHref="/admin/subjects"
      />

      <AdminForm action={saveSubjectAction}>
        <input type="hidden" name="_checkboxes" value="" />
        <SubjectFields
          grades={grades.map((g) => ({ value: g.id, label: g.nameAr }))}
          defaults={{ gradeId }}
        />
        <div className="mt-4">
          <SaveButton />
        </div>
      </AdminForm>
    </div>
  );
}