import Link from "next/link";
import { Plus, Search, BookOpen } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton } from "@/components/admin/ui";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "المواد" };

export default async function SubjectsPage({
  searchParams,
}: {
  searchParams: Promise<{ grade?: string }>;
}) {
  const { grade: gradeSlug } = await searchParams;

  const grades = await prisma.grade.findMany({
    orderBy: { order: "asc" },
    select: { id: true, slug: true, nameAr: true },
  });

  const grade = gradeSlug ? grades.find((g) => g.slug === gradeSlug) : undefined;

  const subjects = await prisma.subject.findMany({
    where: grade ? { gradeId: grade.id } : undefined,
    orderBy: [{ grade: { order: "asc" } }, { order: "asc" }],
    include: {
      grade: { select: { nameAr: true } },
      _count: { select: { courses: true } },
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="المواد الدراسية"
        description="كل مادة مرتبطة بصف واحد (مثال: رياضيات الصف الثاني عشر)."
        action={
          <ButtonLink href="/admin/subjects/new">
            <Plus className="h-4 w-4" />
            إضافة مادة
          </ButtonLink>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/subjects"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !grade
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          كل الصفوف
        </Link>
        {grades.map((g) => (
          <Link
            key={g.id}
            href={`/admin/subjects?grade=${g.slug}`}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              grade?.id === g.id
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {g.nameAr}
          </Link>
        ))}
      </div>

      {subjects.length === 0 ? (
        <EmptyState
          title="لا توجد مواد"
          description="أضف مادة للصف الذي تريد نشر دروسه."
          icon={<BookOpen className="h-6 w-6" />}
          action={<ButtonLink href="/admin/subjects/new">إضافة مادة</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable headers={["المادة", "الصف", "المقررات", "الإجراءات"]}>
            {subjects.map((s) => (
              <tr key={s.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink-900">{s.nameAr}</p>
                  <p className="text-xs text-ink-400" dir="ltr">
                    {s.nameEn}
                  </p>
                </td>
                <td className="px-4 py-3 text-ink-600">{s.grade.nameAr}</td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">{s._count.courses}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <Link
                      href={`/admin/courses/new?subjectId=${s.id}`}
                      className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                    >
                      إضافة مقرر
                    </Link>
                    <Link
                      href={`/admin/subjects/${s.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="subject" id={s.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}