import Link from "next/link";
import {
  Users,
  BookOpen,
  CreditCard,
  Wallet,
  ClipboardCheck,
  TrendingUp,
  DollarSign,
  Activity,
  ArrowLeft,
  HelpCircle,
} from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { getAdminStats } from "@/lib/content";
import { checkEnv } from "@/lib/env";
import { StatCard, Alert, ButtonLink, EmptyState } from "@/components/ui/buttons";
import { DataTable } from "@/components/admin/ui";
import { PaymentBadge, UserStatusBadge } from "@/components/ui/badges";
import { formatDate, formatPrice } from "@/lib/utils";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

export const metadata = { title: "لوحة المؤشرات" };

export default async function AdminDashboard() {
  const stats = await getAdminStats();
  const env = checkEnv();

  const [recentStudents, recentAttempts, topLessons, lowStock] = await Promise.all([
    prisma.user.findMany({
      where: { role: "STUDENT" },
      orderBy: { createdAt: "desc" },
      take: 6,
      select: {
        id: true,
        fullName: true,
        email: true,
        createdAt: true,
        status: true,
        studentProfile: { select: { grade: { select: { nameAr: true } } } },
      },
    }),
    prisma.examAttempt.findMany({
      where: { submittedAt: { gte: SUBMITTED_EPOCH } },
      orderBy: { submittedAt: "desc" },
      take: 6,
      include: {
        student: { select: { fullName: true } },
        exam: { select: { title: true } },
      },
    }),
    prisma.lessonProgress.groupBy({
      by: ["lessonId"],
      where: { completed: true },
      _count: { lessonId: true },
      orderBy: { _count: { lessonId: "desc" } },
      take: 5,
    }),
    prisma.subscription.findMany({
      where: {
        status: { in: ["ACTIVE", "TRIAL"] },
        currentPeriodEnd: {
          gt: new Date(),
          lt: new Date(Date.now() + 7 * 86400_000),
        },
      },
      include: {
        user: { select: { id: true, fullName: true } },
        plan: { select: { nameAr: true } },
      },
      orderBy: { currentPeriodEnd: "asc" },
      take: 5,
    }),
  ]);

  const lessonIds = topLessons.map((t) => t.lessonId);
const lessonTitles =
  lessonIds.length > 0
    ? await prisma.lesson.findMany({
        where: { id: { in: lessonIds } },
        select: { id: true, title: true },
      })
    : [];

  const maxRevenue = Math.max(
    ...stats.revenue.byMonth.map((m) => m.total as number),
    1,
  );

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">
          لوحة المؤشرات
        </h1>
        <p className="mt-1 text-sm text-ink-600">
          كل الأرقام محسوبة مباشرة من قاعدة البيانات.
        </p>
      </header>

      {/* تنبيهات الإعداد */}
      {env.missing.length > 0 ? (
        <Alert tone="error" title="إعداد ناقص — المنصة لن تعمل بالكامل">
          المتغيرات التالية مفقودة:{" "}
          <span className="font-mono" dir="ltr">
            {env.missing.join(", ")}
          </span>
          . أضفها في ملف <code>.env</code> وفي إعدادات Vercel.
        </Alert>
      ) : null}

      {env.warnings.length > 0 ? (
        <Alert tone="warn" title="إعدادات اختيارية غير مكتملة">
          <ul className="mt-1 space-y-1">
            {env.warnings.map((w) => (
              <li key={w}>• {w}</li>
            ))}
          </ul>
          <p className="mt-2 text-xs">
            المنصة تعمل بدونها، لكن بعض الوظائف معطّلة. راجع ملف{" "}
            <code>SETUP.md</code> للخطوات خطوة بخطوة.
          </p>
        </Alert>
      ) : null}

      {/* المؤشرات الرئيسية */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="إجمالي الطلاب"
          value={stats.students.total}
          hint={`${stats.students.active} نشط · ${stats.students.suspended} موقوف`}
          icon={<Users className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="الدروس المنشورة"
          value={`${stats.content.published} / ${stats.content.lessons}`}
          hint={`${stats.content.questions} سؤال في البنك`}
          icon={<BookOpen className="h-5 w-5" />}
          tone="green"
        />
        <StatCard
          label="الاشتراكات الفعّالة"
          value={stats.subscriptions.active}
          hint={`${stats.exams.attempts} محاولة اختبار`}
          icon={<CreditCard className="h-5 w-5" />}
          tone="amber"
        />
        <StatCard
          label="إجمالي الإيرادات"
          value={formatPrice(stats.revenue.total)}
          hint={`${stats.revenue.count} دفعة · هذا الشهر ${formatPrice(stats.revenue.month)}`}
          icon={<DollarSign className="h-5 w-5" />}
          tone="ink"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* الإيرادات الشهرية */}
        <section className="card p-5 lg:col-span-2">
          <h2 className="text-base font-bold text-ink-900">الإيرادات الشهرية</h2>

          {stats.revenue.byMonth.length === 0 ? (
            <p className="mt-6 rounded-xl border border-dashed border-ink-300 p-8 text-center text-sm text-ink-500">
              لا توجد مدفوعات حتى الآن. ستظهر هنا عند أول اشتراك.
            </p>
          ) : (
            <div className="mt-6 flex h-52 items-end gap-2">
              {stats.revenue.byMonth.map((m) => {
                const total = Number(m.total ?? 0);
                const height = Math.max(4, (total / maxRevenue) * 100);
                return (
                  <div key={m.month} className="group flex flex-1 flex-col items-center gap-2">
                    <div className="relative flex w-full flex-1 items-end">
                      <div
                        className="w-full rounded-t-lg bg-gradient-to-t from-brand-600 to-brand-400 transition-all group-hover:from-brand-700 group-hover:to-brand-500"
                        style={{ height: `${height}%` }}
                        title={`${m.month}: ${formatPrice(total)}`}
                      />
                      <span className="absolute -top-6 right-1/2 translate-x-1/2 rounded bg-ink-900 px-2 py-0.5 text-[10px] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100">
                        {formatPrice(total)}
                      </span>
                    </div>
                    <span className="text-[10px] text-ink-500">
                      {String(m.month).slice(5)}/{String(m.month).slice(2, 4)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* تنبيهات */}
        <section className="card p-5">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <Activity className="h-5 w-5 text-amber-500" />
            يحتاج انتباهك
          </h2>

          <div className="mt-4 space-y-3">
            <div className="rounded-xl bg-ink-50 p-3.5">
              <p className="text-sm font-semibold text-ink-900">
                {lowStock.length} اشتراك ينتهي خلال 7 أيام
              </p>
              {lowStock.length > 0 ? (
                <ul className="mt-2 space-y-1.5">
                  {lowStock.map((s) => (
                    <li key={s.id} className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate text-ink-600">{s.user.fullName}</span>
                      <span className="shrink-0 font-semibold text-amber-700">
                        {formatDate(s.currentPeriodEnd)}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-1 text-xs text-ink-500">لا يوجد اشتراكات قاربت الانتهاء.</p>
              )}
            </div>

            <div className="rounded-xl bg-ink-50 p-3.5">
              <p className="text-sm font-semibold text-ink-900">مسودات غير منشورة</p>
              <p className="mt-1 text-xs text-ink-500">
                {stats.content.lessons - stats.content.published} درس في حالة مسودة.
                <Link
                  href="/admin/lessons"
                  className="ms-1 font-semibold text-brand-700 hover:underline"
                >
                  عرض
                </Link>
              </p>
            </div>

            {stats.exams.attempts > 0 ? (
              <div className="rounded-xl bg-ink-50 p-3.5">
                <p className="text-sm font-semibold text-ink-900">متوسط درجات الاختبارات</p>
                <p className="mt-1 text-2xl font-bold text-brand-700 tabular-nums">
                  {stats.exams.averagePercentage}%
                </p>
                <p className="text-xs text-ink-500">من {stats.exams.attempts} محاولة</p>
              </div>
            ) : null}
          </div>
        </section>
      </div>

      {/* أكثر الدروس إكمالًا */}
      {topLessons.length > 0 ? (
        <section className="card p-5">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <TrendingUp className="h-5 w-5 text-emerald-600" />
            الدروس الأكثر إكمالًا
          </h2>
          <ul className="mt-4 space-y-2.5">
            {topLessons.map((t, i) => {
              const lesson = lessonTitles.find((l) => l.id === t.lessonId);
              return (
                <li
                  key={t.lessonId}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 px-4 py-3"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand-50 text-xs font-bold text-brand-700">
                      {i + 1}
                    </span>
                    <span className="truncate text-sm font-medium text-ink-800">
                      {lesson?.title ?? "درس محذوف"}
                    </span>
                  </div>
                  <span className="shrink-0 text-sm font-bold text-emerald-700 tabular-nums">
                    {t._count.lessonId} طالب
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}

      {/* الطلاب الجدد */}
      <section className="card p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-ink-900">أحدث الطلاب المسجّلين</h2>
          <Link
            href="/admin/students"
            className="inline-flex items-center gap-1 text-xs font-semibold text-brand-700 hover:underline"
          >
            كل الطلاب
            <ArrowLeft className="h-3 w-3" />
          </Link>
        </div>

        {recentStudents.length === 0 ? (
          <EmptyState
            title="لا يوجد طلاب بعد"
            description="يظهر هنا كل طالب يسجّل في المنصة. يمكنك أيضًا إضافة طالب يدويًا."
            icon={<Users className="h-6 w-6" />}
            className="mt-4"
          />
        ) : (
          <div className="mt-4">
            <DataTable headers={["الطالب", "البريد", "الصف", "تاريخ التسجيل", "الحالة"]}>
              {recentStudents.map((s) => (
                <tr key={s.id} className="hover:bg-ink-50/50">
                  <td className="px-4 py-3 font-medium text-ink-900">{s.fullName}</td>
                  <td className="px-4 py-3 text-ink-600" dir="ltr">
                    {s.email}
                  </td>
                  <td className="px-4 py-3 text-ink-600">
                    {s.studentProfile?.grade?.nameAr ?? "—"}
                  </td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">
                    {formatDate(s.createdAt)}
                  </td>
                  <td className="px-4 py-3">
                    <UserStatusBadge status={s.status} />
                  </td>
                </tr>
              ))}
            </DataTable>
          </div>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* آخر النتائج */}
        <section className="card p-5">
          <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
            <ClipboardCheck className="h-5 w-5 text-brand-600" />
            آخر نتائج الاختبارات
          </h2>

          {recentAttempts.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
              لا توجد محاولات بعد.
            </p>
          ) : (
            <ul className="mt-4 space-y-2">
              {recentAttempts.map((a) => (
                <li
                  key={a.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 px-3.5 py-2.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-900">
                      {a.student.fullName}
                    </p>
                    <p className="truncate text-xs text-ink-500">{a.exam.title}</p>
                  </div>
                  <span
                    className={`shrink-0 text-sm font-bold tabular-nums ${
                      a.passed ? "text-emerald-700" : "text-rose-700"
                    }`}
                  >
                    {Math.round(a.percentage)}%
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* آخر المدفوعات */}
        <section className="card p-5">
          <div className="flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <Wallet className="h-5 w-5 text-emerald-600" />
              آخر المدفوعات
            </h2>
            <Link
              href="/admin/payments"
              className="inline-flex items-center gap-1 text-xs font-semibold text-brand-700 hover:underline"
            >
              الكل
              <ArrowLeft className="h-3 w-3" />
            </Link>
          </div>

          {stats.lastPayments.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
              لا توجد مدفوعات حتى الآن.
            </p>
          ) : (
            <ul className="mt-4 space-y-2">
              {stats.lastPayments.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 px-3.5 py-2.5"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-900">
                      {p.user.fullName}
                    </p>
                    <p className="truncate text-xs text-ink-500">
                      {(p.plan?.nameAr as string | undefined) ?? "—"} · {formatDate(p.paidAt)}
                    </p>
                  </div>
                  <span className="shrink-0 text-sm font-bold text-emerald-700 tabular-nums">
                    {formatPrice(p.amount, p.currency)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* اختصارات */}
      <section className="card p-5">
        <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
          <HelpCircle className="h-5 w-5 text-brand-600" />
          إجراءات سريعة
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { href: "/admin/lessons/new", label: "إضافة درس جديد", icon: BookOpen },
            { href: "/admin/questions/new", label: "إضافة سؤال", icon: HelpCircle },
            { href: "/admin/exams/new", label: "إنشاء اختبار", icon: ClipboardCheck },
            { href: "/admin/terms", label: "الفصول الدراسية", icon: BookOpen },
            { href: "/admin/units", label: "الوحدات", icon: BookOpen },
            { href: "/admin/skills", label: "المهارات", icon: HelpCircle },
            { href: "/admin/plans", label: "تعديل الأسعار", icon: CreditCard },
          ].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-xl border border-ink-200 p-4 transition-all hover:border-brand-300 hover:bg-brand-50/40"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-600">
                <item.icon className="h-5 w-5" />
              </span>
              <span className="text-sm font-semibold text-ink-800">{item.label}</span>
              <ArrowLeft className="ms-auto h-4 w-4 text-ink-300" />
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}