import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveUnitAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { UnitFields } from "@/components/admin/forms/unit-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل وحدة" };

export default async function EditUnitPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const unit = await prisma.unit.findUnique({
    where: { id },
    include: { course: true },
  });
  if (!unit) notFound();

  const [allCourses, terms] = await Promise.all([
    prisma.course.findMany({
      orderBy: { order: "asc" },
      include: { subject: { include: { grade: true } } },
    }),
    prisma.term.findMany({
      where: { courseId: unit.courseId },
      orderBy: { order: "asc" },
    }),
  ]);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title={`تعديل: ${unit.title}`}
        backHref={`/admin/courses/${unit.courseId}`}
      />

      <AdminForm action={saveUnitAction}>
        <input type="hidden" name="id" value={unit.id} />
        <input type="hidden" name="_checkboxes" value="isFree" />
        <UnitFields
          courses={allCourses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          terms={terms.map((t) => ({ value: t.id, label: t.title }))}
          defaults={{
            id: unit.id,
            slug: unit.slug,
            title: unit.title,
            description: unit.description,
            courseId: unit.courseId,
            termId: unit.termId,
            status: unit.status,
            isFree: unit.isFree,
            order: unit.order,
          }}
        />
      </AdminForm>
    </div>
  );
}