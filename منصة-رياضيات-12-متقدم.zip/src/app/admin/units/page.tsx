import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState } from "@/components/ui/buttons";
import { DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "الوحدات" };

export default async function UnitsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string }>;
}) {
  const { q, status } = await searchParams;
  const query = (q ?? "").trim();

  const units = await prisma.unit.findMany({
    where: {
      ...(query
        ? { title: { contains: query, mode: "insensitive" as const } }
        : {}),
      ...(status && ["DRAFT", "PUBLISHED", "ARCHIVED"].includes(status)
        ? { status: status as "DRAFT" | "PUBLISHED" | "ARCHIVED" }
        : {}),
    },
    orderBy: [{ course: { order: "asc" } }, { order: "asc" }],
    take: 200,
    include: {
      course: { include: { subject: { include: { grade: true } } } },
      _count: { select: { lessons: true } },
    },
  });

  const stats = await prisma.unit.groupBy({
    by: ["status"],
    _count: { status: true },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="الوحدات"
        description="الوحدة تجمع الدروس حول موضوع واحد داخل المقرر."
        action={
          <Link href="/admin/units/new" className="btn btn-primary">
            <Plus className="h-4 w-4" />
            إضافة وحدة
          </Link>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/units"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !status
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل ({stats.reduce((s, x) => s + x._count.status, 0)})
        </Link>
        {(["PUBLISHED", "DRAFT", "ARCHIVED"] as const).map((st) => {
          const count = stats.find((s) => s.status === st)?._count.status ?? 0;
          const label =
            st === "PUBLISHED" ? "منشور" : st === "DRAFT" ? "مسودة" : "مؤرشف";
          return (
            <Link
              key={st}
              href={`/admin/units?status=${st}`}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                status === st
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {label} ({count})
            </Link>
          );
        })}
      </div>

      <form className="max-w-md">
        <input
          type="search"
          name="q"
          defaultValue={query}
          placeholder="ابحث باسم الوحدة…"
          className="input"
        />
        {status ? <input type="hidden" name="status" value={status} /> : null}
      </form>

      {units.length === 0 ? (
        <EmptyState
          title="لا توجد وحدات"
          description="أضف مقررًا أولًا ثم أنشئ وحداته."
          action={
            <Link href="/admin/units/new" className="btn btn-primary">
              إضافة وحدة
            </Link>
          }
        />
      ) : (
        <ul className="space-y-3">
          {units.map((unit) => (
            <li key={unit.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-bold text-ink-900">{unit.title}</h2>
                    <StatusBadge status={unit.status} />
                    <AccessBadge isFree={unit.isFree} />
                  </div>
                  <p className="mt-1 text-xs text-ink-500">
                    {unit.course.title} · {unit.course.subject.nameAr} ·{" "}
                    {unit._count.lessons} درس · {formatDate(unit.updatedAt)}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <StatusSwitcher entity="unit" id={unit.id} current={unit.status} />
                  <Link
                    href={`/admin/units/${unit.id}/edit`}
                    className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                  >
                    تعديل
                  </Link>
                  <Link
                    href={`/admin/courses/${unit.courseId}`}
                    className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                  >
                    المقرر
                  </Link>
                  <DeleteButton entity="unit" id={unit.id} />
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}