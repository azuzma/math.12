import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveUnitAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { UnitFields } from "@/components/admin/forms/unit-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة وحدة" };

export default async function NewUnitPage({
  searchParams,
}: {
  searchParams: Promise<{ courseId?: string; termId?: string }>;
}) {
  const { courseId, termId } = await searchParams;

  const [allCourses, terms] = await Promise.all([
    prisma.course.findMany({
      orderBy: { order: "asc" },
      include: { subject: { include: { grade: true } } },
    }),
    prisma.term.findMany({ orderBy: { order: "asc" } }),
  ]);

  const selected = courseId
    ? allCourses.find((c) => c.id === courseId)
    : undefined;

  if (courseId && !selected) notFound();

  // اعرض فصول المقرر المختار فقط إن وُجد
  const visibleTerms = courseId ? terms.filter((t) => t.courseId === courseId) : terms;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة وحدة"
        description={
          selected
            ? `داخل المقرر: ${selected.title}`
            : "اختر المقرر ثم الفصل الدراسي الذي تنتمي إليه الوحدة."
        }
        backHref={selected ? `/admin/courses/${selected.id}` : "/admin/courses"}
      />

      <AdminForm action={saveUnitAction}>
        <input type="hidden" name="_checkboxes" value="isFree" />
        <UnitFields
          courses={allCourses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          terms={visibleTerms.map((t) => ({ value: t.id, label: t.title }))}
          defaults={{ courseId: courseId ?? "", termId: termId ?? "" }}
        />
      </AdminForm>
    </div>
  );
}