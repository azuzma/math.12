import { prisma } from "@/lib/db/prisma";
import { saveQuestionAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { QuestionFields } from "@/components/admin/forms/question-fields";
import { PageHeader } from "@/components/admin/page-header";
import { loadCurriculumOptions } from "@/lib/curriculum-options";

export const metadata = { title: "إضافة سؤال" };

export default async function NewQuestionPage({
  searchParams,
}: {
  searchParams: Promise<{ lessonId?: string; type?: string; skillId?: string }>;
}) {
  const { lessonId, type, skillId } = await searchParams;

  const { termOptions, skillOptions, lessonOptions } =
    await loadCurriculumOptions();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة سؤال جديد"
        description="اربط السؤال بالفصل والوحدة والمهارة والدرس ليظهر في بنك الأسئلة والاختبارات الصحيحة."
        backHref="/admin/questions"
      />

      <AdminForm action={saveQuestionAction}>
        <QuestionFields
          lessons={lessonOptions}
          skills={skillOptions}
          terms={termOptions}
          defaults={{ lessonId, type, skillId }}
        />
      </AdminForm>
    </div>
  );
}