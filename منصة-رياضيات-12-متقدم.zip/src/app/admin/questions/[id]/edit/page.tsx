import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveQuestionAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { QuestionFields } from "@/components/admin/forms/question-fields";
import { PageHeader } from "@/components/admin/page-header";
import { loadCurriculumOptions } from "@/lib/curriculum-options";

export const metadata = { title: "تعديل سؤال" };

export default async function EditQuestionPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const question = await prisma.question.findUnique({ where: { id } });
  if (!question) notFound();

  const { termOptions, skillOptions, lessonOptions } =
    await loadCurriculumOptions();

  const optionList = Array.isArray(question.options)
    ? (question.options as { id: string; text: string }[])
    : [];

  const correctLabels: string[] = Array.isArray(question.correct)
    ? (question.correct as string[]).map(
        (cid) => optionList.find((o) => o.id === cid)?.text ?? cid,
      )
    : question.correct !== null && question.correct !== undefined
      ? [
          optionList.find((o) => o.id === question.correct)?.text ??
            String(question.correct),
        ]
      : [];

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title="تعديل السؤال" backHref="/admin/questions" />

      <AdminForm action={saveQuestionAction}>
        <input type="hidden" name="id" value={question.id} />
        <input type="hidden" name="_checkboxes" value="isActive,autoGrade" />
        <QuestionFields
          lessons={lessonOptions}
          skills={skillOptions}
          terms={termOptions}
          defaults={{
            id: question.id,
            type: question.type,
            text: question.text,
            options: optionList.map((o) => o.text),
            correctLabels,
            solution: question.solution,
            hint: question.hint,
            points: question.points,
            difficulty: question.difficulty,
            lessonId: question.lessonId,
            skillId: question.skillId,
            termId: question.termId,
            isActive: question.isActive,
          }}
        />
      </AdminForm>
    </div>
  );
}