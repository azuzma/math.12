import Link from "next/link";
import { Plus, HelpCircle } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton } from "@/components/admin/ui";
import { PageHeader } from "@/components/admin/page-header";
import { QUESTION_TYPE_LABELS } from "@/lib/utils";
import { DIFFICULTY_LEVELS, DIFFICULTY_MAP } from "@/lib/platform";
import { loadCurriculumOptions } from "@/lib/curriculum-options";
import type { DifficultyLevel } from "@/generated/prisma/client";

export const metadata = { title: "بنك الأسئلة" };

export default async function QuestionsPage({
  searchParams,
}: {
  searchParams: Promise<{
    lesson?: string;
    skill?: string;
    term?: string;
    type?: string;
    difficulty?: string;
    page?: string;
  }>;
}) {
  const { lesson: lessonId, skill: skillId, term: termId, type, difficulty, page } =
    await searchParams;
  const currentPage = Math.max(1, Number(page ?? "1") || 1);
  const perPage = 30;

  const validDifficulty = DIFFICULTY_LEVELS.some((d) => d.value === difficulty)
    ? (difficulty as DifficultyLevel)
    : undefined;

  const where = {
    ...(lessonId ? { lessonId } : {}),
    ...(skillId ? { skillId } : {}),
    ...(termId ? { termId } : {}),
    ...(type ? { type: type as "MCQ" } : {}),
    ...(validDifficulty ? { difficulty: validDifficulty } : {}),
  };

  const [questions, total, options] = await Promise.all([
    prisma.question.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (currentPage - 1) * perPage,
      take: perPage,
      include: {
        lesson: { select: { id: true, title: true } },
        skill: { select: { id: true, title: true } },
        term: { select: { id: true, title: true } },
        _count: { select: { exams: true, assignments: true } },
      },
    }),
    prisma.question.count({ where }),
    loadCurriculumOptions(),
  ]);

  const pages = Math.ceil(total / perPage);
  const [counts, difficultyCounts] = await Promise.all([
    prisma.question.groupBy({ by: ["type"], _count: { type: true } }),
    prisma.question.groupBy({ by: ["difficulty"], _count: { difficulty: true } }),
  ]);

  const qs = (extra: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    if (type) p.set("type", type);
    if (lessonId) p.set("lesson", lessonId);
    if (skillId) p.set("skill", skillId);
    if (termId) p.set("term", termId);
    if (difficulty) p.set("difficulty", difficulty);
    for (const [k, v] of Object.entries(extra)) if (v) p.set(k, v);
    const s = p.toString();
    return s ? `?${s}` : "";
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="بنك الأسئلة"
        description="بنك أسئلة رياضيات الصف 12 متقدم — كل سؤال مرتبط بفصل ومهارة ودرس ومستوى صعوبة."
        action={
          <ButtonLink href="/admin/questions/new">
            <Plus className="h-4 w-4" />
            إضافة سؤال
          </ButtonLink>
        }
      />

      {/* فلاتر النوع */}
      <div className="flex flex-wrap gap-2">
        <Link
          href={qs({ type: undefined })}
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !type
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل ({counts.reduce((s, c) => s + c._count.type, 0)})
        </Link>
        {Object.entries(QUESTION_TYPE_LABELS).map(([value, label]) => {
          const count = counts.find((c) => c.type === value)?._count.type ?? 0;
          return (
            <Link
              key={value}
              href={qs({ type: value })}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                type === value
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {label} ({count})
            </Link>
          );
        })}
      </div>

      {/* فلاتر الصعوبة */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold text-ink-500">الصعوبة:</span>
        <Link
          href={qs({ difficulty: undefined })}
          className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
            !difficulty
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل
        </Link>
        {DIFFICULTY_LEVELS.map((d) => {
          const count =
            difficultyCounts.find((c) => c.difficulty === d.value)?._count
              .difficulty ?? 0;
          return (
            <Link
              key={d.value}
              href={qs({ difficulty: d.value })}
              className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                difficulty === d.value
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {d.emoji} {d.label} ({count})
            </Link>
          );
        })}
      </div>

      {/* فلاتر المنهج */}
      <form className="flex flex-wrap gap-2">
        <select
          name="term"
          defaultValue={termId ?? ""}
          className="input w-auto min-w-52 cursor-pointer"
        >
          <option value="">كل الفصول</option>
          {options.termOptions.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
        <select
          name="skill"
          defaultValue={skillId ?? ""}
          className="input w-auto min-w-56 cursor-pointer"
        >
          <option value="">كل المهارات</option>
          {options.skillOptions.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
        <select
          name="lesson"
          defaultValue={lessonId ?? ""}
          className="input w-auto min-w-56 cursor-pointer"
        >
          <option value="">كل الدروس</option>
          {options.lessonOptions.map((l) => (
            <option key={l.value} value={l.value}>
              {l.label}
            </option>
          ))}
        </select>
        {type ? <input type="hidden" name="type" value={type} /> : null}
        {difficulty ? (
          <input type="hidden" name="difficulty" value={difficulty} />
        ) : null}
        <button type="submit" className="btn btn-outline">
          تصفية
        </button>
      </form>

      {questions.length === 0 ? (
        <EmptyState
          title="لا توجد أسئلة"
          description="أضف أول سؤال لتستخدمه في الاختبارات والواجبات."
          icon={<HelpCircle className="h-6 w-6" />}
          action={<ButtonLink href="/admin/questions/new">إضافة سؤال</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["السؤال", "الصعوبة", "النوع", "الدرجة", "الربط", "الاستخدام", ""]}
          >
            {questions.map((q) => {
              const diff = DIFFICULTY_MAP[q.difficulty];
              return (
                <tr key={q.id} className="hover:bg-ink-50/50">
                  <td className="max-w-md px-4 py-3">
                    <p className="line-clamp-2 font-medium text-ink-900">{q.text}</p>
                    {!q.isActive ? (
                      <span className="text-xs text-rose-600">معطّل</span>
                    ) : null}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <span className={`text-xs font-bold ${diff?.color ?? "text-ink-500"}`}>
                      {diff?.emoji ?? ""} {diff?.label ?? q.difficulty}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-ink-600">
                    {QUESTION_TYPE_LABELS[q.type]}
                  </td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">{q.points}</td>
                  <td className="max-w-48 px-4 py-3">
                    <p className="truncate text-xs text-ink-700">
                      {q.term?.title ?? "—"}
                    </p>
                    <p className="truncate text-[11px] text-ink-500">
                      {q.skill?.title ?? q.lesson?.title ?? "—"}
                    </p>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-xs text-ink-500">
                    {q._count.exams > 0 ? `${q._count.exams} اختبار` : ""}
                    {q._count.exams > 0 && q._count.assignments > 0 ? " · " : ""}
                    {q._count.assignments > 0 ? `${q._count.assignments} واجب` : ""}
                    {q._count.exams === 0 && q._count.assignments === 0
                      ? "غير مستخدم"
                      : ""}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/admin/questions/${q.id}/edit`}
                        className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                      >
                        تعديل
                      </Link>
                      <DeleteButton entity="question" id={q.id} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </DataTable>
        </div>
      )}

      {pages > 1 ? (
        <div className="flex items-center justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
            <Link
              key={n}
              href={`/admin/questions?${qs({ page: String(n) })}`}
              className={`grid h-9 w-9 place-items-center rounded-lg text-sm font-semibold tabular-nums transition-colors ${
                n === currentPage
                  ? "bg-brand-600 text-white"
                  : "text-ink-700 hover:bg-ink-100"
              }`}
            >
              {n}
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}