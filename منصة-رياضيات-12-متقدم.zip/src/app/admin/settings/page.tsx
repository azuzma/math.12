import {
  saveSettingsAction,
  changeAdminPasswordAction,
} from "@/app/actions/admin";
import { AdminForm, SaveButton, AdminSection } from "@/components/admin/ui";
import {
  TextField,
  TextareaField,
  ToggleField,
} from "@/components/ui/forms";
import { getSettings } from "@/lib/settings";
import { getCurrentUser } from "@/lib/auth/session";
import { checkEnv } from "@/lib/env";
import { isPaymentConfigured, activeProvider } from "@/lib/payments/provider";
import { isVideoConfigured } from "@/lib/storage/video";
import { storageDriver } from "@/lib/storage/provider";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "الإعدادات" };

export default async function SettingsPage() {
  const [settings, user, env] = await Promise.all([
    getSettings(),
    getCurrentUser(),
    Promise.resolve(checkEnv()),
  ]);

  const integrations = [
    {
      name: "قاعدة البيانات",
      ok: !env.missing.includes("DATABASE_URL"),
      hint: "PostgreSQL (Neon)",
      envKey: "DATABASE_URL",
    },
    {
      name: "بوابة الدفع",
      ok: isPaymentConfigured(),
      hint: activeProvider() === "manual" ? "غير مرتبطة" : activeProvider(),
      envKey: "STRIPE_SECRET_KEY / TELR_STORE_ID",
    },
    {
      name: "مفتاح Webhook للدفع",
      ok: Boolean(
        process.env.STRIPE_WEBHOOK_SECRET || process.env.TELR_WEBHOOK_SECRET,
      ),
      hint: "مطلوب لتفعيل الاشتراك تلقائيًا",
      envKey: "STRIPE_WEBHOOK_SECRET",
    },
    {
      name: "الفيديو (Bunny Stream)",
      ok: isVideoConfigured(),
      hint: "حماية روابط الفيديو",
      envKey: "BUNNY_STREAM_AUTH_KEY",
    },
    {
      name: "رفع الفيديو (Bunny API)",
      ok: Boolean(process.env.BUNNY_API_KEY),
      hint: "لرفع الملفات من لوحة التحكم",
      envKey: "BUNNY_API_KEY",
    },
    {
      name: "البريد الإلكتروني",
      ok: Boolean(process.env.RESEND_API_KEY || process.env.SMTP_HOST),
      hint: process.env.RESEND_API_KEY ? "Resend" : "SMTP",
      envKey: "RESEND_API_KEY",
    },
    {
      name: "تخزين الملفات",
      ok: storageDriver() === "supabase",
      hint:
        storageDriver() === "supabase"
          ? "Supabase Storage"
          : "محلي — غير دائم على Vercel",
      envKey: "SUPABASE_URL",
    },
    {
      name: "AUTH_SECRET",
      ok: Boolean(process.env.AUTH_SECRET),
      hint: "توقيع الجلسات",
      envKey: "AUTH_SECRET",
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="الإعدادات"
        description="بيانات المنصة وبيانات التواصل ومفتاح الأمان."
      />

      {/* حالة التكاملات */}
      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">حالة الخدمات</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {integrations.map((item) => (
            <div
              key={item.name}
              className="flex items-center justify-between gap-3 rounded-xl border border-ink-200 p-3.5"
            >
              <div className="min-w-0">
                <p className="text-sm font-semibold text-ink-900">{item.name}</p>
                <p className="truncate text-xs text-ink-500" dir="ltr">
                  {item.envKey}
                </p>
                <p className="text-xs text-ink-400">{item.hint}</p>
              </div>
              <span
                className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-bold ${
                  item.ok
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-amber-50 text-amber-700"
                }`}
              >
                {item.ok ? "مُعد" : "غير مُعد"}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-ink-500">
          الخدمات غير المُعدة لا تمنع عمل المنصة، لكنها تُعطّل الوظائف المرتبطة بها.
          جميع الخطوات بالتفصيل في ملف <code>SETUP.md</code>.
        </p>
      </section>

      {/* بيانات المنصة */}
      <AdminForm action={saveSettingsAction}>
        <input type="hidden" name="_checkboxes" value="vatIncluded" />
        <div className="space-y-5">
          <AdminSection title="هوية المنصة">
            <div className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <TextField
                  label="اسم المنصة"
                  name="siteName"
                  defaultValue={settings.siteName}
                  required
                />
                <TextField
                  label="الشعار (حرف واحد)"
                  name="logoText"
                  defaultValue={settings.logoText}
                  maxLength={3}
                  hint="الحرف الظاهر داخل مربع الشعار"
                />
              </div>
              <TextField
                label="الجملة التعريفية"
                name="tagline"
                defaultValue={settings.tagline}
              />
            </div>
          </AdminSection>

          <AdminSection title="بيانات الأستاذ">
            <div className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <TextField
                  label="اسم الأستاذ"
                  name="teacherName"
                  defaultValue={settings.teacherName}
                />
                <TextField
                  label="الصفة"
                  name="teacherTitle"
                  defaultValue={settings.teacherTitle}
                />
              </div>
              <TextareaField
                label="نبذة عن الأستاذ (تظهر في الصفحة الرئيسية)"
                name="teacherBio"
                defaultValue={settings.teacherBio}
                rows={5}
              />
            </div>
          </AdminSection>

          <AdminSection title="بيانات التواصل">
            <div className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <TextField
                  label="البريد الإلكتروني"
                  name="contactEmail"
                  type="email"
                  dir="ltr"
                  defaultValue={settings.contactEmail}
                  className="[&>input]:text-start"
                />
                <TextField
                  label="رقم الهاتف"
                  name="contactPhone"
                  dir="ltr"
                  defaultValue={settings.contactPhone}
                  className="[&>input]:text-start"
                />
                <TextField
                  label="واتساب"
                  name="whatsapp"
                  dir="ltr"
                  defaultValue={settings.whatsapp}
                  className="[&>input]:text-start"
                />
                <TextField
                  label="الموقع / العنوان"
                  name="address"
                  defaultValue={settings.address}
                />
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <TextField
                  label="رابط إنستغرام"
                  name="instagramUrl"
                  type="url"
                  dir="ltr"
                  defaultValue={settings.instagramUrl}
                  className="[&>input]:text-start"
                />
                <TextField
                  label="رابط يوتيوب"
                  name="youtubeUrl"
                  type="url"
                  dir="ltr"
                  defaultValue={settings.youtubeUrl}
                  className="[&>input]:text-start"
                />
              </div>

              <div className="grid gap-5 sm:grid-cols-2">
                <TextField
                  label="العملة"
                  name="currency"
                  defaultValue={settings.currency}
                  dir="ltr"
                  maxLength={3}
                />
                <TextField
                  label="نسبة الضريبة %"
                  name="vatPercent"
                  type="number"
                  defaultValue={settings.vatPercent}
                />
              </div>

              <ToggleField
                label="الأسعار شاملة الضريبة"
                name="vatIncluded"
                defaultChecked={settings.vatIncluded}
              />

              <TextareaField
                label="ملاحظة التذييل"
                name="footerNote"
                defaultValue={settings.footerNote}
                rows={2}
              />
            </div>
          </AdminSection>

          <div>
            <SaveButton label="حفظ الإعدادات" />
          </div>
        </div>
      </AdminForm>

      {/* كلمة المرور */}
      <AdminForm action={changeAdminPasswordAction}>
        <input type="hidden" name="_checkboxes" value="" />
        <AdminSection title="تغيير كلمة مرور الإدارة">
          <div className="max-w-md space-y-4">
            <p className="text-sm text-ink-600">
              أنت مسجّل الدخول بحساب: <strong>{user?.email}</strong>
            </p>
            <TextField
              label="كلمة المرور الحالية"
              name="currentPassword"
              type="password"
              dir="ltr"
              required
              className="[&>input]:text-start"
            />
            <TextField
              label="كلمة المرور الجديدة"
              name="newPassword"
              type="password"
              dir="ltr"
              required
              hint="8 أحرف على الأقل مع رقم"
              className="[&>input]:text-start"
            />
            <TextField
              label="تأكيد كلمة المرور الجديدة"
              name="confirmPassword"
              type="password"
              dir="ltr"
              required
              className="[&>input]:text-start"
            />
            <SaveButton label="تغيير كلمة المرور" variant="outline" />
          </div>
        </AdminSection>
      </AdminForm>
    </div>
  );
}