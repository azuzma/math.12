import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveSkillAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { SkillFields } from "@/components/admin/forms/skill-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل مهارة" };

export default async function EditSkillPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const skill = await prisma.skill.findUnique({
    where: { id },
    include: { unit: { include: { term: { select: { title: true } } } } },
  });
  if (!skill) notFound();

  const units = await prisma.unit.findMany({
    orderBy: { order: "asc" },
    include: { term: { select: { title: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={`تعديل: ${skill.title}`} backHref="/admin/skills" />

      <AdminForm action={saveSkillAction}>
        <input type="hidden" name="id" value={skill.id} />
        <SkillFields
          units={units.map((u) => ({
            value: u.id,
            label: `${u.term?.title ?? "—"} › ${u.title}`,
          }))}
          defaults={{
            id: skill.id,
            slug: skill.slug,
            title: skill.title,
            description: skill.description,
            unitId: skill.unitId,
            status: skill.status,
            order: skill.order,
          }}
        />
      </AdminForm>
    </div>
  );
}