import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState } from "@/components/ui/buttons";
import { DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "المهارات" };

export default async function SkillsPage({
  searchParams,
}: {
  searchParams: Promise<{ unit?: string }>;
}) {
  const { unit } = await searchParams;

  const [skills, units] = await Promise.all([
    prisma.skill.findMany({
      where: unit ? { unitId: unit } : {},
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      include: {
        unit: { select: { id: true, title: true, term: { select: { title: true } } } },
        _count: { select: { questions: true, lessons: true } },
      },
      take: 300,
    }),
    prisma.unit.findMany({
      orderBy: { order: "asc" },
      select: { id: true, title: true },
    }),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="المهارات"
        description="المهارة هي الموضوع الفرعي داخل الوحدة. بنك الأسئلة والتحليل يعتمدان عليها."
        action={
          <Link href="/admin/skills/new" className="btn btn-primary">
            <Plus className="h-4 w-4" />
            إضافة مهارة
          </Link>
        }
      />

      {units.length > 0 ? (
        <form className="max-w-sm">
          <select name="unit" defaultValue={unit ?? ""} className="input">
            <option value="">كل الوحدات</option>
            {units.map((u) => (
              <option key={u.id} value={u.id}>
                {u.title}
              </option>
            ))}
          </select>
          <button type="submit" className="btn btn-ghost mt-2">
            تصفية
          </button>
        </form>
      ) : null}

      {skills.length === 0 ? (
        <EmptyState
          title="لا توجد مهارات"
          description="أضف وحدة أولًا ثم أنشئ مهاراتها."
          action={
            <Link href="/admin/skills/new" className="btn btn-primary">
              إضافة مهارة
            </Link>
          }
        />
      ) : (
        <ul className="space-y-3">
          {skills.map((skill) => (
            <li key={skill.id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-semibold text-ink-900">{skill.title}</h2>
                    <StatusBadge status={skill.status} />
                  </div>
                  <p className="mt-1 text-xs text-ink-500">
                    {skill.unit.term?.title ?? "—"} › {skill.unit.title} ·{" "}
                    {skill._count.questions} سؤال · {skill._count.lessons} درس
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusSwitcher entity="skill" id={skill.id} current={skill.status} />
                  <Link
                    href={`/admin/questions/new?skillId=${skill.id}`}
                    className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                  >
                    + سؤال
                  </Link>
                  <Link
                    href={`/admin/skills/${skill.id}/edit`}
                    className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                  >
                    تعديل
                  </Link>
                  <DeleteButton entity="skill" id={skill.id} />
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}