import { prisma } from "@/lib/db/prisma";
import { saveSkillAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { SkillFields } from "@/components/admin/forms/skill-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة مهارة" };

export default async function NewSkillPage({
  searchParams,
}: {
  searchParams: Promise<{ unitId?: string }>;
}) {
  const { unitId } = await searchParams;

  const units = await prisma.unit.findMany({
    orderBy: { order: "asc" },
    include: { term: { select: { title: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة مهارة"
        description="المهارة هي الموضوع الفرعي داخل الوحدة — مثال: «قاعدة السلسلة» داخل وحدة التفاضل."
        backHref="/admin/skills"
      />

      <AdminForm action={saveSkillAction}>
        <SkillFields
          units={units.map((u) => ({
            value: u.id,
            label: `${u.term?.title ?? "—"} › ${u.title}`,
          }))}
          defaults={{ unitId: unitId ?? "" }}
        />
      </AdminForm>
    </div>
  );
}