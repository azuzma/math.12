import { prisma } from "@/lib/db/prisma";
import { saveAssignmentAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { AssignmentFields } from "@/components/admin/forms/assignment-fields";
import { PageHeader } from "@/components/admin/page-header";
import type { PickerQuestion } from "@/components/admin/question-picker";

export const metadata = { title: "إنشاء واجب" };

export default async function NewAssignmentPage({
  searchParams,
}: {
  searchParams: Promise<{ lessonId?: string }>;
}) {
  const { lessonId } = await searchParams;

  const [questions, lessons] = await Promise.all([
    prisma.question.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        text: true,
        type: true,
        points: true,
        lesson: { select: { title: true } },
      },
    }),
    prisma.lesson.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      include: {
        unit: { select: { title: true, course: { select: { subject: { select: { nameAr: true } } } } } },
      },
    }),
  ]);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إنشاء واجب"
        description="اختر الأسئلة من البنك — الموضوعية تُصحَّح تلقائيًا والمقالية يدويًا."
        backHref="/admin/assignments"
      />

      <AdminForm action={saveAssignmentAction}>
        <input type="hidden" name="_checkboxes" value="questionIds[],isFree" />
        <AssignmentFields
          lessons={lessons.map((l) => ({
            value: l.id,
            label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
          }))}
          questions={questions.map(
            (q): PickerQuestion => ({
              id: q.id,
              text: q.text,
              type: q.type,
              points: q.points,
              lessonTitle: q.lesson?.title ?? null,
            }),
          )}
          defaults={{ lessonId }}
        />
      </AdminForm>
    </div>
  );
}