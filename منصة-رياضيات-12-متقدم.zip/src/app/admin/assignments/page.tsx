import Link from "next/link";
import { Plus, NotebookPen } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "الواجبات" };

export default async function AssignmentsPage() {
  const assignments = await prisma.assignment.findMany({
    orderBy: { createdAt: "desc" },
    take: 150,
    include: {
      lesson: {
        select: {
          id: true,
          title: true,
          unit: { select: { course: { select: { subject: { select: { nameAr: true } } } } } },
        },
      },
      _count: { select: { questions: true, submissions: true } },
    },
  });

  const submissionsNeedingReview = await prisma.assignmentSubmission.count({
    where: { needsReview: true },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="الواجبات"
        description="الواجبات بلا مدة محددة — الطالب يسلّم في أي وقت، وتُصحَّح الأسئلة الموضوعية تلقائيًا."
        action={
          <ButtonLink href="/admin/assignments/new">
            <Plus className="h-4 w-4" />
            إنشاء واجب
          </ButtonLink>
        }
      />

      {submissionsNeedingReview > 0 ? (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          يوجد {submissionsNeedingReview} تسليم يحتاج تصحيح يدوي (أسئلة مقالية).
        </div>
      ) : null}

      {assignments.length === 0 ? (
        <EmptyState
          title="لا توجد واجبات"
          description="أنشئ واجبًا من بنك الأسئلة ليستلمه الطلاب."
          icon={<NotebookPen className="h-6 w-6" />}
          action={<ButtonLink href="/admin/assignments/new">إنشاء أول واجب</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الواجب", "الدرس", "الأسئلة", "التسليمات", "الحالة", "الإجراءات"]}
          >
            {assignments.map((a) => (
              <tr key={a.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/assignments/${a.id}/edit`}
                    className="font-semibold text-ink-900 hover:text-brand-700"
                  >
                    {a.title}
                  </Link>
                  <p className="text-xs text-ink-400">{formatDate(a.createdAt)}</p>
                </td>
                <td className="max-w-48 px-4 py-3 text-xs text-ink-600">
                  {a.lesson?.title ?? "—"}
                  <p className="text-ink-400">
                    {a.lesson?.unit.course.subject.nameAr ?? ""}
                  </p>
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {a._count.questions}
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {a._count.submissions}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <StatusBadge status={a.status} />
                    <AccessBadge isFree={a.isFree} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="assignment" id={a.id} current={a.status} />
                    <Link
                      href={`/admin/assignments/${a.id}`}
                      className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                    >
                      التسليمات
                    </Link>
                    <Link
                      href={`/admin/assignments/${a.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="assignment" id={a.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}