import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { gradeSubmissionAction } from "@/app/actions/admin";
import { AdminForm, SaveButton, AdminSection, DataTable } from "@/components/admin/ui";
import { ButtonLink, EmptyState, Alert } from "@/components/ui/buttons";
import { ScoreBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { formatDateTime } from "@/lib/utils";
import { gradeAnswer } from "@/lib/grading";

export const metadata = { title: "تسليمات الواجب" };

export default async function AssignmentSubmissionsPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const assignment = await prisma.assignment.findUnique({
    where: { id },
    include: {
      lesson: { select: { title: true } },
      questions: {
        orderBy: { order: "asc" },
        include: { question: true },
      },
      submissions: {
        orderBy: { submittedAt: "desc" },
        include: { student: { select: { fullName: true, email: true } } },
      },
    },
  });
  if (!assignment) notFound();

  const pending = assignment.submissions.filter((s) => s.needsReview);

  return (
    <div className="space-y-6">
      <PageHeader
        title={`تسليمات: ${assignment.title}`}
        description={`${assignment.submissions.length} تسليم · ${assignment.questions.length} سؤال`}
        backHref="/admin/assignments"
        action={
          <Link href={`/admin/assignments/${assignment.id}/edit`} className="btn btn-outline">
            تعديل الواجب
          </Link>
        }
      />

      {pending.length > 0 ? (
        <Alert tone="warn" title={`${pending.length} تسليم يحتاج تصحيحًا يدويًا`}>
          الأسئلة المقالية والإجابات القصيرة تحتاج تقييمك. عيّن الدرجة واكتب ملاحظة للطالب.
        </Alert>
      ) : null}

      {assignment.submissions.length === 0 ? (
        <EmptyState
          title="لا توجد تسليمات بعد"
          description="ستظهر هنا إجابات الطلاب فور تسليمها."
        />
      ) : (
        <div className="space-y-4">
          {assignment.submissions.map((submission) => {
            const answers =
              submission.answers && typeof submission.answers === "object"
                ? (submission.answers as Record<string, unknown>)
                : {};

            return (
              <div key={submission.id} className="card p-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-bold text-ink-900">
                      {submission.student.fullName}
                    </p>
                    <p className="text-xs text-ink-500" dir="ltr">
                      {submission.student.email}
                    </p>
                    <p className="text-xs text-ink-400">
                      {formatDateTime(submission.submittedAt)}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold text-ink-900 tabular-nums">
                      {submission.score} / {submission.maxScore}
                    </span>
                    {submission.maxScore > 0 ? (
                      <ScoreBadge
                        percentage={Math.round((submission.score / submission.maxScore) * 100)}
                      />
                    ) : null}
                  </div>
                </div>

                {/* مراجعة الإجابات */}
                <div className="mt-4 space-y-3">
                  {assignment.questions.map((eq, i) => {
                    const q = eq.question;
                    const given = answers[q.id] ?? null;
                    const graded = gradeAnswer(q.type, given, q.correct, q.options);

                    const options = Array.isArray(q.options)
                      ? (q.options as { id: string; text: string }[])
                      : [];

                    const textOf = (v: unknown) =>
                      Array.isArray(v)
                        ? v
                            .map(
                              (cid) =>
                                options.find((o) => o.id === cid)?.text ?? String(cid),
                            )
                            .join("، ")
                        : options.find((o) => o.id === v)?.text ??
                          (v ? String(v) : "لم يُجب");

                    return (
                      <div
                        key={q.id}
                        className="rounded-xl border border-ink-200 p-3.5"
                      >
                        <p className="text-xs font-medium text-ink-500">
                          سؤال {i + 1} · {eq.points} درجة
                        </p>
                        <p className="mt-1 text-sm leading-relaxed text-ink-900">
                          {q.text}
                        </p>
                        <p className="mt-2 text-sm">
                          <span className="font-semibold text-ink-500">إجابة الطالب: </span>
                          <span
                            className={
                              graded.isCorrect ? "text-emerald-700" : "text-rose-700"
                            }
                          >
                            {textOf(given)}
                          </span>
                        </p>
                        {graded.needsReview ? (
                          <p className="mt-1 text-xs font-medium text-amber-700">
                            يحتاج تصحيحًا يدويًا
                          </p>
                        ) : null}
                      </div>
                    );
                  })}
                </div>

                {submission.needsReview ? (
                  <AdminForm action={gradeSubmissionAction} className="mt-4">
                    <input type="hidden" name="submissionId" value={submission.id} />
                    <AdminSection title="التصحيح اليدوي" className="!p-4">
                      <div className="grid gap-4 sm:grid-cols-[120px_1fr]">
                        <div>
                          <label className="label">الدرجة</label>
                          <input
                            type="number"
                            name="score"
                            step="0.5"
                            defaultValue={submission.score}
                            max={submission.maxScore}
                            min={0}
                            className="input"
                            required
                          />
                          <p className="mt-1 text-xs text-ink-400">
                            من {submission.maxScore}
                          </p>
                        </div>
                        <div>
                          <label className="label">ملاحظة للطالب</label>
                          <textarea
                            name="feedback"
                            rows={3}
                            defaultValue={submission.feedback ?? ""}
                            placeholder="ملاحظتك على إجابات الطالب…"
                            className="input resize-y"
                          />
                        </div>
                      </div>
                      <div className="mt-4">
                        <SaveButton label="حفظ التصحيح" />
                      </div>
                    </AdminSection>
                  </AdminForm>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}