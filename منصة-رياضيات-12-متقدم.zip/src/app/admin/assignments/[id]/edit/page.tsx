import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveAssignmentAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { AssignmentFields } from "@/components/admin/forms/assignment-fields";
import { PageHeader } from "@/components/admin/page-header";
import type { PickerQuestion } from "@/components/admin/question-picker";

export const metadata = { title: "تعديل واجب" };

export default async function EditAssignmentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const assignment = await prisma.assignment.findUnique({
    where: { id },
    include: { questions: { orderBy: { order: "asc" } } },
  });
  if (!assignment) notFound();

  const [questions, lessons] = await Promise.all([
    prisma.question.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        text: true,
        type: true,
        points: true,
        lesson: { select: { title: true } },
      },
    }),
    prisma.lesson.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      include: {
        unit: { select: { title: true, course: { select: { subject: { select: { nameAr: true } } } } } },
      },
    }),
  ]);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title={`تعديل: ${assignment.title}`}
        backHref="/admin/assignments"
      />

      <AdminForm action={saveAssignmentAction}>
        <input type="hidden" name="id" value={assignment.id} />
        <input type="hidden" name="_checkboxes" value="questionIds[],isFree" />
        <AssignmentFields
          lessons={lessons.map((l) => ({
            value: l.id,
            label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
          }))}
          questions={questions.map(
            (q): PickerQuestion => ({
              id: q.id,
              text: q.text,
              type: q.type,
              points: q.points,
              lessonTitle: q.lesson?.title ?? null,
            }),
          )}
          defaults={{
            id: assignment.id,
            title: assignment.title,
            instructions: assignment.instructions,
            lessonId: assignment.lessonId,
            status: assignment.status,
            isFree: assignment.isFree,
            dueAfterDays: assignment.dueAfterDays ?? 7,
            questionIds: assignment.questions.map((q) => q.questionId),
          }}
        />
      </AdminForm>
    </div>
  );
}