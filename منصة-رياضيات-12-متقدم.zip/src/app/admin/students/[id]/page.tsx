import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import {
  updateStudentAction,
  grantSubscriptionAction,
} from "@/app/actions/admin";
import {
  AdminForm,
  SaveButton,
  AdminSection,
  DataTable,
  DeleteButton,
} from "@/components/admin/ui";
import { TextField, SelectField, TextareaField } from "@/components/ui/forms";
import {
  UserStatusBadge,
  SubscriptionBadge,
  PaymentBadge,
  ScoreBadge,
} from "@/components/ui/badges";
import { Alert, EmptyState } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { ProgressBar } from "@/components/dashboard/progress-bar";
import { formatDate, formatDateTime, formatPrice } from "@/lib/utils";

export const metadata = { title: "ملف الطالب" };

export default async function StudentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const [student, grades, plans] = await Promise.all([
    prisma.user.findUnique({
      where: { id },
      include: {
        studentProfile: { include: { grade: true } },
        subscriptions: {
          orderBy: { createdAt: "desc" },
          include: { plan: true },
        },
        payments: { orderBy: { createdAt: "desc" }, take: 20, include: { plan: true } },
        lessonProgress: {
          orderBy: { lastViewedAt: "desc" },
          take: 15,
          include: { lesson: { select: { title: true } } },
        },
        examAttempts: {
          orderBy: { submittedAt: "desc" },
          take: 15,
          include: { exam: { select: { title: true } } },
        },
      },
    }),
    prisma.grade.findMany({ orderBy: { order: "asc" }, select: { id: true, nameAr: true } }),
    prisma.plan.findMany({ where: { isActive: true }, orderBy: { sortOrder: "asc" } }),
  ]);

  if (!student) notFound();

  const activeSub = student.subscriptions.find(
    (s) =>
      (s.status === "ACTIVE" || s.status === "TRIAL") &&
      s.currentPeriodEnd > new Date(),
  );

  const totalLessons = student.studentProfile?.gradeId
    ? await prisma.lesson.count({
        where: {
          status: "PUBLISHED",
          unit: { course: { subject: { gradeId: student.studentProfile.gradeId } } },
        },
      })
    : 0;

  const completed = student.lessonProgress.filter((p) => p.completed).length;
  const attempts = student.examAttempts.filter((a) => a.submittedAt);
  const averageScore = attempts.length
    ? Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)
    : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title={student.fullName}
        description={`${student.email}${student.phone ? ` · ${student.phone}` : ""}`}
        backHref="/admin/students"
      />

      {/* الملخص */}
      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { label: "الصف", value: student.studentProfile?.grade?.nameAr ?? "—" },
          { label: "الدروس المكتملة", value: `${completed} / ${totalLessons}` },
          { label: "محاولات الاختبار", value: attempts.length },
          { label: "متوسط الدرجات", value: `${averageScore}%` },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="card p-5">
        <ProgressBar
          percent={totalLessons ? (completed / totalLessons) * 100 : 0}
          label="نسبة إكمال الدروس"
          showValue
        />
      </div>

      {/* إدارة الحساب */}
      <div className="grid gap-6 lg:grid-cols-2">
        <AdminForm action={updateStudentAction}>
          <input type="hidden" name="userId" value={student.id} />
          <input type="hidden" name="_checkboxes" value="" />
          <AdminSection title="إدارة الحساب">
            <div className="space-y-4">
              <SelectField
                label="حالة الحساب"
                name="status"
                defaultValue={student.status}
                options={[
                  { value: "ACTIVE", label: "نشط" },
                  { value: "SUSPENDED", label: "موقوف" },
                  { value: "PENDING", label: "بانتظار التفعيل" },
                ]}
                hint="الإيقاف يمنع تسجيل الدخول فورًا."
              />

              <SelectField
                label="الصف الدراسي"
                name="gradeId"
                defaultValue={student.studentProfile?.gradeId ?? ""}
                options={[
                  { value: "", label: "— بدون صف —" },
                  ...grades.map((g) => ({ value: g.id, label: g.nameAr })),
                ]}
              />

              <TextField
                label="المدرسة"
                name="schoolName"
                defaultValue={student.studentProfile?.schoolName ?? ""}
              />

              <TextField
                label="هدف اليوم (دقائق)"
                name="dailyGoalMinutes"
                type="number"
                defaultValue={student.studentProfile?.dailyGoalMinutes ?? 30}
                min={0}
                max={600}
              />

              <TextField
                label="تعيين كلمة مرور جديدة (اختياري)"
                name="newPassword"
                type="password"
                dir="ltr"
                placeholder="اتركه فارغًا للإبقاء على الحالية"
                className="[&>input]:text-start"
              />

              <SaveButton label="حفظ التعديلات" />
            </div>
          </AdminSection>
        </AdminForm>

        <AdminForm action={grantSubscriptionAction}>
          <input type="hidden" name="_checkboxes" value="" />
          <AdminSection title="تفعيل اشتراك يدوي">
            <p className="mb-4 rounded-lg bg-ink-50 px-3 py-2 text-sm text-ink-600">
              استخدم هذا عند التحويل البنكي أو عند الاشتراك خارج المنصة.
              يُسجَّل الاشتراك باسم الطالب ويُنشئ له إشعار.
            </p>

            <div className="space-y-4">
              <input type="hidden" name="userId" value={student.id} />

              <SelectField
                label="الباقة"
                name="planId"
                placeholder="اختر الباقة"
                options={plans.map((p) => ({
                  value: p.id,
                  label: `${p.nameAr} (${p.monthlyPrice} ${p.currency}/شهر)`,
                }))}
                required
              />

              <div className="grid gap-4 sm:grid-cols-2">
                <SelectField
                  label="نوع الاشتراك"
                  name="billingCycle"
                  defaultValue="monthly"
                  options={[
                    { value: "monthly", label: "شهري" },
                    { value: "yearly", label: "سنوي" },
                  ]}
                />
                <TextField
                  label="المدة بالأيام"
                  name="days"
                  type="number"
                  defaultValue={30}
                  min={1}
                  max={3650}
                  required
                />
              </div>

              <SaveButton label="تفعيل الاشتراك" />
            </div>
          </AdminSection>
        </AdminForm>
      </div>

      {/* الاشتراكات */}
      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">سجل الاشتراكات</h2>

        {student.subscriptions.length === 0 ? (
          <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
            لا يوجد اشتراكات — الطالب على الباقة المجانية.
          </p>
        ) : (
          <DataTable headers={["الباقة", "الحالة", "الفترة", "المزوّد", "المبلغ"]}>
            {student.subscriptions.map((s) => (
              <tr key={s.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3 font-medium text-ink-900">{s.plan.nameAr}</td>
                <td className="px-4 py-3">
                  <SubscriptionBadge status={s.status} />
                </td>
                <td className="px-4 py-3 text-xs text-ink-600">
                  {formatDate(s.currentPeriodStart)} — {formatDate(s.currentPeriodEnd)}
                </td>
                <td className="px-4 py-3 text-ink-600">{s.provider}</td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {formatPrice(s.amount, s.currency)}
                </td>
              </tr>
            ))}
          </DataTable>
        )}
      </section>

      {/* المدفوعات */}
      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">سجل المدفوعات</h2>

        {student.payments.length === 0 ? (
          <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
            لا توجد مدفوعات.
          </p>
        ) : (
          <DataTable headers={["التاريخ", "الباقة", "المبلغ", "الحالة", "المرجع"]}>
            {student.payments.map((p) => (
              <tr key={p.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3 text-ink-600">
                  {formatDateTime(p.createdAt)}
                </td>
                <td className="px-4 py-3 text-ink-600">{p.plan?.nameAr ?? "—"}</td>
                <td className="px-4 py-3 font-semibold text-ink-900 tabular-nums">
                  {formatPrice(p.amount, p.currency)}
                </td>
                <td className="px-4 py-3">
                  <PaymentBadge status={p.status} />
                </td>
                <td className="px-4 py-3 text-xs text-ink-500" dir="ltr">
                  {p.providerRef ?? "—"}
                </td>
              </tr>
            ))}
          </DataTable>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* التقدم */}
        <section className="card p-5">
          <h2 className="mb-4 text-base font-bold text-ink-900">آخر الدروس</h2>
          {student.lessonProgress.length === 0 ? (
            <p className="text-sm text-ink-500">لم يبدأ أي درس.</p>
          ) : (
            <ul className="space-y-2">
              {student.lessonProgress.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3 rounded-lg bg-ink-50 px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-900">
                      {p.lesson.title}
                    </p>
                    <p className="text-xs text-ink-500">
                      {formatDate(p.lastViewedAt)}
                    </p>
                  </div>
                  <span className="shrink-0 text-xs font-bold text-ink-700 tabular-nums">
                    {p.completed ? "مكتمل" : `${Math.round(p.watchPercent)}%`}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* نتائج الاختبارات */}
        <section className="card p-5">
          <h2 className="mb-4 text-base font-bold text-ink-900">نتائج الاختبارات</h2>
          {attempts.length === 0 ? (
            <p className="text-sm text-ink-500">لا توجد محاولات.</p>
          ) : (
            <ul className="space-y-2">
              {attempts.map((a) => (
                <li
                  key={a.id}
                  className="flex items-center justify-between gap-3 rounded-lg bg-ink-50 px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink-900">
                      {a.exam.title}
                    </p>
                    <p className="text-xs text-ink-500">
                      {formatDate(a.submittedAt)} · {a.score}/{a.maxScore}
                    </p>
                  </div>
                  <ScoreBadge percentage={Math.round(a.percentage)} />
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* منطقة الحذف */}
      {activeSub ? (
        <Alert tone="info">
          هذا الطالب لديه اشتراك فعّال ({activeSub.plan.nameAr}) حتى{" "}
          {formatDate(activeSub.currentPeriodEnd)}.
        </Alert>
      ) : null}

      <section className="card border-rose-200 p-5">
        <h2 className="text-base font-bold text-rose-800">منطقة الحذف</h2>
        <p className="mt-1 text-sm text-ink-600">
          حذف الحساب يزيل كل بياناته (التقدم والنتائج والمدفوعات) نهائيًا.
        </p>
        <div className="mt-3">
          <DeleteButton
            entity="student"
            id={student.id}
            label="حذف حساب الطالب نهائيًا"
            confirmText={`سيتم حذف حساب «${student.fullName}» وكل بياناته نهائيًا. لا يمكن التراجع.`}
          />
        </div>
      </section>
    </div>
  );
}