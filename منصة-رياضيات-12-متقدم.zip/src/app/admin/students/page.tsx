import Link from "next/link";
import { Search, Users, Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { createStudentAction } from "@/app/actions/admin";
import { AdminForm, SaveButton, DataTable } from "@/components/admin/ui";
import { TextField, SelectField } from "@/components/ui/forms";
import { UserStatusBadge, SubscriptionBadge } from "@/components/ui/badges";
import { EmptyState, Alert } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { NewStudentPanel } from "@/components/admin/new-student-panel";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "الطلاب" };

export default async function StudentsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; page?: string }>;
}) {
  const { q, status, page } = await searchParams;
  const query = (q ?? "").trim();
  const currentPage = Math.max(1, Number(page ?? "1") || 1);
  const perPage = 25;

  const where = {
    role: "STUDENT" as const,
    ...(status && ["ACTIVE", "SUSPENDED", "PENDING"].includes(status)
      ? { status: status as "ACTIVE" | "SUSPENDED" | "PENDING" }
      : {}),
    ...(query
      ? {
          OR: [
            { fullName: { contains: query, mode: "insensitive" as const } },
            { email: { contains: query, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };

  const [students, total, grades] = await Promise.all([
    prisma.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (currentPage - 1) * perPage,
      take: perPage,
      select: {
        id: true,
        fullName: true,
        email: true,
        phone: true,
        status: true,
        createdAt: true,
        lastLoginAt: true,
        studentProfile: {
          select: {
            gradeId: true,
            schoolName: true,
            grade: { select: { nameAr: true } },
          },
        },
        subscriptions: {
          where: { status: { in: ["ACTIVE", "TRIAL"] }, currentPeriodEnd: { gt: new Date() } },
          select: {
            id: true,
            status: true,
            currentPeriodEnd: true,
            plan: { select: { nameAr: true, tier: true } },
          },
          take: 1,
        },
        _count: { select: { lessonProgress: true, examAttempts: true } },
      },
    }),
    prisma.user.count({ where }),
    prisma.grade.findMany({ orderBy: { order: "asc" }, select: { id: true, nameAr: true } }),
  ]);

  const pages = Math.ceil(total / perPage);

  return (
    <div className="space-y-6">
      <PageHeader
        title="الطلاب"
        description={`${total} طالب مسجّل`}
        action={<NewStudentPanel grades={grades} />}
      />

      {/* إضافة طالب يدويًا */}
      <details className="card p-5">
        <summary className="cursor-pointer text-sm font-bold text-ink-900">
          + إضافة طالب يدويًا (للطلاب الجدد أو أولياء الأمور)
        </summary>
        <div className="mt-4">
          <AdminForm action={createStudentAction}>
            <input type="hidden" name="_checkboxes" value="" />
            <div className="grid gap-4 sm:grid-cols-2">
              <TextField label="الاسم الكامل" name="fullName" required />
              <TextField
                label="البريد الإلكتروني"
                name="email"
                type="email"
                dir="ltr"
                required
                className="[&>input]:text-start"
              />
              <TextField
                label="كلمة مرور مؤقتة"
                name="password"
                defaultValue="Student@123"
                dir="ltr"
                required
                hint="8 أحرف على الأقل — أعطِها للطالب"
                className="[&>input]:text-start"
              />
              <TextField label="الهاتف" name="phone" dir="ltr" className="[&>input]:text-start" />
              <SelectField
                label="الصف"
                name="gradeId"
                placeholder="— بدون —"
                options={grades.map((g) => ({ value: g.id, label: g.nameAr }))}
              />
              <TextField label="المدرسة" name="schoolName" />
            </div>
            <div className="mt-4">
              <SaveButton label="إنشاء الحساب" />
            </div>
          </AdminForm>
        </div>
      </details>

      {/* البحث والفلاتر */}
      <form className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-56 flex-1">
          <Search className="pointer-events-none absolute top-1/2 right-3.5 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            type="search"
            name="q"
            defaultValue={query}
            placeholder="ابحث بالاسم أو البريد…"
            className="input pr-10"
          />
        </div>
        <select name="status" defaultValue={status ?? ""} className="input w-auto cursor-pointer">
          <option value="">كل الحالات</option>
          <option value="ACTIVE">نشط</option>
          <option value="SUSPENDED">موقوف</option>
          <option value="PENDING">بانتظار التفعيل</option>
        </select>
        <button type="submit" className="btn btn-outline">
          تصفية
        </button>
      </form>

      {students.length === 0 ? (
        <EmptyState
          title="لا يوجد طلاب"
          description="سيظهر هنا كل طالب يسجّل بنفسه في المنصة."
          icon={<Users className="h-6 w-6" />}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الطالب", "الصف", "الاشتراك", "النشاط", "الحالة", ""]}
          >
            {students.map((s) => {
              const sub = s.subscriptions[0];
              return (
                <tr key={s.id} className="hover:bg-ink-50/50">
                  <td className="px-4 py-3">
                    <Link
                      href={`/admin/students/${s.id}`}
                      className="font-semibold text-ink-900 hover:text-brand-700"
                    >
                      {s.fullName}
                    </Link>
                    <p className="text-xs text-ink-400" dir="ltr">
                      {s.email}
                    </p>
                    {s.studentProfile?.schoolName ? (
                      <p className="text-xs text-ink-400">
                        {s.studentProfile.schoolName}
                      </p>
                    ) : null}
                  </td>
                  <td className="px-4 py-3 text-ink-600">
                    {s.studentProfile?.grade?.nameAr ?? "—"}
                  </td>
                  <td className="px-4 py-3">
                    {sub ? (
                      <div className="flex flex-col gap-1">
                        <SubscriptionBadge status={sub.status} />
                        <span className="text-xs text-ink-500">{sub.plan.nameAr}</span>
                        <span className="text-xs text-ink-400">
                          حتى {formatDate(sub.currentPeriodEnd)}
                        </span>
                      </div>
                    ) : (
                      <span className="text-xs text-ink-400">مجاني</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-ink-600">
                    <p>{s._count.lessonProgress} درس شاهده</p>
                    <p>{s._count.examAttempts} محاولة اختبار</p>
                    <p className="text-ink-400">
                      {s.lastLoginAt ? `آخر دخول ${formatDate(s.lastLoginAt)}` : "لم يسجل دخول"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <UserStatusBadge status={s.status} />
                  </td>
                  <td className="px-4 py-3">
                    <Link
                      href={`/admin/students/${s.id}`}
                      className="rounded-lg bg-brand-50 px-2.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                    >
                      إدارة
                    </Link>
                  </td>
                </tr>
              );
            })}
          </DataTable>
        </div>
      )}

      {pages > 1 ? (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
            <Link
              key={n}
              href={`/admin/students?page=${n}${status ? `&status=${status}` : ""}${
                query ? `&q=${encodeURIComponent(query)}` : ""
              }`}
              className={`grid h-9 w-9 place-items-center rounded-lg text-sm font-semibold tabular-nums transition-colors ${
                n === currentPage
                  ? "bg-brand-600 text-white"
                  : "text-ink-700 hover:bg-ink-100"
              }`}
            >
              {n}
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}