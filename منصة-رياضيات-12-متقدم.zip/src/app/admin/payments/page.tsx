import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, Alert, StatCard } from "@/components/ui/buttons";
import { DataTable } from "@/components/admin/ui";
import { PaymentBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { DollarSign, Wallet, TrendingUp } from "lucide-react";
import { formatDateTime, formatPrice } from "@/lib/utils";

export const metadata = { title: "المدفوعات" };

export default async function PaymentsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; page?: string }>;
}) {
  const { status, page } = await searchParams;
  const currentPage = Math.max(1, Number(page ?? "1") || 1);
  const perPage = 30;

  const where = status && ["SUCCEEDED", "PENDING", "FAILED", "REFUNDED"].includes(status)
    ? { status: status as "SUCCEEDED" }
    : {};

  const [payments, total, aggregate, monthAgg] = await Promise.all([
    prisma.payment.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (currentPage - 1) * perPage,
      take: perPage,
      include: {
        user: { select: { id: true, fullName: true, email: true } },
        plan: { select: { nameAr: true } },
      },
    }),
    prisma.payment.count({ where }),
    prisma.payment.aggregate({
      where: { status: "SUCCEEDED" },
      _sum: { amount: true },
      _count: true,
    }),
    prisma.payment.aggregate({
      where: {
        status: "SUCCEEDED",
        paidAt: {
          gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        },
      },
      _sum: { amount: true },
      _count: true,
    }),
  ]);

  const pages = Math.ceil(total / perPage);

  return (
    <div className="space-y-6">
      <PageHeader title="المدفوعات" description="كل عمليات الدفع المسجّلة في المنصة" />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard
          label="إجمالي الإيرادات"
          value={formatPrice(aggregate._sum.amount ?? 0)}
          hint={`${aggregate._count} دفعة ناجحة`}
          icon={<DollarSign className="h-5 w-5" />}
          tone="green"
        />
        <StatCard
          label="إيرادات هذا الشهر"
          value={formatPrice(monthAgg._sum.amount ?? 0)}
          hint={`${monthAgg._count} دفعة`}
          icon={<TrendingUp className="h-5 w-5" />}
          tone="brand"
        />
        <StatCard
          label="إجمالي العمليات"
          value={total}
          hint="تشمل الفاشلة"
          icon={<Wallet className="h-5 w-5" />}
          tone="ink"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          { value: "", label: "الكل" },
          { value: "SUCCEEDED", label: "ناجحة" },
          { value: "PENDING", label: "قيد المعالجة" },
          { value: "FAILED", label: "فاشلة" },
          { value: "REFUNDED", label: "مسترجعة" },
        ].map((s) => (
          <Link
            key={s.value}
            href={`/admin/payments${s.value ? `?status=${s.value}` : ""}`}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              (status ?? "") === s.value
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {s.label}
          </Link>
        ))}
      </div>

      {payments.length === 0 ? (
        <EmptyState
          title="لا توجد مدفوعات"
          description="ستظهر هنا كل عمليات الدفع بعد ربط بوابة الدفع."
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["التاريخ", "الطالب", "الباقة", "المبلغ", "الحالة", "المزوّد", "المرجع"]}
          >
            {payments.map((p) => (
              <tr key={p.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3 text-xs text-ink-600">
                  {formatDateTime(p.paidAt ?? p.createdAt)}
                </td>
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/students/${p.user.id}`}
                    className="font-medium text-ink-900 hover:text-brand-700"
                  >
                    {p.user.fullName}
                  </Link>
                </td>
                <td className="px-4 py-3 text-ink-600">{p.plan?.nameAr ?? "—"}</td>
                <td className="px-4 py-3 font-semibold text-ink-900 tabular-nums">
                  {formatPrice(p.amount, p.currency)}
                </td>
                <td className="px-4 py-3">
                  <PaymentBadge status={p.status} />
                  {p.failureReason ? (
                    <p className="mt-1 text-[11px] text-rose-600">
                      {p.failureReason}
                    </p>
                  ) : null}
                </td>
                <td className="px-4 py-3 text-xs text-ink-500">
                  {p.provider}
                  {p.cardBrand ? (
                    <p className="text-ink-400">
                      {p.cardBrand} •••• {p.cardLast4 ?? "----"}
                    </p>
                  ) : null}
                </td>
                <td className="px-4 py-3 text-xs text-ink-400" dir="ltr">
                  {p.providerRef?.slice(0, 18) ?? "—"}
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}

      {pages > 1 ? (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
            <Link
              key={n}
              href={`/admin/payments?page=${n}${status ? `&status=${status}` : ""}`}
              className={`grid h-9 w-9 place-items-center rounded-lg text-sm font-semibold tabular-nums transition-colors ${
                n === currentPage
                  ? "bg-brand-600 text-white"
                  : "text-ink-700 hover:bg-ink-100"
              }`}
            >
              {n}
            </Link>
          ))}
        </div>
      ) : null}
    </div>
  );
}