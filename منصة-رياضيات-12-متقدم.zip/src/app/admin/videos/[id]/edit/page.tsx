import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveVideoAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { VideoFields } from "@/components/admin/forms/video-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل فيديو" };

export default async function EditVideoPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const video = await prisma.videoAsset.findUnique({ where: { id } });
  if (!video) notFound();

  const lessons = await prisma.lesson.findMany({
    orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
    include: {
      unit: { select: { title: true, course: { select: { subject: { select: { nameAr: true } } } } } },
    },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={`تعديل: ${video.title}`} backHref="/admin/videos" />

      <AdminForm action={saveVideoAction}>
        <input type="hidden" name="id" value={video.id} />
        <input type="hidden" name="_checkboxes" value="isFree,allowSeeking" />
        <VideoFields
          lessons={lessons.map((l) => ({
            value: l.id,
            label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
          }))}
          defaults={{
            id: video.id,
            title: video.title,
            description: video.description,
            lessonId: video.lessonId,
            provider: video.provider,
            providerId: video.providerId,
            playbackId: video.playbackId,
            durationSec: video.durationSec,
            status: video.status,
            isFree: video.isFree,
            allowSeeking: video.allowSeeking,
          }}
        />
      </AdminForm>
    </div>
  );
}