import Link from "next/link";
import { Plus, Video } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, Alert } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { VideoUploader } from "@/components/admin/video-uploader";
import { YouTubeVideoForm } from "@/components/admin/youtube-video-form";
import { isVideoConfigured } from "@/lib/storage/video";
import { formatDuration, formatBytes, formatDate } from "@/lib/utils";

export const metadata = { title: "الفيديوهات" };

export default async function VideosPage() {
  const configured = isVideoConfigured();

  const [videos, lessons] = await Promise.all([
    prisma.videoAsset.findMany({
      orderBy: { createdAt: "desc" },
      take: 150,
      include: {
        lesson: {
          select: {
            id: true,
            title: true,
            unit: { select: { course: { select: { subject: { select: { nameAr: true } } } } } },
          },
        },
        _count: { select: { sessions: true } },
      },
    }),
    prisma.lesson.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      include: {
        unit: { select: { title: true, course: { select: { subject: { select: { nameAr: true } } } } } },
      },
    }),
  ]);

  const totalSize = videos.reduce((s, v) => s + (v.sizeBytes ?? 0), 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="الفيديوهات"
        description="كل الفيديوهات مرتبطة بدروس وتُشغَّل بروابط موقّعة تنتهي بعد 10 دقائق."
      />

      {!configured ? (
        <Alert tone="warn" title="خدمة Bunny Stream غير مُعدة">
          أضف{" "}
          <code className="font-mono" dir="ltr">
            BUNNY_API_KEY
          </code>{" "}
          و{" "}
          <code className="font-mono" dir="ltr">
            BUNNY_STREAM_AUTH_KEY
          </code>{" "}
          في <code>.env</code> و Vercel. الخطوات في <code>SETUP.md</code>. بعد
          الإعداد ستعمل رفع الملفات من هنا. يمكنك دائمًا ربط فيديو مرفوع على Bunny
          يدويًا عبر زر «تعديل».
        </Alert>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "عدد الفيديوهات", value: videos.length },
          {
            label: "المدة الكلية",
            value: formatDuration(
              videos.reduce((s, v) => s + v.durationSec, 0),
            ),
          },
          { label: "الحجم الكلي", value: formatBytes(totalSize) },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      {configured ? (
        <section className="card p-5">
          <h2 className="mb-4 text-base font-bold text-ink-900">رفع فيديو</h2>
          <VideoUploader
            lessons={lessons.map((l) => ({
              value: l.id,
              label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
            }))}
          />
        </section>
      ) : (
        <section className="card p-5">
          <h2 className="mb-4 text-base font-bold text-ink-900">
            رفع فيديو (تحميل محلي)
          </h2>
          <Alert tone="info" title="رفع محلي">
            لم تُعدّ مفاتيح Bunny Stream، وسيقوم رفع الفيديو بحفظها محليًا على
            الخادم (يُستخدم Bunny تلقائيًا بمجرد ضبط المفاتيح).
          </Alert>
          <div className="mt-4">
            <VideoUploader
              lessons={lessons.map((l) => ({
                value: l.id,
                label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
              }))}
            />
          </div>
        </section>
      )}

      {/* إضافة من YouTube — لا تحتاج أي مفاتيح خارجية */}
      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">
          إضافة فيديو من قناة YouTube
        </h2>
        <YouTubeVideoForm
          lessons={lessons.map((l) => ({
            value: l.id,
            label: `${l.unit.course.subject.nameAr} › ${l.unit.title} › ${l.title}`,
          }))}
        />
      </section>

      {videos.length === 0 ? (
        <EmptyState
          title="لا توجد فيديوهات"
          description={
            configured
              ? "ارفع أول فيديو من النموذج أعلاه أو أضفه من يوتيوب."
              : "أضف فيديو من يوتيوب مباشرة، أو ارفع ملفًا ليُحفظ محليًا."
          }
          icon={<Video className="h-6 w-6" />}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الفيديو", "الدرس", "المدة", "المشاهدات", "الحالة", "الإجراءات"]}
          >
            {videos.map((v) => (
              <tr key={v.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink-900">{v.title}</p>
                  <p className="text-xs text-ink-400">
                    {v.provider} · {formatDate(v.createdAt)}
                  </p>
                </td>
                <td className="max-w-48 px-4 py-3 text-xs text-ink-600">
                  {v.lesson?.title ?? "—"}
                  <p className="text-ink-400">
                    {v.lesson?.unit.course.subject.nameAr ?? ""}
                  </p>
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {formatDuration(v.durationSec)}
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {v._count.sessions}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <StatusBadge status={v.status} />
                    <AccessBadge isFree={v.isFree} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="video" id={v.id} current={v.status} />
                    <Link
                      href={`/admin/videos/${v.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="video" id={v.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}