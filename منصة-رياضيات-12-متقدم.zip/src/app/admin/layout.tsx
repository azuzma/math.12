import type { Metadata } from "next";
import { DashboardShell } from "@/components/dashboard/sidebar";
import { adminNav } from "@/lib/navigation";
import { staffGuardPage } from "@/lib/auth/permissions";
import { redirect } from "next/navigation";
import { PLATFORM } from "@/lib/platform";

export const metadata: Metadata = {
  title: { default: "لوحة الإدارة", template: "%s | لوحة الإدارة" },
  robots: { index: false, follow: false },
};

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const guard = await staffGuardPage();
  if ("redirect" in guard) redirect(guard.redirect);

  return (
    <DashboardShell
      user={{
        fullName: guard.user.fullName,
        role: guard.user.role,
        gradeNameAr: null,
        planName: "",
        isPaid: true,
      }}
      groups={adminNav()}
      title={guard.user.role === "OWNER" ? "لوحة التحكم الخاصّة" : "لوحة الأستاذ"}
      subtitle={PLATFORM.gradeShort}
    >
      {children}
    </DashboardShell>
  );
}