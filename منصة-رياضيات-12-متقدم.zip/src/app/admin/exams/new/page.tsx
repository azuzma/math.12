import { prisma } from "@/lib/db/prisma";
import { saveExamAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { ExamFields } from "@/components/admin/forms/exam-fields";
import { PageHeader } from "@/components/admin/page-header";
import type { PickerQuestion } from "@/components/admin/question-picker";
import { loadCurriculumOptions } from "@/lib/curriculum-options";
import { EXAM_TYPES, type ExamTypeMeta } from "@/lib/platform";

export const metadata = { title: "إنشاء اختبار" };

export default async function NewExamPage({
  searchParams,
}: {
  searchParams: Promise<{
    lessonId?: string;
    unitId?: string;
    termId?: string;
    type?: string;
  }>;
}) {
  const { lessonId, unitId, termId, type } = await searchParams;

  const presetType = (EXAM_TYPES.find((t) => t.value === type)?.value ??
    "LESSON") as ExamTypeMeta["value"];

  const [questions, options] = await Promise.all([
    prisma.question.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        text: true,
        type: true,
        points: true,
        difficulty: true,
        lesson: { select: { title: true } },
        skill: { select: { title: true } },
      },
    }),
    loadCurriculumOptions(),
  ]);

  const courses = await prisma.course.findMany({
    orderBy: { order: "asc" },
    include: { subject: { include: { grade: { select: { nameAr: true } } } } },
  });

  const pickerQuestions: PickerQuestion[] = questions.map((q) => ({
    id: q.id,
    text: q.text,
    type: q.type,
    points: q.points,
    difficulty: q.difficulty,
    lessonTitle: q.lesson?.title ?? null,
    skillTitle: q.skill?.title ?? null,
  }));

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إنشاء اختبار"
        description="حدّد نوع الاختبار والأسئلة من البنك، المدة، عدد المحاولات، ونسبة النجاح."
        backHref="/admin/exams"
      />

      <AdminForm action={saveExamAction}>
        <input
          type="hidden"
          name="_checkboxes"
          value="questionIds[],isFree,shuffleQuestions,showCorrectAnswers,showSolutions"
        />
        <ExamFields
          questions={pickerQuestions}
          lessons={options.lessonOptions}
          units={options.unitOptions}
          terms={options.termOptions}
          courses={courses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          defaults={{ lessonId, unitId, termId, type: presetType }}
        />
      </AdminForm>
    </div>
  );
}