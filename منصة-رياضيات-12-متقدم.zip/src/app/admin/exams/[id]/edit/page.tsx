import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveExamAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { ExamFields } from "@/components/admin/forms/exam-fields";
import { PageHeader } from "@/components/admin/page-header";
import type { PickerQuestion } from "@/components/admin/question-picker";
import { formatDate } from "@/lib/utils";
import { EXAM_TYPE_MAP } from "@/lib/platform";
import { loadCurriculumOptions } from "@/lib/curriculum-options";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

export const metadata = { title: "تعديل اختبار" };

export default async function EditExamPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const exam = await prisma.exam.findUnique({
    where: { id },
    include: { questions: { orderBy: { order: "asc" } } },
  });
  if (!exam) notFound();

  const [questions, options, courses, attempts] = await Promise.all([
    prisma.question.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        text: true,
        type: true,
        points: true,
        difficulty: true,
        lesson: { select: { title: true } },
        skill: { select: { title: true } },
      },
    }),
    loadCurriculumOptions(),
    prisma.course.findMany({
      orderBy: { order: "asc" },
      include: { subject: { include: { grade: { select: { nameAr: true } } } } },
    }),
    prisma.examAttempt.findMany({
      where: { examId: id, submittedAt: { gte: SUBMITTED_EPOCH } },
      orderBy: { percentage: "desc" },
      take: 20,
      include: { student: { select: { fullName: true, email: true } } },
    }),
  ]);

  const pickerQuestions: PickerQuestion[] = questions.map((q) => ({
    id: q.id,
    text: q.text,
    type: q.type,
    points: q.points,
    difficulty: q.difficulty,
    lessonTitle: q.lesson?.title ?? null,
    skillTitle: q.skill?.title ?? null,
  }));

  const typeMeta = EXAM_TYPE_MAP[exam.type];

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title={`تعديل: ${exam.title}`}
        description={`${typeMeta?.icon ?? "📘"} ${typeMeta?.label ?? exam.type} · ${attempts.length} محاولة مسجّلة`}
        backHref="/admin/exams"
      />

      {attempts.length > 0 ? (
        <section className="card p-5">
          <h2 className="mb-3 text-sm font-bold text-ink-900">نتائج الطلاب</h2>
          <div className="space-y-1.5">
            {attempts.map((a) => (
              <div
                key={a.id}
                className="flex items-center justify-between gap-3 rounded-lg bg-ink-50 px-3 py-2 text-sm"
              >
                <div className="min-w-0">
                  <p className="truncate font-medium text-ink-900">
                    {a.student.fullName}
                  </p>
                  <p className="text-xs text-ink-500">{formatDate(a.submittedAt)}</p>
                </div>
                <span
                  className={`shrink-0 font-bold tabular-nums ${
                    a.passed ? "text-emerald-700" : "text-rose-700"
                  }`}
                >
                  {Math.round(a.percentage)}% ({a.score}/{a.maxScore})
                </span>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <AdminForm action={saveExamAction}>
        <input type="hidden" name="id" value={exam.id} />
        <input
          type="hidden"
          name="_checkboxes"
          value="questionIds[],isFree,shuffleQuestions,showCorrectAnswers,showSolutions"
        />
        <ExamFields
          questions={pickerQuestions}
          lessons={options.lessonOptions}
          units={options.unitOptions}
          terms={options.termOptions}
          courses={courses.map((c) => ({
            value: c.id,
            label: `${c.title} — ${c.subject.grade.nameAr}`,
          }))}
          defaults={{
            id: exam.id,
            title: exam.title,
            slug: exam.slug,
            type: exam.type,
            description: exam.description,
            instructions: exam.instructions,
            lessonId: exam.lessonId,
            unitId: exam.unitId,
            termId: exam.termId,
            courseId: exam.courseId,
            status: exam.status,
            isFree: exam.isFree,
            durationMinutes: exam.durationMinutes,
            attemptsAllowed: exam.attemptsAllowed,
            passingScore: exam.passingScore,
            shuffleQuestions: exam.shuffleQuestions,
            showCorrectAnswers: exam.showCorrectAnswers,
            showSolutions: exam.showSolutions,
            questionIds: exam.questions.map((q) => q.questionId),
          }}
        />
      </AdminForm>
    </div>
  );
}