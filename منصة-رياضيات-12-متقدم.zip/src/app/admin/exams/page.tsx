import Link from "next/link";
import { Plus, ClipboardCheck } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "الاختبارات" };

export default async function ExamsPage() {
  const exams = await prisma.exam.findMany({
    orderBy: { createdAt: "desc" },
    take: 150,
    include: {
      lesson: { select: { title: true } },
      unit: {
        select: {
          title: true,
          course: { select: { subject: { select: { nameAr: true } } } },
        },
      },
      _count: { select: { questions: true, attempts: true } },
    },
  });

  const totalAttempts = exams.reduce((s, e) => s + e._count.attempts, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="الاختبارات"
        description="كل اختبار يحدد المدة وعدد المحاولات ونسبة النجاح."
        action={
          <ButtonLink href="/admin/exams/new">
            <Plus className="h-4 w-4" />
            إنشاء اختبار
          </ButtonLink>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "عدد الاختبارات", value: exams.length },
          { label: "محاولات الطلاب", value: totalAttempts },
          {
            label: "اختبارات منشورة",
            value: exams.filter((e) => e.status === "PUBLISHED").length,
          },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      {exams.length === 0 ? (
        <EmptyState
          title="لا توجد اختبارات"
          description="أنشئ اختبارًا وحدد أسئلته من بنك الأسئلة."
          icon={<ClipboardCheck className="h-6 w-6" />}
          action={<ButtonLink href="/admin/exams/new">إنشاء أول اختبار</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الاختبار", "المحتوى", "الإعدادات", "النتائج", "الحالة", "الإجراءات"]}
          >
            {exams.map((exam) => (
              <tr key={exam.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/exams/${exam.id}/edit`}
                    className="font-semibold text-ink-900 hover:text-brand-700"
                  >
                    {exam.title}
                  </Link>
                </td>
                <td className="max-w-48 px-4 py-3 text-xs text-ink-600">
                  {exam.lesson?.title ?? exam.unit?.title ?? "اختبار عام"}
                  <p className="text-ink-400">
                    {exam.unit?.course.subject.nameAr ?? ""}
                  </p>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-xs text-ink-600">
                  {exam._count.questions} سؤال · {exam.durationMinutes} د ·{" "}
                  {exam.attemptsAllowed} محاولات
                  <p className="text-ink-400">النجاح {exam.passingScore}%</p>
                </td>
                <td className="px-4 py-3 text-ink-600 tabular-nums">
                  {exam._count.attempts} محاولة
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <StatusBadge status={exam.status} />
                    <AccessBadge isFree={exam.isFree} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="exam" id={exam.id} current={exam.status} />
                    <Link
                      href={`/admin/exams/${exam.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="exam" id={exam.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}