import { sendAnnouncementAction } from "@/app/actions/admin";
import { AdminForm, SaveButton, AdminSection, DataTable } from "@/components/admin/ui";
import { TextField, TextareaField, SelectField } from "@/components/ui/forms";
import { prisma } from "@/lib/db/prisma";
import { Alert } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { formatDateTime } from "@/lib/utils";

export const metadata = { title: "الإعلانات والإشعارات" };

export default async function NotificationsPage() {
  const [recent, studentsCount] = await Promise.all([
    prisma.notification.findMany({
      where: { type: "ANNOUNCEMENT" },
      orderBy: { createdAt: "desc" },
      take: 30,
      include: { user: { select: { fullName: true } } },
    }),
    prisma.user.count({ where: { role: "STUDENT", status: "ACTIVE" } }),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="الإعلانات والإشعارات"
        description={`${studentsCount} طالب نشط. الإعلانات تظهر داخل المنصة فورًا.`}
      />

      <AdminForm action={sendAnnouncementAction}>
        <input type="hidden" name="_checkboxes" value="" />
        <AdminSection
          title="إرسال إعلان للطلاب"
          description="سيصل الإعلان كإشعار داخل المنصة لكل الطلاب في الجمهور المحدد."
        >
          <div className="space-y-4">
            <TextField
              label="عنوان الإعلان"
              name="title"
              placeholder="مثال: تم نشر دروس جديدة لوحدة المشتقات"
              required
            />

            <TextareaField
              label="نص الإعلان"
              name="body"
              rows={4}
              placeholder="اكتب التفاصيل…"
              required
            />

            <div className="grid gap-4 sm:grid-cols-2">
              <SelectField
                label="الجمهور"
                name="audience"
                defaultValue="ALL"
                options={[
                  { value: "ALL", label: "كل الطلاب" },
                  { value: "STUDENTS", label: "الطلاب النشطون" },
                  { value: "PAID", label: "المشتركون فقط" },
                  { value: "FREE", label: "غير المشتركين" },
                ]}
                required
              />
              <TextField
                label="رابط (اختياري)"
                name="link"
                placeholder="/lessons/g12-derivative-rules"
                dir="ltr"
                className="[&>input]:text-start"
              />
            </div>

            <SaveButton label="إرسال الإعلان" />
          </div>
        </AdminSection>
      </AdminForm>

      <Alert tone="info" title="إشعارات تلقائية">
        يُرسل النظام إشعارًا تلقائيًا للطلاب في نفس الصف عند نشر درس جديد، وعند
        نتيجة اختبار، وعند تفعيل الاشتراك أو قرب انتهائه.
      </Alert>

      <section className="card p-5">
        <h2 className="mb-4 text-base font-bold text-ink-900">آخر الإعلانات</h2>
        {recent.length === 0 ? (
          <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
            لم تُرسل إعلانات بعد.
          </p>
        ) : (
          <DataTable headers={["الإعلان", "الطالب", "التاريخ"]}>
            {recent.map((n) => (
              <tr key={n.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <p className="font-semibold text-ink-900">{n.title}</p>
                  <p className="line-clamp-1 text-xs text-ink-500">{n.body}</p>
                </td>
                <td className="px-4 py-3 text-xs text-ink-600">{n.user.fullName}</td>
                <td className="px-4 py-3 text-xs text-ink-500">
                  {formatDateTime(n.createdAt)}
                </td>
              </tr>
            ))}
          </DataTable>
        )}
      </section>
    </div>
  );
}