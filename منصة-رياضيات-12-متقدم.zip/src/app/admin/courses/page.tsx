import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "المقررات" };

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ grade?: string }>;
}) {
  const { grade: gradeSlug } = await searchParams;

  const grades = await prisma.grade.findMany({
    orderBy: { order: "asc" },
    select: { id: true, slug: true, nameAr: true },
  });
  const grade = gradeSlug ? grades.find((g) => g.slug === gradeSlug) : undefined;

  const courses = await prisma.course.findMany({
    where: grade
      ? { subject: { gradeId: grade.id } }
      : undefined,
    orderBy: [{ subject: { grade: { order: "asc" } } }, { order: "asc" }],
    include: {
      subject: { include: { grade: true } },
      _count: { select: { units: true } },
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="المقررات"
        description="المقرر هو الحاوية الكبرى للوحدات."
        action={
          <ButtonLink href="/admin/courses/new">
            <Plus className="h-4 w-4" />
            إضافة مقرر
          </ButtonLink>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/courses"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !grade
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          كل الصفوف
        </Link>
        {grades.map((g) => (
          <Link
            key={g.id}
            href={`/admin/courses?grade=${g.slug}`}
            className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
              grade?.id === g.id
                ? "border-brand-600 bg-brand-600 text-white"
                : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
            }`}
          >
            {g.nameAr}
          </Link>
        ))}
      </div>

      {courses.length === 0 ? (
        <EmptyState
          title="لا توجد مقررات"
          description="أضف مادة أولًا ثم أنشئ منها مقررًا."
          action={<ButtonLink href="/admin/courses/new">إضافة مقرر</ButtonLink>}
        />
      ) : (
        <ul className="space-y-3">
          {courses.map((course) => (
            <li key={course.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      href={`/admin/courses/${course.id}`}
                      className="font-bold text-ink-900 hover:text-brand-700"
                    >
                      {course.title}
                    </Link>
                    <StatusBadge status={course.status} />
                    {course.isFree ? (
                      <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-semibold text-emerald-700">
                        مجاني
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 text-xs text-ink-500">
                    {course.subject.nameAr} · {course.subject.grade.nameAr} ·{" "}
                    {course._count.units} وحدة
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <StatusSwitcher entity="course" id={course.id} current={course.status} />
                  <Link
                    href={`/admin/courses/${course.id}/edit`}
                    className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                  >
                    تعديل
                  </Link>
                  <DeleteButton entity="course" id={course.id} />
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}