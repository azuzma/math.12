import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { saveCourseAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { CourseFields } from "@/components/admin/forms/course-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة مقرر" };

export default async function NewCoursePage({
  searchParams,
}: {
  searchParams: Promise<{ subjectId?: string }>;
}) {
  const { subjectId } = await searchParams;

  const subjects = await prisma.subject.findMany({
    orderBy: [{ grade: { order: "asc" } }, { order: "asc" }],
    include: { grade: { select: { nameAr: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة مقرر"
        description="المقرر يجمع وحدات، والوحدة تجمع دروسًا."
        backHref="/admin/courses"
      />

      <AdminForm action={saveCourseAction}>
        <input type="hidden" name="_checkboxes" value="isFree" />
        <CourseFields
          subjects={subjects.map((s) => ({
            value: s.id,
            label: `${s.nameAr} — ${s.grade.nameAr}`,
          }))}
          defaults={{ subjectId }}
        />
      </AdminForm>
    </div>
  );
}