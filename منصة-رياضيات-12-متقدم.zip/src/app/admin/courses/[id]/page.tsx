import { notFound } from "next/navigation";
import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { saveCourseAction } from "@/app/actions/admin";
import { AdminForm, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { ButtonLink, Alert } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { formatDuration } from "@/lib/utils";

export const metadata = { title: "إدارة مقرر" };

export default async function CourseDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const course = await prisma.course.findUnique({
    where: { id },
    include: {
      subject: { include: { grade: true } },
      units: {
        orderBy: { order: "asc" },
        include: {
          lessons: {
            orderBy: { order: "asc" },
            include: {
              _count: { select: { videos: true, files: true, exams: true, assignments: true } },
              videos: { select: { durationSec: true } },
            },
          },
        },
      },
    },
  });
  if (!course) notFound();

  const lessonCount = course.units.reduce((s, u) => s + u.lessons.length, 0);
  const videoCount = await prisma.videoAsset.count({ where: { lesson: { unit: { courseId: id } } } });

  return (
    <div className="space-y-6">
      <PageHeader
        title={course.title}
        description={`${course.subject.nameAr} · ${course.subject.grade.nameAr}`}
        backHref="/admin/courses"
        action={
          <div className="flex flex-wrap gap-2">
            <Link href={`/admin/courses/${course.id}/edit`} className="btn btn-outline">
              تعديل المقرر
            </Link>
            <ButtonLink href={`/admin/units/new?courseId=${course.id}`}>
              <Plus className="h-4 w-4" />
              إضافة وحدة
            </ButtonLink>
            <ButtonLink href={`/admin/lessons/new?courseId=${course.id}`} variant="soft">
              <Plus className="h-4 w-4" />
              إضافة درس
            </ButtonLink>
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "الوحدات", value: course.units.length },
          { label: "الدروس", value: lessonCount },
          { label: "الفيديوهات", value: videoCount },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      {course.units.length === 0 ? (
        <Alert tone="info" title="ابدأ بإضافة وحدة">
          الوحدة تجمع دروسًا متسلسلة حول موضوع واحد (مثال: المشتقات).
        </Alert>
      ) : null}

      {course.units.map((unit) => (
        <section key={unit.id} className="card p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="font-bold text-ink-900">{unit.title}</h2>
                <StatusBadge status={unit.status} />
                <AccessBadge isFree={unit.isFree} />
              </div>
              <p className="mt-0.5 text-xs text-ink-500">
                {unit.lessons.length} درس
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <StatusSwitcher entity="unit" id={unit.id} current={unit.status} />
              <ButtonLink
                href={`/admin/lessons/new?unitId=${unit.id}`}
                size="sm"
                variant="soft"
              >
                <Plus className="h-3.5 w-3.5" />
                درس
              </ButtonLink>
              <Link
                href={`/admin/units/${unit.id}/edit`}
                className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
              >
                تعديل
              </Link>
              <DeleteButton entity="unit" id={unit.id} />
            </div>
          </div>

          {unit.lessons.length === 0 ? (
            <p className="mt-4 rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
              لا توجد دروس في هذه الوحدة.
            </p>
          ) : (
            <ul className="mt-4 space-y-2">
              {unit.lessons.map((lesson) => (
                <li
                  key={lesson.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-200 p-3.5"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        href={`/admin/lessons/${lesson.id}`}
                        className="font-semibold text-ink-900 hover:text-brand-700"
                      >
                        {lesson.title}
                      </Link>
                      <StatusBadge status={lesson.status} />
                      <AccessBadge
                        isFree={lesson.isFree}
                        isPreview={lesson.isPreview}
                      />
                    </div>
                    <p className="mt-0.5 text-xs text-ink-500">
                      {lesson._count.videos} فيديو · {lesson._count.files} ملف ·{" "}
                      {lesson._count.exams} اختبار · {lesson._count.assignments} واجب
                      {lesson.videos[0]?.durationSec
                        ? ` · ${formatDuration(lesson.videos[0].durationSec)}`
                        : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusSwitcher
                      entity="lesson"
                      id={lesson.id}
                      current={lesson.status}
                    />
                    <Link
                      href={`/admin/lessons/${lesson.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="lesson" id={lesson.id} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  );
}