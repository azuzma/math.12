import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveCourseAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { CourseFields } from "@/components/admin/forms/course-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل مقرر" };

export default async function EditCoursePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const course = await prisma.course.findUnique({ where: { id } });
  if (!course) notFound();

  const subjects = await prisma.subject.findMany({
    orderBy: [{ grade: { order: "asc" } }, { order: "asc" }],
    include: { grade: { select: { nameAr: true } } },
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={`تعديل: ${course.title}`} backHref={`/admin/courses/${course.id}`} />

      <AdminForm action={saveCourseAction}>
        <input type="hidden" name="id" value={course.id} />
        <input type="hidden" name="_checkboxes" value="isFree" />
        <CourseFields
          subjects={subjects.map((s) => ({
            value: s.id,
            label: `${s.nameAr} — ${s.grade.nameAr}`,
          }))}
          defaults={{
            id: course.id,
            slug: course.slug,
            title: course.title,
            subtitle: course.subtitle,
            description: course.description,
            subjectId: course.subjectId,
            status: course.status,
            isFree: course.isFree,
            order: course.order,
          }}
        />
      </AdminForm>
    </div>
  );
}