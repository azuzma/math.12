import Link from "next/link";
import { Plus, CreditCard, Sparkles, Gauge } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { savePlanAction } from "@/app/actions/admin";
import { AdminForm, DeleteButton } from "@/components/admin/ui";
import {
  PlanFeaturesEditor,
  MultiSelect,
} from "@/components/admin/plan-editor";
import {
  TextField,
  TextareaField,
  SelectField,
  ToggleField,
} from "@/components/ui/forms";
import { ButtonLink, Alert, EmptyState } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { formatPrice } from "@/lib/utils";
import { QUOTA_META } from "@/lib/quotas";

const fmt = formatPrice;

export const metadata = { title: "الباقات والأسعار" };

/** مفاتيح حدود الباقة — تتحكم في ما يراه الطالب داخل المنصة */
const PLAN_LIMIT_TOGGLES: {
  key: string;
  name: string;
  label: string;
  hint: string;
  defaultOn: boolean;
}[] = [
  { key: "files", name: "limits.files", label: "أوراق العمل والملفات", hint: "التنزيل والطباعة.", defaultOn: true },
  { key: "exams", name: "limits.exams", label: "الاختبارات المدفوعة", hint: "الفصل والوحدة والشاملة والتجريبية.", defaultOn: false },
  { key: "questions", name: "limits.questions", label: "بنك الأسئلة", hint: "تدريب مباشر على الأسئلة.", defaultOn: false },
  { key: "analysis", name: "limits.analysis", label: "التحليل الذكي (مستواي)", hint: "نقاط القوة والتوصيات.", defaultOn: false },
  { key: "studyPlan", name: "limits.studyPlan", label: "خطة الدراسة", hint: "خطة أسبوعية مخصّصة.", defaultOn: false },
  { key: "tutor", name: "limits.tutor", label: "مساعد الرياضيات", hint: "شرح المسألة خطوة بخطوة.", defaultOn: false },
  { key: "solutions", name: "limits.solutions", label: "الحلول النموذجية", hint: "تظهر بعد الاختبار.", defaultOn: false },
  { key: "certificates", name: "limits.certificates", label: "الشهادات", hint: "شهادة إتمام.", defaultOn: false },
];


export default async function PlansPage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const { edit } = await searchParams;

  const [plans, grades, totalSubs] = await Promise.all([
    prisma.plan.findMany({
      orderBy: { sortOrder: "asc" },
      include: {
        grades: { select: { gradeId: true } },
        _count: { select: { subscriptions: true } },
      },
    }),
    prisma.grade.findMany({ orderBy: { order: "asc" }, select: { id: true, nameAr: true } }),
    prisma.subscription.count({
      where: { status: { in: ["ACTIVE", "TRIAL"] }, currentPeriodEnd: { gt: new Date() } },
    }),
  ]);

  const editing = edit ? plans.find((p) => p.id === edit) : null;

  return (
    <div className="space-y-6">
      <PageHeader
        title="الباقات والأسعار"
        description={`${totalSubs} اشتراك فعّال حاليًا. غيّر الأسعار من هنا — تنعكس فورًا على صفحة الاشتراكات.`}
        action={
          <ButtonLink href="/admin/plans?edit=new">
            <Plus className="h-4 w-4" />
            باقة جديدة
          </ButtonLink>
        }
      />

      <Alert tone="info" title="الأسعار تُدار من هذه الصفحة">
        لا توجد أسعار ثابتة داخل الكود. عدّل السعر الشهري والسنوي هنا، وسيظهر التغيير
        مباشرة في صفحة الاشتراكات وفي عملية الدفع.
      </Alert>

      {plans.length === 0 ? (
        <EmptyState
          title="لا توجد باقات"
          description="أضف الباقات المجانية والأصلية والمميزة لتظهر في صفحة الاشتراكات."
          icon={<CreditCard className="h-6 w-6" />}
          action={<ButtonLink href="/admin/plans?edit=new">إضافة باقة</ButtonLink>}
        />
      ) : (
        <ul className="grid gap-4 lg:grid-cols-3">
          {plans.map((plan) => (
            <li
              key={plan.id}
              className={`card p-5 ${
                plan.isFeatured ? "border-brand-400 ring-1 ring-brand-200" : ""
              } ${!plan.isActive ? "opacity-60" : ""}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="flex items-center gap-1.5 font-bold text-ink-900">
                    {plan.nameAr}
                    {plan.isFeatured ? (
                      <Sparkles className="h-4 w-4 text-gold-500" />
                    ) : null}
                  </h2>
                  <p className="text-xs text-ink-500" dir="ltr">
                    {plan.nameEn} · {plan.tier}
                  </p>
                </div>
                {!plan.isActive ? (
                  <span className="rounded-full bg-ink-100 px-2 py-0.5 text-[11px] font-semibold text-ink-600">
                    معطّلة
                  </span>
                ) : null}
              </div>

              <p className="mt-2 text-xs text-ink-600">{plan.tagline}</p>

              <div className="mt-4 space-y-1.5">
                <p className="text-lg font-bold text-ink-900 tabular-nums">
                  {fmt(plan.monthlyPrice, plan.currency)}
                  {plan.monthlyPrice > 0 ? (
                    <span className="text-xs font-normal text-ink-500"> / شهريًا</span>
                  ) : null}
                </p>
                <p className="text-sm text-ink-600 tabular-nums">
                  {fmt(plan.yearlyPrice, plan.currency)}
                  {plan.yearlyPrice > 0 ? (
                    <span className="text-xs text-ink-500"> / سنويًا</span>
                  ) : null}
                </p>
              </div>

              <div className="mt-3 space-y-1 text-xs text-ink-600">
                {plan.trialDays > 0 ? (
                  <p>فترة تجربة: {plan.trialDays} أيام</p>
                ) : null}
                <p>عدد المشتركين: {plan._count.subscriptions}</p>
                <p>الصفوف: {plan.grades.length || "كل الصفوف"}</p>
              </div>

              <ul className="mt-3 space-y-1 border-t border-ink-100 pt-3">
                {(Array.isArray(plan.features) ? (plan.features as string[]) : []).map(
                  (f) => (
                    <li key={f} className="text-xs text-ink-600">
                      • {f}
                    </li>
                  ),
                )}
              </ul>

              <div className="mt-4 flex items-center gap-2 border-t border-ink-100 pt-3">
                <Link
                  href={`/admin/plans?edit=${plan.id}`}
                  className="rounded-lg bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                >
                  تعديل
                </Link>
                <DeleteButton
                  entity="plan"
                  id={plan.id}
                  confirmText={`سيتم حذف باقة «${plan.nameAr}». لن تتأثر الاشتراكات القائمة لكن لا يمكن إنشاء اشتراكات جديدة عليها.`}
                />
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* نموذج التحرير */}
      {edit ? (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-ink-950/50 p-4">
          <div className="mx-auto my-4 w-full max-w-3xl animate-fade-up rounded-2xl bg-white p-6 shadow-xl">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-bold text-ink-900">
                {editing ? `تعديل: ${editing.nameAr}` : "باقة جديدة"}
              </h2>
              <Link
                href="/admin/plans"
                className="rounded-lg bg-ink-100 px-3 py-1.5 text-sm font-semibold text-ink-600 hover:bg-ink-200"
              >
                إغلاق
              </Link>
            </div>

            <AdminForm action={savePlanAction}>
              {editing ? <input type="hidden" name="id" value={editing.id} /> : null}
              <input
                type="hidden"
                name="_checkboxes"
                value={`features[],gradeIds[],isActive,isFeatured,${PLAN_LIMIT_TOGGLES.map((t) => t.name).join(",")},${QUOTA_META.map((q) => `limits.${q.key}`).join(",")}`}
              />

              <div className="space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <TextField
                    label="اسم الباقة (عربي)"
                    name="nameAr"
                    defaultValue={editing?.nameAr}
                    placeholder="المميزة"
                    required
                  />
                  <TextField
                    label="اسم الباقة (إنجليزي)"
                    name="nameEn"
                    defaultValue={editing?.nameEn}
                    dir="ltr"
                    placeholder="Premium"
                    required
                    className="[&>input]:text-start"
                  />
                </div>

                <TextField
                  label="الجملة التسويقية"
                  name="tagline"
                  defaultValue={editing?.tagline ?? ""}
                  placeholder="الاختبارات الكاملة والحلول النموذجية"
                />

                <TextareaField
                  label="وصف الباقة"
                  name="description"
                  defaultValue={editing?.description ?? ""}
                  rows={3}
                />

                <div className="grid gap-5 sm:grid-cols-3">
                  <TextField
                    label="السعر الشهري (درهم)"
                    name="monthlyPrice"
                    type="number"
                    defaultValue={editing?.monthlyPrice ?? 0}
                    min={0}
                    required
                    hint="0 = مجاني"
                  />
                  <TextField
                    label="السعر السنوي (درهم)"
                    name="yearlyPrice"
                    type="number"
                    defaultValue={editing?.yearlyPrice ?? 0}
                    min={0}
                    required
                  />
                  <TextField
                    label="أيام التجربة"
                    name="trialDays"
                    type="number"
                    defaultValue={editing?.trialDays ?? 0}
                    min={0}
                    max={60}
                  />
                </div>

                <div className="grid gap-5 sm:grid-cols-3">
                  <SelectField
                    label="المستوى"
                    name="tier"
                    defaultValue={editing?.tier ?? "BASIC"}
                    options={[
                      { value: "FREE", label: "مجاني" },
                      { value: "BASIC", label: "أساسي" },
                      { value: "PREMIUM", label: "مميز" },
                    ]}
                    required
                    hint="المستوى يحدد ما يراه الطالب."
                  />
                  <TextField
                    label="العملة"
                    name="currency"
                    defaultValue={editing?.currency ?? "AED"}
                    dir="ltr"
                    maxLength={3}
                    required
                    className="[&>input]:text-start"
                  />
                  <TextField
                    label="ترتيب العرض"
                    name="sortOrder"
                    type="number"
                    defaultValue={editing?.sortOrder ?? 1}
                    required
                  />
                </div>

                {!editing ? (
                  <TextField
                    label="المعرّف (slug)"
                    name="slug"
                    placeholder="premium"
                    dir="ltr"
                    hint="أحرف إنجليزية صغيرة فقط"
                    className="[&>input]:text-start"
                  />
                ) : (
                  <input type="hidden" name="slug" value={editing.slug} />
                )}

                <PlanFeaturesEditor
                  defaults={
                    editing && Array.isArray(editing.features)
                      ? (editing.features as string[])
                      : []
                  }
                />

                <MultiSelect
                  name="gradeIds"
                  label="الصفوف المتاحة لهذه الباقة"
                  hint="اتركها فارغة لتكون متاحة لكل الصفوف."
                  options={grades.map((g) => ({ value: g.id, label: g.nameAr }))}
                  defaults={editing?.grades.map((g) => g.gradeId) ?? []}
                />

                <div className="rounded-xl border border-ink-200 p-4">
                  <p className="mb-1 text-sm font-semibold text-ink-800">
                    ما الذي تشمله الباقة؟
                  </p>
                  <p className="mb-3 text-xs text-ink-500">
                    هذه المفاتيح تحدد ما يراه الطالب داخل المنصة. «الاختبارات»
                    تعني الاختبارات المدفوعة؛ الاختبارات المجانية متاحة دائمًا.
                  </p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {PLAN_LIMIT_TOGGLES.map((t) => (
                      <ToggleField
                        key={t.name}
                        label={t.label}
                        name={t.name}
                        defaultChecked={
                          editing
                            ? Boolean(
                                (editing.limits as Record<string, unknown>)?.[
                                  t.key
                                ],
                              )
                            : t.defaultOn
                        }
                        hint={t.hint}
                      />
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-brand-200 bg-brand-50/40 p-4">
                  <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-brand-900">
                    <Gauge className="h-4 w-4" />
                    الحصص اليومية
                  </p>
                  <p className="mb-4 text-xs text-brand-800/80">
                    الحصة تحدد كم مرة يستخدم الطالب الميزة **يوميًا**. الرقم `0`
                    يعني «بلا حد». تُطبَّق على الخادم — لا يمكن تجاوزها من المتصفح،
                    وتُعرض للطالب متبقيّ الحصة في صفحات الباقات والمساعد.
                  </p>
                  <div className="grid gap-4 sm:grid-cols-3">
                    {QUOTA_META.map((q) => (
                      <div key={q.key}>
                        <label
                          htmlFor={`quota-${q.key}`}
                          className="mb-1 block text-xs font-semibold text-ink-700"
                        >
                          {q.label}{" "}
                          <span className="font-normal text-ink-500">
                            ({q.unit})
                          </span>
                        </label>
                        <input
                          id={`quota-${q.key}`}
                          name={`limits.${q.key}`}
                          type="number"
                          min={0}
                          max={999}
                          defaultValue={
                            editing
                              ? Number(
                                  (editing.limits as Record<string, unknown>)?.[
                                    q.key
                                  ] ?? 0,
                                )
                              : 0
                          }
                          className="input"
                          dir="ltr"
                        />
                        <p className="mt-1 text-[11px] leading-relaxed text-ink-500">
                          {q.hint}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <ToggleField
                    label="الباقة نشطة"
                    name="isActive"
                    defaultChecked={editing?.isActive ?? true}
                  />
                  <ToggleField
                    label="تمييز الباقة (الأكثر اختيارًا)"
                    name="isFeatured"
                    defaultChecked={editing?.isFeatured ?? false}
                  />
                </div>

                <details className="rounded-xl border border-ink-200 p-4">
                  <summary className="cursor-pointer text-sm font-semibold text-ink-800">
                    ربط الدفع (Stripe / Telr) — اتركه فارغًا إن لم تُعدّ البوابات بعد
                  </summary>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <TextField
                      label="Stripe Price ID (شهري)"
                      name="stripeMonthlyPriceId"
                      defaultValue={editing?.stripeMonthlyPriceId ?? ""}
                      dir="ltr"
                      placeholder="price_..."
                      className="[&>input]:text-start"
                    />
                    <TextField
                      label="Stripe Price ID (سنوي)"
                      name="stripeYearlyPriceId"
                      defaultValue={editing?.stripeYearlyPriceId ?? ""}
                      dir="ltr"
                      placeholder="price_..."
                      className="[&>input]:text-start"
                    />
                    <TextField
                      label="Telr Client Key (شهري)"
                      name="telrMonthlyClientKey"
                      defaultValue={editing?.telrMonthlyClientKey ?? ""}
                      dir="ltr"
                      className="[&>input]:text-start"
                    />
                    <TextField
                      label="Telr Client Key (سنوي)"
                      name="telrYearlyClientKey"
                      defaultValue={editing?.telrYearlyClientKey ?? ""}
                      dir="ltr"
                      className="[&>input]:text-start"
                    />
                  </div>
                  <p className="mt-3 text-xs text-ink-500">
                    إذا تركتها فارغة تُنشأ الأسعار تلقائيًا عند الدفع من قيمة الحقول
                    أعلاه.
                  </p>
                </details>
              </div>

              <div className="mt-6 flex gap-3">
                <button type="submit" className="btn btn-primary">
                  حفظ الباقة
                </button>
                <Link href="/admin/plans" className="btn btn-outline">
                  إلغاء
                </Link>
              </div>
            </AdminForm>
          </div>
        </div>
      ) : null}
    </div>
  );
}