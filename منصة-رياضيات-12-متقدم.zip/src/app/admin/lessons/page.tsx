import Link from "next/link";
import { Plus, BookOpen } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { EmptyState, ButtonLink } from "@/components/ui/buttons";
import { DataTable, DeleteButton, StatusSwitcher } from "@/components/admin/ui";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { PageHeader } from "@/components/admin/page-header";
import { RedirectSelect } from "@/components/admin/redirect-select";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "الدروس" };

export default async function LessonsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; q?: string; grade?: string }>;
}) {
  const { status, q, grade: gradeSlug } = await searchParams;
  const query = (q ?? "").trim();

  const grades = await prisma.grade.findMany({
    orderBy: { order: "asc" },
    select: { id: true, slug: true, nameAr: true },
  });
  const grade = gradeSlug ? grades.find((g) => g.slug === gradeSlug) : undefined;

  const lessons = await prisma.lesson.findMany({
    where: {
      ...(status && ["DRAFT", "PUBLISHED", "ARCHIVED"].includes(status)
        ? { status: status as "DRAFT" | "PUBLISHED" | "ARCHIVED" }
        : {}),
      ...(query
        ? { title: { contains: query, mode: "insensitive" as const } }
        : {}),
      ...(grade
        ? { unit: { course: { subject: { gradeId: grade.id } } } }
        : {}),
    },
    orderBy: [
      { unit: { course: { subject: { grade: { order: "asc" } } } } },
      { unit: { order: "asc" } },
      { order: "asc" },
    ],
    include: {
      unit: {
        include: {
          course: { include: { subject: { include: { grade: true } } } },
        },
      },
      _count: { select: { videos: true, files: true, exams: true, assignments: true } },
      progress: { select: { completed: true } },
    },
    take: 200,
  });

  const stats = await prisma.lesson.groupBy({
    by: ["status"],
    _count: { status: true },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="الدروس"
        description="أضف الدرس ثم ارفع الفيديو والملفات والاختبار من صفحة الدرس."
        action={
          <ButtonLink href="/admin/lessons/new">
            <Plus className="h-4 w-4" />
            إضافة درس
          </ButtonLink>
        }
      />

      {/* إحصائيات سريعة */}
      <div className="flex flex-wrap gap-2">
        <Link
          href="/admin/lessons"
          className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
            !status
              ? "border-brand-600 bg-brand-600 text-white"
              : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
          }`}
        >
          الكل ({stats.reduce((s, x) => s + x._count.status, 0)})
        </Link>
        {(["PUBLISHED", "DRAFT", "ARCHIVED"] as const).map((st) => {
          const count = stats.find((s) => s.status === st)?._count.status ?? 0;
          const label =
            st === "PUBLISHED" ? "منشور" : st === "DRAFT" ? "مسودة" : "مؤرشف";
          return (
            <Link
              key={st}
              href={`/admin/lessons?status=${st}`}
              className={`rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                status === st
                  ? "border-brand-600 bg-brand-600 text-white"
                  : "border-ink-200 bg-white text-ink-700 hover:border-brand-300"
              }`}
            >
              {label} ({count})
            </Link>
          );
        })}
      </div>

      {/* فلاتر الصف + بحث */}
      <div className="flex flex-wrap items-center gap-3">
        <form className="relative min-w-56 flex-1">
          <input
            type="search"
            name="q"
            defaultValue={query}
            placeholder="ابحث باسم الدرس…"
            className="input"
          />
          {status ? <input type="hidden" name="status" value={status} /> : null}
        </form>
        <RedirectSelect
          basePath="/admin/lessons"
          defaultValue={gradeSlug ?? ""}
          options={[
            { value: "", label: "كل الصفوف" },
            ...grades.map((g) => ({ value: g.slug, label: g.nameAr })),
          ]}
        />
      </div>

      {lessons.length === 0 ? (
        <EmptyState
          title="لا توجد دروس"
          description="أضف درسًا جديدًا من زر «إضافة درس». بعد الحفظ ستفتح لك صفحة الدرس لإضافة الفيديو والملفات."
          icon={<BookOpen className="h-6 w-6" />}
          action={<ButtonLink href="/admin/lessons/new">إضافة أول درس</ButtonLink>}
        />
      ) : (
        <div className="card">
          <DataTable
            headers={["الدرس", "الوحدة", "الصف", "المحتوى", "الحالة", "الإجراءات"]}
          >
            {lessons.map((lesson) => (
              <tr key={lesson.id} className="hover:bg-ink-50/50">
                <td className="px-4 py-3">
                  <Link
                    href={`/admin/lessons/${lesson.id}`}
                    className="font-semibold text-ink-900 hover:text-brand-700"
                  >
                    {lesson.title}
                  </Link>
                  <p className="text-xs text-ink-400">
                    {formatDate(lesson.updatedAt)}
                  </p>
                </td>
                <td className="px-4 py-3 text-ink-600">{lesson.unit.title}</td>
                <td className="px-4 py-3 text-ink-600">
                  {lesson.unit.course.subject.grade.nameAr}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1.5 text-[11px] text-ink-600">
                    <span className="rounded bg-ink-50 px-1.5 py-0.5">
                      {lesson._count.videos} فيديو
                    </span>
                    <span className="rounded bg-ink-50 px-1.5 py-0.5">
                      {lesson._count.files} ملف
                    </span>
                    <span className="rounded bg-ink-50 px-1.5 py-0.5">
                      {lesson._count.exams} اختبار
                    </span>
                    <span className="rounded bg-ink-50 px-1.5 py-0.5">
                      {lesson._count.assignments} واجب
                    </span>
                  </div>
                  {lesson.progress.some((p) => p.completed) ? (
                    <p className="mt-1 text-[11px] font-semibold text-emerald-700">
                      {lesson.progress.filter((p) => p.completed).length} طالب أكمله
                    </p>
                  ) : null}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1.5">
                    <StatusBadge status={lesson.status} />
                    <AccessBadge isFree={lesson.isFree} isPreview={lesson.isPreview} />
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <StatusSwitcher
                      entity="lesson"
                      id={lesson.id}
                      current={lesson.status}
                    />
                    <Link
                      href={`/admin/lessons/${lesson.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="lesson" id={lesson.id} />
                  </div>
                </td>
              </tr>
            ))}
          </DataTable>
        </div>
      )}
    </div>
  );
}