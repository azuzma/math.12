import Link from "next/link";
import { notFound } from "next/navigation";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/db/prisma";
import { ButtonLink, Alert } from "@/components/ui/buttons";
import { PageHeader } from "@/components/admin/page-header";
import { LessonFields } from "@/components/admin/forms/lesson-fields";
import { VideoUploader } from "@/components/admin/video-uploader";
import { FileUploader } from "@/components/admin/file-uploader";
import { QuickLinks } from "@/components/admin/quick-links";
import { StatusBadge, AccessBadge } from "@/components/ui/badges";
import { DeleteButton, StatusSwitcher, DataTable } from "@/components/admin/ui";
import { formatDuration, formatBytes, formatDate } from "@/lib/utils";
import { isVideoConfigured } from "@/lib/storage/video";
import { storageDriver } from "@/lib/storage/provider";

export const metadata = { title: "إدارة درس" };

export default async function LessonAdminPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const lesson = await prisma.lesson.findUnique({
    where: { id },
    include: {
      unit: {
        include: {
          course: { include: { subject: { include: { grade: true } } } },
        },
      },
      videos: { orderBy: { createdAt: "asc" } },
      files: { orderBy: { createdAt: "desc" } },
      assignments: {
        include: { _count: { select: { questions: true, submissions: true } } },
      },
      exams: {
        include: { _count: { select: { questions: true, attempts: true } } },
      },
      progress: { select: { completed: true, studentId: true } },
    },
  });
  if (!lesson) notFound();

  const videoConfigured = isVideoConfigured();
  const fileDriver = storageDriver();
  const completedCount = lesson.progress.filter((p) => p.completed).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title={lesson.title}
        description={`${lesson.unit.course.subject.grade.nameAr} · ${lesson.unit.title}`}
        backHref="/admin/lessons"
        action={
          <div className="flex flex-wrap items-center gap-2">
            <StatusSwitcher entity="lesson" id={lesson.id} current={lesson.status} />
            <Link href={`/admin/lessons/${lesson.id}/edit`} className="btn btn-outline">
              تعديل بيانات الدرس
            </Link>
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-4">
        {[
          { label: "الحالة", value: lesson.status === "PUBLISHED" ? "منشور" : lesson.status === "DRAFT" ? "مسودة" : "مؤرشف" },
          { label: "الفيديوهات", value: lesson.videos.length },
          { label: "الملفات", value: lesson.files.length },
          { label: "طلاب أكملوه", value: completedCount },
        ].map((s) => (
          <div key={s.label} className="card p-4">
            <p className="text-2xl font-bold text-ink-900 tabular-nums">{s.value}</p>
            <p className="text-xs text-ink-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* ============ الفيديو ============ */}
      <section className="card p-5 sm:p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-ink-900">فيديو الدرس</h2>
            <p className="mt-0.5 text-sm text-ink-500">
              الفيديو يُرفع إلى Bunny Stream ويُشغَّل بروابط موقّعة لا يمكن نسخها.
            </p>
          </div>
          <Link
            href="/admin/videos"
            className="text-xs font-semibold text-brand-700 hover:underline"
          >
            إدارة كل الفيديوهات
          </Link>
        </div>

        {!videoConfigured ? (
          <Alert tone="warn" title="خدمة الفيديو غير مُعدة بعد">
            أضف{" "}
            <code className="font-mono" dir="ltr">
              BUNNY_API_KEY
            </code>{" "}
            و{" "}
            <code className="font-mono" dir="ltr">
              BUNNY_STREAM_AUTH_KEY
            </code>{" "}
            في ملف <code>.env</code> (وفي Vercel). الخطوات بالتفصيل في ملف{" "}
            <code>SETUP.md</code>. بدونها يمكنك ربط فيديو مرفوع على Bunny يدويًا
            من زر «إدارة كل الفيديوهات».
          </Alert>
        ) : null}

        {lesson.videos.length === 0 ? (
          <p className="mt-4 rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
            لم يُرفع أي فيديو لهذا الدرس.
          </p>
        ) : (
          <div className="mt-4 space-y-2.5">
            {lesson.videos.map((v) => (
              <div
                key={v.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ink-200 p-3.5"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold text-ink-900">{v.title}</p>
                    <StatusBadge status={v.status} />
                    <AccessBadge isFree={v.isFree} />
                  </div>
                  <p className="mt-0.5 text-xs text-ink-500">
                    {v.provider} ·{" "}
                    {v.durationSec ? formatDuration(v.durationSec) : "المدة غير محددة"}
                    {v.playbackId ? ` · ID: ${v.playbackId}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusSwitcher entity="video" id={v.id} current={v.status} />
                  <Link
                    href={`/admin/videos/${v.id}/edit`}
                    className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                  >
                    تعديل
                  </Link>
                  <DeleteButton entity="video" id={v.id} />
                </div>
              </div>
            ))}
          </div>
        )}

        {videoConfigured ? (
          <div className="mt-5">
            <VideoUploader lessonId={lesson.id} lessonTitle={lesson.title} />
          </div>
        ) : null}
      </section>

      {/* ============ الملفات ============ */}
      <section className="card p-5 sm:p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-ink-900">
              الملخصات وأوراق العمل
            </h2>
            <p className="mt-0.5 text-sm text-ink-500">
              التخزين الحالي:{" "}
              {fileDriver === "supabase" ? "Supabase Storage" : "محلي على الخادم"}
            </p>
          </div>
          <Link
            href="/admin/files"
            className="text-xs font-semibold text-brand-700 hover:underline"
          >
            إدارة كل الملفات
          </Link>
        </div>

        {fileDriver === "local" ? (
          <Alert tone="warn" title="تخزين الملفات محلي">
            يعمل على جهازك أو سيرفر خاص. عند النشر على Vercel لن تكون الملفات دائمة،
            لذا يُنصح بإعداد Supabase Storage (الخطوات في <code>SETUP.md</code>).
          </Alert>
        ) : null}

        {lesson.files.length === 0 ? (
          <p className="mt-4 rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
            لم تُرفع ملفات لهذا الدرس.
          </p>
        ) : (
          <div className="mt-4">
            <DataTable headers={["الملف", "النوع", "الحجم", "التنزيلات", "الحالة"]}>
              {lesson.files.map((f) => (
                <tr key={f.id} className="hover:bg-ink-50/50">
                  <td className="px-4 py-3">
                    <p className="font-semibold text-ink-900">{f.title}</p>
                    <p className="text-xs text-ink-400">{f.fileName}</p>
                  </td>
                  <td className="px-4 py-3 text-ink-600">{f.kind}</td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">
                    {formatBytes(f.sizeBytes)}
                  </td>
                  <td className="px-4 py-3 text-ink-600 tabular-nums">
                    {f.downloadCount}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1.5">
                      <StatusBadge status={f.status} />
                      <AccessBadge isFree={f.isFree} />
                    </div>
                  </td>
                </tr>
              ))}
            </DataTable>
          </div>
        )}

        <div className="mt-5">
          <FileUploader
            defaultLessonId={lesson.id}
            units={[{ value: lesson.unitId, label: lesson.unit.title }]}
          />
        </div>
      </section>

      {/* ============ الواجبات والاختبارات ============ */}
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-bold text-ink-900">الواجبات</h2>
            <ButtonLink
              href={`/admin/assignments/new?lessonId=${lesson.id}`}
              size="sm"
              variant="soft"
            >
              <Plus className="h-3.5 w-3.5" />
              واجب
            </ButtonLink>
          </div>

          {lesson.assignments.length === 0 ? (
            <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
              لا توجد واجبات. أنشئ واجبًا من بنك الأسئلة ليعمل عليه الطلاب.
            </p>
          ) : (
            <ul className="space-y-2.5">
              {lesson.assignments.map((a) => (
                <li
                  key={a.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink-200 p-3.5"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-ink-900">{a.title}</p>
                    <p className="text-xs text-ink-500">
                      {a._count.questions} سؤال · {a._count.submissions} تسليم
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="assignment" id={a.id} current={a.status} />
                    <Link
                      href={`/admin/assignments/${a.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="assignment" id={a.id} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-bold text-ink-900">الاختبارات</h2>
            <ButtonLink
              href={`/admin/exams/new?lessonId=${lesson.id}`}
              size="sm"
              variant="soft"
            >
              <Plus className="h-3.5 w-3.5" />
              اختبار
            </ButtonLink>
          </div>

          {lesson.exams.length === 0 ? (
            <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
              لا توجد اختبارات. أنشئ اختبارًا وحدد المدة وعدد المحاولات.
            </p>
          ) : (
            <ul className="space-y-2.5">
              {lesson.exams.map((e) => (
                <li
                  key={e.id}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink-200 p-3.5"
                >
                  <div className="min-w-0">
                    <p className="font-semibold text-ink-900">{e.title}</p>
                    <p className="text-xs text-ink-500">
                      {e._count.questions} سؤال · {e.durationMinutes} دقيقة ·{" "}
                      {e._count.attempts} محاولة
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusSwitcher entity="exam" id={e.id} current={e.status} />
                    <Link
                      href={`/admin/exams/${e.id}/edit`}
                      className="rounded-lg bg-ink-50 px-2.5 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
                    >
                      تعديل
                    </Link>
                    <DeleteButton entity="exam" id={e.id} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* روابط سريعة */}
      <QuickLinks
        items={[
          { href: `/lessons/${lesson.slug}`, label: "معاينة الصفحة العامة للدرس" },
          { href: "/admin/questions", label: "بنك الأسئلة" },
          { href: "/admin/files", label: "كل الملفات" },
          { href: `/admin/units/${lesson.unitId}/edit`, label: "تعديل الوحدة" },
        ]}
      />

      <p className="text-center text-xs text-ink-400">
        آخر تحديث: {formatDate(lesson.updatedAt)}
      </p>
    </div>
  );
}