import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { saveLessonAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { LessonFields } from "@/components/admin/forms/lesson-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "تعديل درس" };

export default async function EditLessonPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const lesson = await prisma.lesson.findUnique({ where: { id } });
  if (!lesson) notFound();

  const units = await prisma.unit.findMany({
    orderBy: [{ course: { order: "asc" } }, { order: "asc" }],
    include: {
      course: { include: { subject: { include: { grade: true } } } },
      _count: { select: { lessons: true } },
    },
  });

  const options = units.map((u) => ({
    value: u.id,
    label: `${u.course.title} — ${u.course.subject.grade.nameAr} › ${u.order + 1}. ${u.title}`,
  }));

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={`تعديل: ${lesson.title}`} backHref={`/admin/lessons/${lesson.id}`} />

      <AdminForm action={saveLessonAction}>
        <input type="hidden" name="id" value={lesson.id} />
        <input type="hidden" name="_checkboxes" value="isFree,isPreview" />
        <LessonFields
          units={options}
          defaults={{
            id: lesson.id,
            slug: lesson.slug,
            title: lesson.title,
            summary: lesson.summary,
            description: lesson.description,
            unitId: lesson.unitId,
            status: lesson.status,
            isFree: lesson.isFree,
            isPreview: lesson.isPreview,
            order: lesson.order,
          }}
        />
      </AdminForm>
    </div>
  );
}