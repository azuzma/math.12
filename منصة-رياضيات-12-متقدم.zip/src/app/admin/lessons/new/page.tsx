import { prisma } from "@/lib/db/prisma";
import { saveLessonAction } from "@/app/actions/admin";
import { AdminForm } from "@/components/admin/ui";
import { LessonFields } from "@/components/admin/forms/lesson-fields";
import { PageHeader } from "@/components/admin/page-header";

export const metadata = { title: "إضافة درس" };

export default async function NewLessonPage({
  searchParams,
}: {
  searchParams: Promise<{ unitId?: string; courseId?: string; grade?: string }>;
}) {
  const { unitId, courseId, grade: gradeSlug } = await searchParams;

  const units = await prisma.unit.findMany({
    where: courseId ? { courseId } : undefined,
    orderBy: [{ course: { order: "asc" } }, { order: "asc" }],
    include: {
      course: { include: { subject: { include: { grade: true } } } },
      _count: { select: { lessons: true } },
    },
  });

  // كل الوحدات مجمّبة حسب المقرر لعرض أوضح
  const grouped = new Map<string, { label: string; items: { value: string; label: string }[] }>();
  for (const u of units) {
    const key = u.courseId;
    if (!grouped.has(key)) {
      grouped.set(key, {
        label: `${u.course.title} — ${u.course.subject.grade.nameAr}`,
        items: [],
      });
    }
    grouped.get(key)!.items.push({
      value: u.id,
      label: `${u.order + 1}. ${u.title} (${u._count.lessons} درس)`,
    });
  }

  const options = [...grouped.values()].flatMap((g) => g.items);
  const maxOrder = units.length
    ? Math.max(...units.map((u) => u._count.lessons)) + 1
    : 1;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader
        title="إضافة درس جديد"
        description="بعد الحفظ ستفتح صفحة الدرس لتضيف الفيديو والملفات والاختبار."
        backHref="/admin/lessons"
      />

      {options.length === 0 ? (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
          لا توجد وحدات متاحة. أضف مقررًا ووحدة أولًا قبل إنشاء الدروس.
        </div>
      ) : null}

      <AdminForm action={saveLessonAction}>
        <input type="hidden" name="_checkboxes" value="isFree,isPreview" />
        <LessonFields units={options} defaults={{ unitId, order: maxOrder }} />
      </AdminForm>
    </div>
  );
}