import { z } from "zod";

/** التحقق من الإيميل */
export const emailSchema = z
  .string()
  .trim()
  .min(5, "البريد الإلكتروني قصير جدًا")
  .max(160, "البريد الإلكتروني طويل جدًا")
  .email("صيغة البريد الإلكتروني غير صحيحة");

/** كلمة المرور: 8 أحرف على الأقل مع رقم وحرف */
export const passwordSchema = z
  .string()
  .min(8, "كلمة المرور يجب أن تكون 8 أحرف على الأقل")
  .max(128, "كلمة المرور طويلة جدًا")
  .regex(/[A-Za-z؀-ۿ]/, "يجب أن تحتوي على حرف واحد على الأقل")
  .regex(/\d/, "يجب أن تحتوي على رقم واحد على الأقل");

export const nameSchema = z
  .string()
  .trim()
  .min(3, "الاسم قصير جدًا")
  .max(80, "الاسم طويل جدًا");

export const phoneSchema = z
  .string()
  .trim()
  .regex(/^(\+971|00971|0)?5[0-9]{8}$/, "رقم هاتف إماراتي غير صحيح (مثال: 0501234567)")
  .optional()
  .or(z.literal(""));

/**
 * تسجيل طالب جديد.
 * المنصة مخصصة لصف واحد (الصف 12 متقدم)، لذلك لا يوجد اختيار للصف —
 * يُسند الطالب تلقائيًا إلى صف المنصة.
 */
export const registerStudentSchema = z.object({
  fullName: nameSchema,
  email: emailSchema,
  password: passwordSchema,
  phone: phoneSchema,
  schoolName: z.string().trim().max(120).optional().or(z.literal("")),
  guardianName: z.string().trim().max(120).optional().or(z.literal("")),
  guardianPhone: phoneSchema,
  terms: z.literal("on", { message: "يجب الموافقة على الشروط والأحكام" }),
});

export type RegisterStudentInput = z.infer<typeof registerStudentSchema>;

/** تسجيل الدخول */
export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "أدخل كلمة المرور"),
});

/** استعادة كلمة المرور */
export const forgotPasswordSchema = z.object({ email: emailSchema });

export const resetPasswordSchema = z
  .object({
    code: z.string().min(4, "رمز التحقق مطلوب"),
    password: passwordSchema,
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, {
    message: "كلمتا المرور غير متطابقتين",
    path: ["confirm"],
  });

/** تحديث الملف الشخصي */
export const profileSchema = z.object({
  fullName: nameSchema,
  phone: phoneSchema,
  gradeId: z.string().optional().or(z.literal("")),
  schoolName: z.string().trim().max(120).optional().or(z.literal("")),
  emirate: z.string().trim().max(60).optional().or(z.literal("")),
  guardianName: z.string().trim().max(120).optional().or(z.literal("")),
  guardianPhone: phoneSchema,
  dailyGoalMinutes: z.coerce.number().int().min(0).max(600).optional(),
});

/* ======================= لوحة التحكم ======================= */

const statusEnum = z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]);
/** حقل checkbox: غير موجود أو فارغ = false */
const boolFromForm = z
  .union([z.boolean(), z.string()])
  .nullish()
  .transform((v) => v === true || v === "on" || v === "true" || v === "1");

const idOptional = z.string().transform((v) => (v ? v : null));

export const gradeSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(40)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  nameAr: nameSchema,
  nameEn: z.string().trim().min(2).max(80),
  stageAr: z.string().trim().min(2).max(80),
  stageSlug: z.string().trim().min(2).max(80),
  order: z.coerce.number().int().min(0).max(999),
  description: z.string().trim().max(600).optional().or(z.literal("")),
});

export const subjectSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(40)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  nameAr: nameSchema,
  nameEn: z.string().trim().min(2).max(80),
  gradeId: z.string().min(1, "اختر الصف"),
  description: z.string().trim().max(600).optional().or(z.literal("")),
  order: z.coerce.number().int().min(0).max(999),
});

export const courseSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(60)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  title: z.string().trim().min(3, "العنوان مطلوب").max(140),
  subtitle: z.string().trim().max(200).optional().or(z.literal("")),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
  subjectId: z.string().min(1, "اختر المادة"),
  status: statusEnum,
  isFree: boolFromForm,
  order: z.coerce.number().int().min(0).max(999),
});

export const unitSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(60)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  title: z.string().trim().min(3).max(140),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  courseId: z.string().min(1, "اختر المادة/المقرر"),
  termId: idOptional,
  status: statusEnum,
  isFree: boolFromForm,
  order: z.coerce.number().int().min(0).max(999),
});

export const lessonSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(80)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  title: z.string().trim().min(3, "عنوان الدرس مطلوب").max(160),
  summary: z.string().trim().max(400).optional().or(z.literal("")),
  description: z.string().trim().max(4000).optional().or(z.literal("")),
  unitId: z.string().min(1, "اختر الوحدة"),
  status: statusEnum,
  isFree: boolFromForm,
  isPreview: boolFromForm,
  order: z.coerce.number().int().min(0).max(9999),
});

export const videoSchema = z.object({
  title: z.string().trim().min(3).max(160),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  lessonId: z.string().min(1, "اختر الدرس"),
  provider: z.enum(["BUNNY", "MUX", "EXTERNAL", "YOUTUBE"]),
  providerId: z.string().trim().max(200).optional().or(z.literal("")),
  playbackId: z.string().trim().max(200).optional().or(z.literal("")),
  durationSec: z.coerce.number().int().min(0).max(86400),
  status: statusEnum,
  isFree: boolFromForm,
  allowSeeking: boolFromForm,
});

export const fileSchema = z.object({
  title: z.string().trim().min(3).max(160),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  kind: z.enum(["SUMMARY", "WORKSHEET", "ASSIGNMENT", "ANSWERS", "OTHER"]),
  lessonId: idOptional,
  unitId: idOptional,
  courseId: idOptional,
  status: statusEnum,
  isFree: boolFromForm,
});

export const questionSchema = z.object({
  type: z.enum(["MCQ", "MULTI_TRUE", "TRUE_FALSE", "SHORT", "NUMERIC", "ESSAY"]),
  text: z.string().trim().min(3, "نص السؤال مطلوب").max(2000),
  options: z.array(z.string().trim().min(1).max(500)).max(8).default([]),
  correct: z.string().trim().max(500).optional().or(z.literal("")),
  solution: z.string().trim().max(3000).optional().or(z.literal("")),
  hint: z.string().trim().max(500).optional().or(z.literal("")),
  points: z.coerce.number().int().min(1).max(100),
  /** 🟢 سهل · 🟡 متوسط · 🔴 صعب · 🔥 تحدي */
  difficulty: z.enum(["EASY", "MEDIUM", "HARD", "CHALLENGE"]).default("MEDIUM"),
  lessonId: idOptional,
  skillId: idOptional,
  termId: idOptional,
  autoGrade: boolFromForm,
  isActive: boolFromForm,
});

export const assignmentSchema = z.object({
  title: z.string().trim().min(3).max(160),
  instructions: z.string().trim().max(3000).optional().or(z.literal("")),
  lessonId: idOptional,
  status: statusEnum,
  isFree: boolFromForm,
  dueAfterDays: z.coerce.number().int().min(0).max(365),
  questionIds: z.array(z.string()).default([]),
});

export const examSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(80)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط")
    .optional()
    .or(z.literal("")),
  title: z.string().trim().min(3).max(160),
  /** نوع الاختبار: درس / وحدة / فصل / شامل / مراجعة / تجريبي */
  type: z
    .enum(["LESSON", "UNIT", "TERM", "COMPREHENSIVE", "REVIEW", "MOCK"])
    .default("LESSON"),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
  instructions: z.string().trim().max(1000).optional().or(z.literal("")),
  lessonId: idOptional,
  unitId: idOptional,
  termId: idOptional,
  courseId: idOptional,
  status: statusEnum,
  isFree: boolFromForm,
  durationMinutes: z.coerce.number().int().min(1).max(300),
  attemptsAllowed: z.coerce.number().int().min(1).max(20),
  passingScore: z.coerce.number().int().min(0).max(100),
  shuffleQuestions: boolFromForm,
  showCorrectAnswers: boolFromForm,
  showSolutions: boolFromForm,
  questionIds: z.array(z.string()).default([]),
});

/** فصل دراسي */
export const termSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(40)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  title: z.string().trim().min(3).max(140),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  courseId: z.string().min(1, "اختر المقرر"),
  status: statusEnum,
  isFree: boolFromForm,
  order: z.coerce.number().int().min(0).max(99),
});

/** مهارة داخل الوحدة */
export const skillSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(40)
    .regex(/^[a-z0-9-]+$/, "المعرّف يقبل أحرفًا إنجليزية صغيرة وأرقامًا فقط"),
  title: z.string().trim().min(3).max(140),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  unitId: z.string().min(1, "اختر الوحدة"),
  status: statusEnum,
  order: z.coerce.number().int().min(0).max(99),
});

/** حصة يومية: عدد صحيح 0..999 — و0 تعني «بلا حد» */
const quotaField = z.preprocess(
  (v) => (v === "" || v === null || v === undefined ? 0 : v),
  z.coerce.number().int().min(0).max(999),
);

export const planSchema = z.object({
  slug: z
    .string()
    .trim()
    .min(1)
    .max(40)
    .regex(/^[a-z0-9-]+$/),
  nameAr: nameSchema,
  nameEn: z.string().trim().min(2).max(80),
  tagline: z.string().trim().max(200).optional().or(z.literal("")),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
  tier: z.enum(["FREE", "BASIC", "PREMIUM"]),
  monthlyPrice: z.coerce.number().int().min(0).max(100000),
  yearlyPrice: z.coerce.number().int().min(0).max(100000),
  currency: z.string().trim().length(3).default("AED"),
  trialDays: z.coerce.number().int().min(0).max(60),
  features: z.array(z.string().trim().min(1).max(200)).max(30).default([]),
  /** ما تشمله الباقة + الحصص اليومية — يحدد ما يراه الطالب وكم مرة */
  limits: z
    .object({
      // مفاتيح المميزات (منطقية)
      files: boolFromForm,
      exams: boolFromForm,
      questions: boolFromForm,
      analysis: boolFromForm,
      studyPlan: boolFromForm,
      tutor: boolFromForm,
      solutions: boolFromForm,
      certificates: boolFromForm,
      // الحصص اليومية (أرقام — 0 يعني بلا حد)
      questionsPerDay: quotaField,
      examsPerDay: quotaField,
      tutorPerDay: quotaField,
    })
    .default({
      files: false,
      exams: false,
      questions: false,
      analysis: false,
      studyPlan: false,
      tutor: false,
      solutions: false,
      certificates: false,
      questionsPerDay: 0,
      examsPerDay: 0,
      tutorPerDay: 0,
    }),
  isActive: boolFromForm,
  isFeatured: boolFromForm,
  sortOrder: z.coerce.number().int().min(0).max(999),
  gradeIds: z.array(z.string()).default([]),
  stripeMonthlyPriceId: z.string().trim().max(200).optional().or(z.literal("")),
  stripeYearlyPriceId: z.string().trim().max(200).optional().or(z.literal("")),
  telrMonthlyClientKey: z.string().trim().max(200).optional().or(z.literal("")),
  telrYearlyClientKey: z.string().trim().max(200).optional().or(z.literal("")),
});

export const announcementSchema = z.object({
  title: z.string().trim().min(3, "عنوان الإعلان مطلوب").max(160),
  body: z.string().trim().min(3, "نص الإعلان مطلوب").max(5000),
  audience: z.enum(["ALL", "STUDENTS", "PAID", "FREE"]),
});

export const studentUpdateSchema = z.object({
  status: z.enum(["ACTIVE", "SUSPENDED", "PENDING"]),
  gradeId: z.string().optional().or(z.literal("")),
  schoolName: z.string().trim().max(120).optional().or(z.literal("")),
  dailyGoalMinutes: z.coerce.number().int().min(0).max(600),
  newPassword: z.string().optional().or(z.literal("")),
});

export const manualSubscriptionSchema = z.object({
  userId: z.string().min(1),
  planId: z.string().min(1),
  billingCycle: z.enum(["monthly", "yearly"]),
  days: z.coerce.number().int().min(1).max(3650),
});

export const siteSettingSchema = z.record(
  z.string(),
  z.union([z.string(), z.number(), z.boolean(), z.null()]),
);

export type {
  RegisterStudentInput as RegisterInput,
  ExamFormInput,
  LessonFormInput,
  PlanFormInput,
};
type ExamFormInput = z.infer<typeof examSchema>;
type LessonFormInput = z.infer<typeof lessonSchema>;
type PlanFormInput = z.infer<typeof planSchema>;