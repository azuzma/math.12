/**
 * استعلامات المحتوى للواجهة العامة ولوحة الطالب.
 * كل الاستعلامات هنا مُحسّنة (select محدود + include انتقائي).
 */

import "server-only";
import { prisma } from "@/lib/db/prisma";

const SUBMITTED_EPOCH = new Date("2000-01-01T00:00:00.000Z");

/* ============ الهيكل الدراسي ============ */

export async function getGrades() {
  return prisma.grade.findMany({
    orderBy: { order: "asc" },
    include: { _count: { select: { subjects: true } } },
  });
}

export async function getGradeBySlug(slug: string) {
  return prisma.grade.findUnique({
    where: { slug },
    include: {
      subjects: {
        orderBy: { order: "asc" },
        include: {
          courses: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            include: { _count: { select: { units: true } } },
          },
        },
      },
    },
  });
}

export async function getSubjectsByGrade(gradeId: string) {
  return prisma.subject.findMany({
    where: { gradeId },
    orderBy: { order: "asc" },
    include: {
      courses: {
        where: { status: "PUBLISHED" },
        orderBy: { order: "asc" },
      },
    },
  });
}

export async function getCourseBySlug(slug: string) {
  return prisma.course.findFirst({
    where: { slug, status: "PUBLISHED" },
    include: {
      subject: { include: { grade: true } },
      units: {
        where: { status: "PUBLISHED" },
        orderBy: { order: "asc" },
        include: {
          lessons: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            include: {
              _count: { select: { videos: true, files: true, exams: true, assignments: true } },
            },
          },
        },
      },
    },
  });
}

export async function getLessonBySlug(slug: string) {
  return prisma.lesson.findFirst({
    where: { slug, status: "PUBLISHED" },
    include: {
      unit: { include: { course: { include: { subject: { include: { grade: true } } } } } },
      videos: { where: { status: "PUBLISHED" }, orderBy: { createdAt: "asc" } },
      files: { where: { status: "PUBLISHED" }, orderBy: { createdAt: "asc" } },
      assignments: {
        where: { status: "PUBLISHED" },
        include: { _count: { select: { questions: true } } },
      },
      exams: {
        where: { status: "PUBLISHED" },
        include: { _count: { select: { questions: true } } },
      },
    },
  });
}

/** الدروس المجانية لعرض أمثلة في الصفحة الرئيسية. */
export async function getFeaturedLessons(limit = 6) {
  return prisma.lesson.findMany({
    where: { status: "PUBLISHED", isFree: true },
    orderBy: { updatedAt: "desc" },
    take: limit,
    include: {
      unit: { include: { course: { include: { subject: { include: { grade: true } } } } } },
      _count: { select: { videos: true, files: true, exams: true } },
    },
  });
}

/** قائمة الدروس مع التصفية والترقيم للصفحة العامة. */
export async function getLessonsForCatalog(opts: {
  gradeId?: string;
  subjectId?: string;
  termSlug?: string;
  unitSlug?: string;
  page?: number;
  perPage?: number;
  freeOnly?: boolean;
}) {
  const page = Math.max(1, opts.page ?? 1);
  const perPage = Math.min(48, opts.perPage ?? 12);

  const where = {
    status: "PUBLISHED" as const,
    ...(opts.freeOnly ? { isFree: true } : {}),
    ...(opts.unitSlug ? { unit: { slug: opts.unitSlug } } : {}),
    ...(opts.gradeId || opts.subjectId || opts.termSlug
      ? {
          unit: {
            course: {
              subject: {
                ...(opts.gradeId ? { gradeId: opts.gradeId } : {}),
                ...(opts.subjectId ? { id: opts.subjectId } : {}),
              },
            },
            ...(opts.termSlug ? { term: { slug: opts.termSlug } } : {}),
          },
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.lesson.findMany({
      where,
      orderBy: [
        { unit: { term: { order: "asc" } } },
        { unit: { order: "asc" } },
        { order: "asc" },
      ],
      skip: (page - 1) * perPage,
      take: perPage,
      include: {
        unit: {
          include: {
            course: { include: { subject: { include: { grade: true } } } },
            term: { select: { id: true, title: true } },
          },
        },
        skill: { select: { id: true, title: true } },
        _count: { select: { videos: true, files: true, exams: true } },
      },
    }),
    prisma.lesson.count({ where }),
  ]);

  return { items, total, page, perPage, pages: Math.ceil(total / perPage) };
}

/** الدروس التالية/السابقة داخل نفس الوحدة (للتنقل بين الدروس). */
export async function getLessonSiblings(lessonId: string) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    select: { unitId: true, order: true },
  });
  if (!lesson) return { prev: null, next: null };

  const [prev, next] = await Promise.all([
    prisma.lesson.findFirst({
      where: { unitId: lesson.unitId, status: "PUBLISHED", order: { lt: lesson.order } },
      orderBy: { order: "desc" },
      select: { slug: true, title: true },
    }),
    prisma.lesson.findFirst({
      where: { unitId: lesson.unitId, status: "PUBLISHED", order: { gt: lesson.order } },
      orderBy: { order: "asc" },
      select: { slug: true, title: true },
    }),
  ]);

  return { prev, next };
}

/* ============ البحث ============ */

export type SearchResultType = "lesson" | "unit" | "exam" | "file";

export type SearchHit = {
  type: SearchResultType;
  title: string;
  description: string;
  href: string;
  breadcrumb: string;
  isFree: boolean;
};

export async function searchContent(
  rawQuery: string,
  limitPerType = 8,
): Promise<{ query: string; total: number; hits: SearchHit[] }> {
  const query = rawQuery.trim();
  if (query.length < 2) return { query, total: 0, hits: [] };

  // تطبيع البحث العربي: توحيد الهمزات والتاء المربوطة والألف المقصورة
  const normalizeAr = (v: string) =>
    v
      .toLowerCase()
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ة/g, "ه")
      .replace(/[ىي]/g, "ي")
      .replace(/ؤ/g, "و")
      .replace(/ئ/g, "ي")
      .replace(/ـ/g, "")
      .trim();

  const nq = normalizeAr(query);
  const variants = [query, nq];
  // إزالة أدوات التعريف الزائدة: "ال" في بداية الكلمة
  if (nq.startsWith("ال") && nq.length > 4) {
    variants.push(nq.slice(2));
    variants.push(query.replace(/^ال/, ""));
  }

  // PostgreSQL: بحث case-insensitive على الحقول النصية بكل الصيغ
  const contains = (field: string) => ({
    OR: variants.map((v) => ({ [field]: { contains: v, mode: "insensitive" as const } })),
  });

  const [lessons, units, exams, files, skills] = await Promise.all([
    prisma.lesson.findMany({
      where: {
        status: "PUBLISHED",
        OR: [...contains("title").OR, ...contains("summary").OR, ...contains("description").OR],
      },
      take: limitPerType,
      include: {
        unit: { include: { course: { include: { subject: { include: { grade: true } } } } } },
      },
    }),
    prisma.unit.findMany({
      where: {
        status: "PUBLISHED",
        OR: [...contains("title").OR, ...contains("description").OR],
      },
      take: limitPerType,
      include: { course: { include: { subject: { include: { grade: true } } } } },
    }),
    prisma.exam.findMany({
      where: { status: "PUBLISHED", OR: [...contains("title").OR, ...contains("description").OR] },
      take: limitPerType,
      include: {
        lesson: { select: { slug: true } },
        unit: { include: { course: { include: { subject: { include: { grade: true } } } } } },
      },
    }),
    prisma.fileAsset.findMany({
      where: { status: "PUBLISHED", OR: [...contains("title").OR, ...contains("description").OR] },
      take: limitPerType,
      include: { lesson: { select: { slug: true } } },
    }),
    prisma.skill.findMany({
      where: {
        status: "PUBLISHED",
        OR: [...contains("title").OR, ...contains("description").OR],
      },
      take: limitPerType,
      include: { unit: { include: { course: true } } },
    }),
  ]);

  const hits: SearchHit[] = [
    ...lessons.map((l) => ({
      type: "lesson" as const,
      title: l.title,
      description: l.summary ?? "",
      href: `/lessons/${l.slug}`,
      breadcrumb: `${l.unit.course.subject.grade.nameAr} · ${l.unit.title}`,
      isFree: l.isFree,
    })),
    ...units.map((u) => ({
      type: "unit" as const,
      title: u.title,
      description: u.description ?? "",
      href: `/courses/${u.course.slug}#unit-${u.id}`,
      breadcrumb: `${u.course.subject.grade.nameAr} · ${u.course.title}`,
      isFree: u.isFree,
    })),
    ...exams.map((e) => ({
      type: "exam" as const,
      title: e.title,
      description: e.description ?? "",
      href: `/dashboard/exams/${e.id}`,
      breadcrumb: e.unit ? `اختبار · ${e.unit.title}` : "اختبار",
      isFree: e.isFree,
    })),
    ...files.map((f) => ({
      type: "file" as const,
      title: f.title,
      description: f.description ?? "",
      href: f.lessonId
        ? `/dashboard/lessons/${f.lesson?.slug ?? ""}#files`
        : "/dashboard/worksheets",
      breadcrumb: "ملف تعليمي",
      isFree: f.isFree,
    })),
    ...skills.map((s) => ({
      type: "unit" as const,
      title: s.title,
      description: s.description ?? "",
      href: `/dashboard/question-bank?skill=${s.id}`,
      breadcrumb: `مهارة · ${s.unit.title}`,
      isFree: false,
    })),
  ];

  return { query, total: hits.length, hits };
}

/* ============ الاشتراكات ============ */

export async function getActivePlans() {
  return prisma.plan.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: "asc" },
    include: { grades: { include: { grade: true } } },
  });
}

export async function getPlanBySlug(slug: string) {
  return prisma.plan.findFirst({ where: { slug, isActive: true } });
}

/* ============ إحصائيات لوحة الإدارة ============ */

export async function getAdminStats() {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const [
    totalStudents,
    activeStudents,
    suspended,
    totalLessons,
    publishedLessons,
    totalQuestions,
    totalExams,
    totalFiles,
    activeSubs,
    revenueAgg,
    revenueMonthAgg,
    lastPayments,
    attemptsAgg,
  ] = await Promise.all([
    prisma.user.count({ where: { role: "STUDENT" } }),
    prisma.user.count({ where: { role: "STUDENT", status: "ACTIVE" } }),
    prisma.user.count({ where: { role: "STUDENT", status: "SUSPENDED" } }),
    prisma.lesson.count(),
    prisma.lesson.count({ where: { status: "PUBLISHED" } }),
    prisma.question.count(),
    prisma.exam.count(),
    prisma.fileAsset.count(),
    prisma.subscription.count({
      where: { status: { in: ["ACTIVE", "TRIAL"] }, currentPeriodEnd: { gt: now } },
    }),
    prisma.payment.aggregate({
      where: { status: "SUCCEEDED" },
      _sum: { amount: true },
      _count: true,
    }),
    prisma.payment.aggregate({
      where: { status: "SUCCEEDED", paidAt: { gte: monthStart } },
      _sum: { amount: true },
      _count: true,
    }),
    prisma.payment.findMany({
      where: { status: "SUCCEEDED" },
      orderBy: { paidAt: "desc" },
      take: 6,
      include: { user: { select: { fullName: true, email: true } }, plan: true },
    }),
    prisma.examAttempt.aggregate({
      where: { submittedAt: { gte: SUBMITTED_EPOCH } },
      _avg: { percentage: true },
      _count: true,
    }),
  ]);

  // استعلام خام للإيراد الشهري — نجعله آمنًا حتى لا تُسقط الصفحة كلّها
  const revenueByMonth = await prisma
    .$queryRaw<{ month: string; total: number }[]>`
      SELECT to_char(date_trunc('month', "paidAt"), 'YYYY-MM') AS month,
             SUM(amount)::int AS total
      FROM payments
      WHERE status = 'SUCCEEDED' AND "paidAt" IS NOT NULL
      GROUP BY 1
      ORDER BY 1 DESC
      LIMIT 12
    `
    .catch(() => [] as { month: string; total: number }[]);

  return {
    students: { total: totalStudents, active: activeStudents, suspended },
    content: {
      lessons: totalLessons,
      published: publishedLessons,
      questions: totalQuestions,
      exams: totalExams,
      files: totalFiles,
    },
    subscriptions: { active: activeSubs },
    revenue: {
      total: revenueAgg._sum.amount ?? 0,
      count: revenueAgg._count,
      month: revenueMonthAgg._sum.amount ?? 0,
      monthCount: revenueMonthAgg._count,
      byMonth: revenueByMonth.reverse(),
    },
    exams: {
      attempts: attemptsAgg._count,
      averagePercentage: Math.round(attemptsAgg._avg.percentage ?? 0),
    },
    lastPayments,
  };
}

/** إحصائيات لوحة الطالب. */
export async function getStudentStats(studentId: string) {
  const gradeId = (
    await prisma.studentProfile.findUnique({
      where: { userId: studentId },
      select: { gradeId: true },
    })
  )?.gradeId;

  if (!gradeId) {
    return {
      totalLessons: 0,
      completedLessons: 0,
      progressPercent: 0,
      watchedMinutes: 0,
      examsTaken: 0,
      averageScore: 0,
      filesDownloaded: 0,
    };
  }

  const totalLessons = await prisma.lesson.count({
    where: { status: "PUBLISHED", unit: { course: { subject: { gradeId } } } },
  });

  const progress = await prisma.lessonProgress.findMany({
    where: { studentId, completed: true },
    select: { lessonId: true, lesson: { select: { durationSec: true } } },
  });

  const completedLessons = progress.length;

  const attempts = await prisma.examAttempt.findMany({
    where: { studentId, submittedAt: { gte: SUBMITTED_EPOCH } },
    select: { percentage: true, passed: true },
  });

  // إجمالي مرات تنزيل الملفات من قِبل الطالب (بدون تتبع تفصيلي لكل ملف)
  const downloadRecords = await prisma.auditLog.findMany({
    where: { userId: studentId, action: "file_download" },
    select: { id: true },
  });

  return {
    totalLessons,
    completedLessons,
    progressPercent: totalLessons ? Math.round((completedLessons / totalLessons) * 100) : 0,
    watchedMinutes: 0,
    examsTaken: attempts.length,
    averageScore: attempts.length
      ? Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)
      : 0,
    filesDownloaded: downloadRecords.length,
  };
}