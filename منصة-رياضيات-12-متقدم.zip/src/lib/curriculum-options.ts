import "server-only";
import { prisma } from "@/lib/db/prisma";

/**
 * خيارات معرّفات المنهج لاستمارات لوحة الإدارة:
 * الفصول ← المهارات ← الدروس، كلها لمقرّر الصف 12 متقدم.
 */
export type CurriculumOptions = {
  termOptions: { value: string; label: string }[];
  skillOptions: { value: string; label: string; unitId: string }[];
  lessonOptions: { value: string; label: string }[];
  unitOptions: { value: string; label: string }[];
};

export async function loadCurriculumOptions(): Promise<CurriculumOptions> {
  const [terms, units, skills, lessons] = await Promise.all([
    prisma.term.findMany({
      orderBy: { order: "asc" },
      select: { id: true, title: true },
    }),
    prisma.unit.findMany({
      orderBy: { order: "asc" },
      select: { id: true, title: true },
    }),
    prisma.skill.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      select: {
        id: true,
        title: true,
        unitId: true,
        unit: { select: { title: true } },
      },
    }),
    prisma.lesson.findMany({
      orderBy: [{ unit: { order: "asc" } }, { order: "asc" }],
      select: {
        id: true,
        title: true,
        unit: { select: { title: true, term: { select: { title: true } } } },
      },
    }),
  ]);

  return {
    termOptions: terms.map((t) => ({ value: t.id, label: t.title })),
    unitOptions: units.map((u) => ({ value: u.id, label: u.title })),
    skillOptions: skills.map((s) => ({
      value: s.id,
      label: `${s.unit.title} › ${s.title}`,
      unitId: s.unitId,
    })),
    lessonOptions: lessons.map((l) => ({
      value: l.id,
      label: `${l.unit.term?.title ?? ""} › ${l.unit.title} › ${l.title}`.replace(
        /^ › /,
        "",
      ),
    })),
  };
}