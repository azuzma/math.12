/**
 * ثوابت المنصة — خاصة برياضيات الصف 12 متقدم.
 * المنصة مخصصة لصف واحد فقط؛ أي تغيير هنا ينعكس على كل الواجهات.
 */

export const PLATFORM = {
  /** معرّف الصف الوحيد */
  gradeSlug: "grade-12-advanced",
  /** اسم الصف كما يظهر للطالب */
  gradeNameAr: "الصف الثاني عشر متقدم",
  /** الاسم المختصر للواجهات الضيقة */
  gradeShort: "الصف 12 متقدم",
  /** اسم المادة */
  subjectNameAr: "الرياضيات",
  /** معرّف المقرر */
  courseSlug: "math-grade-12-advanced",
  /** الجملة التعريفية */
  tagline: "كل ما تحتاجه لإتقان رياضيات الصف 12 متقدم في مكان واحد",
  /** نص قصير للوصف */
  shortDesc:
    "دروس فيديو، ملخصات، أوراق عمل، بنك أسئلة، واختبارات بتصحيح فوري — كلها لمنهج رياضيات الصف الثاني عشر المتقدم.",
} as const;

export type DifficultyMeta = {
  value: "EASY" | "MEDIUM" | "HARD" | "CHALLENGE";
  label: string;
  emoji: string;
  color: string;
  dot: string;
};

export const DIFFICULTY_LEVELS: DifficultyMeta[] = [
  {
    value: "EASY",
    label: "سهل",
    emoji: "🟢",
    color: "text-emerald-700",
    dot: "bg-emerald-500",
  },
  {
    value: "MEDIUM",
    label: "متوسط",
    emoji: "🟡",
    color: "text-amber-700",
    dot: "bg-amber-500",
  },
  {
    value: "HARD",
    label: "صعب",
    emoji: "🔴",
    color: "text-rose-700",
    dot: "bg-rose-500",
  },
  {
    value: "CHALLENGE",
    label: "تحدي",
    emoji: "🔥",
    color: "text-gold-600",
    dot: "bg-gold-500",
  },
];

export const DIFFICULTY_MAP = Object.fromEntries(
  DIFFICULTY_LEVELS.map((d) => [d.value, d]),
) as Record<DifficultyMeta["value"], DifficultyMeta>;

export type ExamTypeMeta = {
  value:
    | "LESSON"
    | "UNIT"
    | "TERM"
    | "COMPREHENSIVE"
    | "REVIEW"
    | "MOCK";
  label: string;
  short: string;
  icon: string;
};

export const EXAM_TYPES: ExamTypeMeta[] = [
  { value: "LESSON", label: "اختبار درس", short: "درس", icon: "📘" },
  { value: "UNIT", label: "اختبار وحدة", short: "وحدة", icon: "📗" },
  { value: "TERM", label: "اختبار فصل دراسي", short: "فصل", icon: "📕" },
  { value: "COMPREHENSIVE", label: "اختبار شامل", short: "شامل", icon: "📙" },
  { value: "REVIEW", label: "اختبار مراجعة", short: "مراجعة", icon: "🔁" },
  { value: "MOCK", label: "اختبار تجريبي", short: "تجريبي", icon: "🎯" },
];

export const EXAM_TYPE_MAP = Object.fromEntries(
  EXAM_TYPES.map((t) => [t.value, t]),
) as Record<ExamTypeMeta["value"], ExamTypeMeta>;

export type QuestionTypeLabel = Record<string, string>;