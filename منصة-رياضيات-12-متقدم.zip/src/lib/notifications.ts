import "server-only";
import { prisma } from "@/lib/db/prisma";
import type { NotificationType } from "@/generated/prisma/client";

export type NotifyInput = {
  userId: string;
  type?: NotificationType;
  title: string;
  body?: string | null;
  link?: string | null;
  image?: string | null;
};

/** إنشاء إشعار داخل المنصة للطالب. */
export async function notify(input: NotifyInput) {
  return prisma.notification.create({
    data: {
      userId: input.userId,
      type: input.type ?? "INFO",
      title: input.title,
      body: input.body ?? null,
      link: input.link ?? null,
      image: input.image ?? null,
    },
  });
}

export type BroadcastAudience = "ALL" | "STUDENTS" | "PAID" | "FREE";

/**
 * إعلان عام من الأستاذ.
 * يُنشئ إشعارًا لكل مستخدم مطابق (بدون تحميل كل الصفحات دفعة واحدة).
 */
export async function broadcast(input: {
  title: string;
  body: string;
  audience: BroadcastAudience;
  link?: string | null;
}): Promise<number> {
  const now = new Date();

  const paidUserIds = (
    await prisma.subscription.findMany({
      where: {
        status: { in: ["ACTIVE", "TRIAL"] },
        currentPeriodEnd: { gt: now },
      },
      select: { userId: true },
      distinct: ["userId"],
    })
  ).map((s) => s.userId);

  const paidSet = new Set(paidUserIds);

  const users = await prisma.user.findMany({
    where: { status: "ACTIVE", role: "STUDENT" },
    select: { id: true },
  });

  const targets = users.filter((u) => {
    if (input.audience === "PAID") return paidSet.has(u.id);
    if (input.audience === "FREE") return !paidSet.has(u.id);
    return true;
  });

  if (targets.length === 0) return 0;

  // دفعات لتفادي تجاوز حد معاملات قاعدة البيانات
  const BATCH = 200;
  for (let i = 0; i < targets.length; i += BATCH) {
    const chunk = targets.slice(i, i + BATCH);
    await prisma.notification.createMany({
      data: chunk.map((u) => ({
        userId: u.id,
        type: "ANNOUNCEMENT" as NotificationType,
        title: input.title,
        body: input.body,
        link: input.link ?? null,
      })),
    });
  }
  return targets.length;
}

/** إشعار جماعي بالنشر: كل الطلاب (المشتركون وغيرهم). */
export async function notifyNewLesson(lessonId: string, lessonTitle: string) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    include: {
      unit: {
        include: { course: { include: { subject: { include: { grade: true } } } } },
      },
    },
  });
  if (!lesson || lesson.status !== "PUBLISHED") return 0;

  const gradeId = lesson.unit.course.subject.gradeId;
  const grade = lesson.unit.course.subject.grade;

  const users = await prisma.user.findMany({
    where: {
      status: "ACTIVE",
      role: "STUDENT",
      studentProfile: { gradeId },
    },
    select: { id: true },
  });

  if (users.length === 0) return 0;

  const BATCH = 200;
  for (let i = 0; i < users.length; i += BATCH) {
    const chunk = users.slice(i, i + BATCH);
    await prisma.notification.createMany({
      data: chunk.map((u) => ({
        userId: u.id,
        type: "NEW_LESSON" as NotificationType,
        title: `درس جديد في ${grade.nameAr}`,
        body: `تم نشر درس «${lessonTitle}» في ${lesson.unit.title}.`,
        link: `/dashboard/lessons/${lesson.slug}`,
      })),
    });
  }
  return users.length;
}

/** إشعار بالنتيجة مباشرة بعد الاختبار. */
export async function notifyExamResult(input: {
  userId: string;
  examTitle: string;
  percentage: number;
  passed: boolean;
  link: string;
}) {
  await notify({
    userId: input.userId,
    type: "EXAM_RESULT",
    title: input.passed ? "نتيجة اختبار: ناجح 🎯" : "نتيجة اختبار: تحتاج مراجعة",
    body: `${input.examTitle} — حصلت على ${input.percentage}% ${
      input.passed ? "وهذا نجاح، أحسنت!" : "تحتاج إلى مراجعة المادة."
    }`,
    link: input.link,
  });
}