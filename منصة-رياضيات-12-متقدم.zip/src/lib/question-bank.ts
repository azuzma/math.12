import "server-only";
import { prisma } from "@/lib/db/prisma";
import { PLATFORM, type DifficultyMeta } from "@/lib/platform";
import type { DifficultyLevel } from "@/generated/prisma/client";
import { normalizeOptions } from "@/lib/question-options";

export type BankQuestion = {
  id: string;
  type: string;
  text: string;
  options: { id: string; text: string }[];
  points: number;
  difficulty: DifficultyLevel;
  hint: string | null;
  skillId: string | null;
  skillTitle: string | null;
  lessonTitle: string | null;
  unitTitle: string | null;
  termId: string | null;
  termTitle: string | null;
};

export type BankFilters = {
  termId?: string;
  unitId?: string;
  skillId?: string;
  difficulty?: DifficultyLevel;
  q?: string;
};

/** قائمة بنك الأسئلة مع الفلاتر، دون كشف الإجابات. */
export async function listBankQuestions(
  filters: BankFilters,
): Promise<BankQuestion[]> {
  const rows = await prisma.question.findMany({
    where: {
      isActive: true,
      ...(filters.termId ? { termId: filters.termId } : {}),
      ...(filters.skillId ? { skillId: filters.skillId } : {}),
      ...(filters.difficulty ? { difficulty: filters.difficulty } : {}),
      ...(filters.q
        ? { text: { contains: filters.q, mode: "insensitive" as const } }
        : {}),
      ...(filters.unitId
        ? {
            OR: [
              { lesson: { unitId: filters.unitId } },
              { skill: { unitId: filters.unitId } },
            ],
          }
        : {}),
    },
    orderBy: [{ createdAt: "desc" }],
    take: 200,
    select: {
      id: true,
      type: true,
      text: true,
      options: true,
      points: true,
      difficulty: true,
      hint: true,
      skillId: true,
      termId: true,
      skill: { select: { title: true } },
      term: { select: { title: true } },
      lesson: {
        select: {
          title: true,
          unit: {
            select: {
              title: true,
              term: { select: { id: true, title: true } },
            },
          },
        },
      },
    },
  });

  return rows.map((r) => ({
    id: r.id,
    type: r.type,
    text: r.text,
    options: normalizeOptions(r.type, r.options),
    points: r.points,
    difficulty: r.difficulty,
    hint: r.hint,
    skillId: r.skillId,
    skillTitle: r.skill?.title ?? null,
    lessonTitle: r.lesson?.title ?? null,
    unitTitle: r.lesson?.unit.title ?? null,
    termId: r.termId ?? r.lesson?.unit.term?.id ?? null,
    termTitle: r.term?.title ?? r.lesson?.unit.term?.title ?? null,
  }));
}

/** خيارات التصفية: الفصول، الوحدات، المهارات. */
export async function getBankFilterOptions() {
  const course = await prisma.course.findFirst({
    where: { slug: PLATFORM.courseSlug },
    select: { id: true },
  });
  if (!course) return { terms: [], units: [], skills: [] };

  const terms = await prisma.term.findMany({
    where: { courseId: course.id, status: "PUBLISHED" },
    orderBy: { order: "asc" },
    select: {
      id: true,
      title: true,
      units: {
        where: { status: "PUBLISHED" },
        orderBy: { order: "asc" },
        select: {
          id: true,
          title: true,
          skills: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            select: { id: true, title: true },
          },
        },
      },
    },
  });

  return {
    terms: terms.map((t) => ({ id: t.id, title: t.title })),
    units: terms.flatMap((t) =>
      t.units.map((u) => ({ id: u.id, title: u.title, termId: t.id })),
    ),
    skills: terms.flatMap((t) =>
      t.units.flatMap((u) =>
        u.skills.map((s) => ({
          id: s.id,
          title: s.title,
          unitId: u.id,
          termId: t.id,
        })),
      ),
    ),
  };
}

/** أرقام بنك الأسئلة لكل مستوى صعوبة (لعرضها في الفلترة). */
export async function getDifficultyCounts() {
  const rows = await prisma.question.groupBy({
    by: ["difficulty"],
    where: { isActive: true },
    _count: { difficulty: true },
  });
  const map = new Map<DifficultyLevel, number>();
  for (const r of rows) map.set(r.difficulty, r._count.difficulty);
  return map;
}