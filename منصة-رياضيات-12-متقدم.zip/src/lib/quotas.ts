import "server-only";
import { prisma } from "@/lib/db/prisma";
import type { PlanTier } from "@/generated/prisma/client";

/**
 * الحصص اليومية — يتحكم بها الأستاذ من لوحة الإدارة ← الباقات والأسعار.
 *
 * كل قيمة رقمية في `Plan.limits`:`0` يعني «بلا حد».
 * تُطبَّق على الخادم فقط — لا يمكن تجاوزها من المتصفح.
 */

export type QuotaKey = "questionsPerDay" | "examsPerDay" | "tutorPerDay";

export const QUOTA_META: {
  key: QuotaKey;
  label: string;
  unit: string;
  hint: string;
}[] = [
  {
    key: "questionsPerDay",
    label: "حصص بنك الأسئلة",
    unit: "سؤال/يوم",
    hint: "عدد أسئلة التدريب المسموح بها يوميًا. 0 = بلا حد.",
  },
  {
    key: "examsPerDay",
    label: "محاولات الاختبارات",
    unit: "محاولة/يوم",
    hint: "عدد الاختبارات التي يبدأها الطالب يوميًا. 0 = بلا حد.",
  },
  {
    key: "tutorPerDay",
    label: "أسئلة مساعد الرياضيات",
    unit: "سؤال/يوم",
    hint: "عدد أسئلة المساعد المسموح بها يوميًا. 0 = بلا حد.",
  },
];

export type QuotaState = {
  key: QuotaKey;
  label: string;
  unit: string;
  /** الحد اليومي (0 = بلا حد) */
  limit: number;
  /** ما استهلكه الطالب اليوم */
  used: number;
  /** المتبقي — null يعني بلا حد */
  remaining: number | null;
  allowed: boolean;
  message: string | null;
};

const DAY_MS = 86_400_000;

/** بداية اليوم UTC — نستخدم يومًا واحدًا ثابتًا لكل الجميع */
function startOfToday(): Date {
  const now = new Date();
  return new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()),
  );
}

function limitsOf(plan: { limits: unknown } | null): Record<string, unknown> {
  if (plan?.limits && typeof plan.limits === "object" && !Array.isArray(plan.limits)) {
    return plan.limits as Record<string, unknown>;
  }
  return {};
}

function num(value: unknown, fallback: number): number {
  if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, Math.floor(value));
  if (typeof value === "string" && value.trim() !== "") {
    const n = Number(value);
    if (Number.isFinite(n)) return Math.max(0, Math.floor(n));
  }
  return fallback;
}

/** الحد الافتراضي حسب الباقة عند غياب المفتاح */
function defaultQuota(tier: PlanTier, key: QuotaKey): number {
  if (tier === "FREE") {
    return key === "questionsPerDay" ? 0 : 0;
  }
  if (tier === "BASIC") {
    if (key === "questionsPerDay") return 30;
    if (key === "examsPerDay") return 10;
    return 0;
  }
  return 0; // PREMIUM — بلا حد افتراضيًا
}

type PlanRow = { tier: PlanTier; limits: unknown };

async function activePlanFor(userId: string): Promise<PlanRow | null> {
  const sub = await prisma.subscription.findFirst({
    where: {
      userId,
      status: { in: ["ACTIVE", "TRIAL"] },
      currentPeriodEnd: { gt: new Date() },
    },
    orderBy: { currentPeriodEnd: "desc" },
    select: { plan: { select: { tier: true, limits: true } } },
  });
  return sub?.plan ?? null;
}

/** عدد ما استهلكه الطالب اليوم من كل نوع. */
async function usedToday(userId: string) {
  const since = startOfToday();
  const [questions, exams, tutor] = await Promise.all([
    prisma.practiceSession.count({
      where: { studentId: userId, submittedAt: { gte: since } },
    }),
    prisma.examAttempt.count({
      where: {
        studentId: userId,
        startedAt: { gte: since },
      },
    }),
    prisma.tutorMessage.count({
      where: {
        role: "USER",
        conversation: { studentId: userId },
        createdAt: { gte: since },
      },
    }),
  ]);
  return { questionsPerDay: questions, examsPerDay: exams, tutorPerDay: tutor } as Record<
    QuotaKey,
    number
  >;
}

/** حالة كل الحصص لطالب — تُعرض في صفحة الاشتراك وفي المساعد. */
export async function getQuotas(userId: string): Promise<QuotaState[]> {
  const [plan, used] = await Promise.all([activePlanFor(userId), usedToday(userId)]);

  if (!plan) {
    // باقة مجانية: كل الحصص مغلقة ما لم تتيحها الباقة
    return QUOTA_META.map((m) => ({
      key: m.key,
      label: m.label,
      unit: m.unit,
      limit: 0,
      used: used[m.key],
      remaining: 0,
      allowed: false,
      message: "هذه الميزة غير متاحة في الباقة المجانية.",
    }));
  }

  const limits = limitsOf(plan);

  return QUOTA_META.map((m) => {
    const limit = num(limits[m.key], defaultQuota(plan.tier, m.key));
    const usedCount = used[m.key];

    if (limit <= 0) {
      return {
        key: m.key,
        label: m.label,
        unit: m.unit,
        limit: 0,
        used: usedCount,
        remaining: null,
        allowed: true,
        message: null,
      };
    }

    const remaining = Math.max(0, limit - usedCount);
    const allowed = remaining > 0;
    return {
      key: m.key,
      label: m.label,
      unit: m.unit,
      limit,
      used: usedCount,
      remaining,
      allowed,
      message: allowed
        ? `متبقٍ لك ${remaining} من ${limit} ${m.unit.split("/")[0]} اليوم.`
        : `استهلكت حصتك اليومية (${limit} ${m.unit.split("/")[0]}). تتجدد الحصة غدًا.`,
    };
  });
}

/**
 * يفحص حصة واحدة قبل السماح بالعملية.
 * يعيد `{ allowed: true }` أو `{ allowed: false, message, state }`.
 */
export async function checkQuota(
  userId: string,
  key: QuotaKey,
): Promise<{ allowed: true } | { allowed: false; message: string; state: QuotaState }> {
  const state = (await getQuotas(userId)).find((q) => q.key === key);
  if (!state) return { allowed: true };
  if (state.allowed) return { allowed: true };
  return {
    allowed: false,
    message: state.message ?? "استهلكت حصتك اليومية. تتجدد غدًا.",
    state,
  };
}

/** رموز HTTP حسب نوع الحصة + عقدayload جاهز للواجهة */
export const QUOTA_HTTP_STATUS = {
  questionsPerDay: 429,
  examsPerDay: 429,
  tutorPerDay: 429,
} as const;