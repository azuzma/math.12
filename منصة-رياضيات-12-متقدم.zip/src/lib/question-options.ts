/**
 * توحيد خيارات السؤال قبل العرض.
 *
 * سؤال «صح / خطأ» قد يكون محفوظًا بلا خيارات (بيانات قديمة أو من التهيئة).
 * في هذه الحالة نولّد الخيارين بمعرّفات ثابتة حتى يعمل التصحيح على الخادم
 * بشكل صحيح:  a = صح ، b = خطأ.
 */

export type QuestionOption = { id: string; text: string };

export const TRUE_FALSE_OPTIONS: QuestionOption[] = [
  { id: "a", text: "صح" },
  { id: "b", text: "خطأ" },
];

/** يتحقق أن الخيارات صالحة للاستخدام */
function isUsable(
  options: unknown,
): options is QuestionOption[] {
  return (
    Array.isArray(options) &&
    options.length > 0 &&
    options.every(
      (o) =>
        o && typeof o === "object" && "id" in o && "text" in o,
    )
  );
}

export function normalizeOptions(
  type: string,
  options: unknown,
): QuestionOption[] {
  if (isUsable(options)) return options;

  if (type === "TRUE_FALSE") {
    // نحاول مطابقة الإجابة الصحيحة المحفوظة كنص مع الخيارين
    return TRUE_FALSE_OPTIONS;
  }

  return [];
}

/**
 * يعيد قيمة الإجابة الصحيحة بصيغة المعرّفات (a/b/...).
 * Transform الإجابات النصية القديمة (مثل «صح») إلى المعرّف المناسب.
 */
export function normalizeCorrect(
  type: string,
  correct: unknown,
  options: unknown,
): unknown {
  const opts = normalizeOptions(type, options);

  if (correct === null || correct === undefined) return correct;

  if (Array.isArray(correct)) {
    return correct.map((c) => matchOption(opts, c));
  }

  return matchOption(opts, correct);
}

function matchOption(opts: QuestionOption[], value: unknown): string {
  const v = String(value).trim();
  const byId = opts.find((o) => o.id === v);
  if (byId) return byId.id;
  const byText = opts.find((o) => o.text.trim() === v);
  return byText ? byText.id : v;
}