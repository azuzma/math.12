import { z } from "zod";

export type FormState = {
  ok: boolean;
  message?: string;
  errors?: Record<string, string[]>;
  redirectTo?: string;
};

/** الحالة الابتدائية لنماذج useActionState. */
export const emptyState: FormState = { ok: false };

/**
 * تحويل FormData إلى كائن عادي للتحقق عبر zod.
 *
 * - مفاتيح checkbox غير المحدّدة لا تظهر في FormData، لذلك نمرّر قائمة
 *   المفاتيح المتوقعة في `_checkboxes` ونضع false لكل مفقود.
 * - المفاتيح المنقوطة مثل `limits.files` تُوسَّع إلى كائن متداخل
 *   `{ limits: { files: ... } }` — بدونها كانت حدود الباقة تُحفظ دائمًا
 *   على أنها القيم الافتراضية (مغلقة كلها).
 */
export function formToObject(
  formData: FormData,
): Record<string, unknown> {
  const out: Record<string, unknown> = {};

  /** يكتب قيمة داخل كائن متداخل حسب مسار النقاط */
  const setDeep = (path: string, value: unknown) => {
    const parts = path.split(".");
    let node = out;
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i]!;
      const next = node[part];
      if (!next || typeof next !== "object" || Array.isArray(next)) {
        node[part] = {};
      }
      node = node[part] as Record<string, unknown>;
    }
    node[parts[parts.length - 1]!] = value;
  };

  const hasPath = (path: string): boolean => {
    const parts = path.split(".");
    let node: unknown = out;
    for (const part of parts) {
      if (!node || typeof node !== "object" || !(part in (node as object))) {
        return false;
      }
      node = (node as Record<string, unknown>)[part];
    }
    return true;
  };

  for (const [key, value] of formData.entries()) {
    if (key.startsWith("_")) continue;
    if (key.endsWith("[]")) {
      const name = key.slice(0, -2);
      const arr = Array.isArray(out[name]) ? (out[name] as unknown[]) : [];
      arr.push(value);
      out[name] = arr;
      continue;
    }
    setDeep(key, value);
  }

  const declared = (formData.get("_checkboxes") ?? "")
    .toString()
    .split(",")
    .filter(Boolean);
  for (const key of declared) {
    if (!hasPath(key)) setDeep(key, false);
  }
  return out;
}

/** التحقق من نموذج وإرجاع أخطاء الحقول. */
export function validate<T extends z.ZodType>(
  schema: T,
  data: unknown,
): { ok: true; data: z.output<T> } | { ok: false; errors: Record<string, string[]> } {
  const result = schema.safeParse(data);
  if (result.success) return { ok: true, data: result.data };

  const errors: Record<string, string[]> = {};
  for (const issue of result.error.issues) {
    const key = String(issue.path[0] ?? "form");
    (errors[key] ??= []).push(issue.message);
  }
  return { ok: false, errors };
}

/** تجميع كل الأخطاء في رسالة واحدة. */
export function firstError(errors?: Record<string, string[]>): string | undefined {
  if (!errors) return undefined;
  for (const msgs of Object.values(errors)) {
    if (msgs[0]) return msgs[0];
  }
  return undefined;
}