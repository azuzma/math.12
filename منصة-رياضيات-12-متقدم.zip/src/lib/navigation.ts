import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  BookOpen,
  ClipboardCheck,
  FileText,
  CreditCard,
  Bell,
  User,
  Trophy,
  Wallet,
  Users,
  Layers,
  Video,
  School,
  Brain,
  ClipboardList,
  Target,
  MessagesSquare,
  Gauge,
  BadgePercent,
  Megaphone,
  Settings,
  GraduationCap,
  PlayCircle,
} from "lucide-react";

/**
 * عناصر التنقل تُعرَّف بالاسم (وليس بالمكوّن نفسه) لأن القائمة تُمرَّر
 * من مكوّن الخادم إلى مكوّن العميل.
 */
export type NavIconName = keyof typeof NAV_ICONS;

export const NAV_ICONS = {
  dashboard: LayoutDashboard,
  book: BookOpen,
  exam: ClipboardCheck,
  file: FileText,
  creditCard: CreditCard,
  bell: Bell,
  user: User,
  settings: Settings,
  trophy: Trophy,
  wallet: Wallet,
  users: Users,
  layers: Layers,
  video: Video,
  school: School,
  brain: Brain,
  plan: ClipboardList,
  target: Target,
  tutor: MessagesSquare,
  gauge: Gauge,
  price: BadgePercent,
  megaphone: Megaphone,
  graduate: GraduationCap,
  play: PlayCircle,
  clipboard: ClipboardList,
} satisfies Record<string, LucideIcon>;

export function navIcon(name: NavIconName): LucideIcon {
  return NAV_ICONS[name];
}

export type NavItemDef = {
  href: string;
  label: string;
  icon: NavIconName;
  badge?: number;
  /** نص قصير يظهر عند تفعيل العناصر المهمة */
  hint?: string;
};

export type NavGroup = {
  /** عنوان المجموعة */
  title: string;
  items: NavItemDef[];
};

/**
 * قائمة الطالب — مصممة حول مسار التعلم:
 * شرح ← تدريب ← اختبار → تحليل ← مراجعة ← إتقان
 */
export function studentNav(unread: number): NavGroup[] {
  return [
    {
      title: "ابدأ من هنا",
      items: [
        { href: "/dashboard", label: "الرئيسية", icon: "dashboard" },
        { href: "/dashboard/lessons", label: "دروسي", icon: "book" },
      ],
    },
    {
      title: "التدريب",
      items: [
        {
          href: "/dashboard/question-bank",
          label: "بنك الأسئلة",
          icon: "brain",
          hint: "تدريب مباشر بالمهارات",
        },
        {
          href: "/dashboard/worksheets",
          label: "أوراق العمل",
          icon: "file",
          hint: "تمارين للطباعة",
        },
        { href: "/dashboard/assignments", label: "الواجبات", icon: "clipboard" },
        { href: "/dashboard/exams", label: "الاختبارات", icon: "exam" },
      ],
    },
    {
      title: "تابع تقدّمك",
      items: [
        {
          href: "/dashboard/analysis",
          label: "مستواي",
          icon: "target",
          hint: "تحليل وتوصيات",
        },
        {
          href: "/dashboard/study-plan",
          label: "خطة الدراسة",
          icon: "plan",
          hint: "خطة أسبوعية",
        },
        { href: "/dashboard/results", label: "نتائجي", icon: "trophy" },
        { href: "/dashboard/progress", label: "تقدّمي", icon: "gauge" },
      ],
    },
    {
      title: "مساعدة",
      items: [
        {
          href: "/dashboard/tutor",
          label: "مساعد الرياضيات",
          icon: "tutor",
          hint: "شرح خطوة بخطوة",
        },
      ],
    },
    {
      title: "حسابي",
      items: [
        { href: "/dashboard/subscription", label: "الاشتراك", icon: "creditCard" },
        { href: "/dashboard/payments", label: "المدفوعات", icon: "wallet" },
        {
          href: "/dashboard/notifications",
          label: "الإشعارات",
          icon: "bell",
          badge: unread,
        },
        { href: "/dashboard/profile", label: "بياناتي", icon: "user" },
      ],
    },
  ];
}

/** قائمة لوحة الإدارة — مصممة حول مسار العمل: محتوى ← طلاب ← بيع. */
export function adminNav(): NavGroup[] {
  return [
    {
      title: "عام",
      items: [
        { href: "/admin", label: "لوحة المؤشرات", icon: "dashboard" },
        { href: "/admin/students", label: "الطلاب", icon: "users" },
      ],
    },
    {
      title: "بناء المنهج",
      items: [
        {
          href: "/admin/terms",
          label: "الفصول الدراسية",
          icon: "school",
          hint: "ابدأ من هنا",
        },
        { href: "/admin/units", label: "الوحدات", icon: "layers" },
        { href: "/admin/skills", label: "المهارات", icon: "target" },
        { href: "/admin/lessons", label: "الدروس", icon: "book" },
        { href: "/admin/videos", label: "الفيديوهات", icon: "video" },
        { href: "/admin/files", label: "أوراق العمل والملفات", icon: "file" },
      ],
    },
    {
      title: "التقييم",
      items: [
        {
          href: "/admin/questions",
          label: "بنك الأسئلة",
          icon: "brain",
          hint: "مصنّف بالمهارات",
        },
        { href: "/admin/exams", label: "الاختبارات", icon: "exam" },
        { href: "/admin/assignments", label: "الواجبات", icon: "clipboard" },
      ],
    },
    {
      title: "البيع",
      items: [
        {
          href: "/admin/plans",
          label: "الباقات والأسعار",
          icon: "price",
          hint: "الأسعار والحصص",
        },
        { href: "/admin/subscriptions", label: "الاشتراكات", icon: "creditCard" },
        { href: "/admin/payments", label: "المدفوعات", icon: "wallet" },
      ],
    },
    {
      title: "أخرى",
      items: [
        { href: "/admin/notifications", label: "الإعلانات", icon: "megaphone" },
        { href: "/admin/settings", label: "الإعدادات", icon: "settings" },
      ],
    },
  ];
}

/** يحوّل القوائم المسطحة إلى قائمة واحدة — للاستخدام في الاختبارات أو الشريط العلوي. */
export function flatNav(groups: NavGroup[]): NavItemDef[] {
  return groups.flatMap((g) => g.items);
}