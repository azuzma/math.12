/**
 * إعادة المحاولة عند انقطاع الاتصال بقاعدة البيانات مؤقتًا.
 * يحدث أحيانًا مع خوادم التخزين المؤقت (Neon) والشبكات المتنقلة،
 * أو مع خوادم التخزين المحلي التي تقطع الجلسات الخاملة.
 */

/** رسائل الأخطاء التي تدل على انقطاع الاتصال مؤقتًا. */
export function isTransientConnectionError(error: unknown): boolean {
  const e = error as {
    code?: string;
    message?: string;
    meta?: { driverAdapterError?: { name?: string } };
  };
  const code = e?.code ?? "";
  const message = e?.message ?? "";
  const adapterName = e?.meta?.driverAdapterError?.name ?? "";

  return (
    code === "P1017" ||
    code === "P1001" ||
    code === "P1008" ||
    code === "P2034" ||
    adapterName === "ConnectionClosed" ||
    message.includes("Server has closed the connection") ||
    message.includes("ConnectionClosed") ||
    message.includes("ECONNRESET") ||
    message.includes("ECONNREFUSED") ||
    message.includes("ETIMEDOUT") ||
    message.includes("terminating connection") ||
    message.includes("connection pool timeout")
  );
}

export async function withRetry<T>(
  operation: () => Promise<T>,
  retries = 4,
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      if (!isTransientConnectionError(error) || attempt === retries) throw error;
      // انتظار متزايد قبل إعادة المحاولة
      await new Promise((r) => setTimeout(r, 250 * (attempt + 1)));
    }
  }
  throw lastError;
}