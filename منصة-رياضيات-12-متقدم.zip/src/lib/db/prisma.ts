import { PrismaClient, Prisma } from "@/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import { withRetry } from "@/lib/db/retry";

declare global {
  // eslint-disable-next-line no-var
  var __prismaClient: PrismaClient | undefined;
  // eslint-disable-next-line no-var
  var __prismaPool: Pool | undefined;
}

/**
 * رسالة غياب DATABASE_URL.
 *
 * ملاحظة: نُبقي الرسالة بالإنجليزية عمدًا. محرّك Turbopack يعرض إطار
 * الكود عند فشل البناء، وحين يحتوي السطر المعروض على حروف عربية
 * ينهار أثناء التظليل (خطأ char boundary) بدل أن يعرض الخطأ بوضوح.
 */
const NO_DATABASE_URL_MESSAGE =
  "DATABASE_URL is missing. Add it to .env or to the environment variables in Vercel.";

function createPool(): Pool {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error(NO_DATABASE_URL_MESSAGE);
  }

  const pool = new Pool({
    connectionString,
    // اتصال واحد يكفي لتطبيق Next.js؛ زيادة العدد تستنزف اتصالات الخادم.
    max: Number(process.env.DATABASE_POOL_MAX ?? 5),
    idleTimeoutMillis: 20_000,
    connectionTimeoutMillis: 15_000,
    // يمنع الخادم من قطع الاتصال أثناء فترة الخمول
    keepAlive: true,
  });

  // بدون مستمع، أي خطأ في اتصال خامل يُسقط العملية بالكامل.
  pool.on("error", (error) => {
    if (process.env.NODE_ENV !== "test") {
      console.error("[db] خطأ في اتصال الخامل:", error.message);
    }
  });

  return pool;
}

function createClient(): PrismaClient {
  const pool = globalThis.__prismaPool ?? createPool();
  globalThis.__prismaPool = pool;

  const client = new PrismaClient({
    adapter: new PrismaPg(pool),
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

  // بعض الخوادم تقطع الاتصال الخامل. نعيد المحاولة تلقائيًا حتى لا تفشل
  // صفحة المستخدم بسبب انقطاع شبكي لحظي.
  return client.$extends({
    name: "connection-retry",
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          return withRetry(() => query(args));
        },
      },
    },
  }) as unknown as PrismaClient;
}

function realClient(): PrismaClient {
  if (!globalThis.__prismaClient) {
    globalThis.__prismaClient = createClient();
  }
  return globalThis.__prismaClient;
}

/**
 * عميل Prisma كسول بالكامل.
 *
 * نستخدم Proxy متداخلًا حتى لا يُنفَّذ أي استعلام قبل أول استخدام فعلي:
 *   - الوصول إلى `prisma.model` لا يُنشئ الاتصال.
 *   - نداء `prisma.model.op(...)` يعيد Promise، فإن فشل الاتصال صار رفضًا
 *     (rejection) يمكن التقاطه بـ `.catch()` بدل أن يرمي استثناءً متزامنًا.
 *
 * هذا يحمي عملية البناء (`next build`) من الفشل عند غياب DATABASE_URL،
 *وكل صفحة تستطيع التصرّف بأمان.
 */
const modelCache = new Map<string, unknown>();

export const prisma: PrismaClient = new Proxy({} as PrismaClient, {
  get(_target, prop) {
    if (typeof prop !== "string") return undefined;

    // عمليات على مستوى العميل مثل $queryRaw و$transaction
    if (prop.startsWith("$")) {
      return (...args: unknown[]) => {
        try {
          const method = (realClient() as unknown as Record<string, unknown>)[prop];
          return (method as (...a: unknown[]) => unknown).apply(realClient(), args);
        } catch (e) {
          return Promise.reject(e);
        }
      };
    }

    if (!modelCache.has(prop)) {
      const modelProxy = new Proxy(
        {},
        {
          get(_m, op) {
            return (...args: unknown[]) => {
              try {
                const model = (realClient() as unknown as Record<string, Record<string, unknown>>)[prop];
                const method = model?.[op as string];
                if (typeof method !== "function") {
                  return Promise.reject(new Error(`Unknown Prisma operation: ${prop}.${String(op)}`));
                }
                return (method as (...a: unknown[]) => unknown).apply(model, args);
              } catch (e) {
                return Promise.reject(e);
              }
            };
          },
        },
      );
      modelCache.set(prop, modelProxy);
    }

    return modelCache.get(prop);
  },
});

export { Prisma };
