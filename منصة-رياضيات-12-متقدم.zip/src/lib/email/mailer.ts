/**
 * طبقة البريد الإلكتروني.
 *
 * الخيار الموصى به: Resend — أرخص وأسهل مع Next.js،
 * ويصل إلى صندوق Gmail بشكل أفضل من Gmail نفسه عند الإرسال إلى Gmail.
 *
 * البديل: أي خادم SMTP عبر Nodemailer (مثل Brevo المجاني 300 رسالة/يوم).
 *
 * عند عدم وجود مفاتيح، يتم تسجيل الرسالة في الـ console بدل فشل الطلب،
 * حتى لا يتعطل تسجيل المستخدم أثناء التطوير.
 */

import "server-only";
import { appUrl } from "@/lib/env";

export type MailResult = { sent: boolean; id?: string; reason?: string };

type MailPayload = {
  to: string;
  subject: string;
  html: string;
  text?: string;
};

function emailShell(title: string, bodyHtml: string): string {
  return `<!doctype html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
</head>
<body style="margin:0;padding:24px;background:#f4f6fb;font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e3e8f0">
    <tr>
      <td style="background:#2445eb;padding:20px 28px">
        <span style="color:#fff;font-size:19px;font-weight:700">رياضيات 12 متقدم</span>
      </td>
    </tr>
    <tr>
      <td style="padding:28px;color:#171c26;font-size:15px;line-height:1.9" dir="rtl">
        ${bodyHtml}
      </td>
    </tr>
    <tr>
      <td style="padding:18px 28px;background:#f8f9fc;color:#6b7890;font-size:12px;border-top:1px solid #e3e8f0">
        هذه رسالة آلية. يمكنك إيقاف استقبالها من إعدادات الحساب.
      </td>
    </tr>
  </table>
</body>
</html>`;
}

async function sendViaResend(payload: MailPayload): Promise<MailResult> {
  const { Resend } = await import("resend");
  const resend = new Resend(process.env.RESEND_API_KEY!);
  const { data, error } = await resend.emails.send({
    from: process.env.MAIL_FROM ?? "رياضيات 12 متقدم <onboarding@resend.dev>",
    to: payload.to,
    subject: payload.subject,
    html: payload.html,
    text: payload.text,
  });
  if (error) return { sent: false, reason: error.message };
  return { sent: true, id: data?.id };
}

async function sendViaSmtp(payload: MailPayload): Promise<MailResult> {
  const nodemailer = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST!,
    port: Number(process.env.SMTP_PORT ?? 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
  await transporter.sendMail({
    from: process.env.MAIL_FROM ?? process.env.SMTP_USER,
    to: payload.to,
    subject: payload.subject,
    html: payload.html,
    text: payload.text,
  });
  return { sent: true };
}

export async function sendMail(payload: MailPayload): Promise<MailResult> {
  if (process.env.RESEND_API_KEY) {
    try {
      return await sendViaResend(payload);
    } catch (e) {
      console.error("[mail:resend] فشل:", (e as Error).message);
      return { sent: false, reason: (e as Error).message };
    }
  }
  if (process.env.SMTP_HOST) {
    try {
      return await sendViaSmtp(payload);
    } catch (e) {
      console.error("[mail:smtp] فشل:", (e as Error).message);
      return { sent: false, reason: (e as Error).message };
    }
  }
  console.info(
    `[mail:dev] لم يتم إعداد البريد — إلى: ${payload.to} | الموضوع: ${payload.subject}`,
  );
  return { sent: false, reason: "لم يتم إعداد خدمة البريد" };
}

/* =====================══ الرسائل ======================= */

export async function sendVerificationEmail(to: string, code: string) {
  const url = `${appUrl()}/verify?code=${code}`;
  return sendMail({
    to,
    subject: "تأكيد بريدك الإلكتروني — رياضيات 12 متقدم",
    html: emailShell(
      "تأكيد البريد",
      `<p>مرحبًا،</p>
       <p>شكرًا لانضمامك. لتأكيد بريدك اضغط الزر التالي:</p>
       <p><a href="${url}" style="display:inline-block;background:#2445eb;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:600">تأكيد البريد الإلكتروني</a></p>
       <p style="color:#6b7890;font-size:13px">أو انسخ الرابط: ${url}</p>`,
    ),
  });
}

export async function sendPasswordResetEmail(to: string, code: string) {
  const url = `${appUrl()}/reset-password?code=${code}`;
  return sendMail({
    to,
    subject: "استعادة كلمة المرور — رياضيات 12 متقدم",
    html: emailShell(
      "استعادة كلمة المرور",
      `<p>طلبت استعادة كلمة المرور. استخدم الرمز التالي أو اضغط الزر:</p>
       <p style="font-size:26px;letter-spacing:6px;font-weight:700;color:#2445eb">${code}</p>
       <p><a href="${url}" style="display:inline-block;background:#2445eb;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:600">تعيين كلمة مرور جديدة</a></p>
       <p style="color:#6b7890;font-size:13px">الرمز صالح لمدة ساعة واحدة. إذا لم تطلب ذلك، تجاهل هذه الرسالة.</p>`,
    ),
  });
}

export async function sendWelcomeEmail(
  to: string,
  fullName: string,
  gradeName = "الصف الثاني عشر متقدم",
) {
  return sendMail({
    to,
    subject: `أهلًا بك في منصة رياضيات ${gradeName}`,
    html: emailShell(
      "أهلًا بك",
      `<p>مرحبًا <strong>${fullName}</strong>،</p>
       <p>تم إنشاء حسابك في منصة <strong>رياضيات ${gradeName}</strong> بنجاح.</p>
       <p>كل ما تحتاجه لإتقان المنهج في مكان واحد. ابدأ الآن:</p>
       <ul style="line-height:2.1;padding-right:18px">
         <li>شاهد أول درس فيديو مع الملخص وأوراق العمل</li>
         <li>تابع نسبة تقدمك في المنهج تلقائيًا</li>
         <li>جرّب اختبار قصير وانظر درجتك فورًا</li>
         <li>راجع تحليلك الذكي لتعرف نقاط قوتك وما يحتاج مراجعة</li>
       </ul>
       <p><a href="${appUrl()}/dashboard" style="display:inline-block;background:#2445eb;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:600">ابدأ التعلم</a></p>`,
    ),
  });
}

export async function sendReceiptEmail(
  to: string,
  fullName: string,
  details: { planName: string; amount: number; currency: string; invoiceRef?: string | null; date: Date },
) {
  return sendMail({
    to,
    subject: "إيصال الدفع — رياضيات 12 متقدم",
    html: emailShell(
      "إيصال الدفع",
      `<p>مرحبًا <strong>${fullName}</strong>،</p>
       <p>شكرًا لاشتراكك. هذه تفاصيل العملية:</p>
       <table style="width:100%;border-collapse:collapse;margin:12px 0">
         <tr><td style="padding:8px;border:1px solid #e3e8f0;color:#6b7890">الباقة</td><td style="padding:8px;border:1px solid #e3e8f0;font-weight:600">${details.planName}</td></tr>
         <tr><td style="padding:8px;border:1px solid #e3e8f0;color:#6b7890">المبلغ</td><td style="padding:8px;border:1px solid #e3e8f0;font-weight:600">${details.amount} ${details.currency}</td></tr>
         <tr><td style="padding:8px;border:1px solid #e3e8f0;color:#6b7890">التاريخ</td><td style="padding:8px;border:1px solid #e3e8f0">${details.date.toLocaleDateString("ar-AE")}</td></tr>
         ${details.invoiceRef ? `<tr><td style="padding:8px;border:1px solid #e3e8f0;color:#6b7890">رقم العملية</td><td style="padding:8px;border:1px solid #e3e8f0">${details.invoiceRef}</td></tr>` : ""}
       </table>
       <p><a href="${appUrl()}/dashboard/payments" style="display:inline-block;background:#2445eb;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:600">عرض كل المدفوعات</a></p>`,
    ),
  });
}

export async function sendExpiryReminderEmail(
  to: string,
  fullName: string,
  daysLeft: number,
  expiryDate: Date,
) {
  const url = `${appUrl()}/dashboard/subscription`;
  return sendMail({
    to,
    subject:
      daysLeft <= 3 ? `اشتراكك ينتهي خلال ${daysLeft} أيام` : "تذكير: تجديد الاشتراك قريبًا",
    html: emailShell(
      "تذكير بالاشتراك",
      `<p>مرحبًا <strong>${fullName}</strong>،</p>
       <p>اشتراكك ينتهي في <strong>${expiryDate.toLocaleDateString("ar-AE")}</strong> (${daysLeft} يوم متبقٍ).</p>
       <p>جدّد الآن حتى لا تفقد الوصول إلى الدروس والاختبارات.</p>
       <p><a href="${url}" style="display:inline-block;background:#2445eb;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:600">تجديد الاشتراك</a></p>`,
    ),
  });
}

export async function sendAccountSuspendedEmail(to: string, fullName: string) {
  return sendMail({
    to,
    subject: "تم إيقاف حسابك مؤقتًا",
    html: emailShell(
      "إيقاف الحساب",
      `<p>مرحبًا <strong>${fullName}</strong>،</p>
       <p>تم إيقاف حسابك مؤقتًا من قِبل إدارة المنصة. تواصل معنا لمعرفة السبب وكيفية التفعيل.</p>`,
    ),
  });
}