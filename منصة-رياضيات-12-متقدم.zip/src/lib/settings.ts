import "server-only";
import { prisma, Prisma } from "@/lib/db/prisma";

export type SiteSettings = {
  siteName: string;
  tagline: string;
  teacherName: string;
  teacherTitle: string;
  teacherBio: string;
  contactEmail: string;
  contactPhone: string;
  whatsapp: string;
  address: string;
  logoText: string;
  instagramUrl: string;
  youtubeUrl: string;
  tiktokUrl: string;
  currency: string;
  vatIncluded: boolean;
  vatPercent: number;
  footerNote: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "رياضيات 12 متقدم",
  tagline: "كل ما تحتاجه لإتقان رياضيات الصف 12 متقدم في مكان واحد",
  teacherName: "أستاذ الرياضيات",
  teacherTitle: "مدرس رياضيات — الصف الثاني عشر متقدم",
  teacherBio: "",
  contactEmail: "",
  contactPhone: "",
  whatsapp: "",
  address: "",
  logoText: "١٢",
  instagramUrl: "",
  youtubeUrl: "",
  tiktokUrl: "",
  currency: "AED",
  vatIncluded: false,
  vatPercent: 5,
  footerNote: "",
};

const cache = new Map<string, { value: SiteSettings; at: number }>();
const TTL = 60_000;

export async function getSettings(): Promise<SiteSettings> {
  const hit = cache.get("settings");
  if (hit && Date.now() - hit.at < TTL) return hit.value;

  try {
    const rows = await prisma.siteSetting.findMany();
    const obj: Record<string, unknown> = {};
    for (const row of rows) obj[row.key] = row.value;

    const value: SiteSettings = { ...DEFAULT_SETTINGS };
    for (const key of Object.keys(DEFAULT_SETTINGS) as (keyof SiteSettings)[]) {
      const raw = obj[key];
      if (raw === undefined || raw === null) continue;
      // كل قيم الإعدادات نصوص أو أرقام أو منطقيات
      (value as Record<string, unknown>)[key] = raw;
    }
    cache.set("settings", { value, at: Date.now() });
    return value;
  } catch {
    // لا تُسقط الصفحة إذا لم تكن قاعدة البيانات متاحة بعد
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(patch: Partial<SiteSettings>) {
  const ops = Object.entries(patch).map(([key, value]) =>
    prisma.siteSetting.upsert({
      where: { key },
      create: { key, value: value as Prisma.InputJsonValue, group: "general" },
      update: { value: value as Prisma.InputJsonValue },
    }),
  );
  await prisma.$transaction(ops);
  cache.delete("settings");
}

export function invalidateSettingsCache() {
  cache.delete("settings");
}