/**
 * أدوات التعامل مع روابط YouTube.
 *
 * الأستاذ يرفع الفيديو على قناته ثم يلصق الرابط هنا، والمنصة تعرضه
 * داخل مشغّلها (embed) مع تتبّع المشاهدة.
 */

/** يحوّل رابط يوتيوب بأشكاله المختلفة إلى معرّف الفيديو (videoId). */
export function extractYouTubeId(input: string): string | null {
  const value = (input ?? "").trim();
  if (!value) return null;

  // رابط مباشر بالمعرّف
  if (/^[A-Za-z0-9_-]{11}$/.test(value)) return value;

  let url: URL;
  try {
    url = new URL(value.includes("://") ? value : `https://${value}`);
  } catch {
    return null;
  }

  const host = url.hostname.replace(/^www\./, "").toLowerCase();

  // youtube.com/watch?v=ID
  if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
    const v = url.searchParams.get("v");
    if (v && /^[A-Za-z0-9_-]{11}$/.test(v)) return v;
    // youtu.be/ID
    if (url.pathname.startsWith("/embed/")) {
      const id = url.pathname.split("/embed/")[1]?.split(/[/?#]/)[0];
      if (id && /^[A-Za-z0-9_-]{11}$/.test(id)) return id;
    }
    // shorts / live / embed
    const m = url.pathname.match(/^\/(shorts|live|embed|v)\/([A-Za-z0-9_-]{11})/);
    if (m) return m[2];
  }

  // youtu.be/ID
  if (host === "youtu.be") {
    const id = url.pathname.slice(1).split(/[/?#]/)[0];
    if (id && /^[A-Za-z0-9_-]{11}$/.test(id)) return id;
  }

  return null;
}

/** رابط التضمين المستخدَم داخل المنصة (privacy-enhanced). */
export function youTubeEmbedUrl(videoId: string): string {
  return `https://www.youtube-nocookie.com/embed/${videoId}?enablejsapi=1&rel=0&modestbranding=1&playsinline=1`;
}

/** صورة مصغّرة للفيديو. */
export function youTubeThumbnail(videoId: string): string {
  return `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
}
