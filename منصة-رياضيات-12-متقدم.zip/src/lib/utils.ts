import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** تنسيق السعر بالدرهم الإماراتي */
export function formatPrice(amount: number, currency = "AED"): string {
  if (amount === 0) return "مجانًا";
  const symbol = currency === "AED" ? "د.إ" : currency;
  return `${new Intl.NumberFormat("ar-AE", { maximumFractionDigits: 0 }).format(amount)} ${symbol}`;
}

/** تنسيق تاريخ ميلادي عربي */
export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("ar-AE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(d);
}

export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("ar-AE", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

/** تحويل الثواني إلى HH:MM:SS أو MM:SS */
export function formatDuration(seconds: number): string {
  if (!seconds || seconds < 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatBytes(bytes: number): string {
  if (!bytes) return "0 KB";
  const units = ["بايت", "كيلوبايت", "ميغابايت", "غيغابايت"];
  let value = bytes;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

/** نسبة مئوية آمنة */
export function pct(value: number, total: number): number {
  if (!total) return 0;
  return Math.round((value / total) * 100);
}

/** توليد slug يدعم العربية */
export function slugify(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/[\s_]+/g, "-")
    .replace(/[^\p{L}\p{N}-]/gu, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

/** دمج className مع دعم الحالة */
export const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  DRAFT: { label: "مسودة", className: "bg-ink-100 text-ink-600" },
  PUBLISHED: { label: "منشور", className: "bg-emerald-50 text-emerald-700" },
  ARCHIVED: { label: "مؤرشف", className: "bg-amber-50 text-amber-700" },
};

export const QUESTION_TYPE_LABELS: Record<string, string> = {
  MCQ: "اختيار من متعدد",
  MULTI_TRUE: "اختيار متعدد الإجابات",
  TRUE_FALSE: "صح / خطأ",
  SHORT: "إجابة قصيرة",
  NUMERIC: "إجابة رقمية",
  ESSAY: "سؤال مقالي",
};

export const FILE_KIND_LABELS: Record<string, string> = {
  SUMMARY: "ملخص",
  WORKSHEET: "ورقة عمل",
  ASSIGNMENT: "واجب",
  ANSWERS: "حل نموذجي",
  OTHER: "أخرى",
};

export const PAYMENT_STATUS_LABELS: Record<string, string> = {
  PENDING: "قيد المعالجة",
  SUCCEEDED: "مدفوع",
  FAILED: "فشل",
  REFUNDED: "مسترجع",
  CANCELED: "ملغى",
};

export const SUB_STATUS_LABELS: Record<string, string> = {
  ACTIVE: "فعّال",
  TRIAL: "تجربة",
  PAST_DUE: "متأخر",
  CANCELED: "ملغى",
  EXPIRED: "منتهي",
  INCOMPLETE: "غير مكتمل",
};

/** رقم عشوائي آمنCryptographically */
export function randomCode(length = 6): string {
  const chars = "0123456789";
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => chars[b % chars.length]).join("");
}

export function initials(name: string): string {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0] ?? "")
    .join("");
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(Math.max(n, min), max);
}