/**
 * تفعيل الاشتراك بعد نجاح الدفع — يعمل من الخادم فقط.
 * يُستدعى من:
 *  - /api/webhooks/stripe  (بعد تحقق التوقيع)
 *  - /api/webhooks/telr    (بعد تحقق التوقيع)
 *  - لوحة الإدارة (تفعيل يدوي عند التحويل البنكي مثلًا)
 */

import "server-only";
import { prisma } from "@/lib/db/prisma";
import type { BillingCycle } from "@/lib/payments/provider";
import { notify } from "@/lib/notifications";

export type ActivateInput = {
  userId: string;
  planSlug: string;
  cycle: BillingCycle;
  amount: number;
  currency: string;
  provider: "stripe" | "telr" | "manual";
  providerRef?: string | null;
  providerSubId?: string | null;
  providerCustId?: string | null;
  invoiceRef?: string | null;
  method?: string | null;
  cardLast4?: string | null;
  cardBrand?: string | null;
  periodStart?: Date;
  periodEnd?: Date;
  status?: "ACTIVE" | "TRIAL" | "PAST_DUE" | "CANCELED" | "EXPIRED" | "INCOMPLETE";
};

function addCycle(start: Date, cycle: BillingCycle): Date {
  const end = new Date(start);
  if (cycle === "monthly") {
    end.setMonth(end.getMonth() + 1);
  } else {
    end.setFullYear(end.getFullYear() + 1);
  }
  return end;
}

/**
 * إنشاء/تحديث الاشتراك وتسجيل الدفعة.
 * آمن للتكرار (idempotent) لأن webhooks قد تتكرر.
 */
export async function activateSubscription(input: ActivateInput) {
  const plan = await prisma.plan.findUnique({ where: { slug: input.planSlug } });
  if (!plan) throw new Error(`الباقة غير موجودة: ${input.planSlug}`);
  if (!plan.isActive) throw new Error("هذه الباقة غير متاحة حاليًا");

  const periodStart = input.periodStart ?? new Date();
  const periodEnd = input.periodEnd ?? addCycle(periodStart, input.cycle);

  // ابحث عن اشتراك نشط لنفس المزوّد لتحديثه بدل التكرار
  const existing = await prisma.subscription.findFirst({
    where: {
      userId: input.userId,
      provider: input.provider,
      ...(input.providerSubId ? { providerSubId: input.providerSubId } : {}),
    },
    orderBy: { createdAt: "desc" },
  });

  const status = input.status ?? "ACTIVE";

  const subscription = existing
    ? await prisma.subscription.update({
        where: { id: existing.id },
        data: {
          planId: plan.id,
          status,
          billingCycle: input.cycle,
          amount: input.amount,
          currency: input.currency,
          currentPeriodStart: periodStart,
          currentPeriodEnd: periodEnd,
          canceledAt: null,
          cancelAtPeriodEnd: false,
        },
      })
    : await prisma.subscription.create({
        data: {
          userId: input.userId,
          planId: plan.id,
          status,
          billingCycle: input.cycle,
          amount: input.amount,
          currency: input.currency,
          provider: input.provider,
          providerSubId: input.providerSubId ?? null,
          providerCustId: input.providerCustId ?? null,
          currentPeriodStart: periodStart,
          currentPeriodEnd: periodEnd,
        },
      });

  // سجل الدفع (تجنّب التكرار عبر providerRef)
  const duplicate = input.providerRef
    ? await prisma.payment.findFirst({
        where: { provider: input.provider, providerRef: input.providerRef },
      })
    : null;

  let paymentId: string | null = null;
  if (!duplicate) {
    const payment = await prisma.payment.create({
      data: {
        userId: input.userId,
        subscriptionId: subscription.id,
        planId: plan.id,
        planSnapshot: {
          slug: plan.slug,
          nameAr: plan.nameAr,
          tier: plan.tier,
          cycle: input.cycle,
        } as never,
        provider: input.provider,
        providerRef: input.providerRef ?? null,
        invoiceRef: input.invoiceRef ?? null,
        amount: input.amount,
        currency: input.currency,
        status: "SUCCEEDED",
        method: input.method ?? null,
        cardLast4: input.cardLast4 ?? null,
        cardBrand: input.cardBrand ?? null,
        paidAt: new Date(),
      },
    });
    paymentId = payment.id;
  }

  // إشعار الطالب
  await notify({
    userId: input.userId,
    type: "SUBSCRIPTION",
    title: "تم تفعيل اشتراكك 🎉",
    body: `باقة ${plan.nameAr} — ${
      input.cycle === "monthly" ? "اشتراك شهري" : "اشتراك سنوي"
    }. ستجد كل الدروس والاختبارات مفتوحة حتى ${periodEnd.toLocaleDateString("ar-AE")}.`,
    link: "/dashboard/subscription",
  });

  await notify({
    userId: input.userId,
    type: "PAYMENT",
    title: "تم استلام دفعة بنجاح",
    body: `دفعة بقيمة ${input.amount} ${input.currency} — ${
      input.invoiceRef ? `رقم الفاتورة ${input.invoiceRef}` : "تم التسجيل"
    }.`,
    link: "/dashboard/payments",
  });

  return { subscription, paymentId, plan };
}

/** تحديث حالة اشتراك من الـ webhook (تجديد/إلغاء/تأخر). */
export async function syncSubscriptionStatus(input: {
  providerSubId: string;
  status: "ACTIVE" | "TRIAL" | "PAST_DUE" | "CANCELED" | "EXPIRED" | "INCOMPLETE";
  periodStart?: Date;
  periodEnd?: Date;
}) {
  const sub = await prisma.subscription.findFirst({
    where: { providerSubId: input.providerSubId },
  });
  if (!sub) return null;

  const updated = await prisma.subscription.update({
    where: { id: sub.id },
    data: {
      status: input.status,
      ...(input.periodStart ? { currentPeriodStart: input.periodStart } : {}),
      ...(input.periodEnd ? { currentPeriodEnd: input.periodEnd } : {}),
      ...(input.status === "CANCELED" ? { canceledAt: new Date() } : {}),
    },
  });

  const messages: Record<string, string> = {
    PAST_DUE: "تعذّر تحصيل الدفعة. حدّث بيانات البطاقة لتفادي توقف الوصول.",
    CANCELED: "تم إلغاء اشتراكك. يمكنك إعادة الاشتراك في أي وقت.",
    EXPIRED: "انتهى اشتراكك. اشترك مجددًا لمتابعة الدروس المدفوعة.",
    INCOMPLETE: "لم تكتمل عملية الدفع. يرجى المحاولة مرة أخرى.",
  };
  const body = messages[input.status];
  if (body) {
    await notify({
      userId: sub.userId,
      type: "SUBSCRIPTION",
      title: "تحديث حالة الاشتراك",
      body,
      link: "/dashboard/subscription",
    });
  }
  return updated;
}