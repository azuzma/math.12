/**
 * طبقة الدفع الموحدة.
 *
 * البوابات المدعومة:
 *  - Stripe: اشتراكات متكررة (Subscriptions API) — الأفضل للاشتراك الشهري/السنوي.
 *  - Telr: بوابة خليجية مناسبة لطلاب الإمارات، وتدعم صفحة دفع مملوكة مع webhook.
 *
 * القاعدة: كل عملية شراء تمر عبر /api/billing/checkout ثم /api/webhooks/<provider>.
 * تفعيل الاشتراك يتم دائمًا من الخادم بناءً على webhook موثّق، لا من المتصفح.
 */

import "server-only";

export type BillingCycle = "monthly" | "yearly";

export type CheckoutRequest = {
  userId: string;
  email: string;
  planSlug: string;
  planName: string;
  cycle: BillingCycle;
  amount: number;
  currency: string;
  stripePriceId?: string | null;
  telrClientKey?: string | null;
  successUrl: string;
  cancelUrl: string;
};

export type CheckoutResult =
  | { provider: "stripe"; url: string; sessionId: string }
  | { provider: "telr"; url: string; reference: string }
  | { provider: "manual"; url: string; reference: string };

export type ProviderName = "stripe" | "telr" | "manual";

export function activeProvider(): ProviderName {
  if (process.env.STRIPE_SECRET_KEY) return "stripe";
  if (process.env.TELR_STORE_ID && process.env.TELR_API_KEY) return "telr";
  return "manual";
}

export function isPaymentConfigured(): boolean {
  return activeProvider() !== "manual";
}

/* ================= Stripe ================= */

export async function createStripeCheckout(
  req: CheckoutRequest,
  customerId?: string | null,
): Promise<CheckoutResult> {
  const { default: Stripe } = await import("stripe");
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

  type SessionParams = Parameters<typeof stripe.checkout.sessions.create>[0];

  const params: SessionParams = {
    mode: "subscription",
    customer: customerId ?? undefined,
    customer_email: customerId ? undefined : req.email,
    client_reference_id: req.userId,
    line_items: req.stripePriceId
      ? [{ price: req.stripePriceId, quantity: 1 }]
      : [
          {
            quantity: 1,
            price_data: {
              currency: req.currency.toLowerCase(),
              product_data: {
                name: `اشتراك ${req.planName}`,
                description: `الاشتراك ${req.cycle === "monthly" ? "الشهري" : "السنوي"}`,
              },
              unit_amount: req.amount * 100,
              recurring: {
                interval: req.cycle === "monthly" ? "month" : "year",
              },
            },
          },
        ],
    success_url: req.successUrl,
    cancel_url: req.cancelUrl,
    metadata: {
      userId: req.userId,
      planSlug: req.planSlug,
      cycle: req.cycle,
      amount: String(req.amount),
      currency: req.currency,
    },
    subscription_data: {
      metadata: {
        userId: req.userId,
        planSlug: req.planSlug,
        cycle: req.cycle,
        amount: String(req.amount),
        currency: req.currency,
      },
    },
    locale: "auto",
  } as SessionParams;

  const session = await stripe.checkout.sessions.create(params);
  return {
    provider: "stripe",
    url: session.url!,
    sessionId: session.id,
  };
}

/** إلغاء اشتراك Stripe عند انتهاء الفترة (يحترم ما تبقى من اشتراك). */
export async function cancelStripeSubscription(
  subscriptionId: string,
  immediate = false,
): Promise<void> {
  const { default: Stripe } = await import("stripe");
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
  await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: !immediate,
    ...(immediate ? { cancel_at: "now" as const } : {}),
  });
}

/* ================= Telr ================= */

/**
 * Telr: ينشئ طلب دفع عبر REST ثم يعيد رابط صفحة الدفع.
 * التوثيق: https://docs.telr.com
 */
export async function createTelrCheckout(
  req: CheckoutRequest,
): Promise<CheckoutResult> {
  const storeId = process.env.TELR_STORE_ID;
  const apiKey = process.env.TELR_API_KEY;
  if (!storeId || !apiKey) throw new Error("إعدادات Telr غير مكتملة");

  const reference = `mp_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

  // في وضع الاختبار:TELR_TEST_MODE=true يُرجع رابطًا تجريبيًا بلا خصم حقيقي.
  const isTest = process.env.TELR_TEST_MODE === "true";
  const endpoint = isTest
    ? "https://test.telr.com/api/charge"
    : "https://secure.telr.com/api/charge";

  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
    },
    body: JSON.stringify({
      store_id: storeId,
      order_id: reference,
      threed_otv: req.telrClientKey ?? undefined,
      tran_type: "no",
      tran_value: `${req.amount}.00`,
      currency: req.currency,
      services: [{ service_id: "pay", service_type: "moto" }],
      customers: { customer_id: req.userId, customer_email: req.email },
      redirect_url: req.successUrl,
      callback_url: `${new URL(req.successUrl).origin}/api/webhooks/telr`,
      user_define: {
        userId: req.userId,
        planSlug: req.planSlug,
        cycle: req.cycle,
        amount: req.amount,
        currency: req.currency,
      },
    }),
  });

  const data = (await res.json()) as { status?: string; data?: { url?: string } };

  if (!res.ok || !data.data?.url) {
    throw new Error(`فشل إنشاء عملية الدفع: ${JSON.stringify(data)}`);
  }

  return { provider: "telr", url: data.data.url, reference };
}

/* ================= نقطة الدخول الموحدة ================= */

export async function startCheckout(req: CheckoutRequest): Promise<CheckoutResult> {
  const provider = activeProvider();

  if (provider === "stripe") {
    return createStripeCheckout(req);
  }
  if (provider === "telr") {
    return createTelrCheckout(req);
  }
  throw new Error("لم يتم ربط بوابة دفع بعد. أضف مفاتيح Stripe أو Telr.");
}