/**
 * طبقة التخزين — ملفات PDF وأوراق العمل.
 *
 * المنصة تعمل مع أي من المخزينين:
 *  1) Supabase Storage (مستحسن): حاوية خاصة + روابط موقّعة قصيرة الصلاحية.
 *  2) التخزين المحلي على القرص (للتطوير فقط أو لسيرفر VPS واحد).
 *
 * المقصود أن المحتوى المدفوع لا يكون له رابط دائم يمكن نسخه.
 * كل طلب تنزيل يمر عبر /api/files/[id]/download الذي يتحقق من
 * صلاحية المستخدم ثم يولّد رابطًا موقّعًا صالحًا لدقائق.
 */

import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";

export type StorageDriver = "supabase" | "local";

export function storageDriver(): StorageDriver {
  return process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
    ? "supabase"
    : "local";
}

/* ---------- التوقيع المحلي (للتطوير) ---------- */

const LOCAL_SECRET = () =>
  process.env.AUTH_SECRET ??
  "dev-only-secret-do-not-use-in-production-please-32-chars";

export function signLocalToken(key: string, expiresAt: number): string {
  const payload = `${key}.${expiresAt}`;
  const sig = createHmac("sha256", LOCAL_SECRET()).update(payload).digest("base64url");
  return `${Buffer.from(`${key}:${expiresAt}`).toString("base64url")}.${sig}`;
}

export function verifyLocalToken(
  key: string,
  token: string,
  maxAgeSec: number,
): boolean {
  const [encoded, sig] = token.split(".");
  if (!encoded || !sig) return false;
  let decoded: string;
  try {
    decoded = Buffer.from(encoded, "base64url").toString();
  } catch {
    return false;
  }
  const [tokKey, expStr] = decoded.split(":");
  const expiresAt = Number(expStr);
  if (tokKey !== key) return false;
  if (!Number.isFinite(expiresAt) || expiresAt < Date.now()) return false;
  if (expiresAt - Date.now() > maxAgeSec * 1000 * 2) return false;

  const expected = createHmac("sha256", LOCAL_SECRET())
    .update(`${key}.${expiresAt}`)
    .digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

/* ---------- Supabase Storage ---------- */

export type StoredObject = {
  path: string;
  size: number;
};

export async function uploadObject(
  path: string,
  body: ArrayBuffer | Buffer,
  contentType: string,
): Promise<StoredObject> {
  if (storageDriver() === "supabase") {
    const res = await fetch(
      `${process.env.SUPABASE_URL}/storage/v1/object/platform-files/${path}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
          "Content-Type": contentType,
          "x-upsert": "true",
        },
        body: body as BodyInit,
      },
    );
    if (!res.ok) {
      throw new Error(`فشل رفع الملف: ${res.status} ${await res.text()}`);
    }
    return { path, size: body.byteLength };
  }

  // التخزين المحلي
  const { promises: fs } = await import("node:fs");
  const { dirname, join, normalize } = await import("node:path");
  const root = process.env.LOCAL_STORAGE_DIR ?? join(process.cwd(), ".storage");
  const target = join(root, normalize(path).replace(/^(\.\.[/\\])+/, ""));
  await fs.mkdir(dirname(target), { recursive: true });
  await fs.writeFile(target, Buffer.from(body as ArrayBuffer));
  return { path, size: body.byteLength };
}

export async function deleteObject(path: string): Promise<void> {
  if (storageDriver() === "supabase") {
    await fetch(
      `${process.env.SUPABASE_URL}/storage/v1/object/platform-files/${path}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
        },
      },
    );
    return;
  }
  const { promises: fs } = await import("node:fs");
  const { join, normalize } = await import("node:path");
  const root = process.env.LOCAL_STORAGE_DIR ?? join(process.cwd(), ".storage");
  await fs.rm(join(root, normalize(path)), { force: true });
}

export async function readObject(path: string): Promise<Buffer> {
  if (storageDriver() === "supabase") {
    const res = await fetch(
      `${process.env.SUPABASE_URL}/storage/v1/object/platform-files/${path}`,
      { headers: { Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}` } },
    );
    if (!res.ok) throw new Error("تعذر قراءة الملف");
    return Buffer.from(await res.arrayBuffer());
  }
  const { promises: fs } = await import("node:fs");
  const { join, normalize } = await import("node:path");
  const root = process.env.LOCAL_STORAGE_DIR ?? join(process.cwd(), ".storage");
  return fs.readFile(join(root, normalize(path)));
}

/** رابط مباشر صالح لمدة قصيرة لتخزين محلي (لا يُستخدم مع Supabase). */
export async function createLocalSignedUrl(
  storageKey: string,
  fileName: string,
  ttlSeconds = 300,
): Promise<string> {
  const expiresAt = Date.now() + ttlSeconds * 1000;
  const token = signLocalToken(storageKey, expiresAt);
  const params = new URLSearchParams({ token, dl: fileName });
  return `/api/files/stream?key=${encodeURIComponent(storageKey)}&${params.toString()}`;
}