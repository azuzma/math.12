/**
 * طبقة الفيديو — Bunny Stream.
 *
 * لماذا Bunny Stream؟
 *  - تكلفة منخفضة (الخطة المجانية تدعم 500GB / 5TB شهريًا تقريبًا، والدفع بالاستهلاك).
 *  - يوفّر "Signed URLs" لت الفيديو الموقّعة: لن يُشغَّل الفيديو لمن لا يملك جلسة صالحة.
 *  - رابط HLS (.m3u8) يمر عبر Bunny CDN ولا يمكن للطالب استخراج رابط دائم من
 *    عنصر <video> لأنه يتغير كل مرة مع رمز توقيع صالح قصير.
 *  - إيقاف التقديم/التأخير (optional) متاح كخيار على مستوى الملف.
 *
 * Alternative مجانية/مؤقتة: EXTERNAL أو MUX في نفس الواجهة.
 *
 * الإعداد المطلوب من الأستاذ (خطوتان في لوحة Bunny):
 *  1) bunny.net → Stream → Add Video (أو API)
 *  2) نسخة Bunny.net → API Keys → المفتاح العام والخاصة (مفتاحين، واحد للقراءة والآخر للكتابة)
 *  3) bunny.net → Stream → Security → فعّل "Token Authentication" ثم انسخ المفتاح
 */

import "server-only";
import { createHmac } from "node:crypto";

export type BunnyConfig = {
  apiKey: string | undefined;
  authKey: string | undefined;
  cdnBase: string;
};

export function bunnyConfig(): BunnyConfig {
  return {
    apiKey: process.env.BUNNY_API_KEY,
    authKey: process.env.BUNNY_STREAM_AUTH_KEY,
    cdnBase: "https://iframe.mediadelivery.net",
  };
}

export function isVideoConfigured(): boolean {
  return Boolean(bunnyConfig().authKey);
}

/**
 * إنشاء رمز تشغيل موقّع لـ Bunny (JWT HS256،Claims: exp, udid, clig).
 * صالح افتراضيًا 10 دقائق — يكفي لتشغيل الفيديو من دون رابط دائم.
 */
export function createBunnyPlaybackToken(
  playbackId: string,
  userId: string,
  ttlSeconds = 600,
): string | null {
  const cfg = bunnyConfig();
  if (!cfg.authKey) return null;

  const now = Math.floor(Date.now() / 1000);
  const exp = now + ttlSeconds;

  // الترويسات base64url بدون توقيع
  const header = base64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = base64url(
    JSON.stringify({
      exp,
      // معرّف المشاهد (يمكن ربطه ببصمة الجهاز لاحقًا لمنع المشاركة)
      udid: userId,
      // صلاحية المشاهدة بالثواني من بداية الفيديو
      clig: "",
      // رمز مميز لكل تشغيل يجعل الرابط غير قابل لإعادة الاستخدام
      jti: crypto.randomUUID(),
    }),
  );

  const signature = base64url(
    createHmac("sha256", cfg.authKey).update(`${header}.${payload}`).digest(),
  );

  return `${header}.${payload}.${signature}`;
}

function base64url(input: string | Buffer): string {
  return Buffer.from(input as never)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

/**
 * توليد رابط HLS موقّع صالح لمدة محددة.
 * يتم استدعاؤه من الخادم بعد التحقق من الهوية والاشتراك.
 */
export async function getSignedPlaybackUrl(
  playbackId: string,
  userId: string,
): Promise<{ url: string; expiresAt: string; provider: "bunny" | "public" } | null> {
  const cfg = bunnyConfig();
  if (!cfg.authKey) {
    // بدون مفاتيح Bunny: نستخدم رابطًا عاديًا (وضع التطوير فقط)
    return {
      url: `https://stream.mux.com/${playbackId}.m3u8`,
      expiresAt: new Date(Date.now() + 3600_000).toISOString(),
      provider: "public",
    };
  }

  const ttl = 600;
  const token = createBunnyPlaybackToken(playbackId, userId, ttl);
  if (!token) return null;

  // Bunny يقبل الـ token عبر query param "token" على رابط HLS
  const url =
    `https://cdn.bunnycdn.net/playback2/pna/${playbackId}/playlist.m3u8` +
    `?token=${encodeURIComponent(token)}` +
    `&no-cookie=true`;

  return {
    url,
    expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
    provider: "bunny",
  };
}

/** Thumbnail Bunny (عام). */
export function bunnyThumbnail(playbackId: string): string {
  return `https://cdn.bunnycdn.net/playback2/pna/${playbackId}/thumbnail.jpg`;
}

/** رفع فيديو إلى Bunny عبر API (من لوحة التحكم). */
export async function uploadToBunny(
  fileName: string,
  contentType: string,
  body: ArrayBuffer | Buffer,
): Promise<{ playbackId: string; assetId: number }> {
  const cfg = bunnyConfig();
  if (!cfg.apiKey) {
    throw new Error("BUNNY_API_KEY غير موجود. أضفه في متغيرات البيئة.");
  }

  // 1) إنشاء الفيديو الفارغ
  const createRes = await fetch("https://api.bunny.net/stream/v1/videos", {
    method: "POST",
    headers: {
      AccessKey: cfg.apiKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name: fileName, type: "mp4" }),
  });
  if (!createRes.ok) {
    throw new Error(`Bunny create failed: ${createRes.status} ${await createRes.text()}`);
  }
  const video = (await createRes.json()) as { id: number; guid: string };

  // 2) رفع المحتوى
  const uploadRes = await fetch(
    `https://upload.bunnycdn.com/v1/videos/${video.id}`,
    {
      method: "PUT",
      headers: {
        "Bunny-Stream-Api-Key": cfg.apiKey,
        "Content-Type": contentType,
        "Content-Length": String(body.byteLength),
      },
      body: body as BodyInit,
    },
  );
  if (!uploadRes.ok) {
    throw new Error(`Bunny upload failed: ${uploadRes.status}`);
  }

  return { playbackId: video.guid, assetId: video.id };
}

/** حذف فيديو من Bunny. */
export async function deleteFromBunny(assetId: number): Promise<void> {
  const cfg = bunnyConfig();
  if (!cfg.apiKey) return;
  await fetch(`https://api.bunny.net/stream/v1/videos/${assetId}`, {
    method: "DELETE",
    headers: { AccessKey: cfg.apiKey },
  });
}