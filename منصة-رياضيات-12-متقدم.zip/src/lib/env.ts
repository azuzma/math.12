/**
 * التحقق من متغيرات البيئة المطلوبة.
 * يُستدعى في وقت التشغيل (وليس وقت البناء) حتى لا يفشل البناء على Vercel
 * قبل أن يضيف المستخدم المفاتيح.
 */

export type EnvReport = {
  ok: boolean;
  missing: string[];
  warnings: string[];
};

const REQUIRED = ["DATABASE_URL"] as const;

const OPTIONAL = [
  { key: "AUTH_SECRET", label: "مفتاح التوقيع (AUTH_SECRET)" },
  { key: "NEXT_PUBLIC_APP_URL", label: "رابط الموقع" },
  { key: "STRIPE_SECRET_KEY", label: "Stripe — مفتاح سري" },
  { key: "STRIPE_WEBHOOK_SECRET", label: "Stripe — سر الـ webhook" },
  { key: "TELR_STORE_ID", label: "Telr — Store ID" },
  { key: "TELR_API_KEY", label: "Telr — مفتاح API" },
  { key: "RESEND_API_KEY", label: "Resend — مفتاح البريد" },
  { key: "BUNNY_STREAM_KEY", label: "Bunny Stream — مفتاح الإدارة" },
  { key: "SUPABASE_URL", label: "Supabase — رابط المشروع" },
  { key: "SUPABASE_SERVICE_ROLE_KEY", label: "Supabase — مفتاح الخدمة" },
  { key: "SMTP_HOST", label: "بريد SMTP" },
] as const;

export function checkEnv(): EnvReport {
  const missing: string[] = [];
  const warnings: string[] = [];

  for (const key of REQUIRED) {
    if (!process.env[key]) missing.push(key);
  }

  const hasStripe = Boolean(process.env.STRIPE_SECRET_KEY);
  const hasTelr = Boolean(process.env.TELR_STORE_ID && process.env.TELR_API_KEY);
  if (!hasStripe && !hasTelr) {
    warnings.push("لم يتم ربط بوابة دفع (Stripe أو Telr) — الدفع معطّل.");
  }

  const hasResend = Boolean(process.env.RESEND_API_KEY);
  const hasSmtp = Boolean(process.env.SMTP_HOST);
  if (!hasResend && !hasSmtp) {
    warnings.push("لم يتم إعداد خدمة البريد — الإيميلات لن تُرسل.");
  }

  if (!process.env.BUNNY_STREAM_AUTH_KEY) {
    warnings.push("Bunny Stream غير مُعد — روابط الفيديو الموقّعة غير متاحة.");
  }

  if (!process.env.AUTH_SECRET) {
    warnings.push("AUTH_SECRET غير موجود — سيُستخدم مفتاح تطوير مؤقت (غير صالح للإنتاج).");
  }

  return { ok: missing.length === 0, missing, warnings };
}

/** المفتاح السرّي لتوقيع الجلسات. في الإنتاج يجب ضبطه. */
export function authSecret(): Uint8Array {
  const secret =
    process.env.AUTH_SECRET ??
    (process.env.NODE_ENV === "production"
      ? undefined
      : "dev-only-secret-do-not-use-in-production-please-32-chars");
  if (!secret) {
    throw new Error(
      "AUTH_SECRET مفقود. أنشئ مفتاحًا عشوائيًا بالأمر: openssl rand -base64 48",
    );
  }
  return new TextEncoder().encode(secret);
}

export function appUrl(): string {
  const url =
    process.env.NEXT_PUBLIC_APP_URL ??
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : undefined) ??
    "http://localhost:3000";
  return url.replace(/\/$/, "");
}

export function isProduction(): boolean {
  return process.env.NODE_ENV === "production";
}