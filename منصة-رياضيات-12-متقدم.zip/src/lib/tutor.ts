/**
 * مساعد الرياضيات — محرك محلي بدون أي API خارجي.
 *
 * المنهج: لا يعطي الإجابة النهائية مباشرة، بل:
 *   1) يحدد نوع المسألة والقانون المناسب
 *   2) يشرح الفكرة بلغة الطالب
 *   3) يشرح الخطوات مرقّمة
 *   4) يعطي مثالًا مشابهًا
 *   5) يختبر فهم الطالب بسؤال متابعة
 *
 * البنية جاهزة للربط بمزوّد ذكاء اصطناعي لاحقًا عبر `tutorProvider`:
 * استبدل `localTutor` بـ `aiTutor` وسيعمل كل شيء كما هو.
 */

import { PLATFORM } from "@/lib/platform";

export type TutorStep = {
  /** رقم الخطوة */
  n: number;
  title: string;
  detail: string;
};

export type TutorResponse = {
  /** ما فهمه المساعد من السؤال */
  understood: string;
  /** الموضوع/المهارة */
  topic: string;
  /** القانون أو القاعدة المستخدمة */
  law: string;
  /** شرح الفكرة */
  idea: string;
  /** الخطوات مرقّمة */
  steps: TutorStep[];
  /** مثال مشابه */
  example: { question: string; solution: string };
  /** سؤال لاختبار فهم الطالب */
  check: { question: string; hint: string };
  /** روابط للمنهج المرتبط */
  related: { title: string; href: string }[];
  /** تنبيه: ما لم يفهمه المساعد */
  needsClarification?: string;
};

/* ============================================================
   1) تحديد نوع المسألة (Intent Detection)
   ============================================================ */

type Intent =
  | "DERIVATIVE"
  | "INTEGRAL"
  | "LIMIT"
  | "SEQUENCE"
  | "TRIGONOMETRY"
  | "EQUATION"
  | "PROBABILITY"
  | "VECTOR"
  | "GENERIC";

type Rule = {
  intent: Intent;
  topic: string;
  law: string;
  keywords: string[];
};

const RULES: Rule[] = [
  {
    intent: "DERIVATIVE",
    topic: "المشتقة والتفاضل",
    law: "قواعد الاشتقاق الأساسية: f′(x) = lim (f(x+h) − f(x))/h، وقاعدة السلسلة",
    keywords: [
      "اشتق",
      "مشتقة",
      "مشتق",
      "قاعدة السلسلة",
      "derivative",
      "derive",
      "القيم الحرجة",
      "النقاط الحرجة",
      "أقصى قيمة",
      "أصغر قيمة",
      "القيم العظمى",
      "القيم الصغرى",
      "التحليل الأمثل",
      "نقطة حرجة",
    ],
  },
  {
    intent: "INTEGRAL",
    topic: "التكامل",
    law: "التكامل عكس الاشتقاق: ∫ f(x) dx = F(x) + C حيث F′ = f",
    keywords: [
      "تكامل",
      "أ integrating",
      "integral",
      "integrate",
      "∫",
      "antiderivative",
      "المساحة تحت",
      "between curves",
      "مساحة",
          ],
  },
  {
    intent: "LIMIT",
    topic: "النهايات",
    law: "تعريف النهاية: lim(x→a) f(x) = L إذا اقتربت f(x) من L عندما يقترب x من a",
    keywords: ["نهاية", " limite", "limit", "lim", "لا نهائي", "infinity", "مستمرة"],
  },
  {
    intent: "SEQUENCE",
    topic: "المتتاليات",
    law: "المتتالية الحسابية: aₙ = a₁ + (n−1)d | الهندسية: aₙ = a₁rⁿ⁻¹",
    keywords: [
      "متتالية",
      "متتاليات",
      "فيبوناتشي",
      "الحد العام",
      "الحد النوني",
      "مجموع جزئي",
      "متسلسلة",
      "متوال",
      "الحد المتسلسل",
      "sequence",
      "fibonacci",
      "geometric",
      "arithmetic",
    ],
  },
  {
    intent: "TRIGONOMETRY",
    topic: "النسب المثلثية",
    law: "sin²θ + cos²θ = 1 | sec²θ = 1 + tan²θ | 1 + tan²θ = sec²θ",
    keywords: [
      "جيب",
      "جيب تمام",
      "ظل",
      "ظل تمام",
      "/sec",
      "cot",
      "tan",
      "sin",
      "cos",
      "مثلث",
      "معادلة مثلثية",
      "trigonometric",
      "دالة عكسية",
    ],
  },
  {
    intent: "PROBABILITY",
    topic: "الإحصاء والاحتمالات",
    law: "P(A) = عدد الحالات المرضية / عدد الحالات الكلية",
    keywords: ["احتمال", "احتمالات", " probab", "متغير عشوائي", "توزيع"],
  },
  {
    intent: "VECTOR",
    topic: "المتجهات",
    law: "مقدار المتجه ‖a‖ = √(x² + y²) | الزاوية: θ = arctan(y/x)",
    keywords: ["متجه", "متجهات", "vector", "Components", "اتجاه"],
  },
  {
    intent: "EQUATION",
    topic: "حل المعادلات",
    law: "انقل الحدود ثم عامل، أو استخدم القسمة على كثيرات الحدود",
    keywords: ["حل المعادلة", "معادلة", "equation", "solve", "جذر", "أصل"],
  },
];

function detectIntent(text: string): { rule: Rule | null; score: number } {
  const lower = text.toLowerCase();
  let best: { rule: Rule; score: number } | null = null;

  for (const rule of RULES) {
    let score = 0;
    for (const kw of rule.keywords) {
      if (lower.includes(kw.toLowerCase())) score += kw.length;
    }
    if (score > 0 && (!best || score > best.score)) {
      best = { rule, score };
    }
  }

  return { rule: best?.rule ?? null, score: best?.score ?? 0 };
}

/* ============================================================
   2) استخراج التعبير الرياضي من نص الطالب
   ============================================================ */

type Parsed = {
  /** التعبير مثل x^3 - 4x */
  expr: string;
  /** المتغير */
  variable: string;
};

function extractExpression(text: string): Parsed | null {
  // يلتقط أنماط مثل: x^3 - 4x + 2 ، f(x) = ... ، sin(x)
  const patterns = [
    /(?:f\(x\)\s*=\s*|y\s*=\s*|h\(x\)\s*=\s*|g\(x\)\s*=\s*)([^،.؟\n]+)/i,
    /([0-9a-z\^\+\-\*\/\(\)\s]{3,})/i,
  ];

  for (const p of patterns) {
    const m = text.match(p);
    if (m?.[1]) {
      const expr = m[1].trim().replace(/\s+/g, " ");
      if (expr.length >= 2) {
        const variable = /\b([a-z])\b/i.exec(expr.replace(/[0-9]/g, ""))?.[1] ?? "x";
        return { expr, variable: variable ?? "x" };
      }
    }
  }
  return null;
}

/* ============================================================
   3) المولّدات pedagogical
   ============================================================ */

function explainDerivative(parsed: Parsed | null): TutorResponse {
  const expr = parsed?.expr ?? "دالتك";
  return {
    understood: `سأشرح لك كيف نشتق ${expr}`,
    topic: "المشتقة والتفاضل",
    law: "قاعدة القوة: d/dx(xⁿ) = n·xⁿ⁻¹ | قاعدة الجداء: (uv)′ = u′v + uv′ | خارج القسمة: (u/v)′ = (u′v − uv′)/v² | السلسلة: dy/dx = dy/du × du/dx",
    idea:
      "المشتقة هي «معدل التغير اللحظي». تخيّل أنك تقود سيارة: السرعة هي نسبة التغير في المسافة إلى نسبة التغير في الزمن. نضعها رياضيًا: عند كل نقطة نحسب الميل، ثم نجمع هذه الميلات في دالة جديدة تسمى المشتقة.",
    steps: [
      {
        n: 1,
        title: "حدّد نوع التعبير",
        detail: `نكتب ${expr} ونرى أنه يتكون من حدود: حدود جبرية (xⁿ) • (معاملات) ضرب/قسمة • دوال مركبة تحتاج قاعدة السلسلة.`,
      },
      {
        n: 2,
        title: "اشتق كل حد على حدة",
        detail:
          "طبّق قاعدة القوة على كل حد يحمل المتغير: xⁿ ← n·xⁿ⁻¹. الثوابت (الأعداد) مشتقتها صفر.",
      },
      {
        n: 3,
        title: "عالج الجداء والقسمة",
        detail:
          "إن كان هناك حاصل ضرب استعمل قاعدة الجداء (uv)′ = u′v + uv′، وإن كان حاصل قسمة استعمل (u/v)′ = (u′v − uv′)/v².",
      },
      {
        n: 4,
        title: "إذا كان الدالة مركّبة استعمل السلسلة",
        detail:
          "إذا رأيت دالة داخل دالة (مثل sin(x²))، اشتق الدالة الخارجية أولًا ثم اضرب في مشتقة الداخلية: d/dx sin(u) = cos(u) · u′.",
      },
      {
        n: 5,
        title: "بسّط النتيجة",
        detail:
          "اجمع الحدود المتشابهة إن أمكن، واستخدم الهوية 2ab = a² − b² إن ظهر الجذر.",
      },
    ],
    example: {
      question: "أوجد مشتقة f(x) = (3x + 1)⁴",
      solution:
        "الخطوة 1: هي دالة مركّبة → قاعدة السلسلة.\nالخطوة 2: مشتقة الخارج: 4(3x+1)³.\nالخطوة 3: مشتقة الداخل: 3.\nالخطوة 4: اضرب: f′(x) = 4(3x+1)³ × 3 = 12(3x+1)³.",
    },
    check: {
      question: "جرّب بنفسك: ما مشتقة g(x) = x⁴ − 3x + 7 ؟",
      hint: "استعمل قاعدة القوة على حدّي x⁴ و −3x، وتذكّر أن مشتقة الثابت 7 هي صفر.",
    },
    related: [
      { title: "درس: قواعد الاشتقاق الأساسية", href: "/dashboard/lessons" },
      { title: "درس: قاعدة السلسلة", href: "/dashboard/lessons" },
    ],
  };
}

function explainIntegral(parsed: Parsed | null): TutorResponse {
  const expr = parsed?.expr ?? "الدالة";
  return {
    understood: `سأشرح لك كيف نتكامل ${expr}`,
    topic: "التكامل",
    law: "التكامل عكس الاشتقاق: نبحث عن دالة F بحيث F′ = f | جدول أساسي: ∫xⁿdx = xⁿ⁺¹/(n+1) | ∫(1/x)dx = ln|x| | ∫eˣdx = eˣ",
    idea:
      "التكامل هو العملية العكسية للمشتقاق تمامًا كما أن السرعة عكس المسافة: إذا أعطاك المشتق «السرعة» من «المسافة» فإن التكامل يعطيك «المسافة» من «السرعة».",
    steps: [
      {
        n: 1,
        title: "اكتب التكامل المحدد أو غير المحدد",
        detail:
          "غير المحدد: ∫f(x)dx = F(x) + C. المحدد: ∫[a→b] f(x)dx = F(b) − F(a).",
      },
      {
        n: 2,
        title: "جد الدالة الأصلية",
        detail:
          "ابحث عن دالة مشتقتها هي f(x). زِد الأس واحدًا واقسم على الأس الجديد.",
      },
      {
        n: 3,
        title: "لا تنسَ ثابت التكامل +C",
        detail: "في التكامل غير المحدد نضيف +C دائمًا، لأن مشتققة الثابت صفر.",
      },
      {
        n: 4,
        title: "في المحدد: اطرح عند الحد الأعلى",
        detail: "عوّض في F عند b ثم اطرح F عند a. لا يوجد ثابت C هنا.",
      },
      {
        n: 5,
        title: "للمساحات لا للاشتقاق المباشر",
        detail:
          "مساحة تحت المنحنى = ∫[a→b] f(x)dx عندما f موجبة. وبين منحنيين = تكامل الفرق.",
      },
    ],
    example: {
      question: "احسب ∫[0→1] x² dx",
      solution:
        "الخطوة 1: ابحث عن أصل x².\nالخطوة 2: X=x³/3.\nالخطوة 3: عند 1: 1/3. عند 0: 0.\nالخطوة 4: الفرق = 1/3 − 0 = 1/3.",
    },
    check: {
      question: "جرّب: ما التكامل غير المحدد لـ 4x dx ؟",
      hint: "الأصل جبراني؟ أم لوغاريتمي؟ انتبه: مشتقة 4x هي 4، فنبحث عن ثابت مثل x.",
    },
    related: [
      { title: "درس: مقدمة في التكامل", href: "/dashboard/lessons" },
      { title: "درس: التكامل المحدد", href: "/dashboard/lessons" },
    ],
  };
}

function explainSequence(parsed: Parsed | null): TutorResponse {
  const expr = parsed?.expr ?? "المتتالية";
  return {
    understood: `سأشرح لك طريقة التعامل مع ${expr}`,
    topic: "المتتاليات",
    law: "الحسابية: aₙ = a₁ + (n−1)d و Sₙ = n/2[2a₁ + (n−1)d] | الهندسية: aₙ = a₁rⁿ⁻¹",
    idea:
      "المتتالية هي سلسلة مرتبة من الأعداد. المفتاح أولًا: هل الفرق بين كل حدين ثابت (حسابية) أم النسبة ثابتة (هندسية)؟ هذا يحدد الصيغة كلها.",
    steps: [
      {
        n: 1,
        title: "صنّف المتتالية",
        detail:
          "احسب الفرق a₂−a₁ ثم a₃−a₂. لو تساوىا فهي حسابية (القيمة d). وإلا احسب النسبة a₂/a₁ — لو تساوىت فهي هندسية (القيمة r).",
      },
      {
        n: 2,
        title: "اكتب الحد النوني",
        detail:
          "حسابية: aₙ = a₁ + (n−1)d. هندسية: aₙ = a₁ · rⁿ⁻¹.",
      },
      {
        n: 3,
        title: "للـ a₅ استعمل n = 5 مباشرة",
        detail: "لا تجمع من البداية — ضع n في الصيغة مباشرة.",
      },
      {
        n: 4,
        title: "للمجموع Sₙ استعمل صيغة المجموع",
        detail:
          "حسابية: Sₙ = n/2[2a₁ + (n−1)d] أو n/2(a₁ + aₙ). هندسية: Sₙ = a₁(rⁿ−1)/(r−1).",
      },
      {
        n: 5,
        title: "شرط التقارب",
        detail: "المجموع اللانهائي للهندسية موجود فقط إذا |r| < 1.",
      },
    ],
    example: {
      question: "أوجد a₁₀ في متتالية حسابية a₁ = 5 و d = 3",
      solution:
        "a₁₀ = a₁ + 9d = 5 + 27 = 32.",
    },
    check: {
      question: "العدّ: 1، 4، 7، 10، … هل هي حسابية أم هندسية؟ وأوجد a₂₀.",
      hint: "احسب 4−1 و 7−4. متساويان؟",
    },
    related: [
      { title: "درس: المتتاليات الحسابية", href: "/dashboard/lessons" },
      { title: "درس: المتتاليات الهندسية", href: "/dashboard/lessons" },
    ],
  };
}

function explainTrig(parsed: Parsed | null): TutorResponse {
  return {
    understood: `سأشرح النسب المثلثية${parsed ? ` في ${parsed.expr}` : ""}`,
    topic: "النسب المثلثية والدوال العكسية",
    law: "sin²θ + cos²θ = 1 | 1 + tan²θ = sec²θ | 1 + cot²θ = csc²θ | cos(π − θ) = −cos θ",
    idea:
      "النسب المثلثية تربط أضلاع المثلث القائم بالمثلث المحيط (دائرة الوحدة). كل دالة لها مجال ومدى محدد، وهذا هو مفتاح حل المسائل.",
    steps: [
      {
        n: 1,
        title: "حدّد المثلث",
        detail:
          "ارسم المثلث إن أمكن، وحدّد الضلع المقابل والقابل والمجاور نسبة للزاوية المطلوبة.",
      },
      {
        n: 2,
        title: "اختر النسبة المناسبة",
        detail:
          "sin = مقابل/وتر · cos = قابل/وتر · tan = مقابل/قابل. المقلوبة: csc=1/sin · sec=1/cos · cot=1/tan.",
      },
      {
        n: 3,
        title: "استعمل هوية بايكاغور لإيجاد المجهول",
        detail: "sin² + cos² = 1. إذا عرفت sin و cos Squared فقط، طبّق الهوية.",
      },
      {
        n: 4,
        title: "للدوال العكسية راعِ المجال",
        detail:
          "أرSin ∈ [−π/2, π/2]. لذلك عند حلّك معادلة، تحقّق دائمًا أن إجابتك ضمن المجال.",
      },
    ],
    example: {
      question: "في مثلث قائم، sin θ = 3/5. أوجد cos θ و tan θ.",
      solution:
        "المثلث 3-4-5 (فيثاغورس).\ncos θ = 4/5 (الضلع القابل/الوتر).\ntan θ = 3/4 (المقابل/القابل).",
    },
    check: {
      question: "ما قيمة sin²θ + cos²θ لأي زاوية θ ؟",
      hint: "هذه أشهر هوية في المثلثات — ستستخدمها كثيرًا.",
    },
    related: [
      { title: "درس: النسب المثلثية في المثلث القائم", href: "/dashboard/lessons" },
      { title: "درس: المتطابقات المثلثية", href: "/dashboard/lessons" },
    ],
  };
}

function explainLimit(parsed: Parsed | null): TutorResponse {
  return {
    understood: `سأشرح لك حدود ${parsed?.expr ?? "الدالة"}`,
    topic: "النهايات",
    law: "lim(x→a) f(x) = L | lim(x→∞) xⁿ = ∞ (n>0) | lim(x→∞) 1/xⁿ = 0",
    idea:
      "النهاية تسأل: «إذا اقترب x من a كثيرًا، إلى أين تتجه f(x)؟» لا نحسب f(a) — لأن f(a) قد لا تكون معرّفة أصلًا.",
    steps: [
      {
        n: 1,
        title: "جرّب التعويض المباشر أولًا",
        detail: "عوّض x = a. إن أعطى عددًا finitًا فهو النهاية.",
      },
      {
        n: 2,
        title: "إن ظهر 0/0 أو ∞/∞",
        detail: "هذه حالة عدم اليقين — لا تعني وجود اللانهاية. نحتاج معالجة.",
      },
      {
        n: 3,
        title: "حلل العامل المشترك (التحليل)",
        detail: "احسب نهاية كل عامل على حدة. مثال: (x²−4)/(x−2) عند x=2 ← (x+2) عند 2 = 4.",
      },
      {
        n: 4,
        title: "استعمل اللوغاريتم للأسس",
        detail:
          "إن كان الحد من الشكل a^(1/x) عند x→0 خذ ln ثم طبّق النهاية على ln a / x.",
      },
      {
        n: 5,
        title: "للمشتقات استعمل L'Hôpital",
        detail: "عند 0/0 أو ∞/∞ اشتق البسط والمقام وأعد المحاولة (إن كان الحد موجودًا).",
      },
    ],
    example: {
      question: "احسب lim(x→2) (x² − 4)/(x − 2)",
      solution:
        "الخطوة 1: تعويض مباشر = 0/0 (حالة عدم يقين).\nالخطوة 2: حلّل إلى (x−2)(x+2)/(x−2).\nالخطوة 3: ألغِ (x−2).\nالخطوة 4: النهاية = lim(x+2) = 4.",
    },
    check: {
      question: "احسب lim(x→0) sin(3x)/x",
      hint: "استعمل lim(sin u)/u = 1، ثم عوّض u = 3x.",
    },
    related: [{ title: "درس: مفهوم النهاية", href: "/dashboard/lessons" }],
  };
}

function explainGeneric(parsed: Parsed | null): TutorResponse {
  return {
    understood: parsed
      ? `سأساعدك في حل ${parsed.expr}`
      : "سأساعدك في الحل خطوة بخطوة",
    topic: "مهارات رياضيات الصف 12 متقدم",
    law: "كل مسألة تُحل بخطوات: افهم → خطّط → نفّذ → تحقق",
    idea:
      "قبل الحل الحسابي، تأكد أنك فهمت السؤال: ما المطلوب بالضبط؟ وما المعطيات؟ حل المسألة على ورقة، وتوقّع شكل الإجابة قبل الحساب — هذا يقلل الأخطاء كثيرًا.",
    steps: [
      {
        n: 1,
        title: "اقرأ وافهم",
        detail: "أعد صياغة السؤال بكلماتك. ما المطلوب؟ وما المعطى؟",
      },
      {
        n: 2,
        title: "اختر الطريقة",
        detail:
          "هل تحتاج مشتقة؟ تكامل؟ معادلة؟ متطابقة المثلثية؟ راجع قائمة المهارات في بنك الأسئلة لتحديد الموقع.",
      },
      {
        n: 3,
        title: "نفّذ خطوة بخطوة",
        detail: "لا تقفز خطوات. اكتب كل سطر على حدة.",
      },
      {
        n: 4,
        title: "تحقق من الجواب",
        detail:
          "هل الناتج معقول من حيث الإشارة والقيمة؟ عوّض في السؤال. هل الوحدة منطقية؟",
      },
    ],
    example: {
      question: "كيف أبدأ في مسألة مسألة غير مألوفة؟",
      solution:
        "1) اكتب ما هو مطلوب بدقّة.\n2) اكتب المعطيات.\n3) اسأل: ما نوع المسألة؟ (مشتقة/تكامل/معادلة).\n4) اكتب الصيغة أو القانون المرتبط.\n5) طبّق ثم تحقق.",
    },
    check: {
      question: "اكتب المسألة التي تحلّها الآن (بصيغتك) — وأخبرني ما المطلوب فيها بالتحديد.",
      hint: "اكتب السؤال كاملًا كما ورد في الكتاب أو الواجب.",
    },
    related: [
      { title: "تصفح دروس المنهج", href: "/dashboard/lessons" },
      { title: "بنك الأسئلة", href: "/dashboard/question-bank" },
    ],
    needsClarification: "لم أتأكد من نوع المسألة بالضبط — أرسل السؤال كاملًا مع الصورة إن أمكن.",
  };
}

/* ============================================================
   4) المولّد الرئيسي
   ============================================================ */

const GENERATORS: Record<Intent, (p: Parsed | null) => TutorResponse> = {
  DERIVATIVE: explainDerivative,
  INTEGRAL: explainIntegral,
  SEQUENCE: explainSequence,
  TRIGONOMETRY: explainTrig,
  LIMIT: explainLimit,
  EQUATION: explainGeneric,
  PROBABILITY: explainGeneric,
  VECTOR: explainGeneric,
  GENERIC: explainGeneric,
};

/**
 * توليد رد المساعد على سؤال الطالب.
 * لا يعطي الإجابة النهائية — يعطي الفكرة والقانون والخطوات ومثالًا مطابقًا.
 */
export function localTutor(question: string): TutorResponse {
  const text = question.trim();

  if (text.length < 3) {
    return {
      ...explainGeneric(null),
      understood: "لم يصلني سؤال واضح",
      needsClarification:
        "اكتب السؤال كاملًا (مثلًا: أوجد مشتقة f(x) = x³ − 4x) وسأشرحلك خطوة بخطوة.",
    };
  }

  const { rule, score } = detectIntent(text);
  const parsed = extractExpression(text);

  // إذا كانت المطابقة ضعيفة جداً نستخدم العامل
  const intent: Intent = rule && score >= 3 ? rule.intent : "GENERIC";
  const response = GENERATORS[intent](parsed);

  // إذا كان ردّ العامل فقط، نضيف اقتراح الموضوع المرجّح
  if (intent === "GENERIC" && rule && score > 0) {
    return {
      ...response,
      topic: rule.topic,
      law: rule.law,
      needsClarification: `يبدو أن سؤالك عن «${rule.topic}». هل هذا صحيح؟ وإن كان كذلك أعد كتابة السؤال بتلك المصطلحات لأشرحه بدقة أكبر.`,
    };
  }

  return response;
}

/** رسائل ترحيب وتوجيه. */
export function tutorGreeting(): TutorResponse {
  return {
    understood: "مرحبًا! أنا مساعدك في رياضيات الصف 12 متقدم.",
    topic: PLATFORM.subjectNameAr,
    law: "كل مسألة في المنهج لها قانون واحد ينظّم الحل.",
    idea: `أرسل لي أي مسألة من منهج ${PLATFORM.gradeNameAr} وسأشرح لك: الفكرة، القانون، الخطوات، ثم مثال مشابه، ثم أختبر فهمك بسؤال متابعة. لن أعطيك الإجابة النهائية مباشرة — الهدف أن تفهم الخطوة.`,
    steps: [],
    example: {
      question: "أمثلة على أسئلة أقدر أساعدك فيها:",
      solution:
        "• أوجد مشتقة f(x) = (2x + 1)⁵\n• احسب ∫[1→3] (2x + 1) dx\n• أوجد الحد العاشر في متتالية حسابية\n• أوجد cos θ إذا كان sin θ = 3/5",
    },
    check: {
      question: "ابدأ بأول سؤال من منهجك — من أي وحدة؟",
      hint: "اكتب السؤال كاملًا كما ورد في الكتاب.",
    },
    related: [
      { title: "دروسي", href: "/dashboard/lessons" },
      { title: "بنك الأسئلة", href: "/dashboard/question-bank" },
    ],
  };
}

/**
 * واجهة مزوّد المساعد.
 * لاستخدام API خارجي لاحقًا: أنشئ `aiTutor` يحقّق نفس التواقيع
 * ثم بدّل `activeTutor` في api/tutor/route.ts.
 */
export type TutorProvider = (question: string) => Promise<TutorResponse>;

export const activeTutor: TutorProvider = async (question: string) =>
  localTutor(question);