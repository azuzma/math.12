/**
 * التحليل الذكي لمستوى طالب الصف 12 متقدم.
 *
 * يقرأ من قاعدة البيانات: محاولات الاختبارات، تقدم الدروس، ونسب الإجابة
 * لكل مهارة، ثم يبني:
 *   1) ملخصًا عامًا (المستوى، نقاط القوة، نقاط الضعف)
 *   2) تحليلًا على مستوى الوحدة والمهارة
 *   3) توصيات خطوات عملية مرتّبة حسب الأولوية
 */

import "server-only";
import { prisma } from "@/lib/db/prisma";
import { PLATFORM } from "@/lib/platform";
import { gradeAnswer } from "@/lib/grading";

export type SkillStat = {
  skillId: string;
  skillTitle: string;
  unitTitle: string;
  termTitle: string;
  lessonId: string | null;
  lessonTitle: string | null;
  attempted: number;
  correct: number;
  accuracy: number; // 0..100
};

export type UnitStat = {
  unitId: string;
  unitTitle: string;
  termTitle: string;
  termId: string | null;
  lessonsCompleted: number;
  lessonsTotal: number;
  examAverage: number | null;
  skillAccuracy: number | null;
};

export type Recommendation = {
  priority: 1 | 2 | 3;
  title: string;
  reason: string;
  href: string;
  cta: string;
  kind: "REVIEW_LESSON" | "WATCH_VIDEO" | "SOLVE_WORKSHEET" | "PRACTICE_QUESTIONS" | "TAKE_QUIZ" | "START";
};

export type AnalysisResult = {
  /** null = لم يخض بعد */
  overall: {
    level: "ممتاز" | "جيد جدًا" | "جيد" | "يحتاج تحسين" | "لم يبدأ";
    levelColor: string;
    percentage: number;
    attempts: number;
    passedCount: number;
    lessonsCompleted: number;
    lessonsTotal: number;
    curriculumPercent: number;
  } | null;

  strengths: SkillStat[];
  weaknesses: SkillStat[];
  units: UnitStat[];

  /** الرسالة التي تظهر أعلى الصفحة */
  headline: string;
  recommendations: Recommendation[];
};

/**
 * حساب التحليل الكامل لطالب.
 */
export async function analyzeStudent(studentId: string): Promise<AnalysisResult> {
  const empty: AnalysisResult = {
    overall: null,
    strengths: [],
    weaknesses: [],
    units: [],
    headline: "ابدأ أول اختبار لتظهر تحليلات مستواك هنا.",
    recommendations: [],
  };

  // 1) المقرر
  const course = await prisma.course.findFirst({
    where: { slug: PLATFORM.courseSlug },
    select: { id: true },
  });
  if (!course) return empty;

  // 2) الفصول ← الوحدات ← المهارات
  const termList = await prisma.term.findMany({
    where: { courseId: course.id, status: "PUBLISHED" },
    orderBy: { order: "asc" },
    select: {
      id: true,
      title: true,
      units: {
        where: { status: "PUBLISHED" },
        orderBy: { order: "asc" },
        select: {
          id: true,
          title: true,
          skills: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            select: {
              id: true,
              title: true,
              lessons: {
                where: { status: "PUBLISHED" },
                orderBy: { order: "asc" },
                select: { id: true, title: true, slug: true },
              },
            },
          },
          lessons: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            select: { id: true, title: true, slug: true },
          },
        },
      },
    },
  });

  if (termList.length === 0) return empty;

  const lessonsTotal = termList.reduce(
    (sum, t) => sum + t.units.reduce((s, u) => s + u.lessons.length, 0),
    0,
  );

  /* ---------- اجمع كل الأسئلة مع سياقها ---------- */

  const allSkills = termList.flatMap((term) =>
    term.units.flatMap((unit) =>
      unit.skills.map((skill) => ({
        skillId: skill.id,
        skillTitle: skill.title,
        unitId: unit.id,
        unitTitle: unit.title,
        termId: term.id,
        termTitle: term.title,
        lessons: skill.lessons,
      })),
    ),
  );

  const skillById = new Map(allSkills.map((s) => [s.skillId, s]));

  const allQuestionIds = await prisma.question.findMany({
    where: { skillId: { in: allSkills.map((s) => s.skillId) }, isActive: true },
    select: { id: true, skillId: true },
  });
  const questionSkill = new Map(allQuestionIds.map((q) => [q.id, q.skillId]));

  /* ---------- المحاولات ---------- */

  const attempts = await prisma.examAttempt.findMany({
    where: { studentId: studentId, submittedAt: { gte: new Date("2000-01-01") } },
    include: {
      exam: {
        select: {
          id: true,
          title: true,
          unitId: true,
          termId: true,
          questions: {
            include: {
              question: {
                select: {
                  id: true,
                  skillId: true,
                  type: true,
                  correct: true,
                },
              },
            },
          },
        },
      },
    },
    orderBy: { submittedAt: "desc" },
    take: 60,
  });

  const completedLessons = await prisma.lessonProgress.findMany({
    where: { studentId: studentId, completed: true },
    select: { lessonId: true },
  });
  const completedSet = new Set(completedLessons.map((l) => l.lessonId));

  /* ---------- إحصاء لكل مهارة ---------- */

  const stats = new Map<string, { attempted: number; correct: number }>();

  for (const attempt of attempts) {
    const answers =
      attempt.answers && typeof attempt.answers === "object"
        ? (attempt.answers as Record<string, unknown>)
        : {};

    for (const eq of attempt.exam.questions) {
      const q = eq.question;
      const skillId = q.skillId ?? questionSkill.get(q.id);
      if (!skillId) continue;

      const entry = stats.get(skillId) ?? { attempted: 0, correct: 0 };
      entry.attempted++;
      const graded = gradeAnswer(q.type, answers[q.id] ?? null, q.correct, null);
      if (graded.isCorrect) entry.correct++;
      stats.set(skillId, entry);
    }
  }

  const skillStats: SkillStat[] = [];
  for (const s of allSkills) {
    const st = stats.get(s.skillId);
    if (!st || st.attempted === 0) continue;
    const lesson = s.lessons[0] ?? null;
    skillStats.push({
      skillId: s.skillId,
      skillTitle: s.skillTitle,
      unitTitle: s.unitTitle,
      termTitle: s.termTitle,
      lessonId: lesson?.id ?? null,
      lessonTitle: lesson?.title ?? null,
      attempted: st.attempted,
      correct: st.correct,
      accuracy: Math.round((st.correct / st.attempted) * 100),
    });
  }

  /* ---------- تحليل الوحدات ---------- */

  const units: UnitStat[] = [];
  for (const term of termList) {
    for (const unit of term.units) {
      const unitSkillIds = unit.skills.map((s) => s.id);
      const unitAttempts = attempts.filter(
        (a) => a.exam.unitId === unit.id || a.exam.termId === term.id,
      );

      const relevant = unitSkillIds
        .map((id) => skillStats.find((s) => s.skillId === id))
        .filter((x): x is SkillStat => Boolean(x));

      const totalQ = relevant.reduce((s, x) => s + x.attempted, 0);
      const totalC = relevant.reduce((s, x) => s + x.correct, 0);

      const examAvg = unitAttempts.length
        ? Math.round(
            unitAttempts.reduce((s, a) => s + a.percentage, 0) / unitAttempts.length,
          )
        : null;

      units.push({
        unitId: unit.id,
        unitTitle: unit.title,
        termTitle: term.title,
        termId: term.id,
        lessonsCompleted: unit.lessons.filter((l) => completedSet.has(l.id)).length,
        lessonsTotal: unit.lessons.length,
        examAverage: examAvg,
        skillAccuracy: totalQ > 0 ? Math.round((totalC / totalQ) * 100) : null,
      });
    }
  }

  /* ---------- الملخص العام ---------- */

  if (attempts.length === 0 && completedSet.size === 0) {
    return {
      ...empty,
      units,
      recommendations: [
        {
          priority: 1,
          title: `ابدأ بدرس «${termList[0]?.units[0]?.lessons[0]?.title ?? "الدرس الأول"}»`,
          reason: "لم تبدأ أي درس أو اختبار بعد.",
          href: "/dashboard/lessons",
          cta: "تصفح الدروس",
          kind: "START",
        },
      ],
    };
  }

  const average = attempts.length
    ? Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)
    : 0;
  const passedCount = attempts.filter((a) => a.passed).length;
  const curriculumPercent = lessonsTotal
    ? Math.round((completedSet.size / lessonsTotal) * 100)
    : 0;

  const level =
    average >= 90
      ? ("ممتاز" as const)
      : average >= 75
        ? ("جيد جدًا" as const)
        : average >= 60
          ? ("جيد" as const)
          : ("يحتاج تحسين" as const);

  const levelColor =
    average >= 85
      ? "text-emerald-600"
      : average >= 65
        ? "text-brand-600"
        : "text-amber-600";

  /* ---------- نقاط القوة والضعف ---------- */

  const sorted = [...skillStats].sort((a, b) => b.accuracy - a.accuracy);
  const withData = sorted.filter((s) => s.attempted >= 2);
  const strengths = withData.filter((s) => s.accuracy >= 75).slice(0, 5);
  const weaknesses = withData.filter((s) => s.accuracy < 60).slice(0, 6);

  /* ---------- التوصيات ---------- */

  const recommendations: Recommendation[] = [];

  // 1) أضعف مهارة
  const weakest = weaknesses[0];
  if (weakest && weakest.lessonId) {
    recommendations.push({
      priority: 1,
      title: `راجع «${weakest.lessonTitle ?? weakest.skillTitle}»`,
      reason: `نسبة إجاباتك الصحيحة في مهارة «${weakest.skillTitle}» ${weakest.accuracy}% (${weakest.correct} من ${weakest.attempted}).`,
      href: `/dashboard/lessons`,
      cta: "مراجعة الدرس",
      kind: "REVIEW_LESSON",
    });
  }

  // 2) أوراق عمل للوحدة الأضعف
  const weakUnit = units
    .filter((u) => u.skillAccuracy !== null && u.skillAccuracy < 65)
    .sort((a, b) => (a.skillAccuracy ?? 0) - (b.skillAccuracy ?? 0))[0];

  if (weakUnit) {
    recommendations.push({
      priority: 2,
      title: `حل ورقة عمل وحدة «${weakUnit.unitTitle.replace(/^الوحدة [^:]+:\s*/, "")}»`,
      reason: `دقة إجاباتك في هذه الوحدة ${weakUnit.skillAccuracy}% — الألواح العملية ترفع الفهم أكثر من المشاهدة.`,
      href: "/dashboard/worksheets",
      cta: "أوراق العمل",
      kind: "SOLVE_WORKSHEET",
    });
  }

  // 3) تدريب على الأسئلة
  if (weakest) {
    recommendations.push({
      priority: 2,
      title: `حل 10 أسئلة على «${weakest.skillTitle}»`,
      reason: "التدريب المباشر على أسئلة المهارة نفسها أسرع طريق لإتقانها.",
      href: `/dashboard/question-bank?skill=${weakest.skillId}`,
      cta: "بنك الأسئلة",
      kind: "PRACTICE_QUESTIONS",
    });
  }

  // 4) اختبار قصير
  const weakUnitId = weakUnit?.unitId;
  recommendations.push({
    priority: 3,
    title: "اختبار قصير على الوحدة الضعيفة",
    reason: "اختبر نفسك بعد المراجعة لترى هل ثبت الفهم فعلًا.",
    href: weakUnitId
      ? `/dashboard/exams?unit=${weakUnitId}`
      : "/dashboard/exams",
    cta: "ابدأ الاختبار",
    kind: "TAKE_QUIZ",
  });

  // 5) إكمال المنهج إن كان التقدم بطيئًا
  if (curriculumPercent < 40 && lessonsTotal > 0) {
    const nextLesson = termList.flatMap((t) => t.units.flatMap((u) => u.lessons))
      .find((l) => !completedSet.has(l.id));
    if (nextLesson) {
      recommendations.push({
        priority: 1,
        title: `أكمل منهج «${nextLesson.title}»`,
        reason: `أكملت ${curriculumPercent}% فقط من المنهج (${completedSet.size} من ${lessonsTotal} درس).`,
        href: "/dashboard/lessons",
        cta: "متابعة الدرس",
        kind: "WATCH_VIDEO",
      });
    }
  }

  /* ---------- الرسالة الرئيسية ---------- */

  let headline: string;
  if (attempts.length === 0) {
    headline = "أنت لم تخض أي اختبار بعد — ابدأ باختبار درس لتظهر تحليلاتك.";
  } else if (weakest && weaknesses.length > 0) {
    const bestUnit = units
      .filter((u) => u.examAverage !== null)
      .sort((a, b) => (b.examAverage ?? 0) - (a.examAverage ?? 0))[0];
    headline =
      `أداءك ${average >= 85 ? "ممتاز" : average >= 65 ? "جيد" : "يحتاج إلى مراجعة"} في ${
        PLATFORM.gradeShort
      }. ` +
      (bestUnit
        ? `أداؤك الأقوى في «${bestUnit.unitTitle.replace(/^الوحدة [^:]+:\s*/, "")}». `
        : "") +
      `تحتاج إلى مراجعة موضوع «${weakest.skillTitle}».`;
  } else if (average >= 85) {
    headline = `ممتاز! تجيد منهج ${PLATFORM.gradeShort}. حافظ على مستواك باختبارات مراجعة دورية.`;
  } else {
    headline = `أداءك جيد في ${PLATFORM.gradeShort}.واصل التدريب على المهارات المتبقية.`;
  }

  return {
    overall: {
      level,
      levelColor,
      percentage: average,
      attempts: attempts.length,
      passedCount,
      lessonsCompleted: completedSet.size,
      lessonsTotal,
      curriculumPercent,
    },
    strengths,
    weaknesses,
    units,
    headline,
    recommendations: recommendations.sort((a, b) => a.priority - b.priority).slice(0, 5),
  };
}

/**
 * خطة الدراسة: توزيع الدروس على أسابيع ونصيحة لكل درس حسب حالته.
 */
export async function buildStudyPlan(studentId: string) {
  const course = await prisma.course.findFirst({
    where: { slug: PLATFORM.courseSlug },
    select: { id: true },
  });
  if (!course) return null;

  const planTerms = await prisma.term.findMany({
    where: { courseId: course.id, status: "PUBLISHED" },
    orderBy: { order: "asc" },
    select: {
      id: true,
      title: true,
      units: {
        where: { status: "PUBLISHED" },
        orderBy: { order: "asc" },
        select: {
          id: true,
          title: true,
          order: true,
          lessons: {
            where: { status: "PUBLISHED" },
            orderBy: { order: "asc" },
            select: {
              id: true,
              slug: true,
              title: true,
              summary: true,
              durationSec: true,
              _count: { select: { files: true, exams: true } },
            },
          },
        },
      },
    },
  });

  if (planTerms.length === 0) return null;

  const progress = await prisma.lessonProgress.findMany({
    where: { studentId },
    select: { lessonId: true, completed: true, watchPercent: true },
  });
  const pMap = new Map(progress.map((p) => [p.lessonId, p]));

  const attemptStats = await prisma.examAttempt.groupBy({
    by: ["examId"],
    where: { studentId, submittedAt: { gte: new Date("2000-01-01") } },
    _avg: { percentage: true },
    _count: true,
  });
  const aMap = new Map(attemptStats.map((a) => [a.examId, a]));

  // الدروس مرتبة حسب: غير مشاهد ← قيد المشاهدة ← تم
  const allLessons = planTerms.flatMap((term) =>
    term.units.flatMap((unit) =>
      unit.lessons.map((lesson) => {
        const p = pMap.get(lesson.id);
        return {
          id: lesson.id,
          slug: lesson.slug,
          title: lesson.title,
          summary: lesson.summary,
          durationSec: lesson.durationSec,
          unitId: unit.id,
          unitTitle: unit.title,
          termId: term.id,
          termTitle: term.title,
          unitOrder: unit.order,
          hasFiles: lesson._count.files > 0,
          hasExam: lesson._count.exams > 0,
          completed: p?.completed ?? false,
          watchPercent: p?.watchPercent ?? 0,
        };
      }),
    ),
  );

  const pending = allLessons.filter((l) => !l.completed);
  const inProgress = pending.filter((l) => l.watchPercent > 0);
  const notStarted = pending.filter((l) => l.watchPercent === 0);

  // نوزّع على 4 أسابيع: 3 أيام أسبوعيًا
  const PER_WEEK = 3;
  const weeks: {
    week: number;
    title: string;
    focus: string;
    lessons: typeof allLessons;
  }[] = [];

  let cursor = 0;
  let weekIndex = 1;
  while (cursor < pending.length && weekIndex <= 8) {
    const slice = pending.slice(cursor, cursor + PER_WEEK);
    if (slice.length === 0) break;
    weeks.push({
      week: weekIndex,
      title: `الأسبوع ${weekIndex}`,
      focus: slice[0]!.unitTitle,
      lessons: slice,
    });
    cursor += PER_WEEK;
    weekIndex++;
  }

  const completedCount = allLessons.filter((l) => l.completed).length;

  return {
    totalLessons: allLessons.length,
    completedCount,
    pendingCount: pending.length,
    inProgress: inProgress.slice(0, 3),
    notStarted: notStarted.slice(0, 6),
    weeks,
    examAverages: aMap,
    /** نصيحة حسب الحالة */
    advice: buildPlanAdvice({
      completedCount,
      totalLessons: allLessons.length,
      inProgress: inProgress.length,
      attempts: attemptStats.length,
      average:
        attemptStats.length > 0
          ? Math.round(
              attemptStats.reduce((s, a) => s + (a._avg.percentage ?? 0), 0) /
                attemptStats.length,
            )
          : null,
    }),
  };
}

function buildPlanAdvice(input: {
  completedCount: number;
  totalLessons: number;
  inProgress: number;
  attempts: number;
  average: number | null;
}): string {
  const percent = Math.round((input.completedCount / input.totalLessons) * 100);

  if (input.completedCount === 0) {
    return "ابدأ بأول درس في الفصل الأول — كل دقيقة مشاهدة اليوم توفّر عليك ساعات لاحقًا.";
  }
  if (input.inProgress > 0) {
    return `أكمل الدرس الذي بدأت به قبل الانتقال لدرس جديد — المتتاليات والفرق الصغير يكلفك ساعات إن تكرر.`;
  }
  if (input.average !== null && input.average < 60) {
    return "درجاتك في الاختبارات أقل من 60% — خصّص وقتًا لأوراق العمل قبل الاختبارات، فهي أسرع طريق لرفع الدرجة.";
  }
  if (percent < 50) {
    return `أنجزت ${percent}% من المنهج. ابدأ كل أسبوع بثلاثة دروس، وستنهي المنهج قبل الامتحانات بمرونة.`;
  }
  if (input.average !== null && input.average >= 85) {
    return "مستواك ممتاز. ركّز الآن على الاختبارات الشاملة والتجريبية، وعلى مراجعة المهارات الصعبة فقط.";
  }
  return "أنت على المسار الصحيح. حافظ على إيقاع ثابت وخصّص وقتًا أسبوعيًا للمراجعة.";
}