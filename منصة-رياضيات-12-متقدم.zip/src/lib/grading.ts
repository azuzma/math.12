/**
 * التصحيح التلقائي للأسئلة + حساب درجات الواجبات والاختبارات.
 *
 * كل أسئلة objective تُصحّح على الخادم — لا يُرسل الدرجة من المتصفح.
 */

import type { QuestionType } from "@/generated/prisma/client";

export type CorrectOption = {
  id?: string;
  text: string;
};

export type GradedAnswer = {
  questionId: string;
  points: number;
  maxPoints: number;
  isCorrect: boolean;
  needsReview: boolean;
  given: unknown;
  correct: unknown;
};

export type GradeResult = {
  score: number;
  maxScore: number;
  percentage: number;
  needsReview: boolean;
  items: GradedAnswer[];
};

function normalize(value: unknown): string {
  if (value === null || value === undefined) return "";
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06F0))
    .replace(/\s+/g, " ")
    .replace(/[،,]/g, ",")
    .replace(/[.،]/g, ".");
}

function asArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(normalize);
  if (value === null || value === undefined || value === "") return [];
  return String(value)
    .split(/[,،\s]+/)
    .map(normalize)
    .filter(Boolean);
}

/** يحوّل نصًا رقميًا إلى Number، ويقبل الكسور مثل 1/3 و -2/5 . */
function toNumber(value: unknown): number {
  const raw = normalize(value).replace(/,/g, "").replace(/\s+/g, "");
  if (raw === "") return Number.NaN;

  const direct = Number(raw);
  if (Number.isFinite(direct)) return direct;

  // نسبة بسيطة: a/b أو a÷b
  const frac = raw.match(/^\(?(-?\d+(?:\.\d+)?)\)?[/÷](-?\d+(?:\.\d+)?)$/);
  if (frac?.[1] && frac[2]) {
    const denom = Number(frac[2]);
    if (Number.isFinite(denom) && denom !== 0) {
      return Number(frac[1]) / denom;
    }
  }

  return Number.NaN;
}

function numericEqual(a: unknown, b: unknown, tolerance = 0.0001): boolean {
  const na = toNumber(a);
  const nb = toNumber(b);
  if (!Number.isFinite(na) || !Number.isFinite(nb)) return false;
  return Math.abs(na - nb) <= tolerance;
}

/**
 * تصحيح إجابة واحدة حسب نوع السؤال.
 */
export function gradeAnswer(
  type: QuestionType,
  given: unknown,
  correct: unknown,
  options: unknown,
): { isCorrect: boolean; needsReview: boolean } {
  switch (type) {
    case "MCQ":
    case "TRUE_FALSE": {
      if (given === null || given === undefined || given === "") {
        return { isCorrect: false, needsReview: false };
      }
      return { isCorrect: normalize(given) === normalize(correct), needsReview: false };
    }

    case "MULTI_TRUE": {
      const g = asArray(given).sort();
      const c = asArray(correct).sort();
      const isCorrect = g.length === c.length && g.every((v, i) => v === c[i]);
      return { isCorrect, needsReview: false };
    }

    case "NUMERIC": {
      if (given === null || given === undefined || given === "") {
        return { isCorrect: false, needsReview: false };
      }
      return { isCorrect: numericEqual(given, correct), needsReview: false };
    }

    case "SHORT":
    case "ESSAY": {
      // تصحيح يدوي من الأستاذ
      return { isCorrect: false, needsReview: true };
    }

    default:
      return { isCorrect: false, needsReview: true };
  }
}

/**
 * تصحيح مجموعة أسئلة.
 * @param questions  قائمة الأسئلة مع نقاطها المخصصة في هذه الجلسة
 * @param answers    خريطة { questionId: answer }
 */
export function gradeSubmission(
  questions: { id: string; type: QuestionType; correct: unknown; points: number }[],
  answers: Record<string, unknown>,
): GradeResult {
  let score = 0;
  let maxScore = 0;
  let needsReview = false;
  const items: GradedAnswer[] = [];

  for (const q of questions) {
    const given = answers[q.id] ?? null;
    const result = gradeAnswer(q.type, given, q.correct, null);
    maxScore += q.points;
    if (result.isCorrect) score += q.points;
    if (result.needsReview) needsReview = true;

    items.push({
      questionId: q.id,
      points: result.isCorrect ? q.points : 0,
      maxPoints: q.points,
      isCorrect: result.isCorrect,
      needsReview: result.needsReview,
      given,
      correct: q.correct,
    });
  }

  const percentage = maxScore > 0 ? Math.round((score / maxScore) * 10000) / 100 : 0;

  return { score, maxScore, percentage, needsReview, items };
}