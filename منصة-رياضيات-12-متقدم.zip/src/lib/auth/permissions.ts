import "server-only";
import { prisma } from "@/lib/db/prisma";
import { getCurrentUser, type SessionUser } from "@/lib/auth/session";
import { NextResponse } from "next/server";

export const STAFF_ROLES = ["ADMIN", "TEACHER", "OWNER"] as const;

export type StaffUser = SessionUser & {
  role: "ADMIN" | "TEACHER" | "OWNER";
};

export function isStaffRole(role: string): boolean {
  return role === "ADMIN" || role === "TEACHER" || role === "OWNER";
}

/** يتحقق أن المستخدم إداري (ADMIN) أو أستاذ (TEACHER) أو مالك (OWNER). */
export async function requireStaffApi(): Promise<
  { ok: true; user: StaffUser } | { ok: false; response: NextResponse }
> {
  const user = await getCurrentUser();
  if (!user) {
    return {
      ok: false,
      response: NextResponse.json({ error: "يجب تسجيل الدخول" }, { status: 401 }),
    };
  }
  if (!isStaffRole(user.role)) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "هذه الصفحة مخصصة للإدارة" },
        { status: 403 },
      ),
    };
  }
  return { ok: true, user: user as StaffUser };
}

/** فقط ADMIN (لا يكفي TEACHER) — للإعدادات الحساسة. */
export async function requireAdminApi(): Promise<
  { ok: true; user: StaffUser } | { ok: false; response: NextResponse }
> {
  const result = await requireStaffApi();
  if (!result.ok) return result;
  if (result.user.role !== "ADMIN" && result.user.role !== "OWNER") {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "هذا الإجراء متاح لمدير النظام فقط" },
        { status: 403 },
      ),
    };
  }
  return result;
}

/** تسجيل إجراء إداري. */
export async function audit(input: {
  userId?: string | null;
  action: string;
  entity?: string;
  entityId?: string;
  meta?: Record<string, unknown>;
  ip?: string;
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: input.userId ?? null,
        action: input.action,
        entity: input.entity ?? null,
        entityId: input.entityId ?? null,
        meta: (input.meta ?? null) as never,
        ip: input.ip ?? null,
      },
    });
  } catch (e) {
    console.error("[audit] فشل تسجيل الإجراء:", (e as Error).message);
  }
}

/**
 * حماية صفحات الإدارة على مستوى الخادم.
 * يُستخدم في layout Protected
 */
export async function staffGuardPage(): Promise<
  { user: StaffUser } | { redirect: string }
> {
  const user = await getCurrentUser();
  if (!user) return { redirect: "/login?next=/admin" };
  if (!isStaffRole(user.role)) {
    return { redirect: "/dashboard?denied=1" };
  }
  return { user: user as StaffUser };
}