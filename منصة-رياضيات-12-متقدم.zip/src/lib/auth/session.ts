import "server-only";
import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { cache } from "react";
import { prisma } from "@/lib/db/prisma";
import { authSecret } from "@/lib/env";

const COOKIE_NAME = "mp_session";
const MAX_AGE_SEC = 60 * 60 * 24 * 30; // 30 يومًا

export type SessionUser = {
  id: string;
  email: string;
  fullName: string;
  role: "STUDENT" | "TEACHER" | "ADMIN" | "OWNER";
  status: "ACTIVE" | "SUSPENDED" | "PENDING";
  avatarUrl: string | null;
  gradeId: string | null;
  gradeNameAr: string | null;
};

type TokenPayload = {
  sub: string;
  role: string;
};

/** إنشاء رمز الجلسة (JWT موقّع). */
export async function createSessionToken(user: {
  id: string;
  role: string;
}): Promise<string> {
  return new SignJWT({ role: user.role })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE_SEC}s`)
    .sign(authSecret());
}

/** حفظ الجلسة في كوكي httpOnly + SameSite=Lax + Secure في الإنتاج. */
export async function setSessionCookie(token: string): Promise<void> {
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE_SEC,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

async function readToken(): Promise<TokenPayload | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, authSecret(), {
      algorithms: ["HS256"],
    });
    if (!payload.sub) return null;
    return { sub: payload.sub, role: String(payload.role ?? "") };
  } catch {
    return null;
  }
}

/**
 * المستخدم الحالي من قاعدة البيانات (لا يُكتفي بالـ JWT حتى يُطبَّق
 * إيقاف الحساب فورًا). مُخزّن مؤقتًا لكل طلب.
 */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const token = await readToken();
  if (!token) return null;

  const user = await prisma.user.findUnique({
    where: { id: token.sub },
    select: {
      id: true,
      email: true,
      fullName: true,
      role: true,
      status: true,
      avatarUrl: true,
      studentProfile: { select: { gradeId: true, grade: { select: { nameAr: true } } } },
    },
  });

  if (!user) return null;
  if (user.status !== "ACTIVE") return null;

  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    status: user.status,
    avatarUrl: user.avatarUrl,
    gradeId: user.studentProfile?.gradeId ?? null,
    gradeNameAr: user.studentProfile?.grade?.nameAr ?? null,
  };
});

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}

export async function isAdmin(): Promise<boolean> {
  const user = await getCurrentUser();
  return user?.role === "ADMIN" || user?.role === "TEACHER" || user?.role === "OWNER";
}

export async function isStaff(): Promise<boolean> {
  const user = await getCurrentUser();
  return user?.role === "ADMIN" || user?.role === "TEACHER" || user?.role === "OWNER";
}

export { COOKIE_NAME };