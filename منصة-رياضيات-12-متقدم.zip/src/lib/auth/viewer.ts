import "server-only";
import { getCurrentUser, type SessionUser } from "@/lib/auth/session";
import {
  getEntitlement,
  FREE_ENTITLEMENT,
  type Entitlement,
} from "@/lib/auth/entitlements";
import { prisma } from "@/lib/db/prisma";
import { PLATFORM } from "@/lib/platform";

/**
 * سياق المشاهدة.
 *
 * مبدأ المواقع الحكومية: تتصفّح الخدمة كاملة بلا حساب، والتسجيل مطلوب
 * عند تنفيذها. لذلك نعيد دائمًا "مستخدمًا" افتراضيًا للزائر:
 *   - صف المنصة الثابت (لعرض محتوى المنهج)
 *   - باقة مجانية (فتظهر ما هو مجاني وما يحتاج ترقية)
 *   - userId = null (فلا تُسجَّل محاولات ولا تقدّم باسم أحد)
 */
export type ViewerContext = {
  /** المستخدم المسجّل، أو null للزائر */
  user: SessionUser | null;
  /** معرّف المستخدم للعمليات الشخصية (محاولات، تقدّم) */
  userId: string | null;
  /** صف المنصة (الوحيد) */
  gradeId: string | null;
  /** صلاحيات الباقة */
  ent: Entitlement;
  /** هل الزائر غير مسجّل؟ */
  isGuest: boolean;
};

export async function getViewerContext(): Promise<ViewerContext> {
  const user = await getCurrentUser().catch(() => null);

  if (user) {
    const [ent, grade] = await Promise.all([
      getEntitlement(user.id).catch(() => FREE_ENTITLEMENT),
      user.gradeId
        ? Promise.resolve({ id: user.gradeId })
        : prisma.grade
            .findUnique({
              where: { slug: PLATFORM.gradeSlug },
              select: { id: true },
            })
            .catch(() => null),
    ]);

    return {
      user,
      userId: user.id,
      gradeId: user.gradeId ?? grade?.id ?? null,
      ent,
      isGuest: false,
    };
  }

  // زائر
  const grade = await prisma.grade
    .findUnique({
      where: { slug: PLATFORM.gradeSlug },
      select: { id: true },
    })
    .catch(() => null);

  return {
    user: null,
    userId: null,
    gradeId: grade?.id ?? null,
    ent: FREE_ENTITLEMENT,
    isGuest: true,
  };
}
