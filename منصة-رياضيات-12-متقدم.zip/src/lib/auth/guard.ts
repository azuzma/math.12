import "server-only";
import { NextResponse } from "next/server";
import { getCurrentUser, type SessionUser } from "@/lib/auth/session";

export type GuardResult =
  | { ok: true; user: SessionUser }
  | { ok: false; response: NextResponse };

/** حماية صفحات الخادم: يعيد تحويلًا إلى صفحة الدخول عند عدم السماح. */
export async function requirePage(
  opts: { roles?: SessionUser["role"][] } = {},
): Promise<{ user: SessionUser } | { redirect: string }> {
  const user = await getCurrentUser();
  if (!user) {
    return { redirect: "/login?next=/dashboard" };
  }
  if (opts.roles && !opts.roles.includes(user.role)) {
    return { redirect: "/dashboard?denied=1" };
  }
  return { user };
}

/** حماية مسارات API: يعيد استجابة 401/403. */
export async function requireApi(
  opts: { roles?: SessionUser["role"][] } = {},
): Promise<GuardResult> {
  const user = await getCurrentUser();
  if (!user) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "يجب تسجيل الدخول أولًا" },
        { status: 401 },
      ),
    };
  }
  if (opts.roles && !opts.roles.includes(user.role)) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "ليس لديك صلاحية للوصول إلى هذا المورد" },
        { status: 403 },
      ),
    };
  }
  return { ok: true, user };
}

/** تحديد معدل بسيط في الذاكرة (يحمي تسجيل الدخول من التخمين). */
const attempts = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || entry.resetAt < now) {
    attempts.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1 };
  }
  entry.count += 1;
  if (entry.count > limit) {
    return {
      allowed: false,
      retryAfterSeconds: Math.ceil((entry.resetAt - now) / 1000),
    };
  }
  return { allowed: true, remaining: limit - entry.count };
}

export type HeaderSource = { get(name: string): string | null };

export function clientIp(source: HeaderSource): string {
  const fwd = source.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return source.get("x-real-ip") ?? "local";
}

export function clearRateLimit(key: string) {
  attempts.delete(key);
}