import "server-only";
import { prisma } from "@/lib/db/prisma";
import type { PlanTier } from "@/generated/prisma/client";

export type Entitlement = {
  tier: PlanTier;
  planName: string;
  planSlug: string;
  expiresAt: Date | null;
  isPaid: boolean;
  canViewPaidContent: boolean;
  canDownloadAllFiles: boolean;
  /** الاختبارات المدفوعة (غير المجانية) */
  canTakeExams: boolean;
  /** بنك الأسئلة كامل */
  canUseQuestionBank: boolean;
  /** التحليل الذكي (مستواي) */
  canSeeAnalysis: boolean;
  /** خطة الدراسة */
  canSeeStudyPlan: boolean;
  /** مساعد الرياضيات */
  canUseTutor: boolean;
  /** الحلول النموذجية */
  canViewSolutions: boolean;
  canGetCertificate: boolean;
};

function planLimits(limits: unknown): Record<string, unknown> {
  if (limits && typeof limits === "object" && !Array.isArray(limits)) {
    return limits as Record<string, unknown>;
  }
  return {};
}

export const FREE_ENTITLEMENT: Entitlement = {
  tier: "FREE",
  planName: "المجانية",
  planSlug: "free",
  expiresAt: null,
  isPaid: false,
  canViewPaidContent: false,
  canDownloadAllFiles: false,
  canTakeExams: false,
  canUseQuestionBank: false,
  canSeeAnalysis: false,
  canSeeStudyPlan: false,
  canUseTutor: false,
  canViewSolutions: false,
  canGetCertificate: false,
};

/** حد أدنى: الباقات القديمة لا تحتوي كل المفاتيح، لذا نستخدم قيمًا افتراضية آمنة. */
function defaultsForTier(tier: PlanTier): Record<string, boolean> {
  if (tier === "PREMIUM") {
    return {
      files: true,
      exams: true,
      questions: true,
      analysis: true,
      studyPlan: true,
      tutor: true,
      solutions: true,
      certificates: true,
    };
  }
  if (tier === "BASIC") {
    return {
      files: true,
      exams: true,
      questions: false,
      analysis: false,
      studyPlan: false,
      tutor: false,
      solutions: false,
      certificates: false,
    };
  }
  return {
    files: false,
    exams: false,
    questions: false,
    analysis: false,
    studyPlan: false,
    tutor: false,
    solutions: false,
    certificates: false,
  };
}

/** صلاحيات المستخدم الحالية. يقرأ الاشتراك الفعّال فقط. */
export async function getEntitlement(userId: string): Promise<Entitlement> {
  const sub = await prisma.subscription.findFirst({
    where: {
      userId,
      status: { in: ["ACTIVE", "TRIAL"] },
      currentPeriodEnd: { gt: new Date() },
    },
    orderBy: { currentPeriodEnd: "desc" },
    include: { plan: true },
  });

  if (!sub) return FREE_ENTITLEMENT;

  const limits = planLimits(sub.plan.limits);
  const tier = sub.plan.tier;
  const isPaidTier = tier !== "FREE";
  const fallback = defaultsForTier(tier);

  const flag = (key: string): boolean =>
    typeof limits[key] === "boolean" ? Boolean(limits[key]) : fallback[key]!;

  return {
    tier,
    planName: sub.plan.nameAr,
    planSlug: sub.plan.slug,
    expiresAt: sub.currentPeriodEnd,
    isPaid: tier !== "FREE",
    canViewPaidContent: true,
    canDownloadAllFiles: flag("files"),
    canTakeExams: isPaidTier && flag("exams"),
    canUseQuestionBank: flag("questions"),
    canSeeAnalysis: flag("analysis"),
    canSeeStudyPlan: flag("studyPlan"),
    canUseTutor: flag("tutor"),
    canViewSolutions: flag("solutions"),
    canGetCertificate: flag("certificates"),
  };
}

/** هل يستطيع المستخدم الوصول لعنصر محتوى محدد؟ */
export async function canAccessLessonContent(
  userId: string | null,
  opts: { isFree: boolean; isPreview?: boolean },
): Promise<{ allowed: boolean; reason?: "free" | "preview" | "paid" | "guest" }> {
  if (opts.isFree) return { allowed: true, reason: "free" };
  if (!userId) return { allowed: false, reason: "guest" };
  if (opts.isPreview) return { allowed: true, reason: "preview" };

  const ent = await getEntitlement(userId);
  return ent.canViewPaidContent
    ? { allowed: true, reason: "paid" }
    : { allowed: false, reason: "paid" };
}