"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Alert, Spinner } from "@/components/ui/buttons";
import { FormErrors } from "@/components/ui/forms";
import type { FormState } from "@/lib/actions";
import { cn } from "@/lib/utils";

export function SubmitButton({
  children,
  className,
  variant = "primary",
  pendingText,
}: {
  children: React.ReactNode;
  className?: string;
  variant?: "primary" | "outline" | "danger" | "ghost";
  pendingText?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className={cn("btn", `btn-${variant}`, className)}
    >
      {pending ? (
        <>
          <Spinner />
          {pendingText ?? "جارٍ المعالجة…"}
        </>
      ) : (
        children
      )}
    </button>
  );
}

export function ActionFeedback({ state }: { state: FormState }) {
  if (!state.message) return null;
  return (
    <Alert tone={state.ok ? "success" : "error"}>{state.message}</Alert>
  );
}

export function ActionErrors({ state }: { state: FormState }) {
  if (!state.errors) return null;
  return <FormErrors errors={state.errors} />;
}

/** غلاف يجمع useActionState مع حالة أولية. */
export function useFormAction<T>(
  action: (prev: FormState, formData: FormData) => Promise<FormState>,
  initial: FormState = { ok: false },
) {
  const [state, formAction] = useActionState(action, initial);
  return { state, formAction };
}