"use client";

import { SelectField, TextField, TextareaField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { STATUS_OPTIONS } from "@/components/admin/forms/course-fields";

export type SkillFormDefaults = {
  id?: string;
  slug?: string;
  title?: string;
  description?: string | null;
  unitId?: string;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  order?: number;
};

export function SkillFields({
  defaults,
  units,
}: {
  defaults?: SkillFormDefaults;
  units: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات المهارة">
        <div className="space-y-5">
          <TextField
            label="عنوان المهارة"
            name="title"
            defaultValue={defaults?.title}
            placeholder="قاعدة السلسلة"
            required
            hint="المهارة هي الموضوع الفرعي داخل الوحدة، ويبنى عليها بنك الأسئلة والتحليل."
          />

          <SelectField
            label="الوحدة"
            name="unitId"
            defaultValue={defaults?.unitId}
            placeholder="اختر الوحدة"
            options={units}
            required
          />

          <TextareaField
            label="وصف المهارة"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="مثال: اشتقاق الدوال المركّبة."
            rows={3}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              dir="ltr"
              hint="اتركه فارغًا ليُولَّد تلقائيًا"
              className="[&>input]:text-start"
            />
            <TextField
              label="ترتيب العرض"
              name="order"
              type="number"
              defaultValue={defaults?.order ?? 1}
              required
            />
          </div>

          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "PUBLISHED"}
            options={STATUS_OPTIONS}
            required
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}