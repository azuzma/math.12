"use client";

import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { STATUS_OPTIONS } from "@/components/admin/forms/course-fields";

export type TermFormDefaults = {
  id?: string;
  slug?: string;
  title?: string;
  description?: string | null;
  courseId?: string;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  order?: number;
};

export function TermFields({
  defaults,
  courses,
}: {
  defaults?: TermFormDefaults;
  courses: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الفصل الدراسي">
        <div className="space-y-5">
          <TextField
            label="عنوان الفصل الدراسي"
            name="title"
            defaultValue={defaults?.title}
            placeholder="الفصل الدراسي الأول"
            required
          />

          <SelectField
            label="المقرر"
            name="courseId"
            defaultValue={defaults?.courseId}
            placeholder="اختر المقرر"
            options={courses}
            required
            hint="الفصل الدراسي يجمع وحدات المقرر."
          />

          <TextareaField
            label="وصف الفصل"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="مثال: المتتاليات، كثيرات الحدود، والتفاضل."
            rows={3}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              dir="ltr"
              placeholder="term-1"
              hint="اتركه فارغًا ليُولَّد تلقائيًا"
              className="[&>input]:text-start"
            />
            <TextField
              label="ترتيب العرض"
              name="order"
              type="number"
              defaultValue={defaults?.order ?? 1}
              required
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="النشر والوصول">
        <input type="hidden" name="_checkboxes" value="isFree" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={STATUS_OPTIONS}
            required
          />
          <ToggleField
            label="الفصل مجاني"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
            hint="كل الوحدات التابعة له ستكون متاحة مجانًا."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}