"use client";

import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { QuestionPicker, type PickerQuestion } from "@/components/admin/question-picker";

export type AssignmentFormDefaults = {
  id?: string;
  title?: string;
  instructions?: string | null;
  lessonId?: string | null;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  dueAfterDays?: number;
  questionIds?: string[];
};

export function AssignmentFields({
  defaults,
  questions,
  lessons,
}: {
  defaults?: AssignmentFormDefaults;
  questions: PickerQuestion[];
  lessons: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الواجب">
        <div className="space-y-5">
          <TextField
            label="عنوان الواجب"
            name="title"
            defaultValue={defaults?.title}
            placeholder="واجب: تمارين على الأنظمة الخطية"
            required
          />

          <TextareaField
            label="تعليمات الواجب"
            name="instructions"
            defaultValue={defaults?.instructions ?? ""}
            placeholder="مثال: حل جميع الأسئلة مع كتابة خطوات الحل."
            rows={4}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <SelectField
              label="الدرس"
              name="lessonId"
              defaultValue={defaults?.lessonId ?? ""}
              options={[{ value: "", label: "— بدون درس —" }, ...lessons]}
            />
            <TextField
              label="المهلة (بالأيام من النشر)"
              name="dueAfterDays"
              type="number"
              defaultValue={defaults?.dueAfterDays ?? 7}
              min={0}
              max={365}
              hint="0 = بدون موعد نهائي"
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="أسئلة الواجب">
        <input type="hidden" name="_checkboxes" value="questionIds[]" />
        <QuestionPicker
          name="questionIds"
          questions={questions}
          selected={defaults?.questionIds}
        />
      </AdminSection>

      <AdminSection title="النشر">
        <input type="hidden" name="_checkboxes" value="isFree" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={[
              { value: "DRAFT", label: "مسودة" },
              { value: "PUBLISHED", label: "منشور" },
              { value: "ARCHIVED", label: "مؤرشف" },
            ]}
            required
          />
          <ToggleField
            label="الواجب مجاني"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}