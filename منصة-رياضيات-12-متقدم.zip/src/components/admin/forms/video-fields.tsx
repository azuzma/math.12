"use client";

import { TextField, TextareaField, SelectField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";

export type VideoFormDefaults = {
  id?: string;
  title?: string;
  description?: string | null;
  lessonId?: string;
  provider?: string;
  providerId?: string | null;
  playbackId?: string | null;
  durationSec?: number;
  status?: string;
  isFree?: boolean;
  allowSeeking?: boolean;
};

export function VideoFields({
  defaults,
  lessons,
}: {
  defaults?: VideoFormDefaults;
  lessons: { value: string; label: string }[];
}) {
  const provider = defaults?.provider ?? "BUNNY";

  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الفيديو">
        <div className="space-y-5">
          <TextField
            label="عنوان الفيديو"
            name="title"
            defaultValue={defaults?.title}
            required
          />

          <TextareaField
            label="وصف (اختياري)"
            name="description"
            defaultValue={defaults?.description ?? ""}
            rows={2}
          />

          <SelectField
            label="الدرس"
            name="lessonId"
            defaultValue={defaults?.lessonId}
            options={lessons}
            required
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="مدة الفيديو (بالثواني)"
              name="durationSec"
              type="number"
              defaultValue={defaults?.durationSec ?? 0}
              min={0}
              hint="مثال: 1500 = 25 دقيقة"
              required
            />
            <SelectField
              label="الحالة"
              name="status"
              defaultValue={defaults?.status ?? "PUBLISHED"}
              options={[
                { value: "PUBLISHED", label: "منشور" },
                { value: "DRAFT", label: "مسودة" },
                { value: "ARCHIVED", label: "مؤرشف" },
              ]}
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="الربط مع مزوّد الفيديو">
        <div className="space-y-5">
          <SelectField
            label="المزوّد"
            name="provider"
            defaultValue={provider}
            options={[
              { value: "BUNNY", label: "Bunny Stream" },
              { value: "MUX", label: "Mux" },
              { value: "YOUTUBE", label: "YouTube (رابط من القناة)" },
              { value: "EXTERNAL", label: "رابط خارجي مباشر" },
            ]}
            required
          />

          <TextField
            label="Playback ID"
            name="playbackId"
            defaultValue={defaults?.playbackId ?? ""}
            dir="ltr"
            placeholder="مثال: b1a2c3d4-e5f6-7890-abcd-ef1234567890"
            hint="تجده في bunny.net ← Stream ← الفيديو ← Integration"
            className="[&>input]:text-start"
          />

          <TextField
            label="معرّف الفيديو عند المزوّد (اختياري)"
            name="providerId"
            defaultValue={defaults?.providerId ?? ""}
            dir="ltr"
            hint="رقم الفيديو داخل Bunny — يُستخدم للحذف."
            className="[&>input]:text-start"
          />

          {provider === "YOUTUBE" ? (
            <>
              <TextField
                label="رابط فيديو YouTube"
                name="providerId"
                defaultValue={defaults?.providerId ?? ""}
                dir="ltr"
                placeholder="https://www.youtube.com/watch?v=XXXXXXXXXXX"
                hint="انسخ الرابط من زر «مشاركة» في يوتيوب. يقبل أيضًا youtu.be والاختصار."
                className="[&>input]:text-start"
              />
              <p className="rounded-lg bg-ink-50 p-3 text-xs leading-relaxed text-ink-600">
                الفيديو يُعرض داخل المنصة عبر التضمين الرسمي (embed) بدون تحويل
                العنوان — يبقى على قناتك في يوتيوب. للتأكد من ظهوره: اجعل الفيديو
                «مُضمَّن Everywhere» (عام) في إعدادات يوتيوب.
              </p>
            </>
          ) : null}

          {provider === "EXTERNAL" ? (
            <TextField
              label="رابط الفيديو المباشر"
              name="providerId"
              defaultValue={defaults?.providerId ?? ""}
              dir="ltr"
              hint="ضع الرابط في حقل معرّف المزوّد أعلاه."
              className="[&>input]:text-start"
            />
          ) : null}
        </div>
      </AdminSection>

      <AdminSection title="الوصول والإعدادات">
        <input type="hidden" name="_checkboxes" value="isFree,allowSeeking" />
        <div className="space-y-4">
          <ToggleField
            label="الفيديو مجاني"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
          />
          <ToggleField
            label="السماح بالتقديم والتأخير"
            name="allowSeeking"
            defaultChecked={defaults?.allowSeeking ?? true}
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}