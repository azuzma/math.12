import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { STATUS_OPTIONS } from "@/components/admin/forms/course-fields";

export type UnitFormDefaults = {
  id?: string;
  slug?: string;
  title?: string;
  description?: string | null;
  courseId?: string;
  termId?: string | null;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  order?: number;
};

export function UnitFields({
  defaults,
  courses,
  terms = [],
}: {
  defaults?: UnitFormDefaults;
  courses: { value: string; label: string }[];
  /** الفصول الدراسية التي تنتمي إليها الوحدة */
  terms?: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الوحدة">
        <div className="space-y-5">
          <TextField
            label="عنوان الوحدة"
            name="title"
            defaultValue={defaults?.title}
            placeholder="الوحدة الثانية: المشتقات"
            required
          />

          <SelectField
            label="المقرر"
            name="courseId"
            defaultValue={defaults?.courseId}
            placeholder="اختر المقرر"
            options={courses}
            required
          />

          <SelectField
            label="الفصل الدراسي"
            name="termId"
            defaultValue={defaults?.termId ?? ""}
            options={[{ value: "", label: "— بدون فصل —" }, ...terms]}
            hint="الوحدة تنتمي إلى فصل من فصول المقرر."
          />

          <TextareaField
            label="وصف الوحدة"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="مثال: تغطية قواعد الاشتقاق وقاعدة السلسلة والتطبيقات."
            rows={3}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              dir="ltr"
              hint="اتركه فارغًا ليُولَّد تلقائيًا"
              className="[&>input]:text-start"
            />
            <TextField
              label="ترتيب العرض"
              name="order"
              type="number"
              defaultValue={defaults?.order ?? 1}
              required
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="النشر والوصول">
        <input type="hidden" name="_checkboxes" value="isFree" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={STATUS_OPTIONS}
            required
          />
          <ToggleField
            label="الوحدة مجانية"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
            hint="كل الدروس التابعة لها ستكون متاحة مجانًا."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}