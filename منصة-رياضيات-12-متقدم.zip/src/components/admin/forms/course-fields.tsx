import { TextField, TextareaField, SelectField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";

export const STATUS_OPTIONS = [
  { value: "DRAFT", label: "مسودة" },
  { value: "PUBLISHED", label: "منشور" },
  { value: "ARCHIVED", label: "مؤرشف" },
];

export type CourseFormDefaults = {
  id?: string;
  slug?: string;
  title?: string;
  subtitle?: string | null;
  description?: string | null;
  subjectId?: string;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  order?: number;
};

export function CourseFields({
  defaults,
  subjects,
}: {
  defaults?: CourseFormDefaults;
  subjects: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات المقرر">
        <div className="space-y-5">
          <TextField
            label="عنوان المقرر"
            name="title"
            defaultValue={defaults?.title}
            placeholder="رياضيات الصف الثاني عشر — التفاضل والتكامل"
            required
          />

          <TextField
            label="عنوان فرعي (اختياري)"
            name="subtitle"
            defaultValue={defaults?.subtitle ?? ""}
            placeholder="من النهايات إلى المشتقات والتكامل"
          />

          <SelectField
            label="المادة"
            name="subjectId"
            defaultValue={defaults?.subjectId}
            placeholder="اختر المادة"
            options={subjects}
            required
          />

          <TextareaField
            label="وصف المقرر"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="اكتب وصفًا موجزًا يظهر للطلاب في صفحة المقرر."
            rows={4}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              placeholder="grade12-calculus"
              dir="ltr"
              hint="اتركه فارغًا ليُولَّد تلقائيًا"
              className="[&>input]:text-start"
            />
            <TextField
              label="ترتيب العرض"
              name="order"
              type="number"
              defaultValue={defaults?.order ?? 1}
              required
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="النشر والوصول">
        <input type="hidden" name="_checkboxes" value="isFree" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={STATUS_OPTIONS}
            required
            hint="مسودة: لا تظهر للطلاب. منشور: تظهر مباشرة."
          />

          <ToggleField
            label="المقرر مجاني بالكامل"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
            hint="يتيح لكل الزوار مشاهدة دروس هذا المقرر بدون اشتراك."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}