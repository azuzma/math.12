"use client";

import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { QuestionPicker, type PickerQuestion } from "@/components/admin/question-picker";
import { EXAM_TYPES } from "@/lib/platform";
import type { ExamType } from "@/generated/prisma/client";

export type ExamFormDefaults = {
  id?: string;
  title?: string;
  slug?: string;
  /** نوع الاختبار: درس / وحدة / فصل / شامل / مراجعة / تجريبي */
  type?: ExamType;
  description?: string | null;
  instructions?: string | null;
  lessonId?: string | null;
  unitId?: string | null;
  termId?: string | null;
  courseId?: string | null;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  durationMinutes?: number;
  attemptsAllowed?: number;
  passingScore?: number;
  shuffleQuestions?: boolean;
  showCorrectAnswers?: boolean;
  showSolutions?: boolean;
  questionIds?: string[];
};

export function ExamFields({
  defaults,
  questions,
  lessons,
  units,
  courses,
  terms = [],
}: {
  defaults?: ExamFormDefaults;
  questions: PickerQuestion[];
  lessons: { value: string; label: string }[];
  units: { value: string; label: string }[];
  courses: { value: string; label: string }[];
  /** الفصول الدراسية */
  terms?: { value: string; label: string }[];
}) {
  const totalPoints = defaults?.questionIds?.length
    ? questions
        .filter((q) => defaults.questionIds!.includes(q.id))
        .reduce((s, q) => s + q.points, 0)
    : 0;

  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الاختبار">
        <div className="space-y-5">
          <TextField
            label="عنوان الاختبار"
            name="title"
            defaultValue={defaults?.title}
            placeholder="اختبار قصير: قواعد الاشتقاق"
            required
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <SelectField
              label="نوع الاختبار"
              name="type"
              defaultValue={defaults?.type ?? "LESSON"}
              options={EXAM_TYPES.map((t) => ({
                value: t.value,
                label: `${t.icon} ${t.label}`,
              }))}
              required
              hint="يظهر للطالب ضمن الاختبارات المفلترة حسب النوع."
            />
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              dir="ltr"
              hint="اتركه فارغًا ليُولَّد من العنوان"
              className="[&>input]:text-start"
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-4">
            <SelectField
              label="الفصل الدراسي"
              name="termId"
              defaultValue={defaults?.termId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...terms]}
            />
            <SelectField
              label="الوحدة"
              name="unitId"
              defaultValue={defaults?.unitId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...units]}
            />
            <SelectField
              label="الدرس"
              name="lessonId"
              defaultValue={defaults?.lessonId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...lessons]}
            />
            <SelectField
              label="المقرر"
              name="courseId"
              defaultValue={defaults?.courseId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...courses]}
            />
          </div>

          <TextareaField
            label="وصف الاختبار (يظهر للطالب)"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="مثال: 5 أسئلة على قواعد الاشتقاق الأساسية."
            rows={2}
          />

          <TextareaField
            label="تعليمات قبل البدء"
            name="instructions"
            defaultValue={defaults?.instructions ?? ""}
            placeholder="مثال: أجب عن جميع الأسئلة. الدرجة الكلية 5 درجات."
            rows={2}
          />
        </div>
      </AdminSection>

      <AdminSection title="إعدادات الأداء">
        <div className="grid gap-5 sm:grid-cols-3">
          <TextField
            label="المدة (بالدقائق)"
            name="durationMinutes"
            type="number"
            defaultValue={defaults?.durationMinutes ?? 20}
            min={1}
            max={300}
            required
          />
          <TextField
            label="عدد المحاولات"
            name="attemptsAllowed"
            type="number"
            defaultValue={defaults?.attemptsAllowed ?? 2}
            min={1}
            max={20}
            required
          />
          <TextField
            label="نسبة النجاح (%)"
            name="passingScore"
            type="number"
            defaultValue={defaults?.passingScore ?? 50}
            min={0}
            max={100}
            required
          />
        </div>
      </AdminSection>

      <AdminSection title="أسئلة الاختبار">
        <input type="hidden" name="_checkboxes" value="questionIds[]" />
        <QuestionPicker
          name="questionIds"
          questions={questions}
          selected={defaults?.questionIds}
        />
        {totalPoints > 0 ? (
          <p className="mt-3 rounded-lg bg-ink-50 px-3 py-2 text-sm text-ink-600">
            الدرجة الكلية:{" "}
            <strong className="text-ink-900 tabular-nums">{totalPoints}</strong> درجة
          </p>
        ) : null}
      </AdminSection>

      <AdminSection title="النشر وعرض النتائج">
        <input type="hidden" name="_checkboxes" value="isFree,shuffleQuestions,showCorrectAnswers,showSolutions" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={[
              { value: "DRAFT", label: "مسودة" },
              { value: "PUBLISHED", label: "منشور" },
              { value: "ARCHIVED", label: "مؤرشف" },
            ]}
            required
          />

          <ToggleField
            label="الاختبار مجاني"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
            hint="متاح لكل الطلاب المسجلين بدون اشتراك مدفوع."
          />
          <ToggleField
            label="ترتيب الأسئلة عشوائيًا"
            name="shuffleQuestions"
            defaultChecked={defaults?.shuffleQuestions ?? true}
          />
          <ToggleField
            label="إظهار الإجابات الصحيحة بعد الانتهاء"
            name="showCorrectAnswers"
            defaultChecked={defaults?.showCorrectAnswers ?? true}
          />
          <ToggleField
            label="إظهار الحلول النموذجية"
            name="showSolutions"
            defaultChecked={defaults?.showSolutions ?? false}
            hint="الحلول تظهر فقط لمن يملك صلاحية الحلول (باقة Premium)."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}