import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { STATUS_OPTIONS } from "@/components/admin/forms/course-fields";

export type LessonFormDefaults = {
  id?: string;
  slug?: string;
  title?: string;
  summary?: string | null;
  description?: string | null;
  unitId?: string;
  status?: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  isFree?: boolean;
  isPreview?: boolean;
  order?: number;
};

export function LessonFields({
  defaults,
  units,
}: {
  defaults?: LessonFormDefaults;
  units: { value: string; label: string }[];
}) {
  return (
    <div className="space-y-5">
      <AdminSection title="بيانات الدرس">
        <div className="space-y-5">
          <TextField
            label="عنوان الدرس"
            name="title"
            defaultValue={defaults?.title}
            placeholder="قواعد الاشتقاق الأساسية"
            required
          />

          <SelectField
            label="الوحدة"
            name="unitId"
            defaultValue={defaults?.unitId}
            placeholder="اختر الوحدة"
            options={units}
            required
          />

          <TextareaField
            label="ملخص الدرس (سطر واحد يظهر في البطاقات)"
            name="summary"
            defaultValue={defaults?.summary ?? ""}
            placeholder="مثال: اشتقاق كثيرات الحدود وقواعد الجداء والقسمة والدوال المركبة."
            rows={2}
          />

          <TextareaField
            label="شرح الدرس الكامل"
            name="description"
            defaultValue={defaults?.description ?? ""}
            placeholder="اكتب الشرح النصي الذي يظهر للطالب أسفل الفيديو. اترك سطرًا فارغًا بين الفقرات."
            rows={8}
          />

          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              label="المعرّف في الرابط (slug)"
              name="slug"
              defaultValue={defaults?.slug}
              placeholder="g12-derivative-rules"
              dir="ltr"
              hint="اتركه فارغًا ليُولَّد تلقائيًا"
              className="[&>input]:text-start"
            />
            <TextField
              label="ترتيب الدرس داخل الوحدة"
              name="order"
              type="number"
              defaultValue={defaults?.order ?? 1}
              required
            />
          </div>
        </div>
      </AdminSection>

      <AdminSection title="النشر والوصول">
        <input type="hidden" name="_checkboxes" value="isFree,isPreview" />
        <div className="space-y-4">
          <SelectField
            label="حالة المحتوى"
            name="status"
            defaultValue={defaults?.status ?? "DRAFT"}
            options={STATUS_OPTIONS}
            required
            hint="مسودة: لا يظهر للطلاب. منشور: يظهر فورًا."
          />

          <ToggleField
            label="الدرس مجاني"
            name="isFree"
            defaultChecked={defaults?.isFree ?? false}
            hint="يمكن لأي زائر مشاهدة الفيديو وتنزيل الملفات بدون تسجيل."
          />

          <ToggleField
            label="معاينة مجانية"
            name="isPreview"
            defaultChecked={defaults?.isPreview ?? defaults?.isFree ?? false}
            hint="يتيح للطالب المسجّل مشاهدة أول جزء من الفيديو فقط (تسويق للاشتراك)."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}