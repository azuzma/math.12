import { SaveButton, AdminSection } from "@/components/admin/ui";
import { TextField, TextareaField } from "@/components/ui/forms";

export type GradeFormDefaults = {
  id?: string;
  slug?: string;
  nameAr?: string;
  nameEn?: string;
  stageAr?: string;
  stageSlug?: string;
  order?: number;
  description?: string | null;
};

export function GradeFields({ defaults }: { defaults?: GradeFormDefaults }) {
  return (
    <AdminSection title="بيانات الصف">
      <div className="space-y-5">
        <TextField
          label="اسم الصف بالعربية"
          name="nameAr"
          defaultValue={defaults?.nameAr}
          placeholder="الصف الثاني عشر متقدم"
          required
        />

        <TextField
          label="اسم الصف بالإنجليزية"
          name="nameEn"
          defaultValue={defaults?.nameEn}
          placeholder="Grade 12 Advanced"
          dir="ltr"
          className="[&>input]:text-start"
          required
        />

        <div className="grid gap-5 sm:grid-cols-2">
          <TextField
            label="المرحلة"
            name="stageAr"
            defaultValue={defaults?.stageAr ?? "المرحلة الثانوية"}
            placeholder="المرحلة الثانوية"
            required
          />
          <TextField
            label="معرّف المرحلة"
            name="stageSlug"
            defaultValue={defaults?.stageSlug ?? "secondary"}
            dir="ltr"
            hint="أحرف إنجليزية صغيرة فقط"
            required
          />
        </div>

        <TextField
          label="المعرّف في الرابط (slug)"
          name="slug"
          defaultValue={defaults?.slug}
          placeholder="grade-12-advanced"
          dir="ltr"
          hint="اتركه فارغًا ليُولَّد تلقائيًا من الاسم"
          className="[&>input]:text-start"
        />

        <TextField
          label="ترتيب العرض"
          name="order"
          type="number"
          defaultValue={defaults?.order ?? 10}
          hint="الأصغر يظهر أولًا"
          required
        />

        <TextareaField
          label="وصف الصف (اختياري)"
          name="description"
          defaultValue={defaults?.description ?? ""}
          placeholder="مثال: الصف الثاني عشر متقدم — المرحلة الثانوية في رياضيات الإمارات."
          rows={3}
        />
      </div>

      <div className="mt-6">
        <SaveButton />
      </div>
    </AdminSection>
  );
}