import { TextField, TextareaField, SelectField } from "@/components/ui/forms";
import { AdminSection } from "@/components/admin/ui";

export type SubjectFormDefaults = {
  id?: string;
  slug?: string;
  nameAr?: string;
  nameEn?: string;
  gradeId?: string;
  description?: string | null;
  order?: number;
};

export function SubjectFields({
  defaults,
  grades,
}: {
  defaults?: SubjectFormDefaults;
  grades: { value: string; label: string }[];
}) {
  return (
    <AdminSection title="بيانات المادة">
      <div className="space-y-5">
        <TextField
          label="اسم المادة بالعربية"
          name="nameAr"
          defaultValue={defaults?.nameAr}
          placeholder="الرياضيات"
          required
        />

        <TextField
          label="اسم المادة بالإنجليزية"
          name="nameEn"
          defaultValue={defaults?.nameEn}
          placeholder="Mathematics"
          dir="ltr"
          className="[&>input]:text-start"
          required
        />

        <SelectField
          label="الصف الدراسي"
          name="gradeId"
          defaultValue={defaults?.gradeId}
          placeholder="اختر الصف"
          options={grades}
          required
        />

        <TextField
          label="المعرّف في الرابط (slug)"
          name="slug"
          defaultValue={defaults?.slug}
          placeholder="math-grade-12"
          dir="ltr"
          hint="اتركه فارغًا ليُولَّد تلقائيًا"
          className="[&>input]:text-start"
        />

        <TextField
          label="ترتيب العرض"
          name="order"
          type="number"
          defaultValue={defaults?.order ?? 1}
          required
        />

        <TextareaField
          label="وصف المادة (اختياري)"
          name="description"
          defaultValue={defaults?.description ?? ""}
          placeholder="مثال: رياضيات الصف الثاني عشر — التفاضل والتكامل والإحصاء."
          rows={3}
        />
      </div>
    </AdminSection>
  );
}