"use client";

import { useState } from "react";
import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { AdminSection, SaveButton } from "@/components/admin/ui";
import { QUESTION_TYPE_LABELS } from "@/lib/utils";
import { DIFFICULTY_LEVELS } from "@/lib/platform";
import type { DifficultyLevel } from "@/generated/prisma/client";

export type QuestionFormDefaults = {
  id?: string;
  type?: string;
  text?: string;
  options?: string[];
  correctLabels?: string[];
  solution?: string | null;
  hint?: string | null;
  points?: number;
  /** 🟢 سهل · 🟡 متوسط · 🔴 صعب · 🔥 تحدي */
  difficulty?: DifficultyLevel;
  lessonId?: string | null;
  skillId?: string | null;
  termId?: string | null;
  isActive?: boolean;
};

export function QuestionFields({
  defaults,
  lessons,
  skills = [],
  terms = [],
}: {
  defaults?: QuestionFormDefaults;
  lessons: { value: string; label: string }[];
  /** قائمة المهارات: value = skillId */
  skills?: { value: string; label: string; unitId?: string }[];
  /** قائمة الفصول: value = termId */
  terms?: { value: string; label: string }[];
}) {
  const [type, setType] = useState(defaults?.type ?? "MCQ");

  const isChoice = type === "MCQ" || type === "TRUE_FALSE" || type === "MULTI_TRUE";
  const isMulti = type === "MULTI_TRUE";
  const isNumeric = type === "NUMERIC";
  const isEssay = type === "ESSAY" || type === "SHORT";

  // الخيارات الافتراضية
  const initialOptions =
    type === "TRUE_FALSE"
      ? ["صح", "خطأ"]
      : (defaults?.options && defaults.options.length
          ? defaults.options
          : ["", "", "", ""]);

  return (
    <div className="space-y-5">
      <AdminSection title="نص السؤال">
        <div className="space-y-5">
          <SelectField
            label="نوع السؤال"
            name="type"
            value={type}
            onChange={(e) => setType(e.target.value)}
            options={Object.entries(QUESTION_TYPE_LABELS).map(([value, label]) => ({
              value,
              label,
            }))}
            required
            hint="الأسئلة الموضوعية تُصحَّح تلقائيًا، والمقالية تُصحَّح يدويًا."
          />

          <TextareaField
            label="نص السؤال"
            name="text"
            defaultValue={defaults?.text}
            placeholder="مثال: إذا كانت f(x) = x³ − 4x + 2 فإن f′(x) = ؟"
            rows={3}
            required
          />

          {/* الخيارات والإجابة الصحيحة */}
          {isChoice ? (
            <div className="rounded-xl border border-ink-200 p-4">
              <p className="mb-3 text-sm font-semibold text-ink-800">
                الخيارات والإجابة الصحيحة
              </p>

              {initialOptions.map((option, index) => (
                <div key={index} className="mb-2.5 flex items-center gap-2">
                  <input
                    type={isMulti ? "checkbox" : "radio"}
                    name={isMulti ? "correctMulti[]" : "correct"}
                    value={option}
                    checked={
                      isMulti
                        ? defaults?.correctLabels?.includes(option) ?? false
                        : defaults?.correctLabels?.[0] === option
                    }
                    className="h-4 w-4 shrink-0 accent-brand-600"
                  />
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-ink-100 text-xs font-bold text-ink-600">
                    {String.fromCharCode(1571 + index)}
                  </span>
                  <input
                    type="text"
                    name="options[]"
                    defaultValue={option}
                    placeholder={`الخيار ${index + 1}`}
                    className="input"
                    readOnly={type === "TRUE_FALSE"}
                  />
                </div>
              ))}

              <p className="mt-3 text-xs text-ink-500">
                اكتب النص، ثم اضغط الدائرة (أو المربع) بجوار الإجابة الصحيحة.
              </p>
            </div>
          ) : null}

          {isNumeric ? (
            <TextField
              label="الإجابة الصحيحة (رقم)"
              name="correct"
              defaultValue={defaults?.correctLabels?.[0]}
              placeholder="مثال: 13"
              dir="ltr"
              required
              hint="يقبل الأرقام العشرية والكسور مثل 1/3. يُقارَن ضمن هامش صغير."
              className="[&>input]:text-start"
            />
          ) : null}

          {isEssay ? (
            <TextareaField
              label="كلمة الإجابة النموذجية (للمراجعة فقط)"
              name="correct"
              defaultValue={defaults?.correctLabels?.[0] ?? ""}
              placeholder="اكتب الإجابة المتوقعة — يستخدمها الأستاذ للتصحيح اليدوي."
              rows={2}
            />
          ) : null}

          {type === "TRUE_FALSE" ? (
            <>
              <input type="hidden" name="options[]" value="صح" readOnly />
              <input type="hidden" name="options[]" value="خطأ" readOnly />
            </>
          ) : null}
        </div>
      </AdminSection>

      <AdminSection title="الشرح والتصنيف">
        <div className="space-y-5">
          <TextareaField
            label="الحل النموذجي"
            name="solution"
            defaultValue={defaults?.solution ?? ""}
            placeholder="مثال: f′(x) = 3x² − 4 بقاعدة القوة."
            rows={3}
            hint="يظهر للطالب في باقة Premium أو إذا سمحت بإظهار الحلول."
          />

          <TextField
            label="تلميح (اختياري)"
            name="hint"
            defaultValue={defaults?.hint ?? ""}
            placeholder="مثال: تذكّر قاعدة السلسلة."
          />

          <div className="grid gap-5 sm:grid-cols-3">
            <TextField
              label="الدرجة"
              name="points"
              type="number"
              defaultValue={defaults?.points ?? 1}
              min={1}
              max={100}
              required
            />
            <SelectField
              label="مستوى الصعوبة"
              name="difficulty"
              defaultValue={defaults?.difficulty ?? "MEDIUM"}
              options={DIFFICULTY_LEVELS.map((d) => ({
                value: d.value,
                label: `${d.emoji} ${d.label}`,
              }))}
              required
              hint="يظهر للطالب في بنك الأسئلة والاختبارات."
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-3">
            <SelectField
              label="الفصل الدراسي"
              name="termId"
              defaultValue={defaults?.termId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...terms]}
            />
            <SelectField
              label="المهارة"
              name="skillId"
              defaultValue={defaults?.skillId ?? ""}
              options={[{ value: "", label: "— بدون —" }, ...skills]}
              hint="المهارة داخل الوحدة (مثال: قاعدة السلسلة)."
            />
            <SelectField
              label="الدرس"
              name="lessonId"
              defaultValue={defaults?.lessonId ?? ""}
              options={[{ value: "", label: "— بدون درس —" }, ...lessons]}
            />
          </div>

          <input type="hidden" name="_checkboxes" value="isActive,autoGrade" />
          <ToggleField
            label="السؤال نشط"
            name="isActive"
            defaultChecked={defaults?.isActive ?? true}
            hint="السؤال غير النشط لا يظهر في الاختبارات الجديدة."
          />
          <ToggleField
            label="تصحيح تلقائي"
            name="autoGrade"
            defaultChecked
            hint="فعّل للأنواع الموضوعية فقط."
          />
        </div>
      </AdminSection>

      <div>
        <SaveButton />
      </div>
    </div>
  );
}