import Link from "next/link";
import { ArrowLeft, ExternalLink } from "lucide-react";

export function QuickLinks({
  items,
}: {
  items: { href: string; label: string; external?: boolean }[];
}) {
  if (items.length === 0) return null;

  return (
    <section className="card p-5">
      <h2 className="mb-3 text-sm font-bold text-ink-900">روابط سريعة</h2>
      <div className="flex flex-wrap gap-2">
        {items.map((item) => (
          <Link
            key={item.href + item.label}
            href={item.href}
            target={item.external ? "_blank" : undefined}
            className="inline-flex items-center gap-1.5 rounded-lg border border-ink-200 px-3 py-1.5 text-xs font-semibold text-ink-700 transition-colors hover:border-brand-300 hover:text-brand-700"
          >
            {item.label}
            {item.external ? (
              <ExternalLink className="h-3 w-3" />
            ) : (
              <ArrowLeft className="h-3 w-3" />
            )}
          </Link>
        ))}
      </div>
    </section>
  );
}