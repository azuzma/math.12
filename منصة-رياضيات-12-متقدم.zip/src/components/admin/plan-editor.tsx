"use client";

import { useState } from "react";
import { Plus, X, GripVertical } from "lucide-react";

export function PlanFeaturesEditor({
  name = "features[]",
  defaults = [],
}: {
  name?: string;
  defaults?: string[];
}) {
  const [items, setItems] = useState<string[]>(
    defaults.length ? defaults : ["", ""],
  );

  function update(i: number, v: string) {
    setItems((prev) => prev.map((x, idx) => (idx === i ? v : x)));
  }

  return (
    <div className="rounded-xl border border-ink-200 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold text-ink-800">مميزات الباقة</p>
        <button
          type="button"
          onClick={() => setItems((prev) => [...prev, ""])}
          className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-brand-700 hover:bg-brand-50"
        >
          <Plus className="h-3.5 w-3.5" />
          إضافة ميزة
        </button>
      </div>

      <div className="space-y-2">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-2">
            <GripVertical className="h-4 w-4 shrink-0 text-ink-300" />
            <input
              type="text"
              name={name}
              value={item}
              onChange={(e) => update(i, e.target.value)}
              placeholder="مثال: جميع دروس رياضيات الصف 12 متقدم"
              className="input"
            />
            {items.length > 1 ? (
              <button
                type="button"
                onClick={() => setItems((prev) => prev.filter((_, idx) => idx !== i))}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-ink-400 hover:bg-rose-50 hover:text-rose-600"
                aria-label="حذف"
              >
                <X className="h-4 w-4" />
              </button>
            ) : null}
          </div>
        ))}
      </div>
      <p className="mt-2 text-xs text-ink-400">
        تظهر هذه القائمة في صفحة الاشتراكات. اكتب ميزة واحدة في كل سطر.
      </p>
    </div>
  );
}

/** اختيار متعدد للصفوف (checkboxes). */
export function MultiSelect({
  name,
  label,
  options,
  defaults = [],
  hint,
}: {
  name: string;
  label: string;
  options: { value: string; label: string }[];
  defaults?: string[];
  hint?: string;
}) {
  const [selected, setSelected] = useState<string[]>(defaults);

  function toggle(v: string) {
    setSelected((prev) =>
      prev.includes(v) ? prev.filter((x) => x !== v) : [...prev, v],
    );
  }

  return (
    <div className="rounded-xl border border-ink-200 p-4">
      <p className="text-sm font-semibold text-ink-800">{label}</p>
      {hint ? <p className="mt-0.5 text-xs text-ink-500">{hint}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        {options.map((o) => (
          <label
            key={o.value}
            className={`cursor-pointer rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors ${
              selected.includes(o.value)
                ? "border-brand-500 bg-brand-50 text-brand-700"
                : "border-ink-200 text-ink-600 hover:bg-ink-50"
            }`}
          >
            <input
              type="checkbox"
              checked={selected.includes(o.value)}
              onChange={() => toggle(o.value)}
              className="sr-only"
            />
            {o.label}
          </label>
        ))}
      </div>
      {selected.map((v) => (
        <input key={v} type="hidden" name={`${name}[]`} value={v} />
      ))}
    </div>
  );
}