"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2, X, Loader2, Save, Plus, Minus } from "lucide-react";
import type { FormState } from "@/lib/actions";
import { emptyState } from "@/lib/actions";
import { cn } from "@/lib/utils";

/* ============ زر الحفظ داخل النماذج ============ */

export function SaveButton({
  label = "حفظ",
  variant = "primary",
  className,
  pendingLabel = "جارٍ الحفظ…",
}: {
  label?: string;
  variant?: "primary" | "outline" | "danger";
  className?: string;
  pendingLabel?: string;
}) {
  const { pending } = useFormStatus();
  const styles = {
    primary: "btn-primary",
    outline: "btn-outline",
    danger: "btn-danger",
  };
  return (
    <button
      type="submit"
      disabled={pending}
      className={cn("btn", styles[variant], className)}
    >
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
      {pending ? pendingLabel : label}
    </button>
  );
}

/* ============ نموذج لوحة إدارة عام ============ */

type ActionFn = (prev: FormState, formData: FormData) => Promise<FormState>;

/**
 * غلاف موحّد لنماذج لوحة الإدارة.
 * يتحقق من الصلاحية، يعرض الأخطاء، ويعيد التوجيه بعد النجاح.
 */
export function AdminForm({
  action,
  children,
  className,
  redirectDelay = 900,
  onSuccess,
}: {
  action: ActionFn;
  children: React.ReactNode;
  className?: string;
  redirectDelay?: number;
  onSuccess?: () => void;
}) {
  const router = useRouter();
  const [state, formAction] = useActionState(action, emptyState);
  const [seen, setSeen] = useState<FormState | null>(null);

  // إظهار التنبيه بعد اكتمال العملية
  if (state !== seen && (state.ok || state.message)) {
    setSeen(state);
    if (state.ok) {
      toast.success(state.message ?? "تم الحفظ");
      onSuccess?.();
      if (state.redirectTo) {
        setTimeout(() => {
          router.push(state.redirectTo!);
          router.refresh();
        }, redirectDelay);
      } else {
        router.refresh();
      }
    } else if (state.message) {
      toast.error(state.message);
    }
  }

  return (
    <form action={formAction} className={className}>
      {children}
    </form>
  );
}

/* ============ زر الحذف ============ */

export function DeleteButton({
  entity,
  id,
  label,
  confirmText,
  className,
  onDone,
}: {
  entity: string;
  id: string;
  label?: string;
  confirmText?: string;
  className?: string;
  onDone?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    const fd = new FormData();
    fd.set("entity", entity);
    fd.set("id", id);

    try {
      const res = await fetch("/api/admin/delete", { method: "POST", body: fd });
      const data = (await res.json()) as { ok?: boolean; error?: string };

      if (!res.ok || !data.ok) {
        toast.error(data.error ?? "تعذّر الحذف");
        setBusy(false);
        setOpen(false);
        return;
      }
      toast.success("تم الحذف بنجاح");
      setOpen(false);
      onDone?.();
      window.location.reload();
    } catch {
      toast.error("حدث خطأ في الاتصال");
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-rose-700 transition-colors hover:bg-rose-50",
          className,
        )}
      >
        <Trash2 className="h-3.5 w-3.5" />
        {label ?? "حذف"}
      </button>

      {open ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-ink-950/50 p-4">
          <div className="w-full max-w-md animate-fade-up rounded-2xl bg-white p-6 shadow-xl">
            <div className="flex items-start justify-between gap-3">
              <h3 className="text-base font-bold text-ink-900">تأكيد الحذف</h3>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg text-ink-400 hover:bg-ink-100"
                aria-label="إغلاق"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-3 text-sm leading-relaxed text-ink-600">
              {confirmText ??
                "سيتم حذف هذا العنصر نهائيًا. إذا كان مرتبطًا بعناصر أخرى سيتم حذفها معه. لا يمكن التراجع."}
            </p>

            <div className="mt-6 flex gap-2">
              <button
                type="button"
                onClick={() => void run()}
                disabled={busy}
                className="btn btn-danger flex-1"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                نعم، احذف
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                disabled={busy}
                className="btn btn-outline flex-1"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

/* ============ أزرار المسودة/منشور/مؤرشف ============ */

export function StatusSwitcher({
  entity,
  id,
  current,
}: {
  entity: string;
  id: string;
  current: string;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const router = useRouter();

  const options = [
    { value: "DRAFT", label: "مسودة", cls: "bg-ink-100 text-ink-600" },
    { value: "PUBLISHED", label: "منشور", cls: "bg-emerald-50 text-emerald-700" },
    { value: "ARCHIVED", label: "مؤرشف", cls: "bg-amber-50 text-amber-700" },
  ];

  async function change(status: string) {
    if (status === current) return;
    setBusy(status);
    const fd = new FormData();
    fd.set("entity", entity);
    fd.set("id", id);
    fd.set("status", status);

    const res = await fetch("/api/admin/status", { method: "POST", body: fd });
    const data = (await res.json()) as { ok?: boolean; error?: string };

    if (!res.ok || !data.ok) {
      toast.error(data.error ?? "تعذّر تغيير الحالة");
    } else {
      toast.success(`تم تغيير الحالة إلى ${options.find((o) => o.value === status)?.label}`);
      router.refresh();
    }
    setBusy(null);
  }

  return (
    <div className="inline-flex overflow-hidden rounded-lg border border-ink-200">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => void change(o.value)}
          disabled={busy !== null}
          className={cn(
            "px-2.5 py-1 text-[11px] font-semibold transition-colors",
            current === o.value ? o.cls : "bg-white text-ink-500 hover:bg-ink-50",
          )}
        >
          {busy === o.value ? <Loader2 className="h-3 w-3 animate-spin" /> : o.label}
        </button>
      ))}
    </div>
  );
}

/* ============ قائمة خيارات قابلة للتحديد (أسئلة) ============ */

export function OptionListEditor({
  name,
  label = "الخيارات",
  defaults = [],
  multiple = false,
  correctName = "correct",
  correctLabels = [],
  numeric = false,
}: {
  name: string;
  label?: string;
  defaults?: string[];
  multiple?: boolean;
  correctName?: string;
  correctLabels?: string[];
  numeric?: boolean;
}) {
  const [options, setOptions] = useState<string[]>(
    defaults.length ? defaults : ["", "", "", ""],
  );

  function update(index: number, value: string) {
    setOptions((prev) => prev.map((o, i) => (i === index ? value : o)));
  }

  function add() {
    setOptions((prev) => [...prev, ""]);
  }

  function remove(index: number) {
    setOptions((prev) => prev.filter((_, i) => i !== index));
  }

  return (
    <div className="rounded-xl border border-ink-200 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold text-ink-800">{label}</p>
        {!numeric ? (
          <button
            type="button"
            onClick={add}
            className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-brand-700 hover:bg-brand-50"
          >
            <Plus className="h-3.5 w-3.5" />
            إضافة خيار
          </button>
        ) : null}
      </div>

      <div className="space-y-2.5">
        {options.map((option, index) => (
          <div key={index} className="flex items-center gap-2">
            {!numeric ? (
              <input
                type={multiple ? "checkbox" : "radio"}
                name={multiple ? `${correctName}Multi[]` : correctName}
                value={option}
                checked={
                  multiple
                    ? correctLabels.includes(option)
                    : correctLabels[0] === option
                }
                readOnly={multiple}
                className="h-4 w-4 shrink-0 accent-brand-600"
                title={
                  multiple ? "حدّد الخيارات الصحيحة من القائمة أدناه" : "الإجابة الصحيحة"
                }
              />
            ) : null}

            <input
              type="text"
              name={`${name}[]`}
              value={option}
              onChange={(e) => update(index, e.target.value)}
              placeholder={`الخيار ${index + 1}`}
              className="input"
              readOnly={numeric && index === 0}
            />

            {!numeric && options.length > 2 ? (
              <button
                type="button"
                onClick={() => remove(index)}
                className="grid h-9 w-9 shrink-0 place-items-center rounded-lg text-ink-400 hover:bg-rose-50 hover:text-rose-600"
                aria-label="حذف الخيار"
              >
                <Minus className="h-4 w-4" />
              </button>
            ) : null}
          </div>
        ))}
      </div>

      {multiple ? (
        <p className="mt-3 text-xs text-ink-500">
          لتحديد الإجابات الصحيحة المتعددة، فعّل مربعات الاختيار بجوار الخيارات بعد
          كتابتها.
        </p>
      ) : null}
    </div>
  );
}

/* ============ بطاقة قسم ============ */

export function AdminSection({
  title,
  description,
  children,
  className,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("card p-5 sm:p-6", className)}>
      <div className="mb-5">
        <h2 className="text-base font-bold text-ink-900">{title}</h2>
        {description ? (
          <p className="mt-1 text-sm text-ink-500">{description}</p>
        ) : null}
      </div>
      {children}
    </section>
  );
}

/* ============ جدول بسيط ============ */

export function DataTable({
  headers,
  children,
  className,
}: {
  headers: string[];
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("overflow-x-auto", className)}>
      <table className="w-full min-w-[640px] text-right text-sm">
        <thead>
          <tr className="border-b border-ink-200 bg-ink-50/60">
            {headers.map((h) => (
              <th
                key={h}
                scope="col"
                className="whitespace-nowrap px-4 py-3 text-xs font-bold text-ink-600"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">{children}</tbody>
      </table>
    </div>
  );
}