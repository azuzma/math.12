"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { Upload, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";
import { uploadFileAction } from "@/app/actions/admin";
import { emptyState } from "@/lib/actions";
import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";
import { FILE_KIND_LABELS } from "@/lib/utils";

function SubmitFileButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className="btn btn-primary">
      {pending ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          جارٍ الرفع…
        </>
      ) : (
        <>
          <Upload className="h-4 w-4" />
          رفع الملف
        </>
      )}
    </button>
  );
}

export function FileUploader({
  defaultLessonId,
  lessons,
  units,
  courses,
}: {
  defaultLessonId?: string;
  lessons?: { value: string; label: string }[];
  units?: { value: string; label: string }[];
  courses?: { value: string; label: string }[];
}) {
  const [state, formAction] = useActionState(uploadFileAction, emptyState);
  const formRef = useRef<HTMLFormElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  useEffect(() => {
    if (state.ok) {
      toast.success(state.message ?? "تم رفع الملف");
      formRef.current?.reset();
      setFileName(null);
    } else if (state.message) {
      toast.error(state.message);
    }
  }, [state]);

  return (
    <form
      ref={formRef}
      action={formAction}
      className="rounded-xl border-2 border-dashed border-ink-200 p-5"
    >
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-rose-50 text-rose-600">
          <FileText className="h-5 w-5" />
        </span>
        <div>
          <p className="text-sm font-bold text-ink-900">رفع ملف (PDF)</p>
          <p className="text-xs text-ink-500">
            ملخص، ورقة عمل، واجب، أو حل نموذجي.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <TextField
          label="عنوان الملف"
          name="title"
          placeholder="مثال: ورقة عمل — قواعد الاشتقاق"
          required
        />

        <TextareaField
          label="وصف مختصر (اختياري)"
          name="description"
          rows={2}
          placeholder="مثال: 10 تمارين متدرجة مع مساحة للحل."
        />

        <div className="grid gap-4 sm:grid-cols-2">
          <SelectField
            label="النوع"
            name="kind"
            defaultValue="WORKSHEET"
            options={Object.entries(FILE_KIND_LABELS).map(([value, label]) => ({
              value,
              label,
            }))}
          />
          <SelectField
            label="الحالة"
            name="status"
            defaultValue="PUBLISHED"
            options={[
              { value: "PUBLISHED", label: "منشور" },
              { value: "DRAFT", label: "مسودة" },
              { value: "ARCHIVED", label: "مؤرشف" },
            ]}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {lessons ? (
            <SelectField
              label="الدرس"
              name="lessonId"
              defaultValue={defaultLessonId}
              options={[{ value: "", label: "— بدون درس —" }, ...lessons]}
            />
          ) : null}

          {units ? (
            <SelectField
              label="الوحدة"
              name="unitId"
              placeholder="— بدون وحدة —"
              options={[{ value: "", label: "— بدون وحدة —" }, ...units]}
            />
          ) : null}

          {courses ? (
            <SelectField
              label="المقرر"
              name="courseId"
              placeholder="— بدون مقرر —"
              options={[{ value: "", label: "— بدون مقرر —" }, ...courses]}
            />
          ) : null}
        </div>

        <div>
          <label className="label">الملف</label>
          <input
            type="file"
            name="file"
            accept="application/pdf,.pdf"
            required
            onChange={(e) => setFileName(e.target.files?.[0]?.name ?? null)}
            className="block w-full text-sm text-ink-600 file:me-3 file:rounded-lg file:border-0 file:bg-rose-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-rose-700 hover:file:bg-rose-100"
          />
          {fileName ? (
            <p className="mt-1.5 text-xs text-ink-500">الملف المختار: {fileName}</p>
          ) : null}
        </div>

        <input type="hidden" name="_checkboxes" value="isFree" />
        <ToggleField
          label="الملف مجاني"
          name="isFree"
          hint="متاح لكل الزوار بدون اشتراك"
        />

        <SubmitFileButton />
      </div>
    </form>
  );
}