"use client";

import { useState } from "react";
import { X, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { DIFFICULTY_MAP, type DifficultyMeta } from "@/lib/platform";

export type PickerQuestion = {
  id: string;
  text: string;
  type: string;
  points: number;
  lessonTitle: string | null;
  /** 🟢 سهل · 🟡 متوسط · 🔴 صعب · 🔥 تحدي */
  difficulty?: string;
  skillTitle?: string | null;
};

/** اختيار أسئلة من البنك (متعدد). */
export function QuestionPicker({
  name,
  questions,
  selected,
  label = "الأسئلة",
}: {
  name: string;
  questions: PickerQuestion[];
  selected?: string[];
  label?: string;
}) {
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<string[]>(selected ?? []);

  const filtered = questions.filter((q) =>
    q.text.toLowerCase().includes(query.trim().toLowerCase()),
  );

  function toggle(id: string) {
    setPicked((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  }

  return (
    <div className="rounded-xl border border-ink-200 p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm font-semibold text-ink-800">
          {label} ({picked.length} محدد)
        </p>
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 right-3 h-3.5 w-3.5 -translate-y-1/2 text-ink-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث في الأسئلة…"
            className="input h-9 w-64 pr-9 text-sm"
          />
        </div>
      </div>

      {/* الترتيب المختار */}
      {picked.length > 0 ? (
        <div className="mb-3 space-y-1.5 rounded-lg bg-brand-50 p-3">
          {picked.map((id, idx) => {
            const q = questions.find((x) => x.id === id);
            return (
              <div key={id} className="flex items-center gap-2 text-xs">
                <span className="grid h-5 w-5 shrink-0 place-items-center rounded bg-brand-600 text-[10px] font-bold text-white">
                  {idx + 1}
                </span>
                <span className="min-w-0 flex-1 truncate text-brand-900">
                  {q?.text ?? "سؤال محذوف"}
                </span>
                <span className="shrink-0 font-semibold text-brand-700 tabular-nums">
                  {q?.points} د
                </span>
                <button
                  type="button"
                  onClick={() => toggle(id)}
                  className="grid h-6 w-6 shrink-0 place-items-center rounded text-brand-700 hover:bg-brand-100"
                  aria-label="إزالة"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      ) : null}

      {questions.length === 0 ? (
        <p className="rounded-lg border border-dashed border-ink-300 p-5 text-center text-sm text-ink-500">
          بنك الأسئلة فارغ. أضف أسئلة من صفحة بنك الأسئلة أولًا.
        </p>
      ) : (
        <ul className="max-h-80 space-y-1.5 overflow-y-auto pl-1">
          {filtered.map((q) => {
            const isPicked = picked.includes(q.id);
            return (
              <li key={q.id}>
                <label
                  className={cn(
                    "flex cursor-pointer items-start gap-3 rounded-lg border p-2.5 transition-colors",
                    isPicked
                      ? "border-brand-400 bg-brand-50"
                      : "border-ink-200 hover:bg-ink-50",
                  )}
                >
                  <input
                    type="checkbox"
                    checked={isPicked}
                    onChange={() => toggle(q.id)}
                    className="mt-0.5 h-4 w-4 shrink-0 accent-brand-600"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm leading-relaxed text-ink-800">
                      {q.text}
                    </span>
                    <span className="mt-0.5 block text-[11px] text-ink-400">
                      {q.skillTitle ? `${q.skillTitle} · ` : ""}
                      {q.lessonTitle ?? "بدون درس"} ·{" "}
                      {q.difficulty
                        ? `${DIFFICULTY_MAP[q.difficulty as DifficultyMeta["value"]]?.emoji ?? ""} ${DIFFICULTY_MAP[q.difficulty as DifficultyMeta["value"]]?.label ?? q.difficulty} · `
                        : ""}
                      {q.type} · {q.points} درجة
                    </span>
                  </span>
                </label>
              </li>
            );
          })}
        </ul>
      )}

      {/* القيم المخفية المرسلة مع النموذج */}
      {picked.map((id) => (
        <input key={id} type="hidden" name={`${name}[]`} value={id} />
      ))}
    </div>
  );
}