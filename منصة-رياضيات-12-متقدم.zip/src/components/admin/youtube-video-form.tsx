"use client";

import { useActionState, useEffect, useRef } from "react";
import { useFormStatus } from "react-dom";
import { Video, Loader2, Link2 } from "lucide-react";
import { toast } from "sonner";
import { addYouTubeVideoAction } from "@/app/actions/admin";
import { emptyState } from "@/lib/actions";
import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";

function SubmitYouTubeButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className="btn btn-primary">
      {pending ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          جارٍ الإضافة…
        </>
      ) : (
        <>
          <Video className="h-4 w-4" />
          إضافة الفيديو من يوتيوب
        </>
      )}
    </button>
  );
}

export function YouTubeVideoForm({
  lessons,
  defaultLessonId,
}: {
  lessons: { value: string; label: string }[];
  defaultLessonId?: string;
}) {
  const [state, formAction] = useActionState(addYouTubeVideoAction, emptyState);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.ok) {
      toast.success(state.message ?? "تمت إضافة الفيديو");
      formRef.current?.reset();
    } else if (state.message) {
      toast.error(state.message);
    }
  }, [state]);

  return (
    <form
      ref={formRef}
      action={formAction}
      className="rounded-xl border border-ink-200 p-5"
    >
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-rose-50 text-rose-600">
          <Video className="h-5 w-5" />
        </span>
        <div>
          <p className="text-sm font-bold text-ink-900">
            إضافة فيديو من قناة YouTube
          </p>
          <p className="text-xs text-ink-500">
            انشر الفيديو على قناتك ثم الصق الرابط هنا — يظهر داخل المنصة مع
            تتبّع المشاهدة، ويبقى الفيديو على قناتك.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <SelectField
          label="الدرس"
          name="lessonId"
          defaultValue={defaultLessonId}
          options={lessons}
          required
        />

        <TextField
          label="عنوان الفيديو"
          name="title"
          placeholder="مثال: شرح قواعد الاشتقاق — الجزء الأول"
          required
        />

        <div>
          <label className="label">رابط فيديو YouTube</label>
          <div className="relative">
            <Link2 className="pointer-events-none absolute top-1/2 start-3 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              name="url"
              type="url"
              dir="ltr"
              required
              placeholder="https://www.youtube.com/watch?v=XXXXXXXXXXX"
              className="input ps-9 text-start"
            />
          </div>
          <p className="mt-1.5 text-xs text-ink-500">
            يقبل أيضًا: youtu.be/XXXX أو رابط الاختصار. تأكد أن خيار «مُضمَّن
            Everywhere» مفعّل في إعدادات الفيديو على يوتيوب.
          </p>
        </div>

        <TextareaField
          label="وصف قصير (اختياري)"
          name="description"
          rows={2}
          placeholder="ماذا يغطي هذا الفيديو؟"
        />

        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="المدة (بالثواني)"
            name="durationSec"
            type="number"
            defaultValue={0}
            min={0}
            hint="اختياري — 1500 = 25 دقيقة"
          />
          <div className="flex items-end pb-1">
            <SelectField
              label="الحالة"
              name="status"
              defaultValue="PUBLISHED"
              options={[
                { value: "PUBLISHED", label: "منشور" },
                { value: "DRAFT", label: "مسودة" },
                { value: "ARCHIVED", label: "مؤرشف" },
              ]}
            />
          </div>
        </div>

        <input type="hidden" name="_checkboxes" value="isFree,allowSeeking" />
        <div className="grid gap-3 sm:grid-cols-2">
          <ToggleField
            label="الفيديو مجاني"
            name="isFree"
            hint="متاح بدون اشتراك"
          />
          <ToggleField
            label="السماح بالتقديم والتأخير"
            name="allowSeeking"
            defaultChecked
            hint="أوقفه لتقييد التخطي"
          />
        </div>

        <SubmitYouTubeButton />
      </div>
    </form>
  );
}
