"use client";

import { useState } from "react";
import { Plus, X, UserPlus } from "lucide-react";

export function NewStudentPanel({
  grades,
}: {
  grades: { id: string; nameAr: string }[];
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="btn btn-primary"
      >
        <UserPlus className="h-4 w-4" />
        إضافة طالب
      </button>

      {open ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-ink-950/50 p-4">
          <div className="max-h-[85vh] w-full max-w-lg animate-fade-up overflow-y-auto rounded-2xl bg-white p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-ink-900">
                إضافة طالب أو ولي أمر
              </h2>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="grid h-9 w-9 place-items-center rounded-lg text-ink-400 hover:bg-ink-100"
                aria-label="إغلاق"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="mt-3 rounded-lg bg-brand-50 px-3 py-2.5 text-sm leading-relaxed text-brand-900">
              النموذج الكامل لإضافة طالب موجود في الأسفل تحت عنوان «إضافة طالب
              يدويًا». يمكنك أيضًا تركه ل الطالب ليسجّل بنفسه من صفحة «إنشاء حساب».
            </p>

            <button
              type="button"
              onClick={() => {
                setOpen(false);
                // فتح قسم الإضافة اليدوية
                const el = document.querySelector("details");
                if (el instanceof HTMLDetailsElement) el.open = true;
              }}
              className="btn btn-outline mt-4 w-full"
            >
              <Plus className="h-4 w-4" />
              الذهاب لنموذج الإضافة اليدوية
            </button>
          </div>
        </div>
      ) : null}
    </>
  );
}