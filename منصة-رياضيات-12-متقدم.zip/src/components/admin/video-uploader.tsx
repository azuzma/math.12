"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { Upload, Loader2, Video, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { uploadVideoFileAction } from "@/app/actions/admin";
import { emptyState } from "@/lib/actions";
import { SelectField, TextField, TextareaField, ToggleField } from "@/components/ui/forms";

function SubmitVideoButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className="btn btn-primary">
      {pending ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          جارٍ الرفع… (قد يستغرق عدة دقائق)
        </>
      ) : (
        <>
          <Upload className="h-4 w-4" />
          رفع ونشر الفيديو
        </>
      )}
    </button>
  );
}

export function VideoUploader({
  lessonId,
  lessonTitle,
  lessons,
  defaultLessonId,
}: {
  lessonId?: string;
  lessonTitle?: string;
  lessons?: { value: string; label: string }[];
  defaultLessonId?: string;
}) {
  const [state, formAction] = useActionState(uploadVideoFileAction, emptyState);
  const formRef = useRef<HTMLFormElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  useEffect(() => {
    if (state.ok) {
      toast.success(state.message ?? "تم رفع الفيديو");
      formRef.current?.reset();
      setFileName(null);
    } else if (state.message) {
      toast.error(state.message);
    }
  }, [state]);

  const showLessons = Boolean(lessons?.length);

  return (
    <form
      ref={formRef}
      action={formAction}
      className="rounded-xl border-2 border-dashed border-ink-200 p-5"
    >
      <div className="mb-4 flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-50 text-brand-600">
          <Video className="h-5 w-5" />
        </span>
        <div>
          <p className="text-sm font-bold text-ink-900">رفع فيديو جديد</p>
          <p className="text-xs text-ink-500">
            MP4 أو WebM — يُرفع إلى Bunny Stream ويُشغَّل بروابط موقّعة.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {showLessons ? (
          <SelectField
            label="الدرس"
            name="lessonId"
            defaultValue={defaultLessonId}
            options={lessons!}
            required
          />
        ) : (
          <input type="hidden" name="lessonId" value={lessonId} />
        )}

        <TextField
          label="عنوان الفيديو"
          name="title"
          defaultValue={lessonTitle ? `شرح ${lessonTitle}` : ""}
          placeholder="مثال: شرح قواعد الاشتقاق — الجزء الأول"
          required
        />

        <TextareaField
          label="وصف قصير (اختياري)"
          name="description"
          rows={2}
          placeholder="ماذا يغطي هذا الفيديو؟"
        />

        <div>
          <label className="label">ملف الفيديو</label>
          <input
            type="file"
            name="file"
            accept="video/mp4,video/webm,video/quicktime"
            required
            onChange={(e) => setFileName(e.target.files?.[0]?.name ?? null)}
            className="block w-full text-sm text-ink-600 file:me-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-brand-700 hover:file:bg-brand-100"
          />
          {fileName ? (
            <p className="mt-1.5 text-xs text-ink-500">الملف المختار: {fileName}</p>
          ) : null}
        </div>

        <input type="hidden" name="_checkboxes" value="isFree,allowSeeking" />
        <div className="grid gap-3 sm:grid-cols-2">
          <ToggleField
            label="الفيديو مجاني"
            name="isFree"
            hint="متاح للزوار بدون تسجيل"
          />
          <ToggleField
            label="السماح بالتقديم والتأخير"
            name="allowSeeking"
            defaultChecked
            hint="أوقفه لتقييد التخطي"
          />
        </div>

        <SubmitVideoButton />
      </div>
    </form>
  );
}