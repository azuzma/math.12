"use client";

import { useRouter } from "next/navigation";

/** قائمة منسدلة تعيد توجيه الصفحة (فلتر سريع في لوحة الإدارة). */
export function RedirectSelect({
  options,
  defaultValue,
  basePath,
  className,
}: {
  options: { value: string; label: string }[];
  defaultValue?: string;
  basePath: string;
  className?: string;
}) {
  const router = useRouter();

  return (
    <select
      defaultValue={defaultValue ?? ""}
      onChange={(e) => {
        const sp = new URLSearchParams();
        if (e.target.value) sp.set("grade", e.target.value);
        const qs = sp.toString();
        router.push(qs ? `${basePath}?${qs}` : basePath);
      }}
      className={className ?? "input w-auto cursor-pointer"}
      aria-label="تصفية"
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}