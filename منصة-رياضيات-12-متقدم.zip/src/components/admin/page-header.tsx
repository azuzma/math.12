import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export function PageHeader({
  title,
  description,
  backHref,
  action,
}: {
  title: string;
  description?: string;
  backHref?: string;
  action?: React.ReactNode;
}) {
  return (
    <header>
      {backHref ? (
        <Link
          href={backHref}
          className="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-ink-500 hover:text-brand-700"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          رجوع
        </Link>
      ) : null}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">{title}</h1>
          {description ? (
            <p className="mt-1 text-sm text-ink-600">{description}</p>
          ) : null}
        </div>
        {action}
      </div>
    </header>
  );
}