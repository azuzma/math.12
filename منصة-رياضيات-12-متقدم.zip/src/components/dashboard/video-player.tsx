"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Play, Loader2, AlertTriangle, CheckCircle2, RotateCcw } from "lucide-react";
import { formatDuration, cn } from "@/lib/utils";
import { YouTubePlayer } from "@/components/dashboard/youtube-player";

type VideoMeta = {
  id: string;
  title: string;
  durationSec: number;
  provider: string;
  allowSeeking: boolean;
};

type SignedResponse = {
  url: string;
  expiresAt: string;
  provider: string;
  thumbnail?: string | null;
};

export function VideoPlayer({
  video,
  lessonId,
  initialPosition,
  watchPercent,
  completed,
  onCompleteHref,
}: {
  video: VideoMeta;
  lessonId: string;
  initialPosition: number;
  watchPercent: number;
  completed: boolean;
  onCompleteHref?: string;
}) {
  const [signed, setSigned] = useState<SignedResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [position, setPosition] = useState(initialPosition);
  const [duration, setDuration] = useState(video.durationSec || 0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showHint, setShowHint] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const watchedRanges = useRef<{ start: number; end: number }[]>([]);
  const lastTick = useRef<{ time: number; at: number }>({ time: 0, at: Date.now() });

  /* ---------- جلب الرابط الموقّع ---------- */
  const loadSignedUrl = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/video/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId: video.id }),
      });
      const data = (await res.json()) as SignedResponse & {
        error?: string;
        code?: string;
      };

      if (!res.ok) {
        setError(data.error ?? "تعذّر تشغيل الفيديو");
        return;
      }
      setSigned(data);
    } catch {
      setError("حدث خطأ في الاتصال. تحقق من الإنترنت وحاول مجددًا.");
    } finally {
      setLoading(false);
    }
  }, [video.id]);

  useEffect(() => {
    void loadSignedUrl();
  }, [loadSignedUrl]);

  /* ---------- تركيب HLS (باستخدام hls.js إن لزم) ---------- */
  useEffect(() => {
    const el = videoRef.current;
    if (!el || !signed?.url) return;
    // يوتيوب يُعرض عبر مشغّل iframe خاص
    if (signed.provider === "youtube") return;

    const url = signed.url;

    // HLS (m3u8) فقط يمر عبر hls.js أو متصفح Safari؛ الفيديوهات العادية (mp4…) توضع مباشرة
    const isHls = url.includes(".m3u8");
    if (
      !isHls ||
      // Safari/iOS يدعم HLS أصليًا
      el.canPlayType("application/vnd.apple.mpegurl")
    ) {
      el.src = url;
      return;
    }

    let hls: import("hls.js").default | null = null;
    let cancelled = false;

    (async () => {
      const { default: Hls } = await import("hls.js");
      if (cancelled) return;

      if (Hls.isSupported()) {
        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          backBufferLength: 60,
        });
        hls.loadSource(url);
        hls.attachMedia(el);
        hls.on(Hls.Events.ERROR, (_evt, data) => {
          if (data.fatal) {
            if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
              // غالبًا انتهت صلاحية الرابط — جلب رابط جديد
              void loadSignedUrl();
            } else {
              setError("تعذّر تشغيل الفيديو. جرّب إعادة تحميل الصفحة.");
            }
          }
        });
      } else if (el.canPlayType("application/vnd.apple.mpegurl")) {
        el.src = url;
      } else {
        setError("متصفحك لا يدعم تشغيل الفيديو. جرّب متصفحًا آخر.");
      }
    })();

    return () => {
      cancelled = true;
      if (hls) hls.destroy();
    };
  }, [signed, loadSignedUrl]);

  /* ---------- استئناف من آخر نقطة ---------- */
  useEffect(() => {
    const el = videoRef.current;
    if (!el || !signed) return;
    if (initialPosition > 3 && initialPosition < (duration || video.durationSec) - 5) {
      el.currentTime = initialPosition;
    }
  }, [signed, initialPosition, duration, video.durationSec]);

  /* ---------- حفظ التقدم ---------- */
  const persist = useCallback(
    async (opts?: { forceComplete?: boolean }) => {
      try {
        await fetch("/api/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            lessonId,
            positionSec: Math.round(position),
            durationSec: Math.round(duration || video.durationSec),
            completed: opts?.forceComplete ?? false,
            watchedRanges: watchedRanges.current.slice(-40),
          }),
        });
      } catch {
        // تجاهل: سنحاول مرة أخرى عند الانتقال
      }
    },
    [lessonId, position, duration, video.durationSec],
  );

  const scheduleSave = useCallback(
    (forceComplete = false) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        void persist({ forceComplete });
      }, 2500);
    },
    [persist],
  );

  /* ---------- تتبّع ما شوهد فعليًا ---------- */
  const handleTimeUpdate = () => {
    const el = videoRef.current;
    if (!el) return;

    setPosition(el.currentTime);
    if (duration === 0 && el.duration && Number.isFinite(el.duration)) {
      setDuration(el.duration);
    }

    const now = Date.now();
    const last = lastTick.current;
    const delta = el.currentTime - last.time;

    // نتجاهل التقديم السريع (seeking) عند حساب نسب المشاهدة
    if (delta > 0 && delta < 2) {
      const lastRange = watchedRanges.current[watchedRanges.current.length - 1];
      if (lastRange && el.currentTime - lastRange.end < 3) {
        lastRange.end = el.currentTime;
      } else {
        watchedRanges.current.push({
          start: last.time,
          end: el.currentTime,
        });
      }
      lastTick.current = { time: el.currentTime, at: now };
    }

    scheduleSave();
  };

  const handlePause = () => {
    void persist();
  };

  const handleEnded = () => {
    void persist({ forceComplete: true });
    setShowHint(true);
  };

  const handleSeeked = () => {
    const el = videoRef.current;
    if (el) lastTick.current = { time: el.currentTime, at: Date.now() };
  };

  const percent =
    duration > 0 ? Math.min(100, (position / duration) * 100) : watchPercent;

  /* ---------- التحقق من بدء التشغيل ---------- */
  const handleLoadedMetadata = () => {
    const el = videoRef.current;
    if (el && Number.isFinite(el.duration) && el.duration > 0) {
      setDuration(Math.round(el.duration));
    }
  };

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  const changeRate = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) videoRef.current.playbackRate = rate;
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-ink-200 bg-white">
      <div className="relative aspect-video bg-ink-950">
        {loading ? (
          <div className="absolute inset-0 grid place-items-center">
            <div className="text-center text-white/70">
              <Loader2 className="mx-auto h-8 w-8 animate-spin" />
              <p className="mt-3 text-sm">جارٍ تجهيز الفيديو…</p>
            </div>
          </div>
        ) : null}

        {error ? (
          <div className="absolute inset-0 grid place-items-center bg-ink-950 px-6">
            <div className="text-center">
              <AlertTriangle className="mx-auto h-9 w-9 text-amber-400" />
              <p className="mt-3 text-sm text-white">{error}</p>
              <button
                type="button"
                onClick={() => void loadSignedUrl()}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-white/10 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-white/20"
              >
                <RotateCcw className="h-4 w-4" />
                إعادة المحاولة
              </button>
            </div>
          </div>
        ) : null}

        {/* عنصر الفيديو — لا src ثابت في HTML (الرابط يُجلب من الخادم) */}
        <video
          ref={videoRef}
          className="h-full w-full bg-ink-950"
          controls
          controlsList="nodownload noplaybackrate"
          disablePictureInPicture
          preload="metadata"
          playsInline
          onTimeUpdate={handleTimeUpdate}
          onPause={handlePause}
          onEnded={handleEnded}
          onSeeked={handleSeeked}
          onLoadedMetadata={handleLoadedMetadata}
          style={
            signed?.provider === "youtube" ? { display: "none" } : undefined
          }
        />

        {/* فيديو YouTube — يبقى على قناة الأستاذ ويُعرض داخل المنصة */}
        {signed?.provider === "youtube" && signed.url ? (
          <YouTubePlayer
            videoId={signed.url.split("/embed/")[1]?.split("?")[0] ?? ""}
            startAt={initialPosition}
            onProgress={(pos, total) => {
              setPosition(pos);
              if (total > 0) setDuration(total);
              scheduleSave();
            }}
            onEnded={() => {
              void persist({ forceComplete: true });
              setShowHint(true);
            }}
          />
        ) : null}
      </div>

      {/* شريط معلومات */}
      <div className="border-t border-ink-200 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate font-semibold text-ink-900">{video.title}</p>
            <p className="mt-0.5 text-xs text-ink-500">
              {position > 0 ? `${formatDuration(position)} من ${formatDuration(duration)}` : "لم تبدأ بعد"}
              {completed ? " · تم إكمال الدرس" : ""}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {completed ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                <CheckCircle2 className="h-3.5 w-3.5" />
                مكتمل
              </span>
            ) : null}

            <div className="flex overflow-hidden rounded-lg border border-ink-200">
              {[0.75, 1, 1.25, 1.5, 2].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => changeRate(r)}
                  className={cn(
                    "px-2.5 py-1 text-xs font-semibold tabular-nums transition-colors",
                    playbackRate === r
                      ? "bg-brand-600 text-white"
                      : "bg-white text-ink-600 hover:bg-ink-50",
                  )}
                >
                  {r}×
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* شريط التقدم */}
        <div className="mt-3">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
            <div
              className="h-full rounded-full bg-gradient-to-l from-brand-500 to-brand-700 transition-[width] duration-300"
              style={{ width: `${percent}%` }}
            />
          </div>
          <p className="mt-1.5 text-xs text-ink-500">
            {percent >= 90
              ? "أكملت مشاهدة 90% من الفيديو — سيُعتبر الدرس مكتملًا."
              : `شاهدت ${Math.round(percent)}% — يُعتبر الدرس مكتملًا عند 90%.`}
          </p>
        </div>

        {showHint && onCompleteHref ? (
          <div className="mt-4 rounded-xl bg-emerald-50 px-4 py-3">
            <p className="text-sm font-semibold text-emerald-800">
              أحسنت! أكملت الدرس.
            </p>
            <a
              href={onCompleteHref}
              className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-emerald-700 underline"
            >
              الانتقال إلى الملفات والاختبار
            </a>
          </div>
        ) : null}
      </div>
    </div>
  );
}