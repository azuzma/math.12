import { cn } from "@/lib/utils";

export function ProgressBar({
  percent,
  label,
  size = "md",
  showValue = false,
  tone = "brand",
}: {
  percent: number;
  label?: string;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
  tone?: "brand" | "green" | "amber" | "gold";
}) {
  const clamped = Math.max(0, Math.min(100, Math.round(percent)));

  const heights = { sm: "h-1.5", md: "h-2.5", lg: "h-4" };
  const tones = {
    brand: "from-brand-500 to-brand-600",
    green: "from-emerald-400 to-emerald-600",
    amber: "from-amber-400 to-amber-600",
    gold: "from-gold-400 to-gold-600",
  };

  return (
    <div>
      {label || showValue ? (
        <div className="mb-2 flex items-center justify-between text-xs">
          {label ? <span className="text-ink-600">{label}</span> : <span />}
          {showValue ? (
            <span className="font-bold text-ink-900 tabular-nums">{clamped}%</span>
          ) : null}
        </div>
      ) : null}

      <div
        className={cn("w-full overflow-hidden rounded-full bg-ink-100", heights[size])}
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label ?? "نسبة التقدم"}
      >
        <div
          className={cn(
            "h-full rounded-full bg-gradient-to-l transition-all duration-700 ease-out",
            tones[tone],
          )}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}

/** حلقة تقدم دائرية (للصفحة الرئيسية للوحة). */
export function ProgressRing({
  percent,
  size = 120,
  stroke = 10,
  label,
  tone = "brand",
}: {
  percent: number;
  size?: number;
  stroke?: number;
  label?: string;
  tone?: "brand" | "green" | "amber" | "gold";
}) {
  const clamped = Math.max(0, Math.min(100, Math.round(percent)));
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;

  const ringColors = {
    brand: ["var(--color-brand-400)", "var(--color-brand-700)"],
    green: ["#34d399", "#059669"],
    amber: ["#fbbf24", "#d97706"],
    gold: ["#fcd34d", "#b45309"],
  } as const;
  const [from, to] = ringColors[tone];
  const gid = `ringGrad-${tone}`;

  return (
    <div className="relative inline-flex" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--color-ink-100)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={`url(#${gid})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-all duration-1000 ease-out"
        />
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={from} />
            <stop offset="100%" stopColor={to} />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <p className="text-2xl font-bold text-ink-900 tabular-nums">{clamped}%</p>
          {label ? <p className="text-[11px] text-ink-500">{label}</p> : null}
        </div>
      </div>
    </div>
  );
}