"use client";

import { useEffect, useRef } from "react";

/**
 * مشغّل YouTube داخل المنصة.
 *
 * يستخدم YouTube IFrame API الرسمية — الفيديو يبقى على قناة الأستاذ،
 * ونicked للتتبّع فقط (الوقت الحالي والمدة) لحساب نسبة المشاهدة.
 */

type YTPlayer = {
  getCurrentTime: () => number;
  getDuration: () => number;
  getPlayerState: () => number;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  setPlaybackRate: (rate: number) => void;
  playVideo: () => void;
  destroy: () => void;
};

declare global {
  interface Window {
    YT?: {
      Player: new (
        element: HTMLElement | string,
        options: Record<string, unknown>,
      ) => YTPlayer;
      PlayerState: { ENDED: number; PLAYING: number; PAUSED: number };
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

let apiPromise: Promise<void> | null = null;

/** تحميل مكتبة YouTube مرة واحدة فقط. */
function loadYouTubeApi(): Promise<void> {
  if (apiPromise) return apiPromise;

  apiPromise = new Promise<void>((resolve) => {
    if (window.YT?.Player) {
      resolve();
      return;
    }
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      previous?.();
      resolve();
    };
    const script = document.createElement("script");
    script.src = "https://www.youtube.com/iframe_api";
    script.async = true;
    document.head.appendChild(script);
  });

  return apiPromise;
}

export function YouTubePlayer({
  videoId,
  startAt,
  onProgress,
  onEnded,
  onReady,
}: {
  videoId: string;
  startAt?: number;
  onProgress: (position: number, duration: number) => void;
  onEnded: () => void;
  onReady?: (player: YTPlayer) => void;
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<YTPlayer | null>(null);
  const lastReported = useRef<number>(0);

  useEffect(() => {
    let cancelled = false;

    void loadYouTubeApi().then(() => {
      if (cancelled || !mountRef.current || !window.YT) return;

      const player = new window.YT.Player(mountRef.current, {
        videoId,
        playerVars: {
          rel: 0,
          modestbranding: 1,
          playsinline: 1,
          enablejsapi: 1,
          start: startAt && startAt > 3 ? Math.floor(startAt) : 0,
        },
        events: {
          onReady: () => {
            // لا نضبط المشغّل إلا بعد جاهزيته — قبلها الكائن نائبة بلا دوال
            playerRef.current = player;
            onReady?.(player);
          },
          onStateChange: (event: { data: number }) => {
            if (event.data === window.YT?.PlayerState.ENDED) {
              onEnded();
            }
          },
        },
      });
    });

    return () => {
      cancelled = true;
      try {
        playerRef.current?.destroy();
      } catch {
        // تجاهل
      }
      playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoId]);

  /* ---------- تتبّع الوقت كل ثانيتين ---------- */
  useEffect(() => {
    const timer = setInterval(() => {
      const player = playerRef.current;
      if (!player || typeof player.getCurrentTime !== "function") return;
      const time = player.getCurrentTime();
      const total = player.getDuration();
      if (!Number.isFinite(time) || time <= 0) return;
      // نرسل التقدّم كل ~2 ثانية فقط
      if (Math.abs(time - lastReported.current) < 2) return;
      lastReported.current = time;
      onProgress(time, Number.isFinite(total) ? total : 0);
    }, 1000);

    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="absolute inset-0">
      <div ref={mountRef} className="h-full w-full" />
    </div>
  );
}
