import Link from "next/link";
import {
  Brain,
  ClipboardCheck,
  BarChart3,
  MessagesSquare,
  CalendarClock,
  FileText,
  PlayCircle,
  Trophy,
  CreditCard,
  User,
  Lock,
  ArrowLeft,
} from "lucide-react";

/**
 * بوابة الخدمة للزائر.
 *
 * المبدأ نفسه في المواقع الحكومية: تتصفّح الخدمة كاملة (الخيارات والمزايا
 * والتفاصيل)، والتسجيل مطلوب فقط عند **تنفيذ** الخدمة نفسها.
 */
export function ServiceGate({
  section,
  title,
  description,
  benefits = [],
  actionLabel = "ابدأ الآن",
  actionHref,
  children,
}: {
  section: string;
  title: string;
  description: string;
  benefits?: string[];
  actionLabel?: string;
  actionHref?: string;
  /** محتوى الخدمة العام (يظهر للزائر كما هو) */
  children?: React.ReactNode;
}) {
  const ICONS: Record<string, typeof Brain> = {
    bank: Brain,
    exams: ClipboardCheck,
    analysis: BarChart3,
    tutor: MessagesSquare,
    plan: CalendarClock,
    files: FileText,
    lessons: PlayCircle,
    results: Trophy,
    subscription: CreditCard,
    profile: User,
  };
  const Icon = ICONS[section] ?? Lock;

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600">
            <Icon className="h-5 w-5" />
          </span>
          <div>
            <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">{title}</h1>
            <p className="mt-1 max-w-2xl text-sm leading-relaxed text-ink-600">
              {description}
            </p>
          </div>
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <Link
            href={actionHref ?? "/login?next=/dashboard"}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-brand-700"
          >
            <Lock className="h-3.5 w-3.5" />
            {actionLabel}
          </Link>
          <Link
            href="/register"
            className="rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition-colors hover:bg-ink-50"
          >
            حساب مجاني
          </Link>
        </div>
      </header>

      {benefits.length > 0 ? (
        <section className="card p-5">
          <h2 className="text-sm font-bold text-ink-900">مزايا الخدمة</h2>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.map((b) => (
              <li
                key={b}
                className="flex items-start gap-2 rounded-lg bg-ink-50 px-3 py-2.5 text-sm text-ink-700"
              >
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                {b}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {children}
    </div>
  );
}
