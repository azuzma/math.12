"use client";

import { useState } from "react";
import { Download, FileText, Lock, ExternalLink, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { KindBadge } from "@/components/ui/badges";
import { formatBytes } from "@/lib/utils";

export type FileItem = {
  id: string;
  title: string;
  description: string | null;
  kind: string;
  sizeBytes: number;
  pageCount: number | null;
  isFree: boolean;
};

export function FileList({
  files,
  hasSubscription,
}: {
  files: FileItem[];
  hasSubscription: boolean;
}) {
  const [busy, setBusy] = useState<string | null>(null);

  async function download(file: FileItem) {
    setBusy(file.id);
    try {
      const res = await fetch("/api/files/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileId: file.id }),
      });
      const data = (await res.json()) as { url?: string; error?: string };

      if (!res.ok || !data.url) {
        if (res.status === 403) {
          toast.error("هذا الملف متاح للمشتركين فقط");
          window.setTimeout(() => {
            window.location.href = "/pricing";
          }, 1200);
        } else {
          toast.error(data.error ?? "تعذّر تجهيز الملف");
        }
        return;
      }

      // نافذة جديدة لعرض PDF داخل المتصفح (أفضل للطباعة)
      window.open(data.url, "_blank", "noopener,noreferrer");
      toast.success("تم تجهيز الملف");
    } catch {
      toast.error("حدث خطأ في الاتصال");
    } finally {
      setBusy(null);
    }
  }

  if (files.length === 0) {
    return (
      <p className="mt-4 rounded-xl border border-dashed border-ink-300 p-6 text-center text-sm text-ink-500">
        لا توجد ملفات.
      </p>
    );
  }

  return (
    <ul className="mt-4 space-y-2.5">
      {files.map((file) => {
        const locked = !file.isFree && !hasSubscription;

        return (
          <li key={file.id}>
            <div className="flex items-center gap-4 rounded-xl border border-ink-200 p-4 transition-colors hover:border-brand-200">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-rose-50 text-rose-600">
                <FileText className="h-5 w-5" />
              </span>

              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-semibold text-ink-900">{file.title}</p>
                  <KindBadge kind={file.kind} />
                </div>
                {file.description ? (
                  <p className="mt-0.5 text-xs text-ink-500">{file.description}</p>
                ) : null}
                <p className="mt-0.5 text-xs text-ink-400">
                  {file.pageCount ? `${file.pageCount} صفحة · ` : ""}
                  {formatBytes(file.sizeBytes)}
                </p>
              </div>

              {locked ? (
                <span className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-ink-100 px-3 py-2 text-xs font-semibold text-ink-600">
                  <Lock className="h-3.5 w-3.5" />
                  اشتراك
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => void download(file)}
                  disabled={busy === file.id}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-brand-50 px-3 py-2 text-xs font-semibold text-brand-700 transition-colors hover:bg-brand-100 disabled:opacity-60"
                >
                  {busy === file.id ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Download className="h-3.5 w-3.5" />
                  )}
                  فتح / تنزيل
                </button>
              )}
            </div>
          </li>
        );
      })}
    </ul>
  );
}