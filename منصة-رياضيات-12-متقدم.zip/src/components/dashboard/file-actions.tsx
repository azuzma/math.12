"use client";

import { useState } from "react";
import { Download, Eye, Loader2, Lock } from "lucide-react";

/**
 * أزرار عرض/تحميل ملف.
 * الروابط تُطلب من الخادم بعد التحقق من الصلاحية، ولا تُبنى في HTML.
 */
export function FileActions({
  fileId,
  locked,
  lessonSlug,
}: {
  fileId: string;
  locked: boolean;
  lessonSlug?: string | null;
}) {
  const [busy, setBusy] = useState<"view" | "download" | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function open(kind: "view" | "download") {
    setBusy(kind);
    setError(null);
    try {
      const res = await fetch("/api/files/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileId, disposition: kind }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "تعذّر فتح الملف");
        return;
      }
      window.open(data.url, kind === "view" ? "_blank" : "_self");
    } catch {
      setError("تعذّر الاتصال");
    } finally {
      setBusy(null);
    }
  }

  if (locked) {
    return (
      <a href="/pricing" className="btn btn-outline btn-sm">
        <Lock className="h-3.5 w-3.5" />
        يتطلب اشتراكًا
      </a>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        type="button"
        onClick={() => open("view")}
        disabled={busy !== null}
        className="btn btn-outline btn-sm"
      >
        {busy === "view" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
        ) : (
          <Eye className="h-3.5 w-3.5" />
        )}
        عرض
      </button>
      <button
        type="button"
        onClick={() => open("download")}
        disabled={busy !== null}
        className="btn btn-primary btn-sm"
      >
        {busy === "download" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
        ) : (
          <Download className="h-3.5 w-3.5" />
        )}
        تحميل
      </button>
      {lessonSlug ? (
        <a href={`/dashboard/lessons/${lessonSlug}`} className="btn btn-ghost btn-sm">
          الدرس
        </a>
      ) : null}
      {error ? <span className="text-xs text-rose-600">{error}</span> : null}
    </div>
  );
}