"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { LogOut, Menu, X, ArrowUpRight } from "lucide-react";
import { navIcon, type NavGroup, type NavItemDef } from "@/lib/navigation";
import { Logo } from "@/components/ui/logo";
import { logoutAction } from "@/app/actions/auth";
import { cn, initials } from "@/lib/utils";

/** رتبة كل عنصر في كل المجموعات — لتحديد «التالي» و«السابق» في الموبايل */
function rankOf(groups: NavGroup[]): Map<string, number> {
  const map = new Map<string, number>();
  let i = 0;
  for (const g of groups) for (const it of g.items) map.set(it.href, i++);
  return map;
}

export function DashboardShell({
  user,
  groups,
  title,
  subtitle,
  guest = false,
  children,
}: {
  user: {
    fullName: string;
    role: string;
    gradeNameAr: string | null;
    planName: string;
    isPaid: boolean;
  };
  groups: NavGroup[];
  title: string;
  subtitle?: string;
  /** عرض لزائر غير مسجّل — بدون جلسة ولا أذونات */
  guest?: boolean;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const ranks = rankOf(groups);

  const isActive = (href: string) =>
    href === "/dashboard" || href === "/admin"
      ? pathname === href
      : pathname.startsWith(href);

  // الصفحة الحالية والسابق والتالي — للتنقل السريع دون البحث في القائمة
  const flat = groups.flatMap((g) => g.items);
  const currentIndex = flat.findIndex((it) => isActive(it.href));
  const prevItem = currentIndex > 0 ? flat[currentIndex - 1] : null;
  const nextItem =
    currentIndex >= 0 && currentIndex < flat.length - 1 ? flat[currentIndex + 1] : null;

  const nav = (
    <nav
      className="flex-1 space-y-5 overflow-y-auto px-3 py-4"
      aria-label="القائمة الرئيسية"
    >
      {groups.map((group) => (
        <div key={group.title}>
          <p className="mb-1.5 px-3 text-[11px] font-bold tracking-wide text-ink-400">
            {group.title}
          </p>
          <ul className="space-y-0.5">
            {group.items.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors",
                    isActive(item.href)
                      ? "bg-brand-600 font-semibold text-white shadow-sm shadow-brand-600/20"
                      : "text-ink-600 hover:bg-ink-100 hover:text-ink-900",
                  )}
                  aria-current={isActive(item.href) ? "page" : undefined}
                >
                  {(() => {
                    const Icon = navIcon(item.icon);
                    return (
                      <Icon
                        className={cn(
                          "h-4.5 w-4.5 shrink-0",
                          isActive(item.href)
                            ? "text-white"
                            : "text-ink-400 group-hover:text-brand-600",
                        )}
                      />
                    );
                  })()}

                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{item.label}</span>
                    {!isActive(item.href) && item.hint ? (
                      <span className="block truncate text-[11px] font-normal text-ink-400">
                        {item.hint}
                      </span>
                    ) : null}
                  </span>

                  {item.badge && item.badge > 0 ? (
                    <span
                      className={cn(
                        "shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                        isActive(item.href)
                          ? "bg-white/25 text-white"
                          : "bg-rose-500 text-white",
                      )}
                    >
                      {item.badge > 99 ? "99+" : item.badge}
                    </span>
                  ) : null}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="border-b border-ink-200 p-4">
        <Logo name={title} subtitle={subtitle} size="sm" href={null} />
      </div>

      {nav}

      <div className="border-t border-ink-200 p-3">
        <div className="flex items-center gap-3 rounded-xl bg-ink-50 p-2.5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-600 text-xs font-bold text-white">
            {initials(user.fullName)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-ink-900">
              {user.fullName}
            </p>
            <p className="truncate text-xs text-ink-500">
              {user.role === "STUDENT"
                ? (user.gradeNameAr ?? user.planName)
                : user.role === "TEACHER"
                  ? "أستاذ"
                  : user.role === "OWNER"
                    ? "مالك المنصة"
                    : user.role === "GUEST"
                      ? "زائر — تصفّح بلا حساب"
                      : "مدير النظام"}
            </p>
          </div>
        </div>

        <div className="mt-1 flex items-center gap-1">
          {guest ? (
            <Link
              href="/register"
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-brand-700"
            >
              سجّل حسابًا مجانيًا
            </Link>
          ) : (
            <>
              <Link
                href={user.role === "STUDENT" ? "/" : "/dashboard"}
                className="flex flex-1 items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-ink-600 transition-colors hover:bg-ink-50"
              >
                {user.role === "STUDENT" ? (
                  "الصفحة الرئيسية"
                ) : (
                  <>
                    عرض الموقع
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </>
                )}
              </Link>

              <form action={logoutAction}>
                <button
                  type="submit"
                  className="grid h-9 w-9 place-items-center rounded-lg text-ink-500 transition-colors hover:bg-rose-50 hover:text-rose-600"
                  aria-label="تسجيل الخروج"
                  title="تسجيل الخروج"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-ink-50/40">
      {/* الشريط الجانبي — ثابت على الشاشات الكبيرة */}
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-72 border-l border-ink-200 bg-white lg:block">
        {sidebar}
      </aside>

      {/* القائمة المنسدلة — الموبايل */}
      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="إغلاق القائمة"
            className="absolute inset-0 bg-ink-950/50"
            onClick={() => setOpen(false)}
          />
          <aside className="absolute inset-y-0 right-0 w-80 max-w-[85vw] animate-fade-in bg-white shadow-xl">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute top-4 left-4 z-10 grid h-9 w-9 place-items-center rounded-lg text-ink-500 hover:bg-ink-100"
              aria-label="إغلاق"
            >
              <X className="h-5 w-5" />
            </button>
            {sidebar}
          </aside>
        </div>
      ) : null}

      <div className="lg:mr-72">
        {/* الشريط العلوي — الموبايل + تنقل سريع */}
        <header className="sticky top-0 z-20 border-b border-ink-200 bg-white/90 backdrop-blur">
          <div className="flex h-14 items-center gap-3 px-4 lg:hidden">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="grid h-10 w-10 place-items-center rounded-lg text-ink-700 hover:bg-ink-50"
              aria-label="فتح القائمة"
            >
              <Menu className="h-6 w-6" />
            </button>
            <Logo name={title} subtitle={subtitle} size="sm" href={null} />
          </div>

          {/* شريط breadcrumbs + السابق/التالي — الشاشات الكبيرة */}
          {currentIndex > 0 ? (
            <div className="hidden items-center gap-2 border-t border-ink-100 px-6 py-2 text-xs text-ink-500 lg:flex">
              <span className="font-semibold text-ink-700">
                {flat[currentIndex]?.label}
              </span>
              <span className="ms-auto flex items-center gap-2">
                {prevItem ? (
                  <Link
                    href={prevItem.href}
                    className="rounded-lg px-2.5 py-1 font-medium transition-colors hover:bg-ink-100 hover:text-ink-900"
                  >
                    {prevItem.label}
                  </Link>
                ) : null}
                {nextItem ? (
                  <Link
                    href={nextItem.href}
                    className="rounded-lg bg-brand-50 px-2.5 py-1 font-semibold text-brand-700 transition-colors hover:bg-brand-100"
                  >
                    {nextItem.label} ←
                  </Link>
                ) : null}
              </span>
            </div>
          ) : null}
        </header>

        <main className="mx-auto max-w-6xl p-4 sm:p-6 lg:p-8">
          {guest ? (
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand-200 bg-brand-50 px-4 py-3">
              <p className="text-sm font-medium text-brand-900">
                أنت تتصفّح المنصة كزائر. سجّل دخولك المجاني لتفعيل الحفظ
                والتحليل والمساعد.
              </p>
              <div className="flex items-center gap-2">
                <Link
                  href="/login?next=/dashboard"
                  className="rounded-lg bg-white px-3 py-1.5 text-sm font-semibold text-brand-700 ring-1 ring-brand-200 transition-colors hover:bg-brand-100"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/register"
                  className="rounded-lg bg-brand-600 px-3 py-1.5 text-sm font-semibold text-white transition-colors hover:bg-brand-700"
                >
                  حساب مجاني
                </Link>
              </div>
            </div>
          ) : null}
          {children}
        </main>
      </div>
    </div>
  );
}

export type { NavItemDef };