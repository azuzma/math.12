import { cn } from "@/lib/utils";
import {
  FILE_KIND_LABELS,
  PAYMENT_STATUS_LABELS,
  STATUS_LABELS,
  SUB_STATUS_LABELS,
} from "@/lib/utils";

/* ============ شارة المحتوى ============ */

export function StatusBadge({ status }: { status: string }) {
  const conf = STATUS_LABELS[status] ?? { label: status, className: "bg-ink-100 text-ink-600" };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        conf.className,
      )}
    >
      {conf.label}
    </span>
  );
}

/* ============ شارة مجاني/مدفوع ============ */

export function AccessBadge({
  isFree,
  isPreview,
  className,
}: {
  isFree: boolean;
  isPreview?: boolean;
  className?: string;
}) {
  if (isFree) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700",
          className,
        )}
      >
        مجاني
      </span>
    );
  }
  if (isPreview) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-0.5 text-xs font-semibold text-sky-700",
          className,
        )}
      >
        معاينة
      </span>
    );
  }
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-gold-400/15 px-2.5 py-0.5 text-xs font-semibold text-gold-600",
        className,
      )}
    >
      اشتراك
    </span>
  );
}

/* ============ نوع الملف ============ */

export function KindBadge({ kind }: { kind: string }) {
  const styles: Record<string, string> = {
    SUMMARY: "bg-brand-50 text-brand-700",
    WORKSHEET: "bg-indigo-50 text-indigo-700",
    ASSIGNMENT: "bg-amber-50 text-amber-700",
    ANSWERS: "bg-rose-50 text-rose-700",
    OTHER: "bg-ink-100 text-ink-600",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold",
        styles[kind] ?? styles.OTHER,
      )}
    >
      {FILE_KIND_LABELS[kind] ?? kind}
    </span>
  );
}

/* ============ حالة الدفع ============ */

export function PaymentBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    SUCCEEDED: "bg-emerald-50 text-emerald-700",
    PENDING: "bg-amber-50 text-amber-700",
    FAILED: "bg-rose-50 text-rose-700",
    REFUNDED: "bg-ink-100 text-ink-600",
    CANCELED: "bg-ink-100 text-ink-600",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        styles[status] ?? "bg-ink-100 text-ink-600",
      )}
    >
      {PAYMENT_STATUS_LABELS[status] ?? status}
    </span>
  );
}

/* ============ حالة الاشتراك ============ */

export function SubscriptionBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    ACTIVE: "bg-emerald-50 text-emerald-700",
    TRIAL: "bg-sky-50 text-sky-700",
    PAST_DUE: "bg-rose-50 text-rose-700",
    CANCELED: "bg-ink-100 text-ink-600",
    EXPIRED: "bg-ink-100 text-ink-600",
    INCOMPLETE: "bg-amber-50 text-amber-700",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        styles[status] ?? "bg-ink-100 text-ink-600",
      )}
    >
      {SUB_STATUS_LABELS[status] ?? status}
    </span>
  );
}

/* ============ نتيجة اختبار ============ */

export function ScoreBadge({ percentage }: { percentage: number }) {
  const tone =
    percentage >= 80
      ? "bg-emerald-50 text-emerald-700"
      : percentage >= 50
        ? "bg-amber-50 text-amber-700"
        : "bg-rose-50 text-rose-700";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold tabular-nums",
        tone,
      )}
    >
      {percentage}%
    </span>
  );
}

/* ============ حالة المستخدم ============ */

export function UserStatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    ACTIVE: { label: "نشط", cls: "bg-emerald-50 text-emerald-700" },
    SUSPENDED: { label: "موقوف", cls: "bg-rose-50 text-rose-700" },
    PENDING: { label: "بانتظار التفعيل", cls: "bg-amber-50 text-amber-700" },
  };
  const conf = map[status] ?? { label: status, cls: "bg-ink-100 text-ink-600" };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        conf.cls,
      )}
    >
      {conf.label}
    </span>
  );
}