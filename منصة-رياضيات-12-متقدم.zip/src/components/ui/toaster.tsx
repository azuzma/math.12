"use client";

import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      position="top-center"
      richColors
      dir="rtl"
      closeButton
      toastOptions={{ duration: 4000 }}
    />
  );
}