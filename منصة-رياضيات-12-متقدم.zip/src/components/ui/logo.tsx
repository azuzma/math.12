import Link from "next/link";
import { cn } from "@/lib/utils";

type LogoProps = {
  /** نص داخل الشعار (أول حرف من اسم المنصة) */
  mark?: string;
  name?: string;
  subtitle?: string;
  href?: string | null;
  variant?: "dark" | "light";
  size?: "sm" | "md" | "lg";
  className?: string;
};

export function Logo({
  mark = "ر",
  name = "منصة الرياضيات",
  subtitle,
  href = "/",
  variant = "dark",
  size = "md",
  className,
}: LogoProps) {
  const dims = {
    sm: { box: "h-8 w-8 text-sm", name: "text-sm", sub: "text-[10px]" },
    md: { box: "h-10 w-10 text-lg", name: "text-base", sub: "text-[11px]" },
    lg: { box: "h-12 w-12 text-2xl", name: "text-lg", sub: "text-xs" },
  }[size];

  const content = (
    <span className={cn("flex items-center gap-2.5", className)}>
      <span
        className={cn(
          "grid shrink-0 place-items-center rounded-xl font-bold",
          "bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-sm",
          "ring-1 ring-brand-800/10",
          dims.box,
        )}
      >
        {mark}
      </span>
      <span className="flex flex-col leading-tight">
        <span
          className={cn(
            "font-bold",
            dims.name,
            variant === "dark" ? "text-ink-900" : "text-white",
          )}
        >
          {name}
        </span>
        {subtitle ? (
          <span
            className={cn(
              dims.sub,
              variant === "dark" ? "text-ink-500" : "text-white/70",
            )}
          >
            {subtitle}
          </span>
        ) : null}
      </span>
    </span>
  );

  if (!href) return content;
  return (
    <Link href={href} className="shrink-0" aria-label={name}>
      {content}
    </Link>
  );
}