"use client";

import { useId } from "react";
import { cn } from "@/lib/utils";

/* ============ حقل نصي ============ */

type FieldProps = {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  required?: boolean;
  className?: string;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "name" | "className">;

export function TextField({
  label,
  name,
  error,
  hint,
  required,
  className,
  ...rest
}: FieldProps) {
  const id = useId();
  return (
    <div className={className}>
      <label className="label" htmlFor={id}>
        {label}
        {required ? <span className="text-rose-500"> *</span> : null}
      </label>
      <input
        id={id}
        name={name}
        className={cn("input", error && "border-rose-400 focus:border-rose-500")}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-err` : hint ? `${id}-hint` : undefined}
        required={required}
        {...rest}
      />
      {error ? (
        <p id={`${id}-err`} className="mt-1 text-xs font-medium text-rose-600">
          {error}
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="mt-1 text-xs text-ink-400">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

/* ============ حقل كلمة المرور ============ */

export function PasswordField({
  label,
  name,
  error,
  hint,
  required,
  className,
  ...rest
}: FieldProps) {
  const id = useId();
  return (
    <div className={className}>
      <label className="label" htmlFor={id}>
        {label}
        {required ? <span className="text-rose-500"> *</span> : null}
      </label>
      <input
        id={id}
        name={name}
        type="password"
        className={cn("input", error && "border-rose-400")}
        aria-invalid={Boolean(error)}
        required={required}
        {...rest}
      />
      {error ? (
        <p className="mt-1 text-xs font-medium text-rose-600">{error}</p>
      ) : hint ? (
        <p className="mt-1 text-xs text-ink-400">{hint}</p>
      ) : null}
    </div>
  );
}

/* ============ قائمة منسدلة ============ */

type SelectProps = {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  required?: boolean;
  className?: string;
  options: { value: string; label: string; disabled?: boolean }[];
  placeholder?: string;
  defaultValue?: string;
} & Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "name" | "className">;

export function SelectField({
  label,
  name,
  error,
  hint,
  required,
  className,
  options,
  placeholder,
  defaultValue,
  ...rest
}: SelectProps) {
  const id = useId();
  return (
    <div className={className}>
      <label className="label" htmlFor={id}>
        {label}
        {required ? <span className="text-rose-500"> *</span> : null}
      </label>
      <select
        id={id}
        name={name}
        defaultValue={defaultValue}
        className={cn("input cursor-pointer", error && "border-rose-400")}
        required={required}
        {...rest}
      >
        {placeholder ? (
          <option value="" disabled>
            {placeholder}
          </option>
        ) : null}
        {options.map((o) => (
          <option key={o.value} value={o.value} disabled={o.disabled}>
            {o.label}
          </option>
        ))}
      </select>
      {error ? (
        <p className="mt-1 text-xs font-medium text-rose-600">{error}</p>
      ) : hint ? (
        <p className="mt-1 text-xs text-ink-400">{hint}</p>
      ) : null}
    </div>
  );
}

/* ============ منطقة نص ============ */

type TextareaProps = {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  required?: boolean;
  className?: string;
} & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "name" | "className">;

export function TextareaField({
  label,
  name,
  error,
  hint,
  required,
  className,
  ...rest
}: TextareaProps) {
  const id = useId();
  return (
    <div className={className}>
      <label className="label" htmlFor={id}>
        {label}
        {required ? <span className="text-rose-500"> *</span> : null}
      </label>
      <textarea
        id={id}
        name={name}
        rows={4}
        className={cn("input resize-y", error && "border-rose-400")}
        aria-invalid={Boolean(error)}
        required={required}
        {...rest}
      />
      {error ? (
        <p className="mt-1 text-xs font-medium text-rose-600">{error}</p>
      ) : hint ? (
        <p className="mt-1 text-xs text-ink-400">{hint}</p>
      ) : null}
    </div>
  );
}

/* ============ مفتاح تشغيل ============ */

export function ToggleField({
  label,
  name,
  defaultChecked,
  hint,
  value = "on",
  className,
}: {
  label: string;
  name: string;
  defaultChecked?: boolean;
  hint?: string;
  value?: string;
  className?: string;
}) {
  const id = useId();
  return (
    <label
      htmlFor={id}
      className={cn(
        "flex cursor-pointer items-start gap-3 rounded-xl border border-ink-200 p-3 transition-colors hover:bg-ink-50",
        className,
      )}
    >
      <input
        id={id}
        type="checkbox"
        name={name}
        value={value}
        defaultChecked={defaultChecked}
        className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded border-ink-300 text-brand-600 accent-brand-600"
      />
      <span className="min-w-0">
        <span className="block text-sm font-semibold text-ink-800">{label}</span>
        {hint ? <span className="mt-0.5 block text-xs text-ink-500">{hint}</span> : null}
      </span>
    </label>
  );
}

/* ============ أخطاء النموذج ============ */

export function FormErrors({ errors }: { errors: Record<string, string[]> }) {
  const entries = Object.entries(errors).filter(([, v]) => v.length > 0);
  if (entries.length === 0) return null;
  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3">
      <p className="text-sm font-semibold text-rose-800">
        يوجد {entries.reduce((s, [, v]) => s + v.length, 0)} خطأ في البيانات المدخلة:
      </p>
      <ul className="mt-2 space-y-1 text-sm text-rose-700">
        {entries.map(([field, msgs]) => (
          <li key={field}>
            <span className="font-medium">{field}:</span> {msgs[0]}
          </li>
        ))}
      </ul>
    </div>
  );
}