import Link from "next/link";

/**
 * شاشة «قاعدة البيانات غير مربوطة».
 *
 * تظهر تلقائيًا عندما يُنشر المشروع على Vercel أو Cloud Run قبل إضافة
 * `DATABASE_URL` — بدل خطأ 500 غامض، يرى الزائر خطوات الإعداد.
 */
export function SetupRequired() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-50 p-6">
      <div className="w-full max-w-2xl">
        <div className="card p-8">
          <div className="mb-5 flex items-center gap-3">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand-600 text-xl font-bold text-white">
              م
            </span>
            <div>
              <h1 className="text-xl font-bold text-ink-900">
                منصة رياضيات الصف 12 متقدم
              </h1>
              <p className="text-sm text-ink-500">
                كل ما تحتاجه لإتقان رياضيات الصف 12 متقدم في مكان واحد
              </p>
            </div>
          </div>

          <div className="rounded-xl border border-amber-200 bg-amber-50 p-5">
            <h2 className="font-bold text-amber-900">
              المنصة قيد التهيئة — قاعدة البيانات غير مربوطة بعد
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-amber-800">
              المشروع منشور، لكنه يحتاج قاعدة بيانات لتشغيل المنهج وتسجيل
              الحسابات. لإكمال الإعداد أضف المتغيّرات التالية في إعدادات
              المشروع ثم أعد النشر:
            </p>
          </div>

          <div
            dir="ltr"
            className="mt-5 overflow-x-auto rounded-xl border border-ink-200 bg-ink-950 p-4 font-mono text-sm text-ink-100"
          >
            <p className="text-ink-400"># متطلّب (إلزامي)</p>
            <p className="mt-1">DATABASE_URL=postgresql://...</p>
            <p>AUTH_SECRET=&lt;قيمة عشوائية طويلة&gt;</p>
            <p>NEXT_PUBLIC_APP_URL=https://your-site.vercel.app</p>
            <p className="mt-3 text-ink-400"># ثم شغّل داخل Terminal الخاص بالمشروع:</p>
            <p className="mt-1">npx prisma migrate deploy</p>
            <p>npx tsx prisma/seed.ts</p>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="/api/health"
              className="btn btn-outline"
              target="_blank"
              rel="noreferrer"
            >
              فحص حالة الإعداد
            </a>
            <Link href="/" className="btn btn-primary">
              الصفحة الرئيسية
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
