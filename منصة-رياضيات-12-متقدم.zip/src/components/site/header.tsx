"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, LogOut, LayoutDashboard, Bell, Search, User } from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { Button, ButtonLink } from "@/components/ui/buttons";
import { logoutAction } from "@/app/actions/auth";
import { cn, initials } from "@/lib/utils";

type NavItem = { href: string; label: string };

export function SiteHeader({
  isLoggedIn,
  user,
  unreadCount = 0,
}: {
  isLoggedIn: boolean;
  user: { fullName: string; role: string } | null;
  unreadCount?: number;
}) {
  const [open, setOpen] = useState(false);

  const nav: NavItem[] = [
    { href: "/lessons", label: "الدروس" },
    { href: "/dashboard/question-bank", label: "بنك الأسئلة" },
    { href: "/dashboard/exams", label: "الاختبارات" },
    { href: "/explore", label: "استكشف المنصة" },
    { href: "/pricing", label: "الاشتراكات" },
    { href: "/#faq", label: "الأسئلة الشائعة" },
    { href: "/#contact", label: "تواصل معنا" },
  ];

  const isStaff = user?.role === "ADMIN" || user?.role === "TEACHER";

  return (
    <header className="sticky top-0 z-50 border-b border-ink-200/80 bg-white/90 backdrop-blur-md">
      <div className="container-app flex h-16 items-center justify-between gap-4">
        <Logo />

        <nav className="hidden items-center gap-1 lg:flex" aria-label="التنقل الرئيسي">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-ink-600 transition-colors hover:bg-ink-50 hover:text-ink-900"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <Link
            href="/search"
            className="grid h-10 w-10 place-items-center rounded-lg text-ink-500 transition-colors hover:bg-ink-50 hover:text-ink-900"
            aria-label="بحث"
          >
            <Search className="h-5 w-5" />
          </Link>

          {isLoggedIn && user ? (
            <>
              {isStaff ? (
                <ButtonLink href="/admin" variant="outline" size="sm">
                  <LayoutDashboard className="h-4 w-4" />
                  لوحة الإدارة
                </ButtonLink>
              ) : (
                <ButtonLink href="/dashboard" variant="outline" size="sm">
                  <LayoutDashboard className="h-4 w-4" />
                  لوحة الطالب
                </ButtonLink>
              )}
              <Link
                href="/dashboard/notifications"
                className="relative grid h-10 w-10 place-items-center rounded-lg text-ink-600 transition-colors hover:bg-ink-50 hover:text-ink-900"
                aria-label="الإشعارات"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 ? (
                  <span className="absolute -top-0.5 -right-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                ) : null}
              </Link>
              <div className="flex items-center gap-2 rounded-lg border border-ink-200 py-1 pl-1 pr-3">
                <span className="grid h-8 w-8 place-items-center rounded-md bg-brand-100 text-xs font-bold text-brand-700">
                  {initials(user.fullName)}
                </span>
                <span className="max-w-28 truncate text-sm font-medium text-ink-800">
                  {user.fullName}
                </span>
              </div>
              <form action={logoutAction}>
                <button
                  type="submit"
                  className="grid h-10 w-10 place-items-center rounded-lg text-ink-500 transition-colors hover:bg-rose-50 hover:text-rose-600"
                  aria-label="تسجيل الخروج"
                  title="تسجيل الخروج"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </form>
            </>
          ) : (
            <>
              <ButtonLink href="/login" variant="ghost" size="sm">
                تسجيل الدخول
              </ButtonLink>
              <ButtonLink href="/register" size="sm">
                إنشاء حساب
              </ButtonLink>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="grid h-10 w-10 place-items-center rounded-lg text-ink-700 transition-colors hover:bg-ink-50 lg:hidden"
          aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open ? (
        <div className="animate-fade-in border-t border-ink-200 bg-white lg:hidden">
          <div className="container-app flex flex-col gap-1 py-4">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-700 transition-colors hover:bg-ink-50"
              >
                {item.label}
              </Link>
            ))}

            <div className="my-2 h-px bg-ink-200" />

            {isLoggedIn && user ? (
              <>
                <div className="flex items-center gap-3 rounded-lg bg-ink-50 px-3 py-3">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand-100 text-xs font-bold text-brand-700">
                    {initials(user.fullName)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink-900">
                      {user.fullName}
                    </p>
                    <p className="text-xs text-ink-500">
                      {isStaff ? "إدارة المنصة" : "حساب طالب"}
                    </p>
                  </div>
                </div>
                <ButtonLink href={isStaff ? "/admin" : "/dashboard"} className="mt-1 w-full">
                  <User className="h-4 w-4" />
                  {isStaff ? "لوحة الإدارة" : "لوحة الطالب"}
                </ButtonLink>
                <ButtonLink
                  href="/dashboard/notifications"
                  variant="outline"
                  className="w-full"
                >
                  <Bell className="h-4 w-4" />
                  الإشعارات
                  {unreadCount > 0 ? (
                    <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-bold text-white">
                      {unreadCount}
                    </span>
                  ) : null}
                </ButtonLink>
                <form action={logoutAction} className="mt-1">
                  <Button type="submit" variant="outline" className="w-full">
                    <LogOut className="h-4 w-4" />
                    تسجيل الخروج
                  </Button>
                </form>
              </>
            ) : (
              <>
                <ButtonLink href="/login" variant="outline" className="w-full">
                  تسجيل الدخول
                </ButtonLink>
                <ButtonLink href="/register" className="w-full">
                  إنشاء حساب مجاني
                </ButtonLink>
              </>
            )}
          </div>
        </div>
      ) : null}
    </header>
  );
}