import Link from "next/link";
import { Logo } from "@/components/ui/logo";
import { Mail, Phone, MapPin, Video, Camera } from "lucide-react";
import type { SiteSettings } from "@/lib/settings";
import { PLATFORM } from "@/lib/platform";

const columns = [
  {
    title: "المنصة",
    links: [
      { href: "/lessons", label: "كل الدروس" },
      { href: "/pricing", label: "الاشتراكات" },
      { href: "/search", label: "ابحث عن درس" },
      { href: "/register", label: "إنشاء حساب طالب" },
    ],
  },
  {
    title: "الصف 12 متقدم",
    links: [
      { href: "/lessons?term=term-1", label: "الفصل الدراسي الأول" },
      { href: "/lessons?term=term-2", label: "الفصل الدراسي الثاني" },
      { href: "/lessons?unit=t1-unit-sequences", label: "المتتاليات" },
      { href: "/lessons?unit=t1-unit-differentiation", label: "التفاضل" },
      { href: "/lessons?unit=t2-unit-integration", label: "التكامل" },
    ],
  },
  {
    title: "أدوات الطالب",
    links: [
      { href: "/login", label: "تسجيل الدخول" },
      { href: "/#faq", label: "الأسئلة الشائعة" },
      { href: "/#features", label: "المميزات" },
      { href: "/forgot-password", label: "استعادة كلمة المرور" },
    ],
  },
];

export function SiteFooter({ settings }: { settings: SiteSettings }) {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-ink-200 bg-ink-950 text-white">
      <div className="container-app grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <Logo
            mark={settings.logoText || "ر"}
            name={settings.siteName}
            subtitle={`${PLATFORM.subjectNameAr} · ${PLATFORM.gradeNameAr}`}
            variant="light"
            href={null}
          />
          {settings.teacherBio ? (
            <p className="mt-4 max-w-md text-sm leading-relaxed text-white/60">
              {settings.teacherBio}
            </p>
          ) : null}

          <div className="mt-6 space-y-2.5 text-sm text-white/70">
            {settings.contactEmail ? (
              <a
                href={`mailto:${settings.contactEmail}`}
                className="flex items-center gap-2.5 transition-colors hover:text-white"
              >
                <Mail className="h-4 w-4 text-brand-300" />
                <span dir="ltr">{settings.contactEmail}</span>
              </a>
            ) : null}
            {settings.contactPhone ? (
              <a
                href={`tel:${settings.contactPhone}`}
                className="flex items-center gap-2.5 transition-colors hover:text-white"
              >
                <Phone className="h-4 w-4 text-brand-300" />
                <span dir="ltr">{settings.contactPhone}</span>
              </a>
            ) : null}
            {settings.address ? (
              <p className="flex items-center gap-2.5">
                <MapPin className="h-4 w-4 text-brand-300" />
                {settings.address}
              </p>
            ) : null}
          </div>

          {(settings.instagramUrl || settings.youtubeUrl) && (
            <div className="mt-6 flex items-center gap-2">
              {settings.instagramUrl ? (
                <a
                  href={settings.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="grid h-10 w-10 place-items-center rounded-lg bg-white/10 transition-colors hover:bg-white/20"
                  aria-label="إنستغرام"
                >
                  <Camera className="h-5 w-5" />
                </a>
              ) : null}
              {settings.youtubeUrl ? (
                <a
                  href={settings.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="grid h-10 w-10 place-items-center rounded-lg bg-white/10 transition-colors hover:bg-white/20"
                  aria-label="يوتيوب"
                >
                  <Video className="h-5 w-5" />
                </a>
              ) : null}
            </div>
          )}
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h3 className="mb-4 text-sm font-bold text-white">{col.title}</h3>
            <ul className="space-y-2.5">
              {col.links.map((link) => (
                <li key={link.href + link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/60 transition-colors hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="container-app flex flex-col items-center justify-between gap-3 py-6 text-center sm:flex-row sm:text-start">
          <p className="text-xs text-white/50">
            © {year} {settings.siteName}. جميع الحقوق محفوظة.
          </p>
          {settings.footerNote ? (
            <p className="max-w-xl text-xs text-white/40">{settings.footerNote}</p>
          ) : null}
        </div>
      </div>
    </footer>
  );
}