"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Clock,
  Send,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Loader2,
  CircleHelp,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export type ExamQuestion = {
  id: string;
  type:
    | "MCQ"
    | "MULTI_TRUE"
    | "TRUE_FALSE"
    | "SHORT"
    | "NUMERIC"
    | "ESSAY";
  text: string;
  options: { id: string; text: string }[];
  points: number;
  hint: string | null;
};

const TYPE_LABELS: Record<ExamQuestion["type"], string> = {
  MCQ: "اختيار من متعدد",
  MULTI_TRUE: "اختيار متعدد الإجابات",
  TRUE_FALSE: "صح / خطأ",
  SHORT: "إجابة قصيرة",
  NUMERIC: "إجابة رقمية",
  ESSAY: "سؤال مقالي",
};

export function ExamRunner({
  examId,
  attemptId,
  title,
  durationMinutes,
  deadline,
  startedAt,
  passingScore,
  showCorrectAnswers,
  questions,
  initialAnswers,
  resultHref,
}: {
  examId: string;
  attemptId: string;
  title: string;
  durationMinutes: number;
  deadline: string;
  startedAt: string;
  passingScore: number;
  showCorrectAnswers: boolean;
  questions: ExamQuestion[];
  initialAnswers: Record<string, unknown>;
  resultHref: string;
}) {
  const router = useRouter();
  const [answers, setAnswers] = useState<Record<string, unknown>>(initialAnswers);
  const [remaining, setRemaining] = useState<number>(() =>
    Math.max(0, Math.floor((new Date(deadline).getTime() - Date.now()) / 1000)),
  );
  const [submitting, setSubmitting] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [flagged, setFlagged] = useState<Set<string>>(new Set());
  const [openHints, setOpenHints] = useState<Set<string>>(new Set());

  const submittedRef = useRef(false);
  const answersRef = useRef(answers);
  answersRef.current = answers;

  /* ---------- العداد التنازلي ---------- */
  useEffect(() => {
    const tick = () => {
      const left = Math.max(
        0,
        Math.floor((new Date(deadline).getTime() - Date.now()) / 1000),
      );
      setRemaining(left);
      if (left === 0 && !submittedRef.current) {
        void submit(true);
      }
    };
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deadline]);

  /* ---------- حفظ تلقائي ---------- */
  useEffect(() => {
    const timer = setTimeout(() => {
      void fetch(`/api/exams/${examId}/attempts/${attemptId}/autosave`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      }).catch(() => undefined);
    }, 4000);
    return () => clearTimeout(timer);
  }, [answers, examId, attemptId]);

  /* ---------- منع مغادرة الصفحة مع وجود إجابات ---------- */
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (!submittedRef.current && Object.keys(answersRef.current).length > 0) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  /* ---------- الإرسال ---------- */
  const submit = useCallback(
    async (auto = false) => {
      if (submittedRef.current || submitting) return;
      submittedRef.current = true;
      setSubmitting(true);

      const timeSpentSec = Math.max(
        0,
        Math.floor(
          (Date.now() - new Date(startedAt).getTime()) / 1000,
        ),
      );

      try {
        const res = await fetch(`/api/exams/${examId}/attempts/${attemptId}/submit`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ answers, timeSpentSec }),
        });

        const data = (await res.json()) as { error?: string };

        if (!res.ok) {
          submittedRef.current = false;
          setSubmitting(false);
          toast.error(data.error ?? "تعذّر إرسال الاختبار");
          return;
        }

        router.push(resultHref);
      } catch {
        submittedRef.current = false;
        setSubmitting(false);
        toast.error("انقطع الاتصال. محاولتك محفوظة — أعد المحاولة.");
      }
    },
    [answers, attemptId, examId, resultHref, router, startedAt, submitting],
  );

  /* ---------- تحديث إجابة ---------- */
  const setAnswer = (questionId: string, value: unknown) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const toggleMulti = (questionId: string, optionId: string) => {
    setAnswers((prev) => {
      const current = Array.isArray(prev[questionId])
        ? (prev[questionId] as string[])
        : [];
      const next = current.includes(optionId)
        ? current.filter((o) => o !== optionId)
        : [...current, optionId];
      return { ...prev, [questionId]: next };
    });
  };

  const answeredCount = useMemo(
    () => questions.filter((q) => {
      const v = answers[q.id];
      if (v === undefined || v === null || v === "") return false;
      if (Array.isArray(v)) return v.length > 0;
      return true;
    }).length,
    [answers, questions],
  );

  const totalPoints = questions.reduce((s, q) => s + q.points, 0);

  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");
  const urgent = remaining <= 120;

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      {/* رأس الاختبار */}
      <div className="sticky top-0 z-20 -mx-4 border-b border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:mx-0 sm:rounded-2xl sm:border">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate font-bold text-ink-900">{title}</h1>
            <p className="text-xs text-ink-500">
              {answeredCount} / {questions.length} مُجابة · {totalPoints} درجة
            </p>
          </div>

          <div
            className={cn(
              "inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-bold tabular-nums",
              urgent
                ? "bg-rose-50 text-rose-700"
                : remaining <= 600
                  ? "bg-amber-50 text-amber-700"
                  : "bg-ink-50 text-ink-700",
            )}
            role="timer"
            aria-live="polite"
          >
            <Clock className="h-4 w-4" />
            {mm}:{ss}
          </div>
        </div>

        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-ink-100">
          <div
            className={cn(
              "h-full rounded-full transition-all",
              urgent ? "bg-rose-500" : "bg-brand-500",
            )}
            style={{
              width: `${(remaining / (durationMinutes * 60)) * 100}%`,
            }}
          />
        </div>
      </div>

      {urgent ? (
        <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <p>الوقت ينفد! سيتم إرسال الاختبار تلقائيًا عند انتهاء الوقت.</p>
        </div>
      ) : null}

      {/* الأسئلة */}
      <ol className="space-y-4">
        {questions.map((question, index) => {
          const answer = answers[question.id];
          const isMulti = question.type === "MULTI_TRUE";
          const hintOpen = openHints.has(question.id);

          return (
            <li key={question.id} className="card p-5 sm:p-6">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand-50 text-xs font-bold text-brand-700">
                      {index + 1}
                    </span>
                    <span className="text-xs font-medium text-ink-500">
                      {TYPE_LABELS[question.type]} · {question.points} درجة
                    </span>
                  </div>

                  <p className="mt-3 leading-loose text-ink-900">{question.text}</p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    setFlagged((prev) => {
                      const next = new Set(prev);
                      if (next.has(question.id)) next.delete(question.id);
                      else next.add(question.id);
                      return next;
                    })
                  }
                  title="وضع علامة للمراجعة لاحقًا"
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-lg transition-colors",
                    flagged.has(question.id)
                      ? "bg-amber-50 text-amber-600"
                      : "text-ink-300 hover:bg-ink-50 hover:text-ink-500",
                  )}
                >
                  <AlertTriangle className="h-4 w-4" />
                </button>
              </div>

              {/* الخيارات */}
              {question.options.length > 0 ? (
                <div className="mt-4 space-y-2.5">
                  {question.options.map((option) => {
                    const selected = isMulti
                      ? Array.isArray(answer) && (answer as string[]).includes(option.id)
                      : answer === option.id;

                    return (
                      <label
                        key={option.id}
                        className={cn(
                          "flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition-colors",
                          selected
                            ? "border-brand-500 bg-brand-50"
                            : "border-ink-200 hover:border-brand-300 hover:bg-ink-50",
                        )}
                      >
                        <input
                          type={isMulti ? "checkbox" : "radio"}
                          name={`q-${question.id}`}
                          value={option.id}
                          checked={selected}
                          onChange={() =>
                            isMulti
                              ? toggleMulti(question.id, option.id)
                              : setAnswer(question.id, option.id)
                          }
                          className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer accent-brand-600"
                        />
                        <span className="text-sm leading-relaxed text-ink-800">
                          {option.text}
                        </span>
                      </label>
                    );
                  })}
                </div>
              ) : question.type === "NUMERIC" ? (
                <input
                  type="number"
                  inputMode="decimal"
                  value={String(answer ?? "")}
                  onChange={(e) => setAnswer(question.id, e.target.value)}
                  placeholder="أدخل الإجابة الرقمية"
                  className="input mt-4"
                  dir="ltr"
                />
              ) : (
                <textarea
                  rows={question.type === "ESSAY" ? 6 : 3}
                  value={String(answer ?? "")}
                  onChange={(e) => setAnswer(question.id, e.target.value)}
                  placeholder={
                    question.type === "ESSAY"
                      ? "اكتب إجابتك بالتفصيل…"
                      : "اكتب إجابتك…"
                  }
                  className="input mt-4 resize-y"
                />
              )}

              {question.hint ? (
                <div className="mt-3">
                  <button
                    type="button"
                    onClick={() =>
                      setOpenHints((prev) => {
                        const next = new Set(prev);
                        if (next.has(question.id)) next.delete(question.id);
                        else next.add(question.id);
                        return next;
                      })
                    }
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 hover:text-brand-800"
                  >
                    <CircleHelp className="h-3.5 w-3.5" />
                    تلميح
                    {hintOpen ? (
                      <ChevronUp className="h-3 w-3" />
                    ) : (
                      <ChevronDown className="h-3 w-3" />
                    )}
                  </button>
                  {hintOpen ? (
                    <p className="mt-2 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-900">
                      {question.hint}
                    </p>
                  ) : null}
                </div>
              ) : null}
            </li>
          );
        })}
      </ol>

      {/* شريط الإرسال */}
      <div className="sticky bottom-0 -mx-4 border-t border-ink-200 bg-white/95 px-4 py-3 backdrop-blur sm:mx-0 sm:rounded-2xl sm:border">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-ink-600">
            {answeredCount === questions.length ? (
              <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-700">
                <CheckCircle2 className="h-4 w-4" />
                أجبت على كل الأسئلة
              </span>
            ) : (
              <span>
                بقي <strong>{questions.length - answeredCount}</strong> سؤال بدون إجابة
              </span>
            )}
            {flagged.size > 0 ? (
              <span className="mr-3 text-amber-700">
                {flagged.size} سؤال معلّم للمراجعة
              </span>
            ) : null}
          </div>

          {!confirmOpen ? (
            <button
              type="button"
              onClick={() => setConfirmOpen(true)}
              disabled={submitting}
              className="btn btn-primary"
            >
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              إرسال الاختبار
            </button>
          ) : (
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setConfirmOpen(false)}
                className="btn btn-outline"
                disabled={submitting}
              >
                رجوع
              </button>
              <button
                type="button"
                onClick={() => void submit()}
                disabled={submitting}
                className="btn btn-primary"
              >
                {submitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                تأكيد الإرسال
              </button>
            </div>
          )}
        </div>

        {confirmOpen ? (
          <p className="mt-2 text-sm text-ink-600">
            {answeredCount < questions.length
              ? `لديك ${questions.length - answeredCount} سؤال بدون إجابة. بعد الإرسال لا يمكنك تعديل إجاباتك. هل تريد الإرسال؟`
              : "بعد الإرسال لن تتمكن من تعديل إجاباتك. هل تريد الإرسال؟"}
          </p>
        ) : null}
      </div>

      <p className="pb-4 text-center text-xs text-ink-400">
        {showCorrectAnswers
          ? "بعد الإرسال ستظهر لك الإجابات الصحيحة والحلول."
          : "بعد الإرسال ستظهر لك درجتك مباشرة."}
      </p>
    </div>
  );
}