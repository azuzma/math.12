"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Send, Loader2, CircleHelp, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import type { ExamQuestion } from "@/components/exams/exam-runner";
import { cn } from "@/lib/utils";

export function AssignmentRunner({
  assignmentId,
  questions,
  totalPoints,
}: {
  assignmentId: string;
  questions: ExamQuestion[];
  totalPoints: number;
}) {
  const router = useRouter();
  const [answers, setAnswers] = useState<Record<string, unknown>>({});
  const [submitting, setSubmitting] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [openHints, setOpenHints] = useState<Set<string>>(new Set());

  const setAnswer = (id: string, value: unknown) =>
    setAnswers((prev) => ({ ...prev, [id]: value }));

  const toggleMulti = (id: string, optionId: string) =>
    setAnswers((prev) => {
      const cur = Array.isArray(prev[id]) ? (prev[id] as string[]) : [];
      return {
        ...prev,
        [id]: cur.includes(optionId)
          ? cur.filter((o) => o !== optionId)
          : [...cur, optionId],
      };
    });

  const answered = questions.filter((q) => {
    const v = answers[q.id];
    if (v === undefined || v === null || v === "") return false;
    if (Array.isArray(v)) return v.length > 0;
    return true;
  }).length;

  async function submit() {
    setSubmitting(true);
    try {
      const res = await fetch(`/api/assignments/${assignmentId}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        toast.error(data.error ?? "تعذّر التسليم");
        setSubmitting(false);
        return;
      }
      router.refresh();
      toast.success("تم تسليم الواجب");
    } catch {
      toast.error("حدث خطأ في الاتصال");
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="sticky top-0 z-10 rounded-xl border border-ink-200 bg-white/95 px-4 py-3 backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-ink-600">
            أجبت على{" "}
            <strong className="text-ink-900">{answered}</strong> من {questions.length}
          </p>
          {!confirm ? (
            <button
              type="button"
              onClick={() => setConfirm(true)}
              className="btn btn-primary"
            >
              <Send className="h-4 w-4" />
              تسليم الواجب
            </button>
          ) : (
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirm(false)}
                className="btn btn-outline"
                disabled={submitting}
              >
                رجوع
              </button>
              <button
                type="button"
                onClick={() => void submit()}
                disabled={submitting}
                className="btn btn-primary"
              >
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                تأكيد التسليم
              </button>
            </div>
          )}
        </div>
        {confirm ? (
          <p className="mt-2 text-sm text-ink-600">
            بعد التسليم لا يمكنك تعديل إجاباتك. الدرجة الكلية {totalPoints} درجة.
          </p>
        ) : null}
      </div>

      <ol className="space-y-4">
        {questions.map((question, index) => {
          const answer = answers[question.id];
          const isMulti = question.type === "MULTI_TRUE";
          const hintOpen = openHints.has(question.id);

          return (
            <li key={question.id} className="card p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand-50 text-xs font-bold text-brand-700">
                  {index + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-ink-500">
                    {question.points} درجة
                  </p>
                  <p className="mt-1 leading-loose text-ink-900">{question.text}</p>
                </div>
              </div>

              {question.options.length > 0 ? (
                <div className="mt-4 space-y-2.5">
                  {question.options.map((option) => {
                    const selected = isMulti
                      ? Array.isArray(answer) &&
                        (answer as string[]).includes(option.id)
                      : answer === option.id;

                    return (
                      <label
                        key={option.id}
                        className={cn(
                          "flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 transition-colors",
                          selected
                            ? "border-brand-500 bg-brand-50"
                            : "border-ink-200 hover:border-brand-300 hover:bg-ink-50",
                        )}
                      >
                        <input
                          type={isMulti ? "checkbox" : "radio"}
                          name={`q-${question.id}`}
                          checked={selected}
                          onChange={() =>
                            isMulti
                              ? toggleMulti(question.id, option.id)
                              : setAnswer(question.id, option.id)
                          }
                          className="mt-0.5 h-4 w-4 shrink-0 accent-brand-600"
                        />
                        <span className="text-sm leading-relaxed text-ink-800">
                          {option.text}
                        </span>
                      </label>
                    );
                  })}
                </div>
              ) : question.type === "NUMERIC" ? (
                <input
                  type="number"
                  inputMode="decimal"
                  dir="ltr"
                  value={String(answer ?? "")}
                  onChange={(e) => setAnswer(question.id, e.target.value)}
                  placeholder="أدخل الإجابة الرقمية"
                  className="input mt-4"
                />
              ) : (
                <textarea
                  rows={question.type === "ESSAY" ? 6 : 3}
                  value={String(answer ?? "")}
                  onChange={(e) => setAnswer(question.id, e.target.value)}
                  placeholder={
                    question.type === "ESSAY"
                      ? "اكتب إجابتك بالتفصيل…"
                      : "اكتب إجابتك…"
                  }
                  className="input mt-4 resize-y"
                />
              )}

              {question.hint ? (
                <div className="mt-3">
                  <button
                    type="button"
                    onClick={() =>
                      setOpenHints((prev) => {
                        const next = new Set(prev);
                        if (next.has(question.id)) next.delete(question.id);
                        else next.add(question.id);
                        return next;
                      })
                    }
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700"
                  >
                    <CircleHelp className="h-3.5 w-3.5" />
                    تلميح
                    {hintOpen ? (
                      <ChevronUp className="h-3 w-3" />
                    ) : (
                      <ChevronDown className="h-3 w-3" />
                    )}
                  </button>
                  {hintOpen ? (
                    <p className="mt-2 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-900">
                      {question.hint}
                    </p>
                  ) : null}
                </div>
              ) : null}
            </li>
          );
        })}
      </ol>
    </div>
  );
}