/**
 * البيانات الأولية — رياضيات الصف 12 متقدم فقط.
 *
 * هيكل المنهج:
 *   الصف 12 متقدم ← الفصل الدراسي ← الوحدة ← المهارة ← الدرس
 *
 * ملاحظة: هذا الملف آمن للتشغيل المتكرر (idempotent).
 * التشغيل:  npm run db:seed
 */

import "dotenv/config";
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import bcrypt from "bcryptjs";

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL! });
const prisma = new PrismaClient({ adapter });

/* ==================================================================
   المنهج: رياضيات الصف الثاني عشر المتقدم (منهج دولة الإمارات)
   ================================================================== */

const CURRICULUM = {
  course: {
    slug: "math-grade-12-advanced",
    title: "رياضيات الصف الثاني عشر — متقدم",
    subtitle: "منهج دولة الإمارات العربية المتحدة للصف 12 متقدم",
    description:
      "المنهج الكامل لرياضيات الصف الثاني عشر المتقدم: المتتاليات، كثيرات الحدود، التفاضل، التكامل، النسب المثلثية والدوال العكسية، وتطبيقات التفاضل والتكامل. شرح بالفيديو، ملخصات، أوراق عمل، واختبارات بتصحيح فوري.",
  },
  terms: [
    {
      slug: "term-1",
      title: "الفصل الدراسي الأول",
      description:
        "المتتاليات، كثيرات الحدود والأعداد المركبة، والتفاضل وقواعد الاشتقاق.",
      units: [
        {
          slug: "t1-unit-sequences",
          title: "الوحدة الأولى: المتتاليات",
          description:
            "المتتاليات العددية، المتتاليات الحسابية والهندسية، متتالية فيبوناتشي، والحد المتسلسل.",
          skills: [
            { slug: "seq-types", title: "أنواع المتتاليات", description: "تمييز المتتاليات الحسابية والهندسية وبيانات كل منها." },
            { slug: "seq-arithmetic", title: "المتتاليات الحسابية", description: "الحد العام والحد النوني والمجموع الجزئي." },
            { slug: "seq-geometric", title: "المتتاليات الهندسية", description: "النسبة ومعامل الانتقال والمجموع الهندسي." },
            { slug: "seq-fibonacci", title: "متتالية فيبوناتشي", description: "تصنيف المتتاليات ومثال فيبوناتشي." },
          ],
          lessons: [
            {
              slug: "seq-intro",
              title: "مقدمة في المتتاليات العددية",
              summary: "نتعرّف على المتتالية، حدها النوني، الحد الأول، وكيفية كتابة الحد العام.",
              skills: ["seq-types"],
            },
            {
              slug: "seq-arithmetic",
              title: "المتتاليات الحسابية",
              summary: "الحد النوني، الحد العام، والمجموع الجزئي للمتتالية الحسابية.",
              skills: ["seq-arithmetic"],
            },
            {
              slug: "seq-geometric",
              title: "المتتاليات الهندسية",
              summary: "معامل الانتقال، الحد العام، والمجموع الجزئي مع الحالات الحدّية.",
              skills: ["seq-geometric"],
            },
            {
              slug: "seq-fibonacci",
              title: "متتالية فيبوناتشي",
              summary: "كيف تظهر فيبوناتشي في الطبيعة وكيف نحلّل متتالية تشبهها.",
              skills: ["seq-fibonacci", "seq-types"],
            },
            {
              slug: "seq-convergence",
              title: "الحد المتسلسل للمتتالية",
              summary: "متى تقترب المتتالية، والحد المتسلسل، والمجموع اللانهائي للهندسية.",
              skills: ["seq-geometric", "seq-arithmetic"],
            },
          ],
        },
        {
          slug: "t1-unit-polynomial",
          title: "الوحدة الثانية: كثيرات الحدود والأعداد المركبة",
          description:
            "القسمة على كثيرات الحدود، نظرية الباقي، والأعداد المركبة وطرق كتابتها.",
          skills: [
            { slug: "poly-division", title: "القسمة على كثيرات الحدود", description: "خطوات القسمة الطويلة وإيجاد الناتج والباقي." },
            { slug: "poly-remainder", title: "نظرية الباقي", description: "إيجاد قيمة كثير الحدود عند عدد، وبناء المعادلات من جذورها." },
            { slug: "poly-complex", title: "الأعداد المركبة", description: "الشكل الجبري والقطبي للأعداد المركبة." },
          ],
          lessons: [
            {
              slug: "poly-division-long",
              title: "القسمة الطويلة على كثيرات الحدود",
              summary: "خطوات القسمة الطويلة وناتج القسمة والباقي.",
              skills: ["poly-division"],
            },
            {
              slug: "poly-remainder",
              title: "نظرية الباقي",
              summary: "قيمة كثير الحدود عند عدد، وبناء المعادلة من الباقي.",
              skills: ["poly-remainder"],
            },
            {
              slug: "poly-complex-numbers",
              title: "الأعداد المركبة",
              summary: "المركب|الشكل الجبري والقطبي، والعمليات عليها.",
              skills: ["poly-complex"],
            },
          ],
        },
        {
          slug: "t1-unit-differentiation",
          title: "الوحدة الثالثة: التفاضل",
          description:
            "المشتقة من التعريف، قواعد الاشتقاق، المشتقة العليا، وتطبيقات المشتقة.",
          skills: [
            { slug: "diff-definition", title: "المشتقة من التعريف", description: "اشتقاق دالة بمشتقة التعريف خطوة بخطوة." },
            { slug: "diff-rules", title: "قواعد الاشتقاق", description: "قاعدة الجداء، خارج القسمة، وقاعدة السلسلة." },
            { slug: "diff-higher", title: "المشتقة العليا", description: "حساب المشتقة الثانية والثالثة." },
            { slug: "diff-applications", title: "تطبيقات المشتقة", description: "معدل التغير، النقاط الحرجة، والقيم العظمى والصغرى." },
          ],
          lessons: [
            {
              slug: "diff-definition",
              title: "مشتقة الدالة من التعريف",
              summary: "نسبة الفراض، اشتقاق x² و x³ من التعريف خطوة بخطوة.",
              skills: ["diff-definition"],
            },
            {
              slug: "diff-basic-rules",
              title: "قواعد الاشتقاق الأساسية",
              summary: "قاعدة الجداء، خارج القسمة، ودوال القوة والجيب واللوغاريتم والأس.",
              skills: ["diff-rules"],
            },
            {
              slug: "diff-chain",
              title: "قاعدة السلسلة",
              summary: "اشتقاق الدوال المركبة (u(x))^n والدوال المثلثية المركبة.",
              skills: ["diff-rules"],
            },
            {
              slug: "diff-higher-order",
              title: "المشتقة العليا",
              summary: "المشتقة الثانية والثالثة وتطبيقاتها على منحنى.",
              skills: ["diff-higher"],
            },
            {
              slug: "diff-applications",
              title: "تطبيقات المشتقة: التغيّر والتحليل الأمثل",
              summary: "معدل التغير، النقاط الحرجة، والقيم العظمى والصغرى.",
              skills: ["diff-applications", "diff-higher"],
            },
          ],
        },
      ],
    },
    {
      slug: "term-2",
      title: "الفصل الدراسي الثاني",
      description:
        "التكامل والتطبيقات، النسب المثلثية والدوال العكسية، وتطبيقات التفاضل والتكامل.",
      units: [
        {
          slug: "t2-unit-integration",
          title: "الوحدة الرابعة: التكامل",
          description:
            "التكامل غير المحدد، التكامل المحدد، حساب المساحات، وطرق التكامل.",
          skills: [
            { slug: "int-indefinite", title: "التكامل غير المحدد", description: "إيجاد الدوال الأصلية وشروط التكامل." },
            { slug: "int-definite", title: "التكامل المحدد", description: " foundations وخصائص التكامل المحدد." },
            { slug: "int-techniques", title: "طرق التكامل", description: "التكامل بالتعويض وبالجزئي." },
            { slug: "int-area", title: "التكامل في حساب المساحات", description: "مساحة تحت المنحنى وبين المنحنيات." },
          ],
          lessons: [
            {
              slug: "int-indefinite",
              title: "مقدمة في التكامل",
              summary: "التكامل كعكس الاشتقاق،Finding الدوال الأصلية،الثوابت.",
              skills: ["int-indefinite"],
            },
            {
              slug: "int-basic-methods",
              title: "طرق التكامل الأساسية",
              summary: "التكامل مع حدوده ونوعي الدوال، وجدول تكاملات أساسية.",
              skills: ["int-indefinite", "int-techniques"],
            },
            {
              slug: "int-substitution",
              title: "التكامل بالتعويض",
              summary: "التعرف على u ثم استبدالها وتحويل الحدود.",
              skills: ["int-techniques"],
            },
            {
              slug: "int-by-parts",
              title: "التكامل بالجزئي",
              summary: "طريقة التكامل بالجزئي عندما لا يكون التعويض بسيطًا.",
              skills: ["int-techniques"],
            },
            {
              slug: "int-definite",
              title: "التكامل المحدد وخصائصه",
              summary: "تعريف التكامل المحدد، الخصائص، وقيمة المساحة.",
              skills: ["int-definite"],
            },
            {
              slug: "int-area-under-curve",
              title: "حساب المساحة تحت المنحنى",
              summary: "المساحة bounded، والتكامل المحدد لحساب المساحات.",
              skills: ["int-area", "int-definite"],
            },
          ],
        },
        {
          slug: "t2-unit-trigonometry",
          title: "الوحدة الخامسة: النسب المثلثية والدوال العكسية",
          description:
            "النسب المثلثية في المثلث والدائرة، المتطابقات المثلثية، الدوال المثلثية العكسية.",
          skills: [
            { slug: "trig-ratios", title: "النسب المثلثية", description: "جيب وجيب تمام وظل في المثلث القائم." },
            { slug: "trig-identities", title: "المتطابقات المثلثية", description: "المتطابقات الأساسية والجمع والفرق." },
            { slug: "trig-inverse", title: "الدوال المثلثية العكسية", description: "أرSinSecastcot،ومجال كل منها." },
            { slug: "trig-equations", title: "حل المعادلات المثلثية", description: "حل المعادلات في مجال محدد." },
          ],
          lessons: [
            {
              slug: "trig-ratios-intro",
              title: "النسب المثلثية في المثلث القائم",
              summary: "تعريف الجيب وجيب التمام والظل وأمثلة محسولة.",
              skills: ["trig-ratios"],
            },
            {
              slug: "trig-unit-circle",
              title: "النسب المثلثية على دائرة الوحدة",
              summary: "تمثيل النسب المثلثية بإحداثيات أي نقطة على الدائرة.",
              skills: ["trig-ratios"],
            },
            {
              slug: "trig-identities",
              title: "المتطابقات المثلثية الأساسية",
              summary: "متطابقة بايكاغور، sec²=1+tan²، ومتطابقات الجمع والفرق.",
              skills: ["trig-identities"],
            },
            {
              slug: "trig-inverse",
              title: "الدوال المثلثية العكسية",
              summary: "أرSinSecCot، ومجال كل دالة ومدى كل منها.",
              skills: ["trig-inverse", "trig-ratios"],
            },
            {
              slug: "trig-equations",
              title: "حل المعادلات المثلثية",
              summary: "حل المعادلات المثلثية في مجال محدد بالدرجات.",
              skills: ["trig-equations", "trig-inverse"],
            },
          ],
        },
        {
          slug: "t2-unit-applications",
          title: "الوحدة السادسة: تطبيقات التفاضل والتكامل",
          description:
            "المتجهات في المستوي، الحركة والتسارع، ومعدلات التغيّر المترابطة، وتطبيقات التفاضل والتكامل في الإحصاء.",
          skills: [
            { slug: "app-vectors", title: "المتجهات في المستوي", description: "تمثيل المتجهات والعمليات عليها." },
            { slug: "app-motion", title: "الحركة والتسارع", description: "السرعة والتسارع باستخدام المشتقة الثانية." },
            { slug: "app-rates", title: "معدلات التغيّر المترابطة", description: "معدل التغير بين متغيرين مترابطين." },
            { slug: "app-continuous-prob", title: "الاحتمالات بالتكامل", description: "الدالة التوزيعية المستمرة وحساب الاحتمال بالتكامل." },
          ],
          lessons: [
            {
              slug: "app-vectors",
              title: "المتجهات في المستوي",
              summary: "المقدار والاتجاه وجمع المتجهات، تمثيلها على المستوى.",
              skills: ["app-vectors"],
            },
            {
              slug: "app-motion",
              title: "الحركة والتسارع",
              summary: "السرعة = المشتقة، والتسارع = المشتقة الثانية.",
              skills: ["app-motion", "diff-higher"],
            },
            {
              slug: "app-related-rates",
              title: "معدلات التغيّر المترابطة",
              summary: "العلاقة بين متغيرين واستخراج معدل أحدهما من الآخر.",
              skills: ["app-rates"],
            },
            {
              slug: "app-probability-calculus",
              title: "تطبيقات التفاضل والتكامل في الإحصاء",
              summary: "الدالة التوزيعية الاحتمالية المستمرة وحساب الاحتمال بالتكامل.",
              skills: ["app-continuous-prob", "int-definite"],
            },
          ],
        },
      ],
    },
  ],
};

/* ==================================================================
   بنك الأسئلة
   ================================================================== */

type BankItem = {
  lessonSlug: string;
  examSlug: string;
  examTitle: string;
  type: "LESSON" | "UNIT" | "TERM" | "REVIEW" | "MOCK";
  questions: {
    type: "MCQ" | "MULTI_TRUE" | "TRUE_FALSE" | "NUMERIC" | "SHORT" | "ESSAY";
    text: string;
    options?: string[];
    /** نص واحد للإجابة المفردة، أو مصفوفة نصوص للإجابات المتعددة */
    correct: string | string[];
    solution: string;
    hint?: string;
    points?: number;
    difficulty?: "EASY" | "MEDIUM" | "HARD" | "CHALLENGE";
    skillSlug?: string;
  }[];
};

const QUESTION_BANK: BankItem[] = [
  /* ---------- الوحدة 1: المتتاليات ---------- */
  {
    lessonSlug: "seq-intro",
    examSlug: "exam-seq-intro",
    examTitle: "اختبار درس: مقدمة في المتتاليات العددية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "المتتالية 3، 7، 11، 15، … هي متتالية:",
        options: ["حسابية", "هندسية", "فيبوناتشي", "متناوبة"],
        correct: "حسابية",
        solution: "الفرق بين كل حدين متتاليين ثابت ويساوي 4، وهذا تعريف المتتالية الحسابية.",
        difficulty: "EASY",
      },
      {
        type: "MCQ",
        text: "في المتتالية a₁=2، a₂=5، a₃=8، … الحد النوني العام هو:",
        options: ["aₙ = 3n − 1", "aₙ = 3n + 1", "aₙ = 3n", "aₙ = n² + 1"],
        correct: "aₙ = 3n − 1",
        solution: "aₙ = a₁ + (n−1)d = 2 + (n−1)(3) = 3n − 1.",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "في المتتالية الحسابية a₁=5 و d=3، احسب a₁₂.",
        correct: "38",
        solution: "a₁₂ = 5 + (12−1)(3) = 5 + 33 = 38.",
        difficulty: "EASY",
      },
      {
        type: "TRUE_FALSE",
        text: "كل متتالية فيبوناتشي هي متتالية هندسية.",
        correct: "خطأ",
        solution:
          "خطأ. متتالية فيبوناتشي ليست هندسية لأن النسبة بين كل حدين ليست ثابتة.",
        difficulty: "MEDIUM",
      },
    ],
  },
  {
    lessonSlug: "seq-arithmetic",
    examSlug: "exam-seq-arithmetic",
    examTitle: "اختبار درس: المتتاليات الحسابية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "المجموع الجزئي Sₙ لمتتالية حسابية يساوي:",
        options: [
          "n/2 [2a₁ + (n−1)d]",
          "n(a₁ + aₙ)",
          "a₁ + nd",
          "n²d",
        ],
        correct: "n/2 [2a₁ + (n−1)d]",
        solution: "القيمة بصيغة المجموع заклюفي: Sₙ = n/2 [2a₁ + (n−1)d].",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "احسب S₂₀ لمتتالية حسابية a₁=4 و d=3.",
        correct: "650",
        solution: "a₂₀ = 4 + 19(3) = 61. إذن S₂₀ = 20/2 × (4 + 61) = 10 × 65 = 650.",
        difficulty: "HARD",
      },
      {
        type: "MCQ",
        text: "إذا كان a₈ = 26 في متتالية حسابية و a₁ = 5 فإن الفرق d يساوي:",
        options: ["2", "3", "4", "21"],
        correct: "3",
        solution: "بالعلاقة aₙ = a₁ + (n−1)d: 26 = 5 + 7d → 7d = 21 → d = 3.",
        difficulty: "MEDIUM",
        hint: "استعمل: aₙ = a₁ + (n−1)d ثم عوّض n = 8.",
      },
    ],
  },
  {
    lessonSlug: "seq-geometric",
    examSlug: "exam-seq-geometric",
    examTitle: "اختبار درس: المتتاليات الهندسية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "المتتالية 2، 6، 18، 54، … لها معامل انتقال يساوي:",
        options: ["2", "3", "6", "18"],
        correct: "3",
        solution: "r = 6/2 = 18/6 = 3.",
        difficulty: "EASY",
      },
      {
        type: "NUMERIC",
        text: "في متتالية هندسية a₁=3 و r=2، احسب a₆.",
        correct: "96",
        solution: "a₆ = a₁ × r⁵ = 3 × 32 = 96.",
        difficulty: "EASY",
      },
      {
        type: "MCQ",
        text: "المجموع الجزئي لمتتالية هندسية لا نهائي عدد حدودها ∞ يساوي:",
        options: ["a₁/(1−r) إذا |r| < 1", "a₁/(r−1) دائمًا", "a₁ × r∞", "لا يوجد مجموع"],
        correct: "a₁/(1−r) إذا |r| < 1",
        solution:
          "مجموع المتتالية الهندسية اللانهائية = a₁/(1−r) بشرط |r| < 1 فقط.",
        difficulty: "MEDIUM",
      },
      {
        type: "SHORT",
        text: "اذكر شرط تقارب المتتالية الهندسية اللانهائية.",
        correct: "|r| < 1",
        solution: "يتقارب المجموع فقط إذا كان |r| < 1.",
        difficulty: "MEDIUM",
      },
    ],
  },
  /* ---------- الوحدة 2: كثيرات الحدود ---------- */
  {
    lessonSlug: "poly-remainder",
    examSlug: "exam-poly-remainder",
    examTitle: "اختبار درس: نظرية الباقي",
    type: "LESSON",
    questions: [
      {
        type: "NUMERIC",
        text: "إذا كان f(x) = x³ − 2x + 5 فإن f(2) يساوي:",
        correct: "9",
        solution: "f(2) = 2³ − 2(2) + 5 = 8 − 4 + 5 = 9.",
        difficulty: "EASY",
      },
      {
        type: "MCQ",
        text: "القسمة (x² − 4) ÷ (x − 2) تعطي:",
        options: ["x + 2", "x − 2", "x² + 2", "x + 3"],
        correct: "x + 2",
        solution: "(x−2)(x+2) = x² − 4، إذن الناتج x + 2 والباقي صفر.",
        difficulty: "EASY",
      },
      {
        type: "MCQ",
        text: "إذا كان الباقي عند قسمة P(x) على (x − 3) هو 7 فإن:",
        options: ["P(3) = 7", "P(0) = 7", "P(7) = 3", "لا يمكن تحديد P(3)"],
        correct: "P(3) = 7",
        solution: "نظرية الباقي: الباقي = P(الجذر) أي P(3).",
        difficulty: "MEDIUM",
      },
      {
        type: "ESSAY",
        text: "برهن أن (x − 2) قاسم لكثير حدود f(x) إذا كان f(2) = 0.",
        correct: " f(2) = 0 يعني أن (x−2) عامل من عوامل f(x)",
        solution:
          "حسب نظرية الباقي: قسمة f(x) على (x−2) تترك باقيًا يساوي f(2) = 0، وعليه يكون (x−2) قاسمًا لكثير الحدود.",
        difficulty: "CHALLENGE",
      },
    ],
  },
  /* ---------- الوحدة 3: التفاضل ---------- */
  {
    lessonSlug: "diff-basic-rules",
    examSlug: "exam-diff-basic-rules",
    examTitle: "اختبار درس: قواعد الاشتقاق الأساسية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "إذا كانت f(x) = x³ − 4x + 2 فإن f′(x) يساوي:",
        options: ["3x² − 4", "3x³ − 4", "x² − 4", "3x − 4"],
        correct: "3x² − 4",
        solution: "قاعدة القوة f′(x)=3x²، وقاعدة الخطية f′=−4.",
        difficulty: "EASY",
      },
      {
        type: "MCQ",
        text: "مشتقة g(x) = (2x + 1)⁵ تساوي:",
        options: ["10(2x+1)⁴", "5(2x+1)⁴", "(2x+1)⁴", "10(2x+1)⁵"],
        correct: "10(2x+1)⁴",
        solution: "قاعدة السلسلة: g′ = 5(2x+1)⁴ × 2 = 10(2x+1)⁴.",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "إذا كانت h(x) = 4x² − 3x فإن h′(2) تساوي:",
        correct: "13",
        solution: "h′(x) = 8x − 3، إذن h′(2) = 16 − 3 = 13.",
        difficulty: "EASY",
      },
      {
        type: "MULTI_TRUE",
        text: "أي مما يلي مشتقات صحيحة؟",
        options: [
          "d/dx (sin x) = cos x",
          "d/dx (eˣ) = eˣ",
          "d/dx (ln x) = 1/x",
          "d/dx (x²) = 2",
        ],
        correct: ["d/dx (sin x) = cos x", "d/dx (eˣ) = eˣ", "d/dx (ln x) = 1/x"],
        solution:
          "الأولى والثانية والثالثة صحيحة؛ الرابعة خاطئة لأن مشتقة x² هي 2x لا 2.",
        difficulty: "HARD",
      },
    ],
  },
  {
    lessonSlug: "diff-chain",
    examSlug: "exam-diff-chain",
    examTitle: "اختبار درس: قاعدة السلسلة",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "مشتقة y = sin(x²) تساوي:",
        options: ["2x cos(x²)", "cos(x²)", "2x sin(x²)", "x cos(x²)"],
        correct: "2x cos(x²)",
        solution: "قاعدة السلسلة: مشتقة sin(u) = cos(u)×u′ مع u = x² و u′ = 2x.",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "إذا كانت f(x) = (3x + 1)⁴ فإن f′(1) تساوي:",
        correct: "768",
        solution: "بقاعدة السلسلة: f′(x) = 4(3x+1)³ × 3 = 12(3x+1)³. عند x = 1: 12 × 4³ = 12 × 64 = 768.",
        hint: "f′(x) = 12(3x+1)³، ومنه f′(1) = 12 × 4³.",
        difficulty: "HARD",
      },
      {
        type: "MCQ",
        text: "مشتقة y = (2x + 1)/(x + 3) تساوي:",
        options: ["5/(x+3)²", "(x+3)/(2x+1)", "5/(x+3)", "1/(x+3)²"],
        correct: "5/(x+3)²",
        solution:
          "خارج القسمة: [(2)(x+3) − (2x+1)(1)]/(x+3)² = [2x+6−2x−1]/(x+3)² = 5/(x+3)².",
        difficulty: "CHALLENGE",
      },
    ],
  },
  {
    lessonSlug: "diff-applications",
    examSlug: "exam-diff-applications",
    examTitle: "اختبار درس: تطبيقات المشتقة",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "النقطة التي تكون عندها f′(x) = 0 على منحنى تسمى:",
        options: ["نقطة حرجة", "نقطة نهاية", "نقطة تقاطع", "نقطة قصوى دائمة"],
        correct: "نقطة حرجة",
        solution: "هي النقطة التي مشتقتها صفر، وقد تكون قيمة عظمى أو صغرى أو تقطة انقلاب.",
        difficulty: "EASY",
      },
      {
        type: "NUMERIC",
        text: "إذا كانت f(x) = x³ − 3x فإن أصغر قيمة محلية لـ f(x) تساوي:",
        correct: "2",
        solution: "f′=3x²−3=0 → x=±1. عند x=−1: f=−1+3=2 وهي أصغر قيمة محلية.",
        difficulty: "HARD",
      },
      {
        type: "MCQ",
        text: "عند النقطة الحرجة نفحص f″ لتحديد أن النقطة:",
        options: ["قيمة عظمى أو صغرى", "نقطة نهاية", "جذر", "لا يمكن تحديدها"],
        correct: "قيمة عظمى أو صغرى",
        solution:
          "اختبار المشتقة الثانية: f″>0 → صغرى، f″<0 → عظمى، f″=0 → نكرر.",
        difficulty: "MEDIUM",
      },
    ],
  },
  /* ---------- الوحدة 4: التكامل ---------- */
  {
    lessonSlug: "int-indefinite",
    examSlug: "exam-int-indefinite",
    examTitle: "اختبار درس: مقدمة في التكامل",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "∫ x² dx يساوي:",
        options: ["x³/3 + C", "2x + C", "x³ + C", "ln(x) + C"],
        correct: "x³/3 + C",
        solution: "نحصل على دالة أصلية لـ x² بإضافة 1 للأس ورفع 3، مع ثابت C.",
        difficulty: "EASY",
      },
      {
        type: "SHORT",
        text: "إذا كان F(x) = x³ + 2x فإن ∫ F′(x) dx يساوي (بدون ثابت):",
        correct: "x^3 + 2x",
        solution: "F′(x) = 3x² + 2، وتكاملها يعيد x³ + 2x + C.",
        difficulty: "MEDIUM",
      },
      {
        type: "MCQ",
        text: "القانون ∫ aˣ dx يساوي:",
        options: ["aˣ/ln a + C", "x·aˣ + C", "aˣ⁺¹ + C", "ln(aˣ) + C"],
        correct: "aˣ/ln a + C",
        solution: "التكامل مع الأساس: ∫aˣdx = aˣ/ln a + C.",
        difficulty: "MEDIUM",
      },
    ],
  },
  {
    lessonSlug: "int-definite",
    examSlug: "exam-int-definite",
    examTitle: "اختبار درس: التكامل المحدد",
    type: "LESSON",
    questions: [
      {
        type: "NUMERIC",
        text: "احسب ∫₀¹ x² dx.",
        correct: "1/3",
        solution: "[x³/3]₀¹ = 1/3 − 0 = 1/3.",
        difficulty: "EASY",
      },
      {
        type: "NUMERIC",
        text: "احسب ∫₁³ (2x + 1) dx.",
        correct: "10",
        solution: "الدالة الأصلية لـ 2x + 1 هي x² + x. إذن [x² + x]₁³ = (9 + 3) − (1 + 1) = 12 − 2 = 10.",
        hint: "الدالة الأصلية هي x² + x، عوّض الحدّين ثم اطرح.",
        difficulty: "HARD",
      },
      {
        type: "TRUE_FALSE",
        text: "قيمة التكامل المحدد لا تعتمد على طول الفترة [a, b] بل على موضعها.",
        correct: "خطأ",
        solution: "خطأ. إذا غيّرنا الفترة تغيّرت القيمة إلا إذا كانت الدالة صفرية.",
        difficulty: "MEDIUM",
      },
    ],
  },
  /* ---------- الوحدة 5: المثلثات ---------- */
  {
    lessonSlug: "trig-ratios-intro",
    examSlug: "exam-trig-ratios",
    examTitle: "اختبار درس: النسب المثلثية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "في مثلث قائم، cot θ تساوي:",
        options: ["cos θ / sin θ", "sin θ / cos θ", "1/sin θ", "tan θ"],
        correct: "cos θ / sin θ",
        solution: "cot = 1/tan = cos/sin (الضلع القابل ÷ الضلع المقابل).",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "في مثلث قائم، إذا كان sin θ = 3/5 فإن cos θ يساوي:",
        correct: "0.8",
        solution: "مثلث 3-4-5: cos θ = 4/5 = 0.8.",
        difficulty: "EASY",
      },
      {
        type: "TRUE_FALSE",
        text: "sec θ = 1/cos θ",
        correct: "صح",
        solution: "صح. هذا تعريف الدالة العاكسة للجيب التمام.",
        difficulty: "EASY",
      },
    ],
  },
  {
    lessonSlug: "trig-equations",
    examSlug: "exam-trig-equations",
    examTitle: "اختبار درس: حل المعادلات المثلثية",
    type: "LESSON",
    questions: [
      {
        type: "MCQ",
        text: "الحل العام للمعادلة sin x = ½ في الراديان هو:",
        options: [
          "x = π/6 + 2kπ أو x = 5π/6 + 2kπ",
          "x = π/6 فقط",
          "x = π/6 + kπ",
          "x = 5π/6 فقط",
        ],
        correct: "x = π/6 + 2kπ أو x = 5π/6 + 2kπ",
        solution: "في الدائرة الوحدة يوجد حلان في الدورة الواحدة، ثم يتكرران كل 2π.",
        difficulty: "MEDIUM",
      },
      {
        type: "NUMERIC",
        text: "كم عدد حلول المعادلة sin x = 0 في المجال [0, 2π]؟",
        correct: "2",
        solution: "الحلان هما x = 0 و x = π.",
        difficulty: "MEDIUM",
      },
    ],
  },
  /* ---------- اختبار وحدة ---------- */
  {
    lessonSlug: "seq-geometric",
    examSlug: "exam-unit-sequences",
    examTitle: "اختبار وحدة: المتتاليات",
    type: "UNIT",
    questions: [
      {
        type: "NUMERIC",
        text: "في متتالية هندسية a₁=5 و r=3، احسب a₅.",
        correct: "405",
        solution: "a₅ = 5 × 3⁴ = 5 × 81 = 405.",
        difficulty: "HARD",
      },
      {
        type: "MCQ",
        text: "أي المتتاليات التالية متتالية هندسية؟",
        options: ["1، 3، 9، 27", "1، 2، 4، 5", "5، 4، 3، 2", "0، 1، 2، 3"],
        correct: "1، 3، 9، 27",
        solution: "النسبة بين كل حدين ثابتة = 3.",
        difficulty: "EASY",
      },
      {
        type: "SHORT",
        text: "اذكر شرط تقارب المتتالية الهندسية.",
        correct: "|r| < 1",
        solution: "يجب أن يكون معامل الانتقال |r| < 1 ليتقارب المجموع.",
        difficulty: "MEDIUM",
      },
    ],
  },
  /* ---------- اختبار تجريبي ---------- */
  {
    lessonSlug: "diff-chain",
    examSlug: "exam-mock-1",
    examTitle: "اختبار تجريبي شامل — الفصل الأول",
    type: "MOCK",
    questions: [
      {
        type: "NUMERIC",
        text: "احسب f′(2) إذا كانت f(x) = x³ − 2x.",
        correct: "10",
        solution: "f′(x) = 3x² − 2، إذن f′(2) = 12 − 2 = 10.",
        difficulty: "MEDIUM",
      },
      {
        type: "MCQ",
        text: "قيمة f(3) لكثير الحدود f(x) = x² − 5x + 2 تساوي:",
        options: ["−4", "4", "2", "16"],
        correct: "−4",
        solution: "f(3) = 9 − 15 + 2 = −4.",
        difficulty: "EASY",
      },
      {
        type: "MULTI_TRUE",
        text: "أي مما يلي صحيح حول التكامل؟",
        options: [
          "∫f(x)dx = F(x) + C حيث F′ = f",
          "التكامل المحدد له ثابت C",
          "∫₀ᵃ f = −∫ₐ⁰ f",
          "التكامل عكس الاشتقاق",
        ],
        correct: [
          "∫f(x)dx = F(x) + C حيث F′ = f",
          "∫₀ᵃ f = −∫ₐ⁰ f",
          "التكامل عكس الاشتقاق",
        ],
        solution:
          "التكامل المحدد قيمة عددية محددة فلا يوجد ثابت C فيه، لذا الخيار الثاني خاطئ.",
        difficulty: "CHALLENGE",
      },
    ],
  },
];

/* ==================================================================
   التنفيذ
   ================================================================== */

async function main() {
  console.log("▶ بدء تعبئة بيانات رياضيات الصف 12 متقدم…");

  /* ---------- 1) المدير ---------- */
  const adminEmail = (process.env.SEED_ADMIN_EMAIL ?? "admin@platform.com").toLowerCase();
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "Admin@12345";

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    create: {
      email: adminEmail,
      passwordHash: await bcrypt.hash(adminPassword, 12),
      fullName: process.env.SEED_ADMIN_NAME ?? "مدير المنصة",
      role: "ADMIN",
      status: "ACTIVE",
      emailVerified: true,
    },
    update: { role: "ADMIN", status: "ACTIVE" },
  });
  console.log(`✔ حساب المدير: ${admin.email}`);

  /* ---------- 2) تنظيف أي صفوف أخرى (المنصة للصف 12 فقط) ---------- */
  const others = await prisma.grade.findMany({
    where: { NOT: { slug: "grade-12-advanced" } },
    select: { id: true, slug: true },
  });
  if (others.length > 0) {
    for (const g of others) {
      await prisma.grade.delete({ where: { id: g.id } }).catch(() => undefined);
    }
    console.log(`✔ حذف صفوف غير مطلوبة: ${others.map((g) => g.slug).join(", ")}`);
  }

  /* ---------- 3) الصف 12 متقدم ---------- */
  const grade = await prisma.grade.upsert({
    where: { slug: "grade-12-advanced" },
    create: {
      slug: "grade-12-advanced",
      nameAr: "الصف الثاني عشر متقدم",
      nameEn: "Grade 12 Advanced",
      stageAr: "المرحلة الثانوية",
      stageSlug: "secondary",
      order: 12,
      description:
        "رياضيات الصف الثاني عشر المتقدم — منهج دولة الإمارات العربية المتحدة: المتتاليات، كثيرات الحدود، التفاضل، التكامل، والنسب المثلثية.",
    },
    update: { nameAr: "الصف الثاني عشر متقدم", nameEn: "Grade 12 Advanced" },
  });
  console.log(`✔ الصف: ${grade.nameAr}`);

  /* ---------- 4) المادة والمقرر ---------- */
  const subject = await prisma.subject.upsert({
    where: { slug: "math-grade-12-advanced" },
    create: {
      slug: "math-grade-12-advanced",
      nameAr: "الرياضيات",
      nameEn: "Mathematics",
      order: 1,
      gradeId: grade.id,
    },
    update: { nameAr: "الرياضيات", gradeId: grade.id },
  });

  const course = await prisma.course.upsert({
    where: { slug: CURRICULUM.course.slug },
    create: {
      slug: CURRICULUM.course.slug,
      title: CURRICULUM.course.title,
      subtitle: CURRICULUM.course.subtitle,
      description: CURRICULUM.course.description,
      status: "PUBLISHED",
      order: 1,
      subjectId: subject.id,
    },
    update: { title: CURRICULUM.course.title, status: "PUBLISHED" },
  });
  console.log(`✔ المقرر: ${course.title}`);

  /* ---------- 5) الفصول والوحدات والمهارات والدروس ---------- */
  let termsCount = 0;
  let unitsCount = 0;
  let skillsCount = 0;
  let lessonsCount = 0;

  for (const [termIdx, termData] of CURRICULUM.terms.entries()) {
    const term = await prisma.term.upsert({
      where: { slug: termData.slug },
      create: {
        slug: termData.slug,
        title: termData.title,
        description: termData.description,
        status: "PUBLISHED",
        order: termIdx + 1,
        courseId: course.id,
      },
      update: { title: termData.title, status: "PUBLISHED", courseId: course.id },
    });
    termsCount++;

    for (const [unitIdx, unitData] of termData.units.entries()) {
      const unit = await prisma.unit.upsert({
        where: { slug: unitData.slug },
        create: {
          slug: unitData.slug,
          title: unitData.title,
          description: unitData.description,
          status: "PUBLISHED",
          order: unitIdx + 1,
          courseId: course.id,
          termId: term.id,
        },
        update: {
          title: unitData.title,
          status: "PUBLISHED",
          termId: term.id,
          courseId: course.id,
        },
      });
      unitsCount++;

      const skillIdBySlug = new Map<string, string>();
      for (const [skillIdx, skillData] of unitData.skills.entries()) {
        const skill = await prisma.skill.upsert({
          where: { slug: skillData.slug },
          create: {
            slug: skillData.slug,
            title: skillData.title,
            description: skillData.description,
            status: "PUBLISHED",
            order: skillIdx + 1,
            unitId: unit.id,
          },
          update: { title: skillData.title, status: "PUBLISHED", unitId: unit.id },
        });
        skillIdBySlug.set(skillData.slug, skill.id);
        skillsCount++;
      }

      for (const [lessonIdx, lessonData] of unitData.lessons.entries()) {
        // الدرس يرتبط بأول مهارة مذكورة في تعريفه
        const primarySkillId =
          lessonData.skills[0] !== undefined
            ? (skillIdBySlug.get(lessonData.skills[0]) ?? null)
            : null;

        await prisma.lesson.upsert({
          where: { slug: lessonData.slug },
          create: {
            slug: lessonData.slug,
            title: lessonData.title,
            summary: lessonData.summary,
            description: `${lessonData.summary}\n\nفي هذا الدرس نشرح الفكرة خطوة بخطوة، ثم نحل أمثلة متدرجة، وننهي بتمرين قصير للتقويم الذاتي.`,
            status: "PUBLISHED",
            order: lessonIdx + 1,
            unitId: unit.id,
            skillId: primarySkillId,
          },
          update: {
            title: lessonData.title,
            summary: lessonData.summary,
            unitId: unit.id,
            skillId: primarySkillId,
          },
        });
        lessonsCount++;
      }
    }
  }
  console.log(
    `✔ ${termsCount} فصل · ${unitsCount} وحدة · ${skillsCount} مهارة · ${lessonsCount} درس`,
  );

  /* ---------- 6) بنك الأسئلة والاختبارات ---------- */
  let questionsCount = 0;
  let examsCount = 0;

  // كل درس مرتبط بمهارة واحدة على الأقل، تُستخدم كربط افتراضي للسؤال
  const lessonRows = await prisma.lesson.findMany({
    where: { unit: { courseId: course.id } },
    select: { id: true, skillId: true, unitId: true },
  });
  const unitFirstSkill = new Map<string, string>();
  for (const sk of await prisma.skill.findMany({
    where: { unit: { courseId: course.id } },
    orderBy: { order: "asc" },
    select: { id: true, unitId: true },
  })) {
    if (!unitFirstSkill.has(sk.unitId)) unitFirstSkill.set(sk.unitId, sk.id);
  }
  const lessonSkillFallback = new Map<string, string>();
  for (const row of lessonRows) {
    const id = row.skillId ?? unitFirstSkill.get(row.unitId);
    if (id) lessonSkillFallback.set(row.id, id);
  }

  for (const entry of QUESTION_BANK) {
    const lesson = await prisma.lesson.findUnique({
      where: { slug: entry.lessonSlug },
      include: { unit: { select: { termId: true, id: true } } },
    });
    if (!lesson) {
      console.warn(`⚠ الدرس غير موجود: ${entry.lessonSlug}`);
      continue;
    }

    const unit = await prisma.unit.findUniqueOrThrow({
      where: { id: lesson.unit.id },
      select: { id: true, skills: { select: { id: true, slug: true } } },
    });
    const skillBySlug = new Map(unit.skills.map((s) => [s.slug, s.id]));

    // إن لم تُحدَّد المهارة، نربط السؤال بمهارة الدرس نفسها
    const fallbackSkillId = lessonSkillFallback.get(lesson.id) ?? null;

    const questionIds: string[] = [];
    const pointsById = new Map<string, number>();

    for (const q of entry.questions) {
      const options = q.options ?? [];

      // صح / خطأ: خياران ثابتان والإجابة الصحيحة تُحفظ كمعرّف (a أو b)
      const isTrueFalse = q.type === "TRUE_FALSE";
      const effectiveOptions = isTrueFalse
        ? ["صح", "خطأ"]
        : options;

      const storedOptions =
        effectiveOptions.length > 0
          ? effectiveOptions.map((text, idx) => ({
              id: String.fromCharCode(97 + idx),
              text,
            }))
          : undefined;

      let correct: unknown = q.correct;
      if (q.type === "MULTI_TRUE") {
        // المصفوفة تحتوي نصوص الخيارات، ونحوّلها إلى معرّفات (a, b, c…)
        const wanted = Array.isArray(q.correct) ? q.correct : [q.correct];
        correct = storedOptions
          ? storedOptions
              .filter((o) =>
                wanted.some((w) => String(w).trim() === o.text.trim()),
              )
              .map((o) => o.id)
          : wanted;
      } else if (q.type === "MCQ" || isTrueFalse) {
        const idx = effectiveOptions.findIndex((o) => o === q.correct);
        correct = idx >= 0 ? String.fromCharCode(97 + idx) : q.correct;
      }

      const skillId = q.skillSlug
        ? (skillBySlug.get(q.skillSlug) ?? null)
        : fallbackSkillId;

      // تفادي التكرار: نفس النص في نفس الدرس = نفس السؤال
      const existing = await prisma.question.findFirst({
        where: { lessonId: lesson.id, text: q.text },
      });

      let created = existing;
      if (created) {
        // نُكمل الربط ونوحّد شكل الخيارات والإجابة الصحيحة
        // التهيئة هي المرجع لمحتوى المنهج: نُزامن النوع والصعوبة والحل والخيارات
        const needFix =
          created.type !== q.type ||
          created.difficulty !== (q.difficulty ?? "MEDIUM") ||
          created.solution !== q.solution ||
          !created.skillId ||
          !created.termId ||
          !Array.isArray(created.options) ||
          created.options.length === 0;
        if (needFix) {
          created = await prisma.question.update({
            where: { id: created.id },
            data: {
              skillId: created.skillId ?? skillId,
              termId: created.termId ?? lesson.unit.termId,
              type: q.type,
              difficulty: q.difficulty ?? "MEDIUM",
              solution: q.solution,
              options: (storedOptions ?? created.options ?? undefined) as never,
              correct: correct as never,
            },
          });
        }
      } else {
        created = await prisma.question.create({
          data: {
            type: q.type,
            text: q.text,
            options: storedOptions as never,
            correct: correct as never,
            solution: q.solution,
            hint: q.hint ?? null,
            points: q.points ?? 1,
            difficulty: q.difficulty ?? "MEDIUM",
            lessonId: lesson.id,
            skillId,
            termId: lesson.unit.termId,
          },
        });
      }

      questionIds.push(created.id);
      pointsById.set(created.id, q.points ?? 1);
      questionsCount++;
    }

    const exam =
      (await prisma.exam.findFirst({
        where: { slug: entry.examSlug },
      })) ??
      (await prisma.exam.create({
        data: {
          slug: entry.examSlug,
          title: entry.examTitle,
          description: `${entry.questions.length} سؤال على منهج الصف 12 متقدم.`,
          instructions:
            "أجب عن جميع الأسئلة. الدرجة تُحتسب تلقائيًا بعد الإرسال.",
          status: "PUBLISHED",
          isFree: entry.type === "LESSON",
          type: entry.type,
          durationMinutes: entry.type === "MOCK" ? 45 : entry.type === "TERM" ? 60 : 15,
          attemptsAllowed: entry.type === "LESSON" ? 5 : 2,
          passingScore: 60,
          shuffleQuestions: entry.type !== "LESSON",
          showCorrectAnswers: true,
          showSolutions: true,
          courseId: course.id,
          termId: lesson.unit.termId,
          unitId: entry.type === "UNIT" ? lesson.unit.id : null,
          lessonId: entry.type === "LESSON" ? lesson.id : null,
        },
      }));

    await prisma.examQuestion.deleteMany({ where: { examId: exam.id } });
    await prisma.examQuestion.createMany({
      data: questionIds.map((questionId, idx) => ({
        examId: exam.id,
        questionId,
        points: pointsById.get(questionId) ?? 1,
        order: idx,
      })),
    });
    examsCount++;
  }
  console.log(`✔ ${questionsCount} سؤال · ${examsCount} اختبار`);

  /* ---------- 6ب) اختبارات الفصل والشاملة والمراجعة ---------- */
  let autoExamCount = 0;

  const allQuestions = await prisma.question.findMany({
    where: { skillId: { not: null } },
    select: { id: true, termId: true, skillId: true, points: true },
  });

  async function upsertExam(input: {
    slug: string;
    title: string;
    description: string;
    type:
      | "LESSON"
      | "UNIT"
      | "TERM"
      | "COMPREHENSIVE"
      | "REVIEW"
      | "MOCK";
    termId?: string | null;
    unitId?: string | null;
    questionIds: string[];
    pointsById: Map<string, number>;
    durationMinutes: number;
    attemptsAllowed: number;
    isFree: boolean;
  }) {
    if (input.questionIds.length === 0) return null;

    const exam =
      (await prisma.exam.findUnique({ where: { slug: input.slug } })) ??
      (await prisma.exam.create({
        data: {
          slug: input.slug,
          title: input.title,
          description: input.description,
          instructions:
            "أجب عن جميع الأسئلة. تُحتسب الدرجة تلقائيًا بعد الإرسال، وستظهر الحل النموذجية بعد الانتهاء.",
          status: "PUBLISHED",
          isFree: input.isFree,
          type: input.type,
          durationMinutes: input.durationMinutes,
          attemptsAllowed: input.attemptsAllowed,
          passingScore: 60,
          shuffleQuestions: input.type !== "LESSON",
          showCorrectAnswers: true,
          showSolutions: true,
          courseId: course.id,
          termId: input.termId ?? null,
          unitId: input.unitId ?? null,
          lessonId: null,
        },
      }));

    await prisma.examQuestion.deleteMany({ where: { examId: exam.id } });
    await prisma.examQuestion.createMany({
      data: input.questionIds.map((questionId, idx) => ({
        examId: exam.id,
        questionId,
        points: input.pointsById.get(questionId) ?? 1,
        order: idx,
      })),
    });
    autoExamCount++;
    return exam;
  }

  // اختبار لكل فصل دراسي
  for (const term of await prisma.term.findMany({
    where: { courseId: course.id },
    orderBy: { order: "asc" },
    select: { id: true, title: true, slug: true },
  })) {
    const ids = allQuestions
      .filter((q) => q.termId === term.id)
      .map((q) => q.id);
    await upsertExam({
      slug: `${term.slug}-exam`,
      title: `اختبار ${term.title}`,
      description: `اختبار شامل على جميع وحدات ${term.title}.`,
      type: "TERM",
      termId: term.id,
      questionIds: ids,
      pointsById: new Map(),
      durationMinutes: 60,
      attemptsAllowed: 2,
      isFree: false,
    });
  }

  // اختبار مراجعة لكل وحدة
  const unitsWithSkills = await prisma.unit.findMany({
    where: { courseId: course.id },
    orderBy: { order: "asc" },
    select: {
      id: true,
      title: true,
      slug: true,
      termId: true,
      skills: { select: { id: true } },
    },
  });

  for (const unit of unitsWithSkills) {
    const skillIds = unit.skills.map((s) => s.id);
    const ids = allQuestions
      .filter((q) => q.skillId && skillIds.includes(q.skillId))
      .map((q) => q.id);
    const shortTitle = unit.title.replace(/^الوحدة [^:]+:\s*/, "");
    await upsertExam({
      slug: `${unit.slug}-review`,
      title: `اختبار مراجعة: ${shortTitle}`,
      description: `مراجعة سريعة على ${shortTitle}.`,
      type: "REVIEW",
      termId: unit.termId,
      unitId: unit.id,
      questionIds: ids,
      pointsById: new Map(),
      durationMinutes: 20,
      attemptsAllowed: 3,
      isFree: false,
    });
  }

  // اختبار شامل على المنهج كاملًا
  await upsertExam({
    slug: "comprehensive-full",
    title: "اختبار شامل — كامل المنهج",
    description: "أسئلة من جميع وحدات المنهج للتأكد من إتقانك الكامل.",
    type: "COMPREHENSIVE",
    questionIds: allQuestions.map((q) => q.id),
    pointsById: new Map(),
    durationMinutes: 90,
    attemptsAllowed: 1,
    isFree: false,
  });

  // اختبار تجريبي شامل
  await upsertExam({
    slug: "mock-full",
    title: "اختبار تجريبي — محاكاة الامتحان",
    description: "اختبار تجريبي كامل بنفس نمط امتحان نهاية الفصل.",
    type: "MOCK",
    questionIds: allQuestions.map((q) => q.id),
    pointsById: new Map(),
    durationMinutes: 90,
    attemptsAllowed: 2,
    isFree: false,
  });

  console.log(`✔ ${autoExamCount} اختبار آلي (فصل/مراجعة/شامل/تجريبي)`);

  /* ---------- 6ج) لا يوجد محتوى تجريبي مجاني ---------- */
  // المنصة والمدفوع فقط: كل المحتوى مرتبط بباقة مدفوعة.
  await prisma.unit.updateMany({ data: { isFree: false } });
  await prisma.lesson.updateMany({ data: { isFree: false } });
  await prisma.fileAsset.updateMany({ data: { isFree: false } });
  await prisma.exam.updateMany({ data: { isFree: false } });
  await prisma.videoAsset.updateMany({ data: { isFree: false } });
  // إزالة الباقة المجانية التجريبية إن كانت موجودة
  await prisma.plan
    .deleteMany({ where: { tier: "FREE" } })
    .catch(() => undefined);
  console.log("✔ لا يوجد محتوى تجريبي — الوصول بباقة مدفوعة فقط");

  /* ---------- 7) الباقات ---------- */
  const plans = [
    {
      slug: "basic",
      nameAr: "الأساسية",
      nameEn: "Basic",
      tagline: "كل الدروس والملخصات وأوراق العمل",
      description:
        "الدروس كاملة بالفيديو، الملخصات، أوراق العمل، والواجبات لمنهج الصف 12 متقدم.",
      tier: "BASIC" as const,
      monthlyPrice: 49,
      yearlyPrice: 449,
      trialDays: 0,
      features: [
        "جميع دروس الفصلين الأول والثاني",
        "جميع الملخصات وأوراق العمل",
        "الواجبات مع تصحيح تلقائي",
        "اختبارات الدرس والوحدة",
        "تحميل على الهاتف والكمبيوتر",
      ],
      limits: {
        files: true,
        exams: true,
        questions: false,
        analysis: false,
        studyPlan: false,
        tutor: false,
        solutions: false,
      },
      isActive: true,
      isFeatured: false,
      sortOrder: 1,
    },
    {
      slug: "premium",
      nameAr: "المميزة",
      nameEn: "Premium",
      tagline: "منهج كامل + بنك الأسئلة + التحليل + المساعد",
      description:
        "كل ما في الأساسية، مع بنك الأسئلة والاختبارات الشاملة والتحليل الذكي وخطة الدراسة ومساعد الرياضيات.",
      tier: "PREMIUM" as const,
      monthlyPrice: 99,
      yearlyPrice: 899,
      trialDays: 0,
      features: [
        "كل مزايا الباقة الأساسية",
        "بنك أسئلة الصف 12 متقدم كامل",
        "اختبارات الفصل والشاملة والتجريبية",
        "الحلول النموذجية لكل سؤال",
        "التحليل الذكي لمستواك",
        "خطة دراسة مخصصة",
        "مساعد الرياضيات — شرح خطوة بخطوة",
      ],
      limits: {
        files: true,
        exams: true,
        questions: true,
        analysis: true,
        studyPlan: true,
        tutor: true,
        solutions: true,
      },
      isActive: true,
      isFeatured: true,
      sortOrder: 2,
    },
  ];

  for (const p of plans) {
    const { limits, ...rest } = p;
    await prisma.plan.upsert({
      where: { slug: p.slug },
      create: {
        ...rest,
        features: p.features as never,
        limits: limits as never,
      },
      update: {
        nameAr: p.nameAr,
        tagline: p.tagline,
        description: p.description,
        features: p.features as never,
        limits: limits as never,
      },
    });
    await prisma.planGrade.upsert({
      where: { planId_gradeId: { planId: (await getPlanId(p.slug)), gradeId: grade.id } },
      create: { planId: await getPlanId(p.slug), gradeId: grade.id },
      update: {},
    });
  }
  console.log(`✔ الباقات: ${plans.length}`);

  /* ---------- 8) الإعدادات ---------- */
  const settings: Record<string, unknown> = {
    siteName: "رياضيات 12 متقدم",
    tagline: "كل ما تحتاجه لإتقان رياضيات الصف 12 متقدم في مكان واحد",
    teacherName: "أستاذ الرياضيات",
    teacherTitle: "مدرس رياضيات — الصف الثاني عشر متقدم",
    teacherBio:
      "أستاذ رياضيات متخصص في الصف الثاني عشر المتقدم بالمنهج الإماراتي. أبدأ من الفكرة الأساسية وأشرحها بمثال محسوس، ثم أمثلة متدرجة، ثم اختبار قصير يثبّت الفهم. منهجي: شرح ← تدريب ← اختبار ← تحليل ← مراجعة ← إتقان.",
    contactEmail: "",
    contactPhone: "",
    whatsapp: "",
    address: "دولة الإمارات العربية المتحدة",
    logoText: "١٢",
    currency: "AED",
    vatIncluded: false,
    vatPercent: 5,
    footerNote: "جميع الدروس والملفات محمية بحقوق النشر ولا يجوز إعادة نشرها.",
  };

  // نضيف المفاتيح الناقصة فقط، ولا نكتب فوق تعديلات الأستاذ
  let settingsAdded = 0;
  for (const [key, value] of Object.entries(settings)) {
    const existing = await prisma.siteSetting.findUnique({ where: { key } });
    if (!existing) {
      await prisma.siteSetting.create({
        data: { key, value: value as never, group: "general" },
      });
      settingsAdded++;
    }
  }
  console.log(`✔ إعدادات المنصة (${settingsAdded} إعداد جديد)`);

  console.log(`
╔══════════════════════════════════════════════╗
║  ✅ رياضيات الصف 12 متقدم — جاهز            ║
╠══════════════════════════════════════════════╣
║  لوحة الإدارة: ${adminEmail}
║  كلمة المرور:  ${adminPassword}
╚══════════════════════════════════════════════╝
`);
}

async function getPlanId(slug: string): Promise<string> {
  const plan = await prisma.plan.findUniqueOrThrow({
    where: { slug },
    select: { id: true },
  });
  return plan.id;
}

main()
  .catch((e) => {
    console.error("✖ فشل التهيئة:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });