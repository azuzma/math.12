-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'OWNER';

-- AlterEnum
ALTER TYPE "VideoProvider" ADD VALUE 'LOCAL';
