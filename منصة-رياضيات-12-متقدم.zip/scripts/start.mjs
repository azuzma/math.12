/**
 * 🚀  مشغّل منصة رياضيات الصف 12 متقدم
 *
 * ملف واحد يعمل على macOS و Windows و Linux:
 *   1) يشغّل قاعدة بيانات PostgreSQL محلية (بلا تثبيت)
 *   2) ينشئ الجداول ويزرع المنهج (مرة واحدة)
 *   3) يشغّل الخادم ويفتح المتصفح
 *
 * الاستخدام:  node scripts/start.mjs
 */
import { spawn, spawnSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, appendFileSync, openSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createInterface } from "node:readline";
import { randomBytes } from "node:crypto";
import { execSync } from "node:child_process";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
process.chdir(ROOT);

const C = {
  b: "\x1b[1;34m",
  g: "\x1b[1;32m",
  y: "\x1b[1;33m",
  r: "\x1b[0m",
};
const say = (s) => console.log(`${C.b}▶${C.r} ${s}`);
const ok = (s) => console.log(`${C.g}✔${C.r} ${s}`);
const warn = (s) => console.log(`${C.y}!${C.r} ${s}`);
const die = (s) => {
  console.log(`${C.r}✘ ${s}${C.r}`);
  process.exit(1);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

console.log("");
console.log(`${C.b}  ╔══════════════════════════════════════════════╗${C.r}`);
console.log(`${C.b}  ║   منصة رياضيات الصف 12 متقدم              ║${C.r}`);
console.log(`${C.b}  ║   كل ما تحتاجه لإتقان رياضيات الصف 12     ║${C.r}`);
console.log(`${C.b}  ╚══════════════════════════════════════════════╝${C.r}`);
console.log("");

// ── 0) هل المشروع كامل؟ ────────────────────────────────────────────────
if (!existsSync(join(ROOT, "package.json")) || !existsSync(join(ROOT, "src"))) {
  console.log(`${C.r}✘ المشروع غير مكتمل في هذا المجلد.${C.r}`);
  console.log("");
  console.log("  فكّ الضغط عن الملف ZIP كاملًا (لا ترسل ملف تشغيل وحده)،");
  console.log("  ثم شغّل «ابدأ المنصة» من داخل المجلد.");
  console.log("");
  process.exit(1);
}

// ── 1) الحزم ─────────────────────────────────────────────────────────────
if (!existsSync(join(ROOT, "node_modules"))) {
  say("⋯ تثبيت الحزم (مرة واحدة، قد يستغرق دقيقة)…");
  const inst = spawnSync("npm", ["install"], { stdio: "inherit", shell: true });
  if (inst.status !== 0) die("فشل تثبيت الحزم — تأكد من الإنترنت");
}
ok("الحزم جاهزة");

// ── 2) متغيرات البيئة ───────────────────────────────────────────────────
function readEnv() {
  const out = {};
  if (!existsSync(join(ROOT, ".env"))) return out;
  for (const line of readFileSync(join(ROOT, ".env"), "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
  return out;
}

const envFile = readEnv();
let DATABASE_URL = envFile.DATABASE_URL ?? "";
let AUTH_SECRET = envFile.AUTH_SECRET ?? "";

// ── 3) قاعدة البيانات ───────────────────────────────────────────────────
// خارجية (Neon مثلًا)؟ نستخدمها. غير ذلك: قاعدة محلية تلقائية.
const isLocal = !DATABASE_URL || /localhost|127\.0\.0\.1/.test(DATABASE_URL);

if (!isLocal) {
  ok("استخدام قاعدة البيانات الخارجية من .env");
} else {
  say("⋯ تشغيل قاعدة بيانات PostgreSQL محلية…");
  const logFile = join(ROOT, ".start-db.log");
  const out = openSync(logFile, "w");
  const child = spawn("npx", ["prisma", "dev", "-n", "math12"], {
    stdio: ["ignore", out, out],
    detached: true,
    shell: true,
  });
  child.unref();

  for (let i = 0; i < 90; i++) {
    await sleep(1000);
    const log = readFileSync(logFile, "utf8");
    const m = log.match(/DATABASE_URL="([^"]+)"/);
    if (m) {
      DATABASE_URL = m[1];
      break;
    }
  }
  if (!DATABASE_URL) {
    console.log(readFileSync(logFile, "utf8").split("\n").slice(-8).join("\n"));
    console.log("");
    console.log("  ✘ تعذّر تشغيل قاعدة البيانات المحلية");
    console.log("");
    console.log("    على ويندوز: تأكد أن Node.js مثبّت (https://nodejs.org)");
    console.log("    ثم افتح cmd داخل المجلد وشغّل:  npx prisma dev -n math12");
    console.log("");
    process.exit(1);
  }
  ok("قاعدة البيانات تعمل");
}

// ── 4) حفظ الإعدادات ────────────────────────────────────────────────────
if (!AUTH_SECRET) {
  AUTH_SECRET = randomBytes(48).toString("base64");
}
function saveEnv() {
  let s = existsSync(join(ROOT, ".env")) ? readFileSync(join(ROOT, ".env"), "utf8") : "";
  const set = (key, val) => {
    const line = `${key}="${val}"`;
    s = new RegExp(`^${key}=.*$`, "m").test(s)
      ? s.replace(new RegExp(`^${key}=.*$`, "m"), line)
      : s + (s && !s.endsWith("\n") ? "\n" : "") + line + "\n";
  };
  set("DATABASE_URL", DATABASE_URL);
  set("AUTH_SECRET", AUTH_SECRET);
  writeFileSync(join(ROOT, ".env"), s);
}
saveEnv();
process.env.DATABASE_URL = DATABASE_URL;
process.env.AUTH_SECRET = AUTH_SECRET;
ok("مفتاح الجلسات جاهز");

// ── 5) الجداول ──────────────────────────────────────────────────────────
const run = (cmd, args) =>
  spawnSync(cmd, args, { stdio: "pipe", shell: true, env: process.env });
const sqlCount = (table) => {
  const r = run("node", [
    "-e",
    `const{Pool}=require('pg');const p=new Pool({connectionString:process.env.DATABASE_URL});` +
      `p.query("select count(*)::int n from information_schema.tables where table_schema='public'")` +
      `.then(x=>{console.log(x.rows[0].n);return p.end()}).catch(()=>console.log(0));`,
  ]);
  return Number(String(r.stdout || "0").trim()) || 0;
};

say("⋯ تجهيز جداول قاعدة البيانات…");
run("npx", ["prisma", "generate"]);
const hasTables = sqlCount("tables") > 0;
if (!hasTables) {
  const r = run("npx", ["prisma", "db", "push"]);
  if (r.status !== 0) die("فشل إنشاء الجداول");
} else {
  let r = run("npx", ["prisma", "migrate", "deploy"]);
  if (r.status !== 0) {
    // القاعدة فيها مخطط بلا سجل مخططات → نسجّلها كمنطبقة
    for (const m of readFileSync(join(ROOT, "prisma", "migrations"), "utf8") ? [] : []) void m;
    const dir = join(ROOT, "prisma", "migrations");
    for (const m of (await import("node:fs")).readdirSync(dir)) {
      if (m === "migration_lock.toml") continue;
      run("npx", ["prisma", "migrate", "resolve", "--applied", m]);
    }
    r = run("npx", ["prisma", "migrate", "deploy"]);
    if (r.status !== 0) {
      const r2 = run("npx", ["prisma", "db", "push"]);
      if (r2.status !== 0) die("فشل تجهيز الجداول");
    }
  }
}
ok("الجداول جاهزة");

// ── 6) المنهج ───────────────────────────────────────────────────────────
const lessonCount = Number(
  String(
    run("node", [
      "-e",
      `const{Pool}=require('pg');const p=new Pool({connectionString:process.env.DATABASE_URL});` +
        `p.query("select count(*)::int n from lessons where status='PUBLISHED'")` +
        `.then(x=>{console.log(x.rows[0].n);return p.end()}).catch(()=>console.log(0));`,
    ]).stdout || "0"
  ).trim()
) || 0;

if (lessonCount < 5) {
  say("⋯ بذر المنهج والدروس والاختبارات (مرة واحدة)…");
  const s = run("npx", ["tsx", "prisma/seed.ts"]);
  if (s.status !== 0) warn("اكتمل البذر مع تحذيرات — راجع السجل");
  ok("المنهج جاهز");
} else {
  ok(`المنهج موجود مسبقًا (${lessonCount} درسًا)`);
}

// ── 7) الخادم ───────────────────────────────────────────────────────────
let PORT = 3000;
while (portBusy(PORT)) {
  PORT++;
  if (PORT > 3010) PORT = 3000;
}
process.env.PORT = String(PORT);

say("⋯ تشغيل الخادم…");
const dev = spawn("npm", ["run", "dev"], {
  stdio: "inherit",
  shell: true,
  env: process.env,
});

const URL = `http://localhost:${PORT}`;
for (let i = 0; i < 90; i++) {
  await sleep(1000);
  if (dev.exitCode !== null) break;
  try {
    const res = await fetch(URL, { signal: AbortSignal.timeout(3000) });
    if (res.status > 0) break;
  } catch {
    /* لم يجهز بعد */
  }
}

console.log("");
console.log(`${C.g}  ╔══════════════════════════════════════════════╗${C.r}`);
console.log(`${C.g}  ║            ✔ المنصة تعمل الآن                ║${C.r}`);
console.log(`${C.g}  ╚══════════════════════════════════════════════╝${C.r}`);
console.log("");
console.log(`  ${C.b}افتح في المتصفح:${C.r}  ${C.b}${URL}${C.r}`);
console.log("");
console.log(`  ${C.b}لوحة الأستاذ:${C.r}  ${C.b}${URL}/rlt309/signin${C.r}`);
console.log(`  ${C.b}حساب المعلم:${C.r}   teacher@platform.com  /  Teacher@12345`);
console.log(`  ${C.b}حساب المدير:${C.r}   admin@platform.com   /  Admin@12345`);
console.log("");
console.log(`  ${C.y}لإيقاف الخادم: اضغط Ctrl + C${C.r}`);
console.log("");

// فتح المتصفح
try {
  if (process.platform === "darwin") spawn("open", [URL], { detached: true, stdio: "ignore" }).unref();
  else if (process.platform === "win32")
    spawn("cmd", ["/c", "start", "", URL], { detached: true, stdio: "ignore" }).unref();
  else spawn("xdg-open", [URL], { detached: true, stdio: "ignore" }).unref();
} catch {
  /* تجاهل */
}

// إيقاف الخادم عند الخروج
const stop = () => {
  try {
    if (dev.pid) process.kill(-dev.pid, "SIGTERM");
  } catch {
    /* تجاهل */
  }
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
dev.on("exit", (code) => process.exit(code ?? 0));

/** هل المنفذ مشغول؟ (يعمل على macOS و Linux و Windows) */
function portBusy(port) {
  try {
    if (process.platform === "win32") {
      const out = execSync(`netstat -ano | findstr :${port}`, {
        encoding: "utf8",
        stdio: ["ignore", "pipe", "ignore"],
      });
      return out.trim().length > 0;
    }
    const out = execSync(`lsof -i :${port} 2>/dev/null || true`, {
      encoding: "utf8",
    });
    return out.trim().length > 0;
  } catch {
    return false;
  }
}
