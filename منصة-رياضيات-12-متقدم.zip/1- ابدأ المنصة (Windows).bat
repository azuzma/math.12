@echo off
REM ============================================================
REM  Math 12 Advanced Platform - Windows launcher
REM  (ASCII only, so cmd.exe never breaks on encoding)
REM ============================================================
setlocal
chcp 65001 > nul
cd /d "%~dp0"
title Math 12 Advanced Platform

echo.
echo   ============================================
echo     Math 12 Advanced Platform - local start
echo   ============================================
echo.

where node >nul 2>nul
if errorlevel 1 goto :nonode

node scripts\start.mjs
if errorlevel 1 (
  echo.
  echo   [X] The platform could not start. See the messages above.
  pause
)
goto :eof

:nonode
echo   [X] Node.js is not installed on this computer.
echo.
echo       1) Download the LTS version from:  https://nodejs.org
echo       2) Install it (keep the default options)
echo       3) Run this file again
echo.
start "" "https://nodejs.org"
pause
goto :eof
