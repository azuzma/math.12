#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
#  🚀  اضغط هنا — منصة رياضيات الصف 12 متقدم تعمل فورًا
# ═══════════════════════════════════════════════════════════════════════════
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  ✘ Node.js غير مثبت على هذا الجهاز."
  echo ""
  echo "    حمّله من:  https://nodejs.org  (اختر النسخة LTS)"
  echo "    ثم أعد تشغيل هذا الملف."
  echo ""
  open "https://nodejs.org" 2>/dev/null || xdg-open "https://nodejs.org" 2>/dev/null
  read -r -p "  اضغط Enter بعد التثبيت…"
fi

exec node scripts/start.mjs
