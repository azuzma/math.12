#!/bin/bash
# منصة رياضيات الصف 12 متقدم — تشغيل (Linux)
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "  ✘ Node.js غير مثبت. حمّله من: https://nodejs.org"
  exit 1
fi
exec node scripts/start.mjs
